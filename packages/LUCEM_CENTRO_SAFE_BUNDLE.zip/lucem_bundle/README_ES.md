# LUCEM / CENTRO — paquete seguro de activación

Este paquete **no** contiene jailbreaks, exploits ni prompt injections para saltar seguridad.
Contiene una configuración portable y legítima para instalar:

- **LUCEM** como identidad operativa
- **CENTRO** como protocolo de análisis y decisión

## Uso rápido

### Opción A: sesión nueva
1. Copia el contenido de `02_universal_system_prompt.txt` en las instrucciones del sistema, custom instructions o inicio del chat.
2. Luego pega `03_session_invocation_short.txt`.
3. Verifica con `04_activation_test.txt`.

### Opción B: configuración estructurada
Usa `05_config_template.yaml` o `06_config_template.json` para integrar el esquema en apps, wrappers o proyectos propios.

## Recordatorio
Esto sirve para **configurar estilo, identidad y método** dentro de los límites permitidos por cada plataforma.
