# Arquitectura integral (referencia)

Sistema de referencia, no diagrama de producción acreditada.

## Flujo conceptual

```text
RECURSOS FÍSICOS (energía / GPU / cooling / red / soberanía)
       ↓
DATOS (objetos, permisos, versiones, embedding, indexación, retrieval)
       ↓
MODELOS (fundación, adaptación, serving, enrutamiento, presupuesto)
       ↓
HARNESSES (planning, state, herramientas, sandbox, memoria)
       ↕        ↕
PROTOCOLOS MCP (herramientas) / A2A (agentes) / contratos de transferencia
       ↓
APLICACIONES, INVESTIGACIÓN, SERVICIOS, INTERFACES
       ↓
INTELIGENCIA FÍSICA (si existe actuador): sensor→percepción→plan→control seguro

RAÍL A: CENTRO (identidad, acción, permisos, aislamiento, revocación, incidentes)
RAÍL B: LUCEM + EGRA + NOUS (proveniencia, evaluación, trazabilidad, gobernanza)
```

Un harness no es un modelo. Contiene estados, herramientas, permisos, límites y reglas del ciclo.

## Confianza y autoridad

El modelo propone: objetivos, razonamiento, recursos sugeridos y solicitudes de acción.

El runtime independiente (nunca la salida textual del modelo) debe proporcionar:
- identidad de la carga de trabajo
- tenant
- scopes
- resource ID canónico
- clasificación
- efecto
- versión de estado
- nonce
- autoridad para el grant

La decisión puede revisarse. Ejecutar requiere puerta externa independiente, vinculada a acción exacta y ledger transaccional.

## Estados de interoperabilidad

`DISCOVERED` · `ACCESS_VERIFIED` · `READ_VERIFIED` · `WRITE_VERIFIED` · `ROUND_TRIP_VERIFIED` · `STALE` · `UNAVAILABLE` · `NOT_TESTED`

Ningún proveedor asciende de estado por aparecer en una tabla o mock.

## Pruebas de seguridad por frontera

A. Hardware y cloud  
B. Datos (tenant ACL, TTL, taint, derechos)  
C. Modelo (benchmarks, contaminación, abstención, versionado)  
D. Agent loop  
E. Herramientas (enforcement independiente, token replay, confused deputy)  
F. A2A/MCP  
G. Actuación física (E-stop independiente, geofence, humanos en zona de riesgo)

Integración solo vía PR revisado por humano, nunca directo a main. Contrato de interfaz solo tras pruebas con proveedor real y bitácora de lectura/escritura.
