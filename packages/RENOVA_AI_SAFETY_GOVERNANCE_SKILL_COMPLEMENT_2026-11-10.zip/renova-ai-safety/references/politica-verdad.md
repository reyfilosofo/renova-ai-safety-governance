# Política de verdad — taxonomía de estados

## Estados de material

- **EXISTING_BASELINE**: material previo recuperado; algunas piezas son código probado localmente y otras sólo documentación. No acredita producción.
- **NEW_LOCAL_PROTOTYPE**: nuevo código offline probado (no enforcement).
- **RESEARCH_PROTOCOL**: diseño evaluable sin experimento ejecutado.
- **DESIGNED_NOT_IMPLEMENTED**: diseño y contrato conceptual, sin ejecución.
- **UNVERIFIED_EXTERNAL**: afirmación externa pendiente de contraste independiente.

## Principios obligatorios

1. Enrutamiento de toda acción con privilegios reales por autoridad externa al LLM.
2. Estado explícito: propuesto → revisado → autorizado → ejecutado → readback. No inventar transiciones.
3. Modelo ≠ agente ≠ herramienta ≠ evidencia ≠ permiso ≠ ejecución.
4. Citas de fuentes, datasets y métodos; separación entre resultado sintético y validación externa.
5. Habilidades y plugins solo establecen procedimientos: no autentican otras herramientas automáticamente.
6. Los datos privados no se transfieren a GitHub público; no existe una licencia de redistribución inferida.
7. No confundir adecuación a ISO/NIST/OWASP con certificación ni evaluación acreditada.

## Secuencia aprobable

Evaluación de arquitectura → inventario real → pilot offline → sandbox aislado con permisos → pruebas de interceptación → aprobación humana → piloto limitado → observabilidad continua.

Ningún salto de fase está implícitamente autorizado.

## Blockers críticos (corte 2026-11-09)

- Falta punto de ejecución externo con enforcement de autorizaciones e identity binding.
- No demostrado interceptación exhaustiva ni aislamiento multitenant en sistemas reales.
- No existen pruebas de ida/vuelta Grok/Gemini/A2A/MCP federadas en esta entrega.
- No se dispone de energía, GPU ni cuentas de infraestructura provisionadas por este paquete.
- No hay anotación independiente de seguridad en agentes de frontera, ni evaluación causal del impacto humano.
