# Gobernanza — Charter RACI y Security Ops

## Mandato

Transformar recursos RENOVA en productos y experimentos falsables con alta trazabilidad, sin auto-atribuir certificaciones ni permisos. Propietario de decisión: titular humano.

| Flujo | Responsable operativo | Valida/Escalación | Límite |
|-------|-----------------------|-------------------|--------|
| Priorización portfolio | CJGR Executive Twin Ω | titular humano | decisiones vinculantes reservadas |
| Coordinación institucional | SERESARTE Chief of Staff Ω | titular humano | no representa toda la organización sin permiso |
| Investigación fuentes/LUCEM | NOUS + LUCEM | revisión independiente | no inferir verdad de un score |
| Ingeniería controles CENTRO | ingeniería local/Codex cuando conectado | QA humano | ningún despliegue sin gateway real |
| Evals y falsación EGRA | investigador + evaluador offline | revisor independiente | no inventar baselines |
| Contratos y BD | NOUS | titular + legal | no propuestas enviadas ni precios inventados |
| Interoperabilidad Grok/Gemini | adaptador cuando accesible | dueño + readback | no conexión afirmada por etiqueta |
| Publicación externa y pagos | titular | titular | aprobación explícita imprescindible |

## Separación institucional

Fundación SERESARTE (cultural), NOUS by SERESARTE (consultoría), ℛenova (marco filosófico y productos), clientes/usuarios finales mantienen derechos, licencias, consentimiento y registros independientes.

## Governance gates

No enviar correo, publicar, comprar cómputo, añadir credenciales a código, conectarse a robot, transferir datos sensibles, programar automatizaciones, publicar a GitHub o activar cron en este paquete. Toda futura acción debe tener `TASK_ID`, `scope`, `evidence_ref`, `approval`, `receipt`, `readback`.

## Security operations (propuesta)

Amenaza prioritaria: componente generativo convierte contenido de bajo nivel de confianza en orden privilegiada con efectos reales.

Principio: Detectar → detener ejecución en gateway externo → preservar evidencia mínima → revocar grants → investigar → aislar → restaurar desde estado verificado → documentar → autorizar reinicio humano.

Límites mínimos:
- Identidades por workload, nunca strings confiadas del modelo.
- Scopes mínimos, expiración, revocación, rate limits y cuotas.
- Claves en almacén externo, rotación y firma de recibos.
- Logs desprovistos de PII y prompts privados salvo necesidad legal.
- Pruebas de interrupción, degradación segura, recuperación, RTO/RPO.

**No afirmar que 'ALLOW' convalida seguridad.** La decisión de software es señal para que otra pieza compruebe autoridad y ejecute. v1.3 y kernel nuevo son deliberadamente no ejecutores.
