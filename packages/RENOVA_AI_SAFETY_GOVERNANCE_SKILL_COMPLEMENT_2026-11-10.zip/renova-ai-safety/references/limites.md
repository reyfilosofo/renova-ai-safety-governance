# Límites materiales, físicos, económicos y epistemológicos

## Cómputo y energía

Requisitos por despliegue (métricas por medir, no cifras aportadas por el stack): potencia de placa/GPU, electricidad atribuible, PUE, huella de transmisión, refrigeración, fuente energética, redundancia, cuotas, depreciación, financiación, protección ante cortes, residencia de datos.

## Datos y conocimiento

Ningún embedding prueba que la fuente sea verdadera. RAG presupone recuperación y generación. Política de confianza exige: fuente primaria, fecha, licencia, acceso, granularidad, TTL, verificación independiente, auditoría de rechazo y citación. GraphRAG no elimina inyección indirecta.

## Calidad y coste de inferencia

Throughput, TTFT, tokens/s, latencia p50/p95, tasa de errores, GPU-segundos, coste por caso correcto, consumo estimado de energía e incidencias. Comparar motores requiere misma tarea, presupuesto de contexto, calidad de respuesta y carga de concurrencia. No inventar costo absoluto fuera de contrato.

## Robótica

Probar en simulación no valida seguridad de hardware. Para actuar se requiere definición de daño físico, límites de ingeniería, E-stop verificable sin dependencia del LLM, controles de acceso humano y prueba independiente. **No conectar este prototipo directamente a motores, drones o vehículos.**

## Gobernanza y economía política

Soberanía no se reduce a fabricar chips: incluye licencias, localización, derecho, red, model weights, datasets, idiomas, personal especializado y posibilidad de salida. Riesgo de concentración se mide mediante dependencia y costes de migración, no slogans.

## Restricciones del paquete (2026-11-09)

Este paquete no provisiona cómputo, no accede a proveedores de modelos, no monta servidores MCP/A2A reales, no crea un robot, no firma una certificación, no confirma cumplimiento legal y no sincroniza agentes. No envía comunicaciones, no factura, no compra, no programa tareas, no cambia permisos y no despliega en producción.
