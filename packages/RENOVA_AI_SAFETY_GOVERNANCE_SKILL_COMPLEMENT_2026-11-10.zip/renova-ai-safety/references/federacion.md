# Federación — instrucciones de handoff (no ejecución)

Este complemento no ejecuta llamadas a otros modelos. Solo redacta prompts y contextos para que el titular los use en sesiones firmadas.

## Fuentes de federación incluidas en el stack

- Claude: `02_PROMPTS_PLATAFORMAS/CLAUDE_PROJECT_INSTRUCTIONS.md` y `CLAUDE_FIRST_MESSAGE.md`
- DeepSeek: `DEEPSEEK_START.md`
- Qwen: `QWEN.md` y `QWEN_CHAT_START.md`
- Perplexity: `PERPLEXITY_PROJECT_INSTRUCTIONS.md` y `PERPLEXITY_FIRST_MESSAGE.md`
- Contexto maestro: `01_NUCLEO/MASTER_CONTEXT_ES.md` y `MASTER_PROMPT_UNIVERSAL_ES.md`

## Reglas de handoff

1. Incluir siempre la política de verdad y los límites del stack.
2. Exigir citas y declaración de estado (EXISTING_BASELINE etc.).
3. Prohibir claims de certificación o cumplimiento.
4. Marcar el output como draft para revisión humana.
5. No transferir secretos, claves ni datos privados.
6. Round-trip solo se declara tras evidencia independiente de lectura/escritura.

Handoffs del directorio `10_HANDOFFS/` del stack (centro, codex, egra, grok_review, human_owner, lucem, nous, seresarte_cos) son **no enviados**.
