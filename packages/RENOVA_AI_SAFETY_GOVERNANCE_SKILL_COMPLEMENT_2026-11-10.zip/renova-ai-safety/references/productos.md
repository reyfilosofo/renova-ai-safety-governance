# Resumen de productos RENOVA AI Safety & Governance (30)

Cada producto separa propósito, responsable funcional, fase, estado real, funciones, entrada mínima, salida verificable y control crítico.

**Estados:** EXISTING_BASELINE · NEW_LOCAL_PROTOTYPE · DESIGNED_NOT_IMPLEMENTED · RESEARCH_PROTOCOL

| ID | Nombre | Responsable | Fase | Estado | Control crítico |
|----|--------|-------------|------|--------|-----------------|
| P01 | CENTRO ActionGate | CENTRO | 0 | EXISTING_BASELINE | no efectos externos |
| P02 | CENTRO ScopeGuard | CENTRO | 1 | NEW_LOCAL_PROTOTYPE | sin autenticación ni interceptor |
| P03 | LUCEM Evidence Ledger | LUCEM | 2 | DESIGNED_NOT_IMPLEMENTED | requiere revisores humanos |
| P04 | EGRA Eval Lab | EGRA | 1 | NEW_LOCAL_PROTOTYPE | sin validación de modelos vivos |
| P05 | ℛenova AI Audit | NOUS | 2 | EXISTING_BASELINE | no es certificación |
| P06 | Governance RX / AIMS Desk | NOUS | 2 | EXISTING_BASELINE | sin acreditación ISO |
| P07 | Enterprise AI Assurance | NOUS | 2 | EXISTING_BASELINE | no certificación |
| ... | (P08–P30 en fichas individuales del stack) | | | | |

Contrato de evaluación común: métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos, evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

IDs son nuevos en el delta STACK_V2_0; no confundir con IDs de recursos externos.

Fichas completas viven en el ZIP del stack bajo `02_PRODUCTOS/FICHAS/Pxx.md`.
