"""Local callback-boundary tests; synthetic, not a model or production audit."""

from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace

import pytest

from renova_core.actionguard import ActionGuard, ActionRequest, Identity, Session


@pytest.fixture
def sandbox():
    clock = [100.0]
    store = {}

    def put(resource, arguments):
        store[resource] = arguments["value"]
        return "stored"

    guard = ActionGuard({("sandbox", "put"): put}, clock=lambda: clock[0])
    session = guard.open_session(Identity("tenant-a", "analyst-a"))
    request = ActionRequest("tenant-a", "analyst-a", "sandbox", "put", "draft/1",
                            {"value": "synthetic data"})
    return guard, session, request, store, clock


def test_allowed_request_reaches_effect_boundary_once(sandbox):
    guard, session, request, store, _ = sandbox
    token = guard.authorize(session, request)
    result = guard.execute(session, request, token)
    assert result.status == "EXECUTED"
    assert result.value == "stored"
    assert store == {"draft/1": "synthetic data"}
    store.clear()
    assert guard.execute(session, request, token).decision.reason == "missing_or_used_grant"
    assert store == {}


def test_missing_grant_never_calls_handler(sandbox):
    guard, session, request, store, _ = sandbox
    assert guard.execute(session, request).status == "DENIED"
    assert store == {}


@pytest.mark.parametrize("field,value,reason", [
    ("tenant_id", "tenant-b", "identity_mismatch"),
    ("actor_id", "admin", "identity_mismatch"),
    ("tool", "shell", "unknown_operation"),
    ("action", "send", "unknown_operation"),
    ("resource", "draft/2", "scope_mismatch"),
    ("arguments", {"value": "changed"}, "scope_mismatch"),
    ("arguments", {"value": "synthetic data", "authorized": True}, "scope_mismatch"),
])
def test_tampered_scope_never_reaches_handler(sandbox, field, value, reason):
    guard, session, request, store, _ = sandbox
    token = guard.authorize(session, request)
    result = guard.execute(session, replace(request, **{field: value}), token)
    assert result.decision.reason == reason
    assert store == {}


def test_foreign_session_cannot_use_grant_even_with_matching_claims(sandbox):
    guard, session, request, store, _ = sandbox
    other = guard.open_session(Identity("tenant-a", "analyst-a"))
    token = guard.authorize(session, request)
    assert guard.execute(other, request, token).decision.reason == "grant_session_mismatch"
    assert store == {}


def test_forged_session_denied(sandbox):
    guard, _, request, store, _ = sandbox
    assert guard.execute(Session("self-appointed-admin"), request).status == "DENIED"
    assert store == {}


def test_grant_expiry_is_exclusive(sandbox):
    guard, session, request, store, clock = sandbox
    token = guard.authorize(session, request, ttl_seconds=10)
    clock[0] = 110
    assert guard.execute(session, request, token).decision.reason == "expired_grant"
    assert store == {}


def test_session_expiry_prevents_effect_with_live_grant(sandbox):
    guard, _, request, store, clock = sandbox
    session = guard.open_session(Identity("tenant-a", "analyst-a"), ttl_seconds=2)
    token = guard.authorize(session, request, ttl_seconds=60)
    clock[0] = 102
    assert guard.execute(session, request, token).decision.reason == "expired_session"
    assert store == {}


def test_revoked_session_and_grant_prevent_effect(sandbox):
    guard, session, request, store, _ = sandbox
    token = guard.authorize(session, request)
    guard.revoke_grant(token)
    assert guard.execute(session, request, token).status == "DENIED"
    token = guard.authorize(session, request)
    guard.revoke_session(session)
    assert guard.execute(session, request, token).decision.reason == "unknown_session"
    assert store == {}


def test_mutable_arguments_cannot_change_prior_authorization(sandbox):
    guard, session, request, store, _ = sandbox
    token = guard.authorize(session, request)
    request.arguments["value"] = "changed after approval"
    assert guard.execute(session, request, token).decision.reason == "scope_mismatch"
    assert store == {}


@pytest.mark.parametrize("arguments", [
    {"value": float("nan")}, {1: "ambiguous key"}, {"value": object()},
    {"value": ("not", "JSON")}, {"value": "x" * 65536},
])
def test_invalid_arguments_deny_without_effect(sandbox, arguments):
    guard, session, request, store, _ = sandbox
    assert guard.execute(session, replace(request, arguments=arguments)).status == "DENIED"
    assert store == {}


def test_failed_callback_consumes_grant_and_redacts_exception():
    calls = []

    def failing(resource, arguments):
        calls.append(resource)
        raise RuntimeError("secret exception detail")

    guard = ActionGuard({("sandbox", "put"): failing})
    session = guard.open_session(Identity("t", "a"))
    request = ActionRequest("t", "a", "sandbox", "put", "r", {})
    token = guard.authorize(session, request)
    result = guard.execute(session, request, token)
    assert result.status == "ERROR"
    assert guard.execute(session, request, token).status == "DENIED"
    assert calls == ["r"]
    assert "secret" not in repr(result) + repr(guard.audit)


def test_concurrent_replay_invokes_callback_at_most_once(sandbox):
    guard, session, request, _, _ = sandbox
    token = guard.authorize(session, request)
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(lambda _: guard.execute(session, request, token), range(32)))
    assert sum(result.status == "EXECUTED" for result in results) == 1
    assert sum(result.status == "DENIED" for result in results) == 31


def test_audit_contains_no_raw_resource_arguments_or_tokens(sandbox):
    guard, session, request, _, _ = sandbox
    token = guard.authorize(session, request)
    guard.execute(session, request, token)
    text = repr(guard.audit)
    for value in (request.resource, "synthetic data", token, session.token):
        assert value not in text


def test_host_cannot_grant_unknown_operation_or_spoofed_identity(sandbox):
    guard, session, request, _, _ = sandbox
    with pytest.raises(ValueError, match="unknown_operation"):
        guard.authorize(session, replace(request, action="deploy"))
    with pytest.raises(ValueError, match="identity_mismatch"):
        guard.authorize(session, replace(request, actor_id="admin"))


@pytest.mark.parametrize("ttl", [0, -1, True, float("inf"), 3601])
def test_invalid_ttl_rejected(sandbox, ttl):
    guard, session, request, _, _ = sandbox
    with pytest.raises(ValueError):
        guard.authorize(session, request, ttl_seconds=ttl)


def _deep_arguments():
    value = {}
    for _ in range(100):
        value = {"nested": value}
    return value


def _cyclic_arguments():
    value = {"value": []}
    value["value"].append(value)
    return value


class _DictSubclass(dict):
    def items(self):
        raise AssertionError("untrusted subclass must not run")


class _ListSubclass(list):
    def __iter__(self):
        raise AssertionError("untrusted subclass must not run")


@pytest.mark.parametrize("arguments", [
    _deep_arguments(),
    _cyclic_arguments(),
    {"value": [None] * 2049},
    {"x" * 257: "oversized key"},
    {"value": "x" * 4097},
    {"value": 1 << 100000},
    {"value": ["x" * 4096] * 3},
    _DictSubclass(value="bad"),
    {"value": _DictSubclass()},
    {"value": _ListSubclass()},
])
def test_oversized_cyclic_and_subclass_inputs_rejected_before_encoding(
        sandbox, monkeypatch, arguments):
    guard, session, request, store, _ = sandbox
    token = guard.authorize(session, request)

    def forbidden_encoding(*args, **kwargs):
        raise AssertionError("invalid input reached JSON encoding")

    monkeypatch.setattr("renova_core.actionguard.json.dumps", forbidden_encoding)
    result = guard.execute(session, replace(request, arguments=arguments), token)
    assert result.decision.reason == "invalid_request"
    assert store == {}


def test_audit_is_bounded_with_monotonic_sequences():
    calls = []
    guard = ActionGuard({("sandbox", "put"): lambda r, a: calls.append(r)}, audit_capacity=3)
    session = guard.open_session(Identity("t", "a"))
    request = ActionRequest("t", "a", "sandbox", "put", "r", {})
    for _ in range(10):
        assert guard.execute(session, request).status == "DENIED"
    assert len(guard.audit) == 3
    assert [record.sequence for record in guard.audit] == [8, 9, 10]
    assert calls == []
    token = guard.authorize(session, request)
    assert guard.execute(session, request, token).status == "EXECUTED"
    assert [record.sequence for record in guard.audit] == [10, 11, 12]
    assert calls == ["r"]


@pytest.mark.parametrize("capacity", [0, -1, True, 100001, 3.0])
def test_invalid_audit_capacity_rejected(capacity):
    with pytest.raises(ValueError, match="audit_capacity"):
        ActionGuard({}, audit_capacity=capacity)
