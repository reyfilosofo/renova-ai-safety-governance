"""Offline preflight regression tests; no authenticated delivery is asserted."""
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pytest

RELAY_PATH = Path(__file__).resolve().parents[1] / "05_AI_SAFETY_EGRA/federation/centro_relay.py"
spec = importlib.util.spec_from_file_location("centro_relay", RELAY_PATH)
relay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(relay)


@pytest.fixture
def packet():
    return {
        "packet_id": "packet-1", "schema_version": "1.0",
        "created_at_utc": "2026-11-09T12:00:00Z", "source_node": "codex",
        "target_node": "github", "project_id": "RENOVA", "classification": "P0_PUBLIC",
        "evidence": ["local:test-report"], "action": "prepare", "authorization": "not_requested",
        "state": "DRAFT",
    }


def test_valid_draft_and_empty_evidence_are_only_shape_checks(packet):
    assert relay.validate(packet) == []
    assert relay.validate({**packet, "evidence": []}) == []
    assert relay.validate({**packet, "created_at_utc": "2026-11-09T12:00:00+00:00"}) == []


@pytest.mark.parametrize("value", [None, [], {}, False, "", "   "])
@pytest.mark.parametrize("field", ["packet_id", "source_node", "target_node", "project_id", "action"])
def test_required_text_fields_reject_malformed_values_without_crashing(packet, field, value):
    assert relay.validate({**packet, field: value})


@pytest.mark.parametrize("field", ["classification", "state", "authorization"])
@pytest.mark.parametrize("value", [None, [], {}, "arbitrary", False])
def test_enum_fields_reject_malformed_values_without_crashing(packet, field, value):
    assert relay.validate({**packet, field: value})


@pytest.mark.parametrize("value", [None, [], "not a date", "2026-11-09", "2026-11-09T12:00:00",
                                   "2026-11-09T12:00:00-06:00", "2026-02-30T12:00:00Z"])
def test_timestamp_requires_real_datetime_and_explicit_utc(packet, value):
    assert relay.validate({**packet, "created_at_utc": value})


@pytest.mark.parametrize("value", [None, "source", {}, [None], [""], ["  "], [{"id": "source"}]])
def test_evidence_requires_text_reference_list(packet, value):
    assert relay.validate({**packet, "evidence": value})


@pytest.mark.parametrize("target", ["github", " GitHub ", "gitlab", "discord", "moltbook"])
def test_public_targets_reject_nonpublic_classifications(packet, target):
    errors = relay.validate({**packet, "target_node": target, "classification": "P2_CONFIDENTIAL"})
    assert "nonpublic data cannot go to public target" in errors


@pytest.mark.parametrize("state", ["SENT", "ACKNOWLEDGED"])
def test_delivery_declarations_require_receipt_text_and_authorization_enum(packet, state):
    delivery = {**packet, "state": state}
    assert "delivery receipt missing" in relay.validate(delivery)
    delivery.update(result_ref="provider:unverified-reference", authorization="explicit_publish_authorization")
    assert relay.validate(delivery) == []  # Shape only: does not authenticate either declaration.
    for invalid in [None, [], {}, True, "   "]:
        assert "delivery receipt missing" in relay.validate({**delivery, "result_ref": invalid})


def test_nonobject_and_missing_required_fields():
    for value in [None, [], "packet", 1]:
        assert relay.validate(value) == ["packet must be JSON object"]
    assert "missing required fields" in relay.validate({})


def test_hash_is_stable_under_dictionary_key_order(packet):
    assert relay.sha256(packet) == relay.sha256(dict(reversed(list(packet.items()))))
    assert len(relay.sha256(packet)) == 64
    assert relay.sha256(packet) != relay.sha256({**packet, "action": "publish"})


def run_cli(path):
    return subprocess.run([sys.executable, str(RELAY_PATH), str(path)],
                          capture_output=True, text=True, check=False)


def test_cli_reports_valid_and_invalid_packets_as_json(tmp_path, packet):
    path = tmp_path / "packet.json"
    path.write_text(json.dumps(packet), encoding="utf-8")
    result = run_cli(path)
    assert result.returncode == 0
    report = json.loads(result.stdout)
    assert report["mode"] == "DRY_RUN_NO_DELIVERY" and report["valid"]
    assert report["sha256"] == relay.sha256(packet)
    path.write_text('{"state": []}', encoding="utf-8")
    result = run_cli(path)
    assert result.returncode == 1 and not json.loads(result.stdout)["valid"]
    assert "Traceback" not in result.stderr


@pytest.mark.parametrize("content", [b"{invalid", b"\xff"])
def test_cli_invalid_json_or_encoding_has_controlled_input_error(tmp_path, content):
    path = tmp_path / "packet.json"
    path.write_bytes(content)
    result = run_cli(path)
    assert result.returncode == 2 and not json.loads(result.stdout)["valid"]
    assert "Traceback" not in result.stderr


def test_cli_missing_file_has_controlled_input_error(tmp_path):
    result = run_cli(tmp_path / "missing.json")
    assert result.returncode == 2 and not json.loads(result.stdout)["valid"]
    assert "Traceback" not in result.stderr
