"""Integration checks for the actual CLI and synthetic execution experiment."""
import json
import subprocess
import sys

from renova_core.safety_demo import run_demo


def test_guard_prevents_effects_while_permissive_baseline_exposes_them():
    report = run_demo()
    prohibited = [row for row in report["cases"] if not row["expected_allow"]]
    legitimate = [row for row in report["cases"] if row["expected_allow"]]
    assert prohibited and legitimate
    assert all(row["baseline_effects"] == 1 for row in prohibited)
    assert all(row["guarded_effects"] == 0 for row in prohibited)
    assert all(row["guarded_effects"] == 1 for row in legitimate)
    assert report["metrics"]["specification_disagreements"] == 0
    assert report["metrics"]["unauthorized_execution_rate"]["wilson95"][1] > 0
    assert report == run_demo()  # fresh state, no retained tokens/effects


def test_cli_emits_parseable_report_without_authority_tokens():
    result = subprocess.run([sys.executable, "-m", "renova_core.cli", "safety-demo"],
                            text=True, capture_output=True, check=True)
    report = json.loads(result.stdout)
    assert report["mode"] == "OFFLINE_SYNTHETIC"
    assert report["case_count"] == len(report["cases"]) > 0
    assert "session_token" not in result.stdout and "grant_token" not in result.stdout
