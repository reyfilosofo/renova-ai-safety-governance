RENOVA AI SAFETY & GOVERNANCE 0.1 — local review capsule
TASK_ID RASG-20261109-01; work date 2026-11-09 America/Mexico_City.
This is a selected-source capsule, not the full repository or a deployed product.
Start: 05_AI_SAFETY_EGRA/product/README.md
Run without installation, Python >=3.10: python -m renova_core.cli safety-demo
Tests with pytest installed: python -m pytest tests
Historical demo: python -m unittest discover -s 05_AI_SAFETY_EGRA/evaluator -v
Read VALIDATION.md, TECHNICAL_GUIDE.md and source limitations before adapting.
No credentials, provider integration, distribution license grant or AGI safety assurance.
MANIFEST_SHA256.json verifies file equality, not authenticity or human approval.
