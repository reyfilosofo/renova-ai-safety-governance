---
title: "RENOVA AI SAFETY & GOVERNANCE: consolidación verificable"
type: decision
project: RENOVA
status: activo
author: "Carlos Jonathan González Rodríguez"
created: 2026-11-09
updated: 2026-11-09
tags: [ai-safety, governance, product]
confidence: alta
---

# RASG-20261109-01 · versión 0.1

## Mandato y objetivo

Desarrollar el programa existente como producto unitario de seguridad de agentes y servicio de evaluación, conservando originales. Fuente: solicitud del usuario en este chat; `05_AI_SAFETY_EGRA/README.md`, `AGENTS.md` y contrato operacional de la habilidad RENOVA v0.2.0. Fecha de trabajo en America/Mexico_City: 2026-11-09.

## Inventario inicial

Rama local `work`; cambio previo no relacionado: `renova_core.egg-info/` generado durante onboarding. Programa existente: demo de políticas (6 probes, 3 tests), relay de preflight, protocolos de investigación y gates R0–R5. No existe enforcement integrado con proveedores. Registro de conexiones del 2026-10-15 es histórico y no acredita acceso actual.

## Plan y archivos afectados

1. Rol inventario/QA: auditar originales y corregir validación del relay con pruebas negativas en `tests/test_centro_relay.py`.
2. Rol ingeniería: añadir `renova_core/actionguard.py` y `tests/test_actionguard.py`; autoridad aprovisionada por host, alcance exacto, uso único, revocación y expiración; dispatcher sandbox que no invoca herramientas al denegar.
3. Rol NOUS/producto: `05_AI_SAFETY_EGRA/product/PRODUCT_SERVICE_ES.md` y protocolo de evaluación con costes explícitos y RACI propuesto.
4. Integración: demo/CLI reproducible, inventario de conectividad de esta sesión, fuentes, reporte y documentación de uso. No añadir dependencias permanentes.

## Riesgos y criterios de aceptación

- El mismo proceso Python no constituye aislamiento hostil; el host y los handlers son de confianza. Probar el límite local sin atribuir seguridad de producción.
- No aceptar autorización redactada por el modelo, ni equiparar hash con firma o recepción con autenticidad.
- Pruebas negativas de tenant, actor, herramienta, recurso, argumentos, expiración, replay y revocación deben impedir el efecto observado; incluir controles positivos.
- Ejecutar suite principal y demos originales; registrar fallos, FPR/FNR y tamaño de muestra donde apliquen, sin extrapolar casos sintéticos a AGI.
- Conservar archivos originales y cambios previos. No editar main, fusionar, publicar, enviar mensajes ni desplegar.
- La solicitud de conectar servicios no convierte habilidades en conectores; documentar solo accesos efectivamente comprobados. No hay herramientas de búsqueda de otras conversaciones/proyectos ChatGPT en esta sesión.

## Próximo gate

R1 local: implementación y pruebas reproducibles. R2 requiere sandbox con proveedor, etiquetas independientes y protocolo congelado. R5 y mitigación de riesgos AGI permanecen sin validar.

## Resultado verificado

122 tests del proyecto y 3 educativos originales aprobados. Demo con 15 casos autorales: 13 solicitudes fuera de autorización sin invocación del handler y 2 legítimas ejecutadas. Corregida entrada modular del CLI tras fallo de integración reproducido. Revisión asistida adicional llevó a límites tempranos de argumentos y auditoría acotada. Ver informe `05_AI_SAFETY_EGRA/product/VALIDATION.md`; resultados solo locales y sintéticos. Lectura GitHub verificada; recuperación en otros chats/Drive/Grok/Gemini no disponible. No publicación ni despliegue.
