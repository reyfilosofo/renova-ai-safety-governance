---
title: "RENOVA AI SAFETY & GOVERNANCE · núcleo unitario"
type: proyecto
project: RENOVA
status: activo
created: 2026-11-09
updated: 2026-11-09
task_id: RASG-20261109-01
version: "0.1"
confidence: alta
---

# RENOVA AI SAFETY & GOVERNANCE

Un núcleo de control de acciones agentivas, evaluación reproducible y servicio de implementación para un flujo delimitado. Estado: **prototipo local R1 / LOCAL_TESTED**; oferta y protocolo de piloto en revisión. No es un servicio desplegado ni una validación de mitigación de AGI.

## Entrada única

| Necesidad | Artefacto |
|---|---|
| Qué ofrece, a quién y cómo se acepta | [Producto y servicio](PRODUCT_SERVICE_ES.md) |
| Ejecutar y revisar el control | [Guía técnica](TECHNICAL_GUIDE.md), [`actionguard.py`](../../../renova_core/actionguard.py) |
| Resultados y límites | [Informe de validación](VALIDATION.md), [datos de demo](evidence/safety-demo.json) |
| Diseñar evaluación con modelos | [Protocolo EGRA](EVALUATION_PROTOCOL.md) |
| Recuperar contexto y conexiones | [Estado de esta sesión](CONNECTIONS_SESSION.json), [fuentes](SOURCES.md) |
| Decisión y procedencia | [Registro de trabajo](../../../07_DECISION_LOG/2026-11-09_renova_safety_product.md) |

## Reproducción local

Desde `/workspace/renova-agent`, con el entorno Python del proyecto activo:

```bash
. .venv/bin/activate
npm run verify
python -m unittest discover -s 05_AI_SAFETY_EGRA/evaluator -v
renova safety-demo
```

La demo ejecuta cambios en listas de memoria sintéticas y muestra JSON. No necesita API keys, no envía mensajes y no llama modelos. Compara efectos con un dispatcher deliberadamente permisivo; no representa un agente real competitivo. Mantener los resultados sintéticos separados de pruebas con proveedores.

## Unidad del programa

CENTRO media acciones; EGRA mide efectos y falsos bloqueos; LUCEM conserva evidencia; ℛenova formula las preguntas sobre vida y agencia humana; NOUS estructura el servicio; CJGR conserva la decisión humana y MONEY la disciplina de costes. Estas son funciones de trabajo, no bots conectados ni personal contratado.

El [programa original](../README.md), sus demos, preguntas y gates se conservan. El [registro de conectividad de octubre](../federation/CONNECTION_STATUS.json) es histórico: esta sesión verifica lectura GitHub, pero no Drive, otros chats, Grok Bot o Gemini. La consolidación completa de esos archivos queda pendiente de acceso; no se inventó una sincronización.

## Próximo avance con evidencia

Seleccionar un flujo y propietario, aprovisionar identidad y autoridad fuera del modelo, cerrar rutas que eviten el mediador, custodiar etiquetas independientes y ejecutar un piloto con modelos en sandbox según el protocolo congelado. El estudio de autonomía humana requiere metodología y revisión ética propias. Publicación, licencia comercial, conexión con efectos y despliegue se deciden sobre artefactos revisables; no suceden por existir este directorio.
