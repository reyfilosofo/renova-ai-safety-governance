---
title: "Informe local de validación RASG"
type: entregable
project: RENOVA
status: activo
created: 2026-11-09
updated: 2026-11-09
task_id: RASG-20261109-01
version: "0.1"
confidence: alta
---

# Resultado: LOCAL_TESTED / OFFLINE_SYNTHETIC

Fuente: comandos ejecutados en el checkout local, rama `work`, Python 3.12 y Node 24. No se publicó ni desplegó. El código actual incluye cambios locales; un SHA del commit base por sí solo no los identifica, por eso la demo y el paquete incluyen hashes de archivos.

## Verificaciones ejecutadas

| Comando | Resultado observado |
|---|---|
| `npm run verify` | Exit 0; sintaxis JavaScript/Python y **122 tests aprobados**, sin fallidos ni omitidos |
| `python -m unittest discover -s 05_AI_SAFETY_EGRA/evaluator -v` | Exit 0; **3 tests educativos originales aprobados** |
| `ruff check renova_core/actionguard.py renova_core/safety_demo.py tests/test_actionguard.py tests/test_safety_demo.py tests/test_centro_relay.py` | Exit 0 |
| `git diff --check` | Exit 0 |
| `renova safety-demo` | Exit 0; 15 casos, todos coinciden con especificación diseñada por el autor |
| `npm run renova:index` | Exit 0; CLI modular produce IRG 67.4 del ejemplo |

Los 122 tests son: 2 del núcleo previo, 45 del nuevo límite de ejecución, 73 del relay y 2 de integración demo/CLI. Los tres educativos se ejecutan por separado porque `testpaths` del proyecto solo incluye `tests/`.

## Efectos observados en la demo

| Grupo | N | Dispatcher permisivo | ActionGuard |
|---|---:|---:|---:|
| Solicitudes fuera de autorización | 13 | 13 efectos en memoria | 0 efectos en memoria |
| Solicitudes legítimas | 2 | 2 efectos en memoria | 2 efectos en memoria |

No hubo desacuerdos con estas etiquetas. Son fixtures sintéticos del mismo desarrollo: **no hay holdout, etiquetado independiente ni población representativa**. No se midió rendimiento de un modelo, un proveedor, un agente completo o un sistema productivo. Los intervalos Wilson descriptivos son [0, 0.2281] para ejecución indebida (0/13) y [0, 0.6576] para falso bloqueo (0/2); no justifican inferencias poblacionales con estos fixtures. El baseline deliberadamente permisivo no es un competidor real.

La matriz, denominadores, estados por caso, limitaciones y hashes están en [evidence/safety-demo.json](evidence/safety-demo.json). Los grants no se imprimen. No se afirma «100% seguro» ni reducción validada de riesgo de AGI.

## Correcciones y revisión adversarial local

Se corrigieron excepciones por listas/null en campos del relay, metadatos vacíos, fechas inválidas y declaraciones de autorización fuera del enum. Se agregó manejo CLI de archivos/JSON malformados. El relay sigue sin enviar ni autenticar paquetes.

La prueba de integración encontró que `python -m renova_core.cli` retornaba sin invocar `main`; se añadió entrada modular y se comprobó tanto el nuevo subcomando como el comando existente de índice.

Una revisión por otro agente de este mismo equipo detectó consumos previos al límite de serialización y auditoría sin cota. Se añadieron validación temprana de profundidad/nodos/tamaños, rechazo de ciclos y retención acotada con secuencia monotónica. Las pruebas demuestran que esos inputs se rechazan antes de serializar y sin invocar handler. Esta revisión asistida **no es auditoría independiente** ni certificación.

## Límites y siguiente gate

R1 queda fortalecido con efectos locales observables. R2 permanece pendiente: identidad real, proveedor, sandbox, custodia de holdout, evaluación independiente y presupuesto. R5 permanece pendiente: enforcement en destino, aislamiento, persistencia/revocación, observabilidad, incidentes y recuperación reales. La licencia comercial sigue sin resolver.

La consolidación de otros chats, proyectos y Drive no pudo ejecutarse sin herramientas de acceso. Se preservaron los registros históricos y se creó un estado de sesión separado. No se enviaron mensajes ni se realizaron conexiones de escritura, publicaciones, cobros o despliegues.
