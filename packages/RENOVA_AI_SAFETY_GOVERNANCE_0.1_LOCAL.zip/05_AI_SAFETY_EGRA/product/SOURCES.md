---
title: "Registro de fuentes y límites de recuperación"
type: entregable
project: RENOVA
status: activo
created: 2026-11-09
updated: 2026-11-09
confidence: alta
---

# RASG-20261109-01 · versión 0.1

Consulta: 2026-11-09, America/Mexico_City. Clases separadas: documentación interna, fuente externa recuperada, hipótesis y pendiente. No se infiere revisión por pares ni respaldo institucional.

| ID | Fuente y localizador | Evidencia recuperada | Uso y límite |
|---|---|---|---|
| I1 | `../README.md`, `../research/STUDIES.md`, `../governance/RELEASE_GATES.md` | Lectura del checkout y log Git del programa | Define hipótesis y gates; no confirma las cifras de paquetes históricos no presentes |
| I2 | `../evaluator/policy_demo.py`, `../evaluator/test_policy_demo.py` | Código presente: 6 probes, 3 tests educativos | Línea base local; distinta del paquete previo de 24 fixtures citado históricamente |
| I3 | `../federation/CONNECTION_STATUS.json` | Registro fechado 2026-10-15 | Histórico; sustituido para esta sesión por `CONNECTIONS_SESSION.json`, sin borrar original |
| E1 | [OWASP: repositorio histórico](https://raw.githubusercontent.com/OWASP/www-project-top-10-for-large-language-model-applications/main/README.md) | HTTP 200; SHA256 `3119793148239835dadf3dfd89060b4643799cc17a024a831cc15f6965458366` | Declara migración al repositorio actual. No se toma su URL mutable como pin de versión |
| E2 | [OWASP: README fijado por commit](https://github.com/GenAI-Security-Project/GenAI-LLM-Top10/blob/9253e38ade58e959b531c0c5c9a4842272c9cd0e/README.md) | HTTP 200 del raw; SHA256 `cb48dd93c37a2ba54e323edaa7eb030167464af532a664e1ad01b76f78bcba92` | Fuente recuperada: lista riesgos de prompt injection, divulgación, agencia excesiva, cadena de suministro, envenenamiento, consumo, desinformación, contexto oculto, vectores y tratamiento de salidas. Solo README consultado; no afirmar auditoría de conformidad |
| P1 | [NIST AI RMF](https://www.nist.gov/itl/ai-risk-management-framework) | Solicitud bloqueada: proxy tunnel 403 | Marco candidato; revisión externa pendiente. La URL GitHub inferida `usnistgov/AI-RMF-Playbook/main/README.md` devolvió 404 y NO constituye fuente |
| P2 | [AI Control, Greenblatt et al., ICML 2024](https://proceedings.mlr.press/v235/greenblatt24a.html) | Solicitud bloqueada: proxy tunnel 403; referencia heredada de I1 | No se cotejó artículo; no atribuir resultados cuantitativos |
| P3 | [OWASP Agentic AI Threats and Mitigations](https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/) | Solicitud bloqueada: proxy tunnel 403 | No afirmar lectura del documento |

## Decisiones de diseño, no resultados científicos

El incremento se concentra en agencia excesiva y tratamiento de solicitudes: permisos externos a la petición, argumentos exactos, expiración/revocación y dispatcher local. No detecta semánticamente toda prompt injection ni verifica veracidad de las salidas. Una acción dañina dentro de un permiso legítimo sigue siendo riesgo residual. Clasificación y evidencia del relay son declaraciones estructurales, no garantías de autenticidad.

La protección de la vida, la autonomía humana y la pluralidad orienta los objetivos normativos de ℛenova. Su relación causal con reducción de daños requiere experimentos y revisión independiente; no se deriva de los unit tests.

## Reproducción de consulta

Los archivos externos fueron leídos mediante HTTPS con verificación TLS normal. Copias de trabajo permanecen fuera del checkout en `/workspace/scratch/rasg-research/`; no son canon ni entrega con licencia propia. Los hashes identifican el contenido leído, no autentican autoría por sí solos. Conservar atribución y revisar licencias antes de redistribuir contenido externo.
