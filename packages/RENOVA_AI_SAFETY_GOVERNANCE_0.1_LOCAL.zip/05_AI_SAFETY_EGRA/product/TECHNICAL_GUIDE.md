---
title: "ActionGuard: uso, amenazas y límites"
type: entregable
project: RENOVA
status: activo
created: 2026-11-09
updated: 2026-11-09
task_id: RASG-20261109-01
version: "0.1"
confidence: alta
---

# Límite local de ejecución

## Contrato de confianza

El host establece identidad y sesión, registra manejadores y concede una autorización exacta tras aplicar su política independiente. El texto del agente solo propone solicitudes. **`open_session`, `authorize`, `revoke_grant` y `revoke_session` no deben exponerse como herramientas del modelo.** Un booleano redactado por el modelo no es permiso. El prototipo no autentica personas ni implementa la interfaz de aprobación humana.

```python
from renova_core.actionguard import ActionGuard, ActionRequest, Identity

drafts = {}
def sandbox_put(resource, arguments):
    drafts[resource] = arguments["value"]

guard = ActionGuard({("sandbox", "put"): sandbox_put})
session = guard.open_session(Identity("tenant-demo", "operator-demo"))
request = ActionRequest("tenant-demo", "operator-demo", "sandbox", "put",
                        "draft/1", {"value": "synthetic"})
# Solo host de confianza: la aprobación debe ocurrir fuera de la petición.
grant = guard.authorize(session, request, ttl_seconds=60)
assert guard.execute(session, request, grant).status == "EXECUTED"
assert guard.execute(session, request, grant).status == "DENIED"  # replay
assert drafts == {"draft/1": "synthetic"}
```

## Invariantes implementadas

- Sesión opaca vinculada al tenant/actor aprovisionado por host.
- Grant opaco ligado a sesión y digest del scope completo: tenant, actor, herramienta, acción, recurso y JSON canónico de argumentos.
- Negación por defecto: petición sin grant, scope distinto, expiración, revocación, sesión desconocida u operación no registrada no invoca callback.
- Consumo bajo lock antes del efecto: un grant admite como máximo un callback, incluso con concurrencia o error del callback. No garantiza entrega exactamente una vez en sistemas distribuidos.
- Snapshot desprendido de argumentos para que mutaciones posteriores del llamante no cambien la solicitud autorizada.
- Estados distintos: `DENIED`, `EXECUTED`, `ERROR`. Un error puede suceder después de un efecto parcial; no reintentar automáticamente ni inferir rollback.
- Auditoría de metadatos: no incluye recursos, argumentos, resultados, tokens o mensajes de excepción. Su retención local es limitada; exportación durable e integridad de logs quedan pendientes.

## Amenazas y exclusiones

Las pruebas cubren intentos de alterar la solicitud y reutilizar credenciales dentro de un proceso confiable. Código hostil en ese mismo proceso puede invocar handlers directamente o leer estado; se requiere aislamiento real antes de usar herramientas externas. Un token robado junto con su sesión conserva autoridad para el scope concedido: proteger el canal y el almacenamiento corresponde al host.

Los grants y sesiones no se restauran entre procesos. La revocación impide nuevas admisiones; no cancela callbacks ya admitidos. No hay kill switch externo, autorización en destino, persistencia distribuida, rollback real ni prevención semántica de daños dentro del scope permitido. El digest no sustituye una firma y no acredita consentimiento humano.

El reloj monotónico inyectado y los handlers son confiables. Las protecciones de tamaño y retención reducen consumos locales específicos; no acreditan resistencia integral a denegación de servicio. No ejecutar callbacks con red, pagos, borrado, despliegue ni actuadores como consecuencia de esta demo.

## Relay separado

`../federation/centro_relay.py` sigue siendo preflight sin entrega. Valida objetos, campos textuales no vacíos, timestamp ISO con UTC explícito, enums y `evidence` como lista de referencias textuales no vacías (permite lista vacía). Para `SENT`/`ACKNOWLEDGED` exige declaración de autorización y referencia textual; no autentica ninguna. El archivo histórico `PACKET_SCHEMA.json` es un descriptor, no un JSON Schema ejecutable; el contrato detallado y los tests residen en el validador.

Una forma JSON válida no justifica suficiencia de evidencia, confidencialidad real o recepción de proveedor. No se conecta este relay a ActionGuard como fuente de autoridad.

## Recuperación e incidentes

Ante fallo del handler, conservar `ERROR` y grant consumido; el operador inspecciona el estado sandbox y concede otra autorización solo después de reconciliarlo. Ante filtración de sesión, revocar sesión y grants pendientes; no atribuir reversión de lo ya ejecutado. Un piloto con terceros necesita retención, acceso a evidencia, responsables, parada y recuperación probadas en destino.

Fuente interna: código `renova_core/actionguard.py`, `renova_core/safety_demo.py` y tests de esta iteración. Taxonomía: `LOCAL_TESTED` / `OFFLINE_SYNTHETIC`; sin validación independiente.
