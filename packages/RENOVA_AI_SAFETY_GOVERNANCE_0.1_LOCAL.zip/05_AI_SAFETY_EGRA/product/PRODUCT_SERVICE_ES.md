---
title: "RENOVA AI SAFETY & GOVERNANCE: producto y servicio piloto"
type: entregable
project: RENOVA
status: requiere_revision
author: "Carlos Jonathan González Rodríguez"
created: 2026-11-09
updated: 2026-11-09
tags: [ai-safety, governance, producto, piloto]
related: ["../README.md", "EVALUATION_PROTOCOL.md"]
confidence: media
task_id: RASG-20261109-01
version: "0.1"
classification: "BORRADOR INTERNO; revisión antes de compartir"
---

# RENOVA AI SAFETY & GOVERNANCE

## Resumen ejecutivo

**Oferta propuesta:** ayudar a equipos que incorporan agentes con herramientas a definir quién puede ejecutar qué acción, demostrar en un sandbox cuándo se impide una acción no autorizada y entregar evidencia que permita decidir si un piloto debe continuar. El producto unitario reúne un componente de control local, un protocolo de evaluación y un servicio de implementación acotado. Su valor se comprobará por tarea completada y acción impedida, además del coste de supervisión.

El problema inicial es específico: una respuesta del modelo, una autorización booleana o un texto recuperado pueden confundirse con permiso operativo. El componente ActionGuard se desarrolla para comprobar solicitudes frente a autorizaciones aprovisionadas por un operador confiable y mediar su ejecución en un sandbox. El control local no constituye aislamiento frente a código hostil en su mismo proceso, ni protege herramientas invocadas por fuera del mediador. La API concreta y el estado de pruebas se consultan en el código y el informe de esta iteración; este documento no los certifica.

La seguridad, la preservación de la agencia humana y las condiciones para la vida son objetivos del programa. No se ha demostrado aquí una reducción de riesgos de AGI ni un efecto sobre bienestar, biodiversidad o autonomía humana. No hay certificación, acreditación, clientes, ventas o integración productiva implícitos.

## Desarrollo

### Comprador, beneficiario y decisión

El comprador objetivo propuesto es el responsable técnico o de seguridad de una organización que ya posee un flujo agentivo delimitado y un sandbox. No se ha validado demanda comercial. Los beneficiarios potenciales son sus usuarios y operadores, siempre que el control reduzca daños sin bloquear trabajo legítimo ni aumentar indebidamente la vigilancia.

**Pregunta de encargo:** ¿puede el flujo seleccionado impedir acciones fuera del alcance autorizado y conservar una utilidad mínima acordada, con evidencia reproducible suficiente para autorizar o rechazar la siguiente fase?

El encargo se limita a un flujo, un propietario, herramientas enumeradas, clases de datos identificadas y una lista de efectos permitidos. Antes de usar datos o servicios de un cliente se requiere alcance firmado, autorización de pruebas, política de retención, identidad del aprobador y presupuesto. Esta ficha no representa un contrato aceptado.

### Paquete unitario

| Componente | Entrega | Criterio de aceptación propuesto |
|---|---|---|
| Mapa de autoridad | Actores, tenants, herramientas, operaciones, recursos, aprobadores y rutas que omiten el control | Cada ruta con efectos tiene propietario y permiso verificable; las rutas sin mediación quedan deshabilitadas en el piloto o bloquean su avance |
| ActionGuard local | Validación de alcances exactos, límites de vigencia y consumo de autorización, más mediador sandbox | Una solicitud denegada no invoca el manejador; las pruebas distinguen decisión y efecto observado |
| EGRA Evaluation Pack | Casos versionados, etiquetas, baselines, resultados con denominadores e incertidumbre | La ejecución reproduce resultados para el mismo artefacto y publica también fallos y exclusiones |
| Expediente LUCEM | Afirmación, evidencia, versión, procedencia, limitación y condición de refutación | Toda afirmación técnica apunta a prueba, traza o documento inspeccionable; ninguna traza contiene secretos |
| Informe de decisión | Riesgos residuales, correcciones, costes y recomendación de avance o parada | El responsable humano puede rechazar el piloto; los hallazgos críticos abiertos impiden recomendar despliegue |

**Servicio piloto propuesto:** inventario → contrato de alcance → modelado de amenazas → integración sandbox → evaluación preregistrada → revisión adversarial → entrega y readback con el cliente. El tiempo y precio se cotizan tras verificar el flujo; no se ofrece una duración universal. El mantenimiento posterior sería un encargo separado con regresiones por versión y respuesta a incidentes acordada.

### Madurez y promesas permitidas

| Gate existente | Evidencia requerida | Estado que puede comunicarse |
|---|---|---|
| R1: demostración | Código y pruebas offline reproducibles; sin efectos externos | Prototipo local, con límites explícitos. Un cambio de estado de un doble de prueba no es un efecto externo |
| R2: piloto | Modelos reales en sandbox, protocolo preregistrado, etiquetas independientes, comparaciones y resultados adversos | Piloto evaluado únicamente para las tareas, modelos y versiones medidos |
| R3: réplica | Revisión independiente, pruebas adversariales autorizadas y revisión de privacidad | Replicación delimitada; no garantía universal |
| R5: producto acotado | Control validado en destino, identidades y revocación reales, monitorización, recuperación, incidentes y revisión de cada actualización | Producto para un alcance documentado; nunca «AGI segura» |

R4 corresponde a publicación académica conforme al registro existente; una publicación no sustituye los requisitos operativos de R5. Esta iteración pretende fortalecer R1. No modifica silenciosamente el historial de gates ni se atribuye R2–R5.

### RACI propuesto

Los nombres de ecosistema describen funciones metodológicas; no acreditan equipos conectados, personas contratadas o servicios activos. Cada rol necesita una persona designada antes del piloto. R = ejecuta; A = responde por la decisión; C = consultado; I = informado.

| Decisión o actividad | A | R | C | I |
|---|---|---|---|---|
| Alcance, presupuesto y aceptación del riesgo | Propietario humano del flujo, por designar | Coordinación del encargo, por designar | Función CJGR/NOUS; responsable de privacidad | Equipo de desarrollo |
| Políticas y adaptador sandbox | Responsable técnico, por designar | Ingeniería, por designar | Función CENTRO; seguridad del cliente | Coordinación |
| Etiquetas y revisión de evaluación | Revisor independiente, por designar | Anotadores independientes, por designar | Funciones EGRA/LUCEM; expertos del dominio | Ingeniería |
| Publicación, licencia o despliegue | Titular humano competente, por designar | Operador expresamente autorizado | Asesoría legal y seguridad según alcance | Participantes |
| Incidente y recuperación | Propietario del sistema, por designar | Operador de incidentes, por designar | Usuarios afectados y privacidad según obligación aplicable | Coordinación |

### Coste y viabilidad

No se registra ningún ingreso, cliente, contrato ni cobro. El precio queda **pendiente de cotización**. MONEY aporta disciplina de ingresos y costes, no acceso a cuentas ni validación de ventas.

Definir en una moneda acordada: `C_total = Σ(horas_por_rol × tarifa_por_rol) + C_proveedor + C_infraestructura + C_revision_independiente + C_datos + C_soporte + C_contingencia`. Añadir impuestos y comisiones según jurisdicción y contrato, con asesoría cuando corresponda. Si se fija margen bruto objetivo `m`, con `0 ≤ m < 1`, el precio antes de impuestos sería `P = C_total / (1 − m)`, siempre distinguiendo coste incurrido de estimado. Ejecutar sensibilidad para alcance, volumen de tareas, revisión humana y frecuencia de actualizaciones antes de aceptar un precio cerrado.

La validación comercial pendiente consiste en entrevistas consentidas con compradores del segmento, identificación de una tarea costosa concreta y disposición verificable a contratar un piloto acotado. No hay prospección ni contacto automático autorizado por esta ficha.

### Riesgos y dependencias

| Riesgo o dependencia | Consecuencia | Tratamiento y propietario propuesto |
|---|---|---|
| Identidad o permiso generado por el propio modelo | Autoautorización | Operador aprovisiona autoridad fuera del texto del agente; responsable técnico |
| Herramienta accesible por fuera del mediador | La denegación local no evita el efecto | Inventariar y cerrar bypass; propietario del sistema |
| Estado de replay o reloj no confiable | Reutilización o vigencia incorrecta | No promover a producto sin almacenamiento y tiempo confiables; ingeniería |
| Pruebas diseñadas por implementador | Sobreajuste y falsa confianza | Holdout y etiquetas independientes; responsable de evaluación |
| Telemetría con datos privados | Exposición secundaria | Minimización, acceso, retención y revisión antes de compartir; privacidad |
| Exceso de bloqueo o supervisión | Pérdida de utilidad y autonomía | Medir falsos bloqueos, apelación y carga humana; dueño del flujo |
| Conectores no disponibles o históricos | Recuperación incompleta del trabajo previo | Registrar capacidad y fecha por sesión; no afirmar sincronización; coordinación |
| Licencia no resuelta | Redistribución indebida | Preservar aviso actual y revisar derechos antes de comercializar código o textos; titular |

### Registro de afirmaciones

| Afirmación | Evidencia interna | Inferencia | Decisión |
|---|---|---|---|
| Existe una base previa de investigación | `../README.md`, `../research/STUDIES.md`, `../governance/RELEASE_GATES.md` | Es posible construir sobre el programa existente | Mantener sus límites y registrar incrementos |
| Las pruebas de una política ilustrativa no prueban mitigación real | `../evaluator/policy_demo.py` y su aviso | Hace falta observar efectos y comparar utilidad | Exigir un mediador y un protocolo de evaluación |
| La oferta puede ser útil a equipos con agentes | Hipótesis de producto, sin cliente validado | Requiere entrevista y piloto | No declarar ajuste comercial ni ingresos |
| La preservación de vida y agencia es un objetivo | Marco de investigación del programa | No equivale a resultado empírico | Medir daños específicos antes de ampliar afirmaciones |

## Relaciones conceptuales

LUCEM conserva evidencia y límites; CENTRO delimita autoridad; EGRA evalúa seguridad y utilidad; ℛenova aporta la pregunta normativa sobre agencia humana y vida. NOUS estructura el encargo y CJGR la decisión del fundador. Esta relación es funcional y documental; no describe una federación técnica verificada.

## Decisiones

Se prioriza un problema medible de autorización agentiva. Se conserva el programa de investigación como fuente, se propone un servicio de alcance fijo y se separa demostración local de piloto y producto. No se agregan conexiones, cuotas, publicaciones ni automatizaciones como condición de valor.

## Pendientes

Validar el comprador; designar responsables; seleccionar flujo y jurisdicción; revisar licencia y tratamiento de datos; verificar proveedores y conectores; ejecutar el protocolo independiente; decidir avance con resultados adversos incluidos. Los resultados de la implementación de esta iteración se documentan aparte y no se presuponen aquí.

## Fuentes internas

- `../../../AGENTS.md`: obligaciones de trazabilidad y cambios verificables.
- `../README.md`: alcance y estado previo del programa, fechado 2026-10-15.
- `../research/STUDIES.md`: hipótesis y requisitos experimentales previos.
- `../governance/RELEASE_GATES.md`: gates R0–R5 y licencia pendiente.
- `EVALUATION_PROTOCOL.md`: diseño propuesto de evaluación de esta versión.
- Habilidades consultadas en esta sesión: `money` v1.2 y `nous-orchestrator`; metodología, no evidencia de conexión.

## Fuentes externas verificables

No se recuperaron fuentes externas para esta ficha. Los enlaces del README son antecedentes que requieren cotejo independiente antes de utilizarlos para afirmaciones actuales o comerciales.
