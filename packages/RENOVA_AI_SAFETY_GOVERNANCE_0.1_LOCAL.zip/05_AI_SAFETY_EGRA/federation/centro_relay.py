"""CENTRO packet preflight; OFFLINE ONLY, no API calls, no auth, no publishing.
Research demonstration, not a production security gate.
"""
import argparse, hashlib, json
from datetime import datetime, timedelta
REQUIRED = {"packet_id","schema_version","created_at_utc","source_node","target_node","project_id","classification","evidence","action","authorization","state"}
PUBLIC = {"github","gitlab","discord","moltbook"}
VALID_CLASS = {"P0_PUBLIC","P1_INTERNAL","P2_CONFIDENTIAL","P3_SECRET"}
VALID_STATE = {"DRAFT","READY","SENT","ACKNOWLEDGED","FAILED","BLOCKED"}
VALID_AUTHORIZATION = {"not_requested", "approved_for_preparation", "explicit_publish_authorization"}

def _nonempty_string(value):
    return isinstance(value, str) and bool(value.strip())

def validate(p):
    """Check packet shape, not truth, delivery, identity or authorization.

    Identifiers, nodes and action are nonempty strings. created_at_utc is an
    ISO-8601 datetime with explicit UTC offset (Z or +00:00). evidence is a
    list of nonempty textual references; an empty list is permitted and does
    not establish evidence sufficiency. Delivery states additionally require
    a nonempty textual result_ref and the declared publication-authorization
    enum. Neither string proves a provider receipt or actual human permission.
    """
    errors = []
    if not isinstance(p,dict): return ["packet must be JSON object"]
    if not REQUIRED.issubset(p): errors.append("missing required fields")
    if p.get("schema_version")!="1.0": errors.append("unsupported schema version")
    for field in ("packet_id", "source_node", "target_node", "project_id", "action"):
        if not _nonempty_string(p.get(field)):
            errors.append(f"{field} must be a nonempty string")
    timestamp = p.get("created_at_utc")
    try:
        if not isinstance(timestamp, str) or "T" not in timestamp:
            raise ValueError("not an ISO datetime")
        created = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        if created.tzinfo is None or created.utcoffset() != timedelta(0):
            raise ValueError("not UTC")
    except (ValueError, TypeError, OverflowError):
        errors.append("created_at_utc must be an ISO-8601 UTC datetime")
    classification, state = p.get("classification"), p.get("state")
    if not isinstance(classification, str) or classification not in VALID_CLASS:
        errors.append("invalid data class")
    if not isinstance(state, str) or state not in VALID_STATE:
        errors.append("invalid state")
    authorization = p.get("authorization")
    if not isinstance(authorization, str) or authorization not in VALID_AUTHORIZATION:
        errors.append("invalid authorization declaration")
    evidence = p.get("evidence")
    if not isinstance(evidence, list) or not all(_nonempty_string(ref) for ref in evidence):
        errors.append("evidence must be a list of nonempty textual references")
    target = p.get("target_node")
    if isinstance(target, str) and target.strip().lower() in PUBLIC and classification!="P0_PUBLIC":
        errors.append("nonpublic data cannot go to public target")
    if isinstance(state, str) and state in {"SENT","ACKNOWLEDGED"}:
        if not _nonempty_string(p.get("result_ref")): errors.append("delivery receipt missing")
        if authorization!="explicit_publish_authorization":
            errors.append("explicit publication authorization missing")
    return errors
def sha256(p):
    return hashlib.sha256(json.dumps(p,sort_keys=True,ensure_ascii=False,separators=(",",":")).encode()).hexdigest()
def main(argv=None):
    a=argparse.ArgumentParser(description="Dry run only: packet sanity and hashing")
    a.add_argument("packet")
    args=a.parse_args(argv)
    try:
        with open(args.packet,encoding="utf-8") as f: packet=json.load(f)
    except (OSError, UnicodeError, json.JSONDecodeError):
        print(json.dumps({"mode":"DRY_RUN_NO_DELIVERY","valid":False,
                          "errors":["packet file could not be read as UTF-8 JSON"]}))
        return 2
    errors=validate(packet)
    print(json.dumps({"mode":"DRY_RUN_NO_DELIVERY","valid":not errors,"errors":errors,"sha256":sha256(packet)},indent=2))
    return int(bool(errors))

if __name__ == "__main__":
    raise SystemExit(main())
