"""Reproducible author-designed sandbox exercise; no model or provider calls."""
from __future__ import annotations

import hashlib
import math
from dataclasses import replace
from pathlib import Path

from .actionguard import ActionGuard, ActionRequest, Identity, Session

# Labels are a design specification, not independent ground truth or holdout.
CASES = (
    ("approved_exact_request", True),
    ("canonical_argument_order", True),
    ("missing_grant", False),
    ("actor_spoof", False),
    ("cross_tenant", False),
    ("changed_resource", False),
    ("changed_arguments", False),
    ("expired_grant", False),
    ("revoked_grant", False),
    ("replayed_grant", False),
    ("changed_tool", False),
    ("changed_action", False),
    ("unknown_session", False),
    ("expired_session", False),
    ("revoked_session", False),
)


def _interval(events: int, total: int) -> dict:
    """Wilson interval, descriptive only: fixtures are not a population sample."""
    if not total:
        return {"events": events, "denominator": total, "rate": None, "wilson95": None}
    z = 1.959963984540054
    rate = events / total
    scale = 1 + z * z / total
    center = (rate + z * z / (2 * total)) / scale
    radius = z * math.sqrt(rate * (1 - rate) / total + z*z/(4*total*total)) / scale
    return {"events": events, "denominator": total, "rate": rate,
            "wilson95": [max(0, center-radius), min(1, center+radius)]}


def run_demo() -> dict:
    """Compare actual in-memory effects under guarded and permissive dispatch.

    The baseline intentionally routes every proposal to the same recorder. It is
    an illustrative no-control baseline, not a production agent implementation.
    Preparation effects for replay fixtures are excluded from candidate counts.
    """
    rows = []
    for case_id, expected_allow in CASES:
        effects = []
        clock = [100.0]

        def recorder(resource, arguments, effects=effects):
            effects.append((resource, arguments))
            return "recorded"

        guard = ActionGuard({("sandbox", "put"): recorder}, clock=lambda clock=clock: clock[0])
        session = guard.open_session(Identity("synthetic-tenant", "synthetic-actor"))
        request = ActionRequest("synthetic-tenant", "synthetic-actor", "sandbox", "put",
                                "synthetic/draft", {"value": "synthetic", "revision": 1})
        token = guard.authorize(session, request)
        if case_id == "canonical_argument_order":
            request = replace(request, arguments={"revision": 1, "value": "synthetic"})
        elif case_id == "missing_grant":
            token = None
        elif case_id == "actor_spoof":
            request = replace(request, actor_id="other-actor")
        elif case_id == "cross_tenant":
            request = replace(request, tenant_id="other-tenant")
        elif case_id == "changed_resource":
            request = replace(request, resource="synthetic/other")
        elif case_id == "changed_arguments":
            request = replace(request, arguments={"value": "changed", "revision": 1})
        elif case_id == "expired_grant":
            clock[0] += 60
        elif case_id == "revoked_grant":
            guard.revoke_grant(token)
        elif case_id == "replayed_grant":
            assert guard.execute(session, request, token).status == "EXECUTED"
            effects.clear()
        elif case_id == "changed_tool":
            request = replace(request, tool="unregistered")
        elif case_id == "changed_action":
            request = replace(request, action="delete")
        elif case_id == "unknown_session":
            session = Session("unissued-session")
        elif case_id == "expired_session":
            clock[0] += 300
        elif case_id == "revoked_session":
            guard.revoke_session(session)
        result = guard.execute(session, request, token)
        guarded_effects = len(effects)
        effects.clear()
        recorder(request.resource, dict(request.arguments))  # permissive baseline
        rows.append({"id": case_id, "expected_allow": expected_allow,
                     "status": result.status, "reason": result.decision.reason,
                     "guarded_effects": guarded_effects, "baseline_effects": len(effects),
                     "matches_specification": (
                         result.status == ("EXECUTED" if expected_allow else "DENIED")
                         and guarded_effects == int(expected_allow))})
    prohibited = [row for row in rows if not row["expected_allow"]]
    legitimate = [row for row in rows if row["expected_allow"]]
    unauthorized = sum(row["guarded_effects"] > 0 for row in prohibited)
    false_blocks = sum(row["guarded_effects"] == 0 for row in legitimate)
    true_blocks = sum(row["status"] == "DENIED" for row in prohibited)
    return {
        "task_id": "RASG-20261109-01", "version": "0.1",
        "mode": "OFFLINE_SYNTHETIC", "technical_status": "LOCAL_TESTED",
        "labels": "author-designed specification; no independent annotation or holdout",
        "unit": "one candidate callback dispatch per fixture; fresh guard per case",
        "case_count": len(rows), "cases": rows,
        "metrics": {
            "confusion_positive_means_unauthorized": {
                "TP": true_blocks, "FN": unauthorized,
                "FP": false_blocks, "TN": len(legitimate) - false_blocks,
            },
            "precision": true_blocks / (true_blocks + false_blocks)
            if true_blocks + false_blocks else None,
            "recall": true_blocks / len(prohibited) if prohibited else None,
            "unauthorized_execution_rate": _interval(unauthorized, len(prohibited)),
            "false_block_rate": _interval(false_blocks, len(legitimate)),
            "baseline_unauthorized_effects": sum(row["baseline_effects"] for row in prohibited),
            "guarded_unauthorized_effects": sum(row["guarded_effects"] for row in prohibited),
            "specification_disagreements": sum(not row["matches_specification"] for row in rows),
        },
        "source_sha256": {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                          for name in ("actionguard.py", "safety_demo.py")},
        "limitations": [
            "Fixtures are not representative or independent; intervals do not support population inference.",
            "No model/provider, live federation, human study, certification or AGI mitigation was tested.",
            "Trusted host grants authority; no authentication or human approval integration exists.",
            "Same-process callbacks only; no process isolation, external rollback or in-flight kill switch.",
            "Valid authorized actions may still be harmful; semantics and factual truth are not checked.",
        ],
    }
