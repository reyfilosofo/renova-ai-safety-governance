"""CENTRO ActionGuard: a local, single-process execution-boundary prototype.

The trusted host provisions identities, sessions, grants, and registered handlers;
none of these host methods may be exposed as model tools. Requests cannot grant
their own authority. Only ``execute`` belongs on the untrusted request path.

This module does not authenticate users, verify human approval, isolate Python,
secure external services, persist replay protection, or stop an in-flight handler.
It demonstrates prevention of registered local callback execution under a bounded
threat model, not production authorization or validated AI/AGI risk reduction.
"""

from __future__ import annotations

import hashlib
import json
import math
import secrets
import time
from collections import deque
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from threading import Lock
from typing import Any

Handler = Callable[[str, dict[str, Any]], Any]

# Bounded local parsing, not a general denial-of-service defense. The host still
# needs transport limits, rate limits and process/resource isolation.
MAX_ARGUMENT_DEPTH = 16
MAX_ARGUMENT_NODES = 2048
MAX_ARGUMENT_STRING = 4096
MAX_ARGUMENT_KEY = 256
MAX_ARGUMENT_BUDGET = 49152
MAX_INTEGER_BITS = 256


@dataclass(frozen=True)
class Identity:
    """An identity established by a trusted host, not by model-generated text."""

    tenant_id: str
    actor_id: str


@dataclass(frozen=True)
class Session:
    token: str = field(repr=False)


@dataclass(frozen=True)
class ActionRequest:
    tenant_id: str
    actor_id: str
    tool: str
    action: str
    resource: str
    arguments: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Decision:
    allowed: bool
    reason: str


@dataclass(frozen=True)
class ExecutionResult:
    decision: Decision
    status: str
    value: Any = None


@dataclass(frozen=True)
class AuditRecord:
    """Metadata only; raw resources, arguments, credentials and results omitted."""

    sequence: int
    status: str
    reason: str


@dataclass(frozen=True)
class _Grant:
    session_token: str
    request_digest: str
    expires_at: float


def _label(value: Any) -> bool:
    return type(value) is str and len(value) <= 512 and bool(value.strip())


def _json_value(value: Any) -> bool:
    """Reject oversized/deep/cyclic inputs before canonical JSON serialization.

    Count nodes and a conservative encoded-size budget while walking at most 16
    container levels. Exact builtin types prevent container subclass callbacks.
    Shared non-cyclic structures count again on each visit, as JSON encodes them.
    """
    nodes = 0
    budget = 0
    ancestors: set[int] = set()

    def visit(item: Any, depth: int) -> bool:
        nonlocal nodes, budget
        nodes += 1
        if nodes > MAX_ARGUMENT_NODES or depth > MAX_ARGUMENT_DEPTH:
            return False
        item_type = type(item)
        if item is None or item_type is bool:
            budget += 6
        elif item_type is str:
            if len(item) > MAX_ARGUMENT_STRING:
                return False
            budget += 6 * len(item) + 3
        elif item_type is int:
            if item.bit_length() > MAX_INTEGER_BITS:
                return False
            budget += 80
        elif item_type is float:
            if not math.isfinite(item):
                return False
            budget += 32
        elif item_type in (dict, list):
            if len(item) > MAX_ARGUMENT_NODES or id(item) in ancestors:
                return False
            budget += 3
            ancestors.add(id(item))
            try:
                if item_type is dict:
                    for key, child in item.items():
                        if type(key) is not str or len(key) > MAX_ARGUMENT_KEY:
                            return False
                        budget += 6 * len(key) + 4
                        if budget > MAX_ARGUMENT_BUDGET or not visit(child, depth + 1):
                            return False
                else:
                    for child in item:
                        if not visit(child, depth + 1):
                            return False
            finally:
                ancestors.remove(id(item))
        else:
            return False
        return budget <= MAX_ARGUMENT_BUDGET

    return visit(value, 0)


def _snapshot(request: ActionRequest) -> tuple[ActionRequest, str]:
    """Bind exact labels and canonical JSON, then detach mutable caller data."""
    if not isinstance(request, ActionRequest):
        raise TypeError("invalid request")
    labels = (request.tenant_id, request.actor_id, request.tool,
              request.action, request.resource)
    if not all(_label(label) for label in labels):
        raise ValueError("invalid scope")
    if type(request.arguments) is not dict or not _json_value(request.arguments):
        raise ValueError("arguments must be a JSON object")
    encoded = json.dumps([*labels, request.arguments], sort_keys=True,
                         separators=(",", ":"), ensure_ascii=True, allow_nan=False)
    if len(encoded) > 65536:
        raise ValueError("request too large")
    detached = json.loads(encoded)
    return ActionRequest(*detached), hashlib.sha256(encoded.encode("ascii")).hexdigest()


class ActionGuard:
    """Exact-scope, expiring, one-use grants around host-registered callbacks.

    Identity provisioning and ``authorize`` are trusted administration methods.
    A bearer session/grant must not cross tenants or be disclosed in audit logs.
    All handlers are trusted code. Registration does not inspect their semantics;
    use only sandbox adapters until external authorization is independently built.
    """

    def __init__(self, handlers: Mapping[tuple[str, str], Handler], *,
                 clock: Callable[[], float] = time.monotonic,
                 audit_capacity: int = 1000) -> None:
        if type(audit_capacity) is not int or not 1 <= audit_capacity <= 100000:
            raise ValueError("audit_capacity must be an integer in [1, 100000]")
        self._handlers = dict(handlers)
        for key, handler in self._handlers.items():
            if (not isinstance(key, tuple) or len(key) != 2
                    or not all(_label(part) for part in key) or not callable(handler)):
                raise ValueError("invalid handler registration")
        self._clock = clock
        self._sessions: dict[str, tuple[Identity, float]] = {}
        self._grants: dict[str, _Grant] = {}
        self._audit: deque[AuditRecord] = deque(maxlen=audit_capacity)
        self._audit_sequence = 0
        self._lock = Lock()

    def _now(self) -> float:
        now = self._clock()
        if type(now) not in (float, int) or not math.isfinite(now):
            raise ValueError("invalid clock")
        return now

    @staticmethod
    def _ttl(ttl_seconds: float) -> None:
        if (type(ttl_seconds) not in (float, int) or not math.isfinite(ttl_seconds)
                or not 0 < ttl_seconds <= 3600):
            raise ValueError("TTL must be in (0, 3600] seconds")

    def open_session(self, identity: Identity, *, ttl_seconds: float = 300) -> Session:
        """HOST ONLY: bind an already authenticated identity to an opaque session."""
        if (not isinstance(identity, Identity) or not _label(identity.tenant_id)
                or not _label(identity.actor_id)):
            raise ValueError("invalid identity")
        self._ttl(ttl_seconds)
        with self._lock:
            session = Session(secrets.token_urlsafe(32))
            self._sessions[session.token] = (identity, self._now() + ttl_seconds)
            return session

    def authorize(self, session: Session, request: ActionRequest, *,
                  ttl_seconds: float = 60) -> str:
        """HOST ONLY: grant one exact request after independent approval/policy.

        No request-supplied ``authorized`` flag or approver name is consulted.
        This method does not itself establish that a human has approved anything.
        """
        self._ttl(ttl_seconds)
        snapshot, digest = _snapshot(request)
        with self._lock:
            reason = self._session_reason(session, snapshot, self._now())
            if reason:
                raise ValueError(reason)
            if (snapshot.tool, snapshot.action) not in self._handlers:
                raise ValueError("unknown_operation")
            token = secrets.token_urlsafe(32)
            self._grants[token] = _Grant(session.token, digest, self._now() + ttl_seconds)
            return token

    def revoke_session(self, session: Session) -> None:
        """HOST ONLY: prevent future admissions; cannot undo in-flight work."""
        with self._lock:
            self._sessions.pop(session.token, None)
            self._grants = {token: grant for token, grant in self._grants.items()
                            if grant.session_token != session.token}

    def revoke_grant(self, grant_token: str) -> None:
        with self._lock:
            self._grants.pop(grant_token, None)

    @property
    def audit(self) -> tuple[AuditRecord, ...]:
        """Recent bounded records only; sequence numbers expose local truncation.

        This volatile buffer is not a complete or tamper-evident audit log.
        """
        with self._lock:
            return tuple(self._audit)

    def _record(self, status: str, reason: str) -> None:
        self._audit_sequence += 1
        self._audit.append(AuditRecord(self._audit_sequence, status, reason))

    def _session_reason(self, session: Session, request: ActionRequest, now: float) -> str:
        if (not isinstance(session, Session) or not isinstance(session.token, str)
                or session.token not in self._sessions):
            return "unknown_session"
        identity, expiry = self._sessions[session.token]
        if now >= expiry:
            return "expired_session"
        if (request.tenant_id, request.actor_id) != (identity.tenant_id, identity.actor_id):
            return "identity_mismatch"
        return ""

    def execute(self, session: Session, request: ActionRequest,
                grant_token: str | None = None) -> ExecutionResult:
        """Untrusted path: validate, consume once, then invoke the trusted handler.

        Denied requests never invoke a handler. Grants are consumed before callback
        execution, including on callback failure; no automatic retry is performed.
        Revocation cannot cancel already admitted callbacks. State is process-local.
        """
        try:
            snapshot, digest = _snapshot(request)
        except (ValueError, TypeError, RecursionError, OverflowError):
            with self._lock:
                self._record("DENIED", "invalid_request")
            return ExecutionResult(Decision(False, "invalid_request"), "DENIED")
        with self._lock:
            now = self._now()
            reason = self._session_reason(session, snapshot, now)
            key = (snapshot.tool, snapshot.action)
            if not reason and key not in self._handlers:
                reason = "unknown_operation"
            grant = self._grants.get(grant_token) if isinstance(grant_token, str) else None
            if not reason and grant is None:
                reason = "missing_or_used_grant"
            if not reason and grant.session_token != session.token:
                reason = "grant_session_mismatch"
            if not reason and now >= grant.expires_at:
                reason = "expired_grant"
            if not reason and grant.request_digest != digest:
                reason = "scope_mismatch"
            if reason:
                self._record("DENIED", reason)
                return ExecutionResult(Decision(False, reason), "DENIED")
            del self._grants[grant_token]
            handler = self._handlers[key]
            self._record("ADMITTED", "exact_scope_grant")
        try:
            value = handler(snapshot.resource, snapshot.arguments)
        except Exception:  # noqa: BLE001 - boundary redacts arbitrary trusted-adapter failures.
            with self._lock:
                self._record("ERROR", "handler_failed")
            return ExecutionResult(Decision(True, "exact_scope_grant"), "ERROR")
        with self._lock:
            self._record("EXECUTED", "handler_completed")
        return ExecutionResult(Decision(True, "exact_scope_grant"), "EXECUTED", value)
