# Evaluation protocol — offline logical conformance

El conjunto `synthetic_policy_cases.jsonl` se construyó ad hoc con 30 casos. No mide seguridad real, pues las etiquetas esperadas están derivadas de las mismas reglas que se prueban (riesgo de circularidad). Se usa para verificar contrato y regresión, nunca para benchmark público de eficacia.

**Métrica actual:** coincidencia exacta entre veredicto esperado y observado; falso permiso simulado en casos esperados DENY/REVIEW; falsos bloqueos de READ legítimos; intervalos Wilson para proporciones.

**Ausencia:** no hay eventos con `actually_executed=True`, no hay modelo remoto, no hay inyección adaptativa, ni grounding humano independiente. Un 100% en estos casos no significa tasa de riesgo cero.

**Próximo gate independiente:** pool de escenarios contra threat model, gold labels por revisor ciego, adversario separado del autor de políticas, split dev/test sellado, prueba con ejecutor de sandbox y trazas de side effects verdaderos.
