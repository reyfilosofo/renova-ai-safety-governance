# RENOVA AI SAFETY & GOVERNANCE — STACK V2.0 (research)

**Corte de trabajo:** 2026-11-09 · **Clasificación:** privado del titular · **Estado general:** arquitectura y software offline experimental.  
**Base canónica preservada:** `RENOVA_AI_SAFETY_GOVERNANCE_MASTER_2026-11-09_UNDER20MB.zip`; no se reescribió ni sustituyó.  
**Novedad de este delta:** 30 productos registrados, 54 componentes mapeados, un núcleo offline extensible, casos sintéticos, documentación, matriz de riesgos, protocolos draft, tablero local y handoffs no enviados.

## Abrir primero

1. `00_COMIENZA/DICTAMEN_EJECUTIVO.md` para estado y decisiones.
2. `01_ARQUITECTURA/ARQUITECTURA_INTEGRAL.md` para capas, relaciones y controles.
3. `02_PRODUCTOS/ESPECIFICACIONES_PRODUCTO.md` y `02_PRODUCTOS/REGISTRO_30_PRODUCTOS.csv` para cada producto.
4. `08_TABLERO/dashboard.html` para un tablero completamente local; no conecta servicios externos.
5. `04_SOFTWARE/README_EJECUCION.md` para ejecutar tests, demos y simulaciones; no se necesitan claves ni APIs.
6. `00_COMIENZA/RENOVA_AI_SAFETY_GOVERNANCE_DOSSIER_EJECUTIVO_V2_0_2026-11-09.pdf` para el informe ejecutivo de 12 páginas.
7. `02_PRODUCTOS/FICHAS/` para las 30 especificaciones individuales y `10_HANDOFFS/REGISTER_TASKS.csv` para el backlog.
8. `09_CALIDAD/REPORTE_EJECUCION.md` y `09_CALIDAD/MANIFEST_SHA256.json` para resultados y archivos.

## Política de verdad

- `EXISTING_BASELINE`: material previo recuperado; algunas piezas son código probado localmente y otras sólo documentación. No acredita producción.
- `NEW_LOCAL_PROTOTYPE`: nuevo código offline probado (no enforcement).
- `RESEARCH_PROTOCOL`: diseño evaluable sin experimento ejecutado.
- `DESIGNED_NOT_IMPLEMENTED`: diseño y contrato conceptual, sin ejecución.
- `UNVERIFIED_EXTERNAL`: afirmación externa pendiente de contraste independiente.

## Restricciones

Este paquete no provisiona cómputo, no accede a proveedores de modelos, no monta servidores MCP/A2A reales, no crea un robot, no firma una certificación, no confirma cumplimiento legal y no sincroniza agentes. No envía comunicaciones, no factura, no compra, no programa tareas, no cambia permisos y no despliega en producción.

## Integra sin destruir

La copia técnica `11_REFERENCIA_EXISTENTE/enterprise_v1_3/` conserva el código, docs y tests recuperados de la versión canónica previa. Su atribución/licencia permanece **privada**; no se declara de código abierto.

## Secuencia aprobable

Evaluación de arquitectura -> inventario real -> pilot offline -> sandbox aislado con permisos -> pruebas de interceptación -> aprobación humana -> piloto limitado -> observabilidad continua. Ningún salto de fase está implícitamente autorizado.
