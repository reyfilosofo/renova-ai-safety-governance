# Dictamen de dirección y ejecución — 2026-11-09

## Pregunta principal (KIQ)
¿Cómo convertir una colección interdisciplinaria de investigación y prototipos RENOVA en un programa de ingeniería y assurance auditable, preservando la propiedad intelectual, la supervisión humana y la independencia epistemológica?

## Decisión
Arquitectura modular **federada, local-first y fail-closed**. CENTRO determina decisiones consultivas de riesgo y será integrado a un *gateway ejecutor separado* solo tras controles de identidad, autorización y bypass. LUCEM preserva los datos, su procedencia, contradicciones y niveles de confianza. EGRA compara tratamientos contra baselines y holdouts. NOUS articula productos/negocio y CJGR prioriza cartera y autoridad de aprobación.

## Acreditado en esta sesión
- El ZIP maestro contiene 373 entradas; la documentación separa productos existentes de falta de pruebas externas.
- La suite Enterprise v1.3 recuperada ejecutó 62 pruebas unitarias locales y pasó.
- Se construyó y probó una extensión offline nueva; su informe y hashes están en `09_CALIDAD/`.
- GitHub `reyfilosofo/renova-agent` es accesible vía conector en rama principal `main`; no hubo escrituras remotas.

## Principios obligatorios
1. Enrutamiento de toda acción con privilegios reales por autoridad externa al LLM.
2. Estado explícito: propuesto -> revisado -> autorizado -> ejecutado -> readback. No inventar transiciones.
3. Modelo ≠ agente ≠ herramienta ≠ evidencia ≠ permiso ≠ ejecución.
4. Citas de fuentes, datasets y métodos; separación entre resultado sintético y validación externa.
5. Habilidades y plugins solo establecen procedimientos: no autentican otras herramientas automáticamente.
6. Los datos privados no se transfieren a GitHub público; no existe una licencia de redistribución inferida.
7. No confundir adecuación a ISO/NIST/OWASP con certificación ni evaluación acreditada.

## Blockers críticos
- Falta un punto de ejecución externo con enforcement de autorizaciones y identity binding.
- No se ha demostrado interceptación exhaustiva ni aislamiento multitenant en sistemas reales.
- No existen pruebas de ida/vuelta Grok/Gemini/A2A/MCP federadas en esta entrega.
- No se dispone de energía, GPU ni cuentas de infraestructura provisionadas por este paquete.
- No hay anotación independiente de seguridad en agentes de frontera, ni evaluación causal del impacto humano.

## Siguiente decisión reversible
Aprobar un piloto **exclusivamente offline**: congelar 100–200 escenarios diversos con métricas prerregistradas, instrumentar un ejecutor sintético en sandbox, comparar ActionGate vs baseline, publicar solo resultados tras revisión humana y con límites explícitos.
