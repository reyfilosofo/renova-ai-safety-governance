# Reporte reproducible — 2026-11-09

- Archivo origen: `RENOVA_AI_SAFETY_GOVERNANCE_MASTER_2026-11-09_UNDER20MB.zip`. Integridad ZIP a comprobar con archivo original.
- Base Enterprise v1.3: **62 pruebas** definidas; en esta repetición hubo 62/62 pruebas superadas (exit=0). En una ejecución previa pasó 62/62; se confirmó intermitencia por firma Base64URL; ver `patch_candidate_validation.txt`.
- Extensión v2.0: **32/32 pruebas** superadas en entorno local en esta sesión (exit=0).
- Total de pruebas unitarias locales: **94** definidas (62 heredadas + 32 nuevas), no todas consistentemente estables en código canónico; sin inferir cobertura de producción.
- Simulador políticas: **30 casos sintéticos**, aciertos exactos **30/30**, IC Wilson95 **[0.88649, 1.0]**. Etiquetas construidas de las mismas reglas; no hay eficacia externa ni evaluación ciega.
- Baseline `serve-demo`: ejecución controlada devolvió exit=1; resultado final `UnboundLocalError: cannot access local variable 'issuer' where it is not associated with a value`. **ISS-001 reproducido**. No modificar código histórico sin revisión.
- Handoffs escritos: 8, todos `PREPARED` y sin recibo externo.
- Conexiones activas desde el artefacto: ninguna. GitHub lectura fuera del artefacto se consultó durante la sesión; no escritura.

## Interpretación
Estos tests verifican lógica local y consistencia de contratos en escenarios definidos. No verifican autenticación de identidad real, ejecución de acciones, interceptación de todo tráfico, resiliencia a ataques adaptativos, conformidad oficial MCP/A2A, seguridad física, independencia científica ni certificación de gobernanza.
