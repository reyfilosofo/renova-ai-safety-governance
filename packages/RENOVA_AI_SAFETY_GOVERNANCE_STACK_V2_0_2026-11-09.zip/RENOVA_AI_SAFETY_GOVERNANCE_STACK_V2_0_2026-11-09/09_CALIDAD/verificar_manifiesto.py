from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'09_CALIDAD/MANIFEST_SHA256.json').read_text(encoding='utf-8'))
fail=[]
for f in manifest['files']:
    p=root/f['path']
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=f['sha256']:fail.append(f['path'])
print('OK' if not fail else 'INVALID',len(manifest['files']),'files','errors=',len(fail))
if fail:print('\n'.join(fail))
sys.exit(bool(fail))
