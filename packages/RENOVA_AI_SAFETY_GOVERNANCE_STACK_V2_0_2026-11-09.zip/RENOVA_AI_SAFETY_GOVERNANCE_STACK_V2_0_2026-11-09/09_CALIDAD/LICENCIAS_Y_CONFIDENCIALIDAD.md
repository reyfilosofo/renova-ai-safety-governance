# Licencias, propiedad intelectual y divulgación

Este delta incorpora referencias técnicas recuperadas de los archivos suministrados por su titular, algunas bajo licencias de investigación propietaria. Se presenta **para uso privado**, sin derecho de redistribución inferido. Las fichas de ISO solo enlazan metadatos públicos, no copian textos de la norma. No se incorporaron tokens, claves reales ni listados de clientes.

Antes de publicar código o documentos: separar `11_REFERENCIA_EXISTENTE`, auditar autoría de cada archivo, limpiar metadatos, realizar detección de secretos, licencias de dependencias y dataset model cards, revisar conflictos de marca y someter un PR humano.
