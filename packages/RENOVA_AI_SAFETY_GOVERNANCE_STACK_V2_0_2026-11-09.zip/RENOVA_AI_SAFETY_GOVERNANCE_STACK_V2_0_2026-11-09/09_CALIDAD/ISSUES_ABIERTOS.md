# Issues abiertos para revisión

- `ISS-001`: Enterprise v1.3 `cli.py`, comando `serve-demo`, hace referencia a `issuer` antes de inicializarlo. Hallazgo por lectura estática; se ejecutó una prueba aislada y se reprodujo el error; ver `baseline_cli_serve_demo_error.log`. **No se alteró el baseline.**
- `ISS-002`: nueva capa `TrustedContext` se acepta como objeto local; falta autenticación firmada y binding a recursos reales.
- `ISS-003`: `ContextGuard` aplica ACL, frescura y cuota, pero NO detecta ni elimina de forma fiable prompt injection; los outputs siguen etiquetados como contenido no confiable.
- `ISS-004`: JSON `PREPARED` no transmite a A2A, MCP ni a complementos externos; falta conformance test.
- `ISS-005`: todo benchmark nuevo usa etiquetas derivadas por reglas; se requiere test holdout de tercero.
- `ISS-006`: no hay medidas reales de consumo eléctrico, latencia de modelos remotos o robots.
- `ISS-007`: no hay dictamen de licencia del corpus completo para redistribución pública.
- `ISS-008`: normas vigentes y propuestas requieren revisión contextual por jurisdicción, especialmente altas obligaciones y usos prohibidos.
- `ISS-009`: políticas observadas y acciones con impacto son sólo señales; se requiere aislamiento real y atomicidad del side effect.
