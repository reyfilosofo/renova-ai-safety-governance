# Blueprint de infraestructura y economía — no desplegado

## Perfil L (laboratorio local)
Python stdlib + SQLite local (baseline Enterprise), dataset sintético, Git hashes, sin secretos, sin GPU, localhost. Beneficios: coste variable mínimo y reversibilidad. Riesgos: ningún control contra ejecución externa.

## Perfil S (sandbox aislado)
Container sin red por defecto, rootless, volumen read-only, límites CPU/memoria, secret manager separado, pruebas de identidad, fake MCP/A2A peers, ledger durable; CI aislada y artefactos firmados. No se entrega manifiesto de despliegue productivo porque faltan controles de aplicación.

## Perfil P (piloto regulado futuro)
Workload identity/OIDC, mTLS, KMS/HSM, database per tenant, object storage cifrado, OpenTelemetry collector con redacción, un modelo con serving de referencia, vector index bajo tenant ACL, enforcement gateway, incident response y propietarios humanos. Alta disponibilidad no es sustituto de evaluación del daño.

## Modelo de coste transparente
`coste_total = coste_compute + almacenamiento + transferencia + observabilidad + operadores + seguridad + amortización + energía_atribuible`. Reportar coste por caso correctamente resuelto y verificable. Escenarios no sustituyen facturas ni consumo medido.

## Portabilidad
Evitar dependencia de un motor, proveedor de embeddings o framework de agentes sin prueba de migración. Los contratos JSON son insumos, no garantía de portabilidad semántica.
