# Límites materiales, físicos, económicos y epistemológicos

## Cómputo y energía
Requisitos por despliegue: potencia de placa/GPU, electricidad atribuible al entrenamiento e inferencia, PUE del centro de datos, huella de transmisión, refrigeración, fuente energética, capacidad de redundancia, cuotas contractuales, depreciación, capacidad de financiación, protección ante cortes y obligaciones sobre residencia de datos. Son métricas por medir, no cifras aportadas por esta entrega.

## Datos y conocimiento
Ningún embedding prueba que la fuente sea verdadera. RAG presupone recuperación y generación; la política de confianza exige fuente primaria, fecha, licencia, acceso, granularidad, TTL, verificación independiente, auditoría de rechazo y citación. GraphRAG no elimina inyección indirecta.

## Calidad y coste de inferencia
Throughput, TTFT, tokens/s, latencia p50/p95, tasa de errores, GPU-segundos, coste por caso correcto, consumo estimado de energía e incidencias. Comparar motores requiere la misma tarea, presupuesto de contexto, calidad de respuesta y carga de concurrencia. Un costo absoluto fuera de contrato no se inventa.

## Robótica
Probar en simulación no valida seguridad de hardware. Para actuar se requiere definición de daño físico, límites certificados o definidos en ingeniería, E-stop verificable sin dependencia del LLM, controles de acceso humano y prueba independiente. No se permite conectar este prototipo directamente a motores, drones o vehículos.

## Gobernanza y economía política
Soberanía no se reduce a fabricar chips: también incluye licencias, localización, derecho, red, model weights, datasets, idiomas, personal especializado y posibilidad de salida. El riesgo de concentración se mide mediante dependencia y costes de migración, no slogans.
