# Arquitectura integral y principios de confianza

**Sistema de referencia, no diagrama de producción acreditada.** El modelo de sistema utiliza el eje físico -> informacional -> cognitivo -> agéntico -> institucional y dos raíles transversales (safety/observabilidad y gobernanza/evidencia).

## Flujo conceptual

```text
RECURSOS FÍSICOS (energía / GPU / cooling / red / soberanía)
       ↓
DATOS (objetos, permisos, versiones, embedding, indexación, retrieval)
       ↓
MODELOS (fundación, adaptación, serving, enrutamiento, presupuesto)
       ↓
HARNESSES (planning, state, herramientas, sandbox, memoria)
       ↕        ↕
PROTOCOLOS MCP (herramientas) / A2A (agentes) / contratos de transferencia
       ↓
APLICACIONES, INVESTIGACIÓN, SERVICIOS, INTERFACES
       ↓
INTELIGENCIA FÍSICA (si existe actuador): sensor→percepción→plan→control seguro

RAÍL A: CENTRO (identidad, acción, permisos, aislamiento, revocación, incidentes)
RAÍL B: LUCEM + EGRA + NOUS (proveniencia, evaluación, trazabilidad, gobernanza)
```

Un *harness* no es un modelo: contiene estados, herramientas, permisos, límites y reglas del ciclo de interacción. La mejora de un harness puede superar a una mejora de modelo en una tarea **sólo si hay una comparación reproducible**; no es una ley universal.

## Confianza y autoridad

El modelo puede proponer: objetivos, razonamiento, recursos sugeridos y solicitudes de acción. El **runtime independiente**, nunca la salida textual del modelo, debe proporcionar: identidad de la carga de trabajo, tenant, scopes, resource ID canónico, clasificación, efecto, versión de estado, nonce y autoridad para el grant. La decisión puede ser revisada; ejecutar requiere una puerta externa independiente, vinculada a una acción exacta y ledger transaccional.

## Interoperabilidad

- MCP se usa conceptualmente para descubrir y usar recursos/herramientas; se debe implementar conforme a una versión concreta de su especificación, con autenticación, consentimiento y control de resultados no confiables.
- A2A se usa conceptualmente para delegación entre agentes con tarjetas de capacidad y estados; un JSON de handoff no equivale a soporte de wire protocol.
- Conectores API/OAuth/webhooks deben declarar autenticación, alcance, caducidad, recepción y readback.
- Un plugin ChatGPT no prueba acceso a Google, Grok, Gemini ni a un agente de marca similar.

## Estados de interoperabilidad
`DISCOVERED`, `ACCESS_VERIFIED`, `READ_VERIFIED`, `WRITE_VERIFIED`, `ROUND_TRIP_VERIFIED`, `STALE`, `UNAVAILABLE`, `NOT_TESTED`. Ningún proveedor asciende de estado por aparecer en una tabla o mock.

## Pruebas de seguridad por frontera
A. **Hardware y cloud:** soberanía, supply chain, residencia, consumo real. B. **Datos:** tenant ACL, TTL, taint, derechos. C. **Modelo:** benchmarks, contaminación, abstención, versionado. D. **Agent loop:** límites de llamadas, atribución de acciones, rollback. E. **Herramientas:** enforcement independiente, token replay, confused deputy. F. **A2A/MCP:** Agent Cards maliciosas, servidores falsos, delegación indebida. G. **Actuación física:** parada independiente, fuerza, proximidad, geofence, humanos en zona de riesgo.

## Plan de integración
Mantener `enterprise_v1_3` como referencia en paquete privado. Consolidar luego las interfaces nuevas en una rama GitHub propuesta, mediante PR separado y revisión humana, nunca en `main` directamente. Un contrato de interfaz se integra sólo después de pruebas con proveedor real y bitácora de lectura/escritura.
