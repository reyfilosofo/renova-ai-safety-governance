# Catálogo de componentes y dependencias

Consultar `COMPONENTES_STACK_2026.csv`: cada fila indica capa, entrada, control requerido, producto dueño, fase y estado. El inventario es una arquitectura prescriptiva; no acredita que exista servicio instalado o licencia activa.

**Fase 0:** preservación/proveniencia; **Fase 1:** prototipo local y criterios de control; **Fase 2:** assets y productos de assurance; **Fase 3:** integraciones en sandbox; **Fase 4:** implementación controlada y observabilidad real; **Fase 5:** embodied AI exclusivamente simulación regulada; **Fase 6:** auditorías externas y posible escala.

### Selección orientativa (no adquisición)
- Energía/cómputo: GPU/TPU/CPU, Slurm, Kubernetes + DRA, Kueue, Ray según tamaño; no se recomienda Kubernetes para prototipos de un solo nodo.
- Datos: S3/GCS o MinIO compatible, PostgreSQL, pgvector o Qdrant, lakeFS/DVC, Airflow/Dagster según pipeline.
- Serving: vLLM/SGLang/Triton/KServe; seleccionar tras benchmark de modelos y cargas.
- Agentes: OpenAI Agents SDK, LangGraph, Google ADK, Microsoft Agent Framework; uno como referencia por prueba, no instalar todos.
- Interoperabilidad: MCP y A2A versionados; no tratar la interoperabilidad como acceso privilegiado.
- Observabilidad: OpenTelemetry, Langfuse o Phoenix; no almacenar prompts sensibles indiscriminadamente.
- Seguridad: aislamiento Linux, mínimos permisos, gateways, registro de decisiones, revisión human-in-the-loop.
