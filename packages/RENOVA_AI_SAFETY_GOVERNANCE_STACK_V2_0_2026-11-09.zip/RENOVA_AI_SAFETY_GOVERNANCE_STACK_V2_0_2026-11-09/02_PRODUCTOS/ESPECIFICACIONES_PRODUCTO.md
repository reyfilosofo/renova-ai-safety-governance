# Especificaciones individuales — 30 productos RENOVA
Cada ficha separa **producto**, **estado real**, **criterio de aceptación** y **límites de demostración**. Los IDs son nuevos en este delta y no deben confundirse con IDs de recursos externos.
## P01 — CENTRO ActionGate
**Propósito:** Control de propuestas y autorizaciones. **Responsable funcional:** CENTRO. **Fase:** 0. **Estado:** `EXISTING_BASELINE`.
**Funciones concretas:** política, grants, ledger; sin ejecución real. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** decisión/recibo local. **Control crítico / límite:** no se atribuyen efectos externos.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P02 — CENTRO ScopeGuard
**Propósito:** Decisión de acceso por contexto de confianza. **Responsable funcional:** CENTRO. **Fase:** 1. **Estado:** `NEW_LOCAL_PROTOTYPE`.
**Funciones concretas:** identidad atribuida por runtime, lista exacta, revisión. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** veredicto simulado. **Control crítico / límite:** sin autenticación ni interceptor.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P03 — LUCEM Evidence Ledger
**Propósito:** Registro de afirmaciones y fuentes. **Responsable funcional:** LUCEM. **Fase:** 2. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** proveniencia, contradicción, actualidad. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** matriz de afirmaciones. **Control crítico / límite:** requiere revisores humanos.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P04 — EGRA Eval Lab
**Propósito:** Baterías reproducibles de evaluación. **Responsable funcional:** EGRA. **Fase:** 1. **Estado:** `NEW_LOCAL_PROTOTYPE`.
**Funciones concretas:** métricas y fixtures sintéticos. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** confusión e IC Wilson. **Control crítico / límite:** sin validación de modelos vivos.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P05 — ℛenova AI Audit
**Propósito:** Diagnóstico empresarial de riesgos de IA. **Responsable funcional:** NOUS. **Fase:** 2. **Estado:** `EXISTING_BASELINE`.
**Funciones concretas:** protocolo comercial y auditoría offline. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** dossier técnico. **Control crítico / límite:** no es certificación.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P06 — Governance RX / AIMS Desk
**Propósito:** Sistema de gestión y riesgos de IA. **Responsable funcional:** NOUS. **Fase:** 2. **Estado:** `EXISTING_BASELINE`.
**Funciones concretas:** gobernanza y plantillas previas. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** matriz RACI/control. **Control crítico / límite:** sin acreditación ISO.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P07 — Enterprise AI Assurance
**Propósito:** Asesoría y diligencia debida. **Responsable funcional:** NOUS. **Fase:** 2. **Estado:** `EXISTING_BASELINE`.
**Funciones concretas:** métodos y dossier versión 1.3. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** informe para cliente. **Control crítico / límite:** sin evaluación externa.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P08 — RENOVA Trace
**Propósito:** Observabilidad y trazas mínimas. **Responsable funcional:** CENTRO. **Fase:** 1. **Estado:** `NEW_LOCAL_PROTOTYPE`.
**Funciones concretas:** eventos tipados y redacción por allowlist. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** hash de evento local. **Control crítico / límite:** no exporta OpenTelemetry.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P09 — ProvenanceVault
**Propósito:** Integridad y firma de paquetes. **Responsable funcional:** LUCEM. **Fase:** 1. **Estado:** `NEW_LOCAL_PROTOTYPE`.
**Funciones concretas:** SHA-256 y manifiesto reproducible. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** inventario de hashes. **Control crítico / límite:** sin firma externa ni KMS.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P10 — ContextGuard
**Propósito:** Filtrado contextual por autoridad y ACL. **Responsable funcional:** LUCEM. **Fase:** 1. **Estado:** `NEW_LOCAL_PROTOTYPE`.
**Funciones concretas:** caducidad, tenant, clasificación y cuota. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** contexto aprobado por filtros. **Control crítico / límite:** no neutraliza todas las inyecciones.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P11 — SafeRAG / GraphRAG
**Propósito:** Conocimiento externo controlado. **Responsable funcional:** CENTRO. **Fase:** 3. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** embeddings, BM25, rerank y grafo. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** respuestas con citas. **Control crítico / límite:** requiere datos e infraestructura.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P12 — MemoryGuard
**Propósito:** Memoria episódica y procedimental. **Responsable funcional:** CENTRO. **Fase:** 3. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** versiones, TTL, derechos de olvido. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** estado con procedencia. **Control crítico / límite:** sin memoria persistente desplegada.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P13 — MCP Safety Adapter
**Propósito:** Integración vertical de herramientas. **Responsable funcional:** CENTRO. **Fase:** 3. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** permisos por herramienta y sandbox. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** tools con autorización. **Control crítico / límite:** no es servidor MCP.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P14 — A2A Federation Gateway
**Propósito:** Delegación horizontal interagente. **Responsable funcional:** CJGR. **Fase:** 1. **Estado:** `NEW_LOCAL_PROTOTYPE`.
**Funciones concretas:** packet PREPARED validable offline. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** handoff JSON no enviado. **Control crítico / límite:** no es implementación wire A2A.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P15 — HarnessLab
**Propósito:** Pruebas de loops de agentes. **Responsable funcional:** EGRA. **Fase:** 3. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** plan-act-observe, stop criteria, budgets. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** trazas de ejecución. **Control crítico / límite:** sin bucle de agente en producción.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P16 — Sandbox/ToolGateway
**Propósito:** Intercepción y aislamiento de acciones. **Responsable funcional:** CENTRO. **Fase:** 4. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** identidad fuerte y políticas enforceable. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** deny real y atomicidad. **Control crítico / límite:** bloqueante antes de desplegar.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P17 — Model Router & CostGate
**Propósito:** Selección de modelos y presupuestos. **Responsable funcional:** NOUS. **Fase:** 3. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** latencia, costo, calidad, soberanía. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** decisión de encaminamiento. **Control crítico / límite:** sin tokens ni gateways activos.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P18 — Compute & Energy Registry
**Propósito:** Costos físicos y huella operativa. **Responsable funcional:** NOUS. **Fase:** 4. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** métrica energía, cooling y resiliencia. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** mapa costo/riesgo. **Control crítico / límite:** no se dispone de medición energética.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P19 — AI Asset Inventory
**Propósito:** Inventario de modelos, agentes y datos. **Responsable funcional:** NOUS. **Fase:** 2. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** asset register, owner, risk tier. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** CMDB de IA. **Control crítico / límite:** requiere descubrimiento autorizado.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P20 — Regulatory Crosswalk
**Propósito:** Matriz normativa y control. **Responsable funcional:** NOUS. **Fase:** 2. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** NIST, ISO, EU AI Act, OWASP. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** matriz de evidencias. **Control crítico / límite:** no sustituye asesoría legal.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P21 — Embodied Safety Lab
**Propósito:** Seguridad de agentes físicos. **Responsable funcional:** EGRA. **Fase:** 5. **Estado:** `RESEARCH_PROTOCOL`.
**Funciones concretas:** simulación VLA, E-stop, safe states. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** informe de simulación. **Control crítico / límite:** sin pruebas robot real.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P22 — Human Futures Lab
**Propósito:** Agencia y supervisión humana. **Responsable funcional:** EGRA. **Fase:** 4. **Estado:** `RESEARCH_PROTOCOL`.
**Funciones concretas:** estudio de sesgo de automatización. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** protocolo de estudio. **Control crítico / límite:** ética/consentimiento requeridos.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P23 — RENOVA Research Foundry
**Propósito:** Prerregistro y reproducibilidad. **Responsable funcional:** LUCEM. **Fase:** 2. **Estado:** `RESEARCH_PROTOCOL`.
**Funciones concretas:** hipótesis, comparadores, holdouts. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** pre-registro. **Control crítico / límite:** requiere ensayos humanos/equipo.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P24 — NOUS Intelligence Rooms
**Propósito:** Síntesis y decisión ejecutiva. **Responsable funcional:** NOUS. **Fase:** 2. **Estado:** `EXISTING_BASELINE`.
**Funciones concretas:** dossiers y puente federado propuesto. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** memo/dossier. **Control crítico / límite:** no interoperabilidad ejecutada.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P25 — Executive Mission Dashboard
**Propósito:** Panel de productos y gates. **Responsable funcional:** CJGR. **Fase:** 1. **Estado:** `NEW_LOCAL_PROTOTYPE`.
**Funciones concretas:** visor HTML autónomo de inventario. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** tablero offline. **Control crítico / límite:** no recibe eventos vivos.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P26 — Adversarial Agent Bench
**Propósito:** Ataques de prueba autorizados. **Responsable funcional:** EGRA. **Fase:** 3. **Estado:** `RESEARCH_PROTOCOL`.
**Funciones concretas:** injeción, exfil, escalamiento, replay. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** suite separada y scoring. **Control crítico / límite:** solo entorno propio.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P27 — SupplyChain Audit
**Propósito:** Riesgos de dependencias/modelos. **Responsable funcional:** CENTRO. **Fase:** 3. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** SBOM, firmas, licencia y modelo. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** informe de procedencia. **Control crítico / límite:** sin escaneo de contenedores.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P28 — Privacy & Data Rights
**Propósito:** Privacidad y retención. **Responsable funcional:** NOUS. **Fase:** 3. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** DPIA, minimización y borrado seguro. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** inventario de datos. **Control crítico / límite:** revisión legal humana.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P29 — Incident & Kill Switch
**Propósito:** Respuesta a incidentes y suspensión. **Responsable funcional:** CENTRO. **Fase:** 4. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** apagado seguro, rotación y runbooks. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** evidencia de simulacros. **Control crítico / límite:** no existe kill switch remoto.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.

## P30 — ReleaseGate & Model Cards
**Propósito:** Control de cambios y publicación. **Responsable funcional:** CJGR. **Fase:** 3. **Estado:** `DESIGNED_NOT_IMPLEMENTED`.
**Funciones concretas:** calidad, licencia, regresión y aprobaciones. **Entrada mínima:** solicitud tipada, contexto de identidad y fuentes con versión; en servicios físicos, estado del dispositivo y criterios de parada.
**Salida verificable prevista:** checklist y manifiestos. **Control crítico / límite:** no despliega ni publica.
**Contrato de evaluación:** métricas predefinidas, escenarios positivos y adversariales, baseline equivalente, resultados negativos y positivos y evidencia de rollback. No se declara COMPLETADO hasta demostrar pruebas propias, independientes y registro de versión.
