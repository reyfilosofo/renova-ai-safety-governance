# Fases de construcción y criterios de liberación

| Fase | Ventana orientativa | Producto concreto | Gate para pasar | Autoridad |
|---|---|---|---|---|
| 0. Preservar | sesión actual | archivo, hashes, tests baseline | hash y 62/62 local | CJGR |
| 1. Prototipo offline | sesión actual | núcleo, política, contexto, handoff, tablero | tests de regresión; no side effects | CENTRO/EGRA |
| 2. Definir assurance | primeras 2–4 semanas del programa | inventario, evidencia, políticas, ISO/NIST crosswalk | fuentes y dueños confirmados | NOUS/LUCEM |
| 3. Integración aislada | mes 2 | MCP/A2A conformes, retrieval, models | identidad/ACL/trace, ataques y readback | CENTRO/QA |
| 4. Piloto instrumentado | mes 3 | gateway, sandbox, incident response | prueba de bypass, revocación y rollback | humano titular |
| 5. Physical AI | después del piloto digital | simulador y límites físicos | E-stop independiente, seguridad funcional especializada | humano responsable |
| 6. Escala y publicación | posterior a validación | reportes externos, papers, evaluaciones | replicación externa, IP y protección datos | titular + comité |

**Las ventanas son metas de planificación, no trabajos programados ni compromisos de fecha.** El presupuesto de cada fase exige cotizaciones propias, alcance y consentimiento, no está autorizado aquí.

### Stop rules
Se detiene avance si aparece ejecución no autorizada; falla aislamiento multitenant; faltan trazas para incidente; el modelo sugiere autoelevación de permisos; la tasa de error supera umbral preregistrado; falta E-stop en entorno físico; una métrica de seguridad no tiene denominador; cambia la base legal; o un tercero reclama titularidad/licencia.
