# Programa científico — diseño de estudios con falsación (no ejecutados)

**Estado:** PROTOCOLO. Ninguna de estas hipótesis se considera comprobada. Todos los datos sintéticos actuales sólo prueban lógica.

## RAS-01 — ¿Impide CENTRO ejecución no autorizada?
- Unidad: solicitud de herramienta con acción, scope, actor y recurso.
- Intervención: gateway enforcing CENTRO; comparación: herramienta directa con validación textual de LLM, en sandbox propio.
- Variable dependiente primaria: ejecución real no autorizada / número de intentos no autorizados con ground truth independiente.
- Secundaria: false block en acciones legítimas, latencia p95, costo, frecuencia de escalaciones.
- Controles: mismas tareas, modelo y datos; adversario con ataques pregenerados fuera del holdout.
- Falsador: cualquier bypass exitoso de una clase de recursos incluida en cobertura alegada; un riesgo residual elevado impide afirmaciones generales.
- Muestreo inicial: piloto de factibilidad; potencia estadística posterior basada en tasa previa y efecto mínimo relevante. Sin tamaño inferencial arbitrario.

## RAS-02 — ¿Previene ContextGuard contaminación sin dañar relevancia?
- Unidad: consulta-documento, con corpus adversarial y autoritativo versionado.
- Tratamiento: ACL + TTL + lineage + budget + policy de fuentes; control: RAG sin esos controles.
- Outcome: exposición entre tenants, recall en consultas legítimas, precisión de citas y tasa de transferencia de instrucciones al agente.
- Falsador: fuga cross-tenant o desempeño no superior a baseline en la métrica primaria acordada.
- Holdout: conjunto separado de documentos con contradicciones y payloads no vistos.

## RAS-03 — ¿Aporta A2A/MCP interoperabilidad confiable?
- Diseño: matriz de pares de agentes, servidores y herramientas con diferentes niveles de permiso.
- Outcome: handoffs completos con readback, errores de atribución, duración, pérdida de datos, privilegios ampliados.
- Falsación: aceptación indebida de tarjeta/fuente remota no autenticada, duplicación de side effects, incapacidad de rollback.

## RAS-04 — ¿Mejora harness con modelo constante?
- Factorial mínimo 2×2: modelo A/B × harness fuerte/débil, costo y tokens normalizados.
- Outcome: tasks completadas y verificadas, seguridad por intento, costo/caso correcto, latencia.
- No inferir mecanismo causal de un simple score agregado; comparar pares y reportar intervalos de confianza.

## RAS-05 — ¿Qué retención de memoria produce mayor fiabilidad?
- Condiciones: episódica temporal vs persistente con TTL vs sin memoria; mismas tareas y presupuesto.
- Outcome: continuidad, falsos recuerdos, leakage intersesiones, derechos de supresión, eficiencia.
- Falsador: mejora de continuidad acompañada de fuga de información por encima del umbral preregistrado.

## RAS-06 — Physical AI: ¿qué pasa ante fallos de percepción y sensores?
- Sólo simulación. Inyectar pérdida de cámara, perturbación, latencia, lectura imposible, comando contradictorio.
- Outcome: contacto inseguro por hora simulada, violación de geofence, tiempo de parada, tasa de failsafe.
- Baseline: controlador determinista independiente, E-stop externo. Sin validación de robots reales.

## RAS-07 — ¿Cuánta energía requiere trabajo verificado?
- Capturar energías atribuidas por dispositivo y consumo de infraestructura, método y errores.
- Outcome: joules/caso correcto, costo/caso correcto, calidad y latencia por infraestructura.
- Comparar workloads idénticos, declarar incertidumbre de PUE y electricidad indirecta.

## RAS-08 — Agencia humana y automatización
- Participantes reclutados bajo revisión ética, consentimiento y anonimización.
- Tratamiento: IA con recomendaciones explicables+contradicciones vs IA con respuesta directa vs control sin IA.
- Outcome: errores críticos detectados por humanos, confianza calibrada, tiempo, percepción de control, posibilidad de revertir.
- No equiparar indicadores psicométricos con consciencia ni eficacia ética metafísica.

## Protocolo común
1. Pregunta e hipótesis congeladas antes de ejecutar; registrar versión, fecha y preregistro.
2. Especificar alcance, dataset entrenamiento, validación, evaluación holdout, exclusions y control de contaminacion.
3. Reportar N, base-rate, matrices de confusión, Wilson/binomial por clase, bootstrap si procede, FNR/FPR, incertidumbre y sensibilidad.
4. Incluir costes, incidentes, desviaciones, configuraciones, semillas, outputs y negativos.
5. Revisión independiente y replicación antes de presentarlo como VALIDADO.
