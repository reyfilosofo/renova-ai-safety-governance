# ℛenova: del marco filosófico a constructos investigables

**A → A′** se emplea como esquema filosófico de transformación y continuidad, **no** como relación física universal validada. De la tríada Hábitat–Herida–Horizonte se pueden derivar preguntas para sistemas sociotécnicos: condiciones iniciales, pérdidas, daños previsibles, opciones futuras y capacidad de reparación.

| Concepto | Estatuto | Operacionalización candidata | Falsación/limitación |
|---|---|---|---|
| Reversibilidad | propiedad de sistema | recuperación exacta, rollback en t+1, irreversibilidad de efectos | medir side effects, no solo revertir un log |
| Responsabilidad | normativo/institucional | actor responsable por acción, aprobación, reclamación y remediación | accountability no se reduce a scoring |
| Sensibilidad fundante | filosófico/interpretativo | propuesta experimental: detección de daños invisibilizados y participación afectada | no equivale a consciencia ni sentimiento de IA |
| Horizonte | normativo/prospectivo | diversidad de alternativas viables tras decisión; capacidad de reconsiderar | altos puntajes no prueban justicia |
| Herida | filosófico/ético | incidentes, quejas, daños documentados con consentimiento | la medición parcial no agota el fenómeno |
| Hábitat | sistémico | restricciones materiales, legales, sociales y ambientales | cambia con geografía y escala |
| LUCEM | metodológico | proporción de afirmaciones con respaldo independiente y contradicción explícita | no se infiere verdad sólo por coherencia |
| Gewalt | hermenéutico | registro de coerción, pérdida de autonomía y asimetrías de poder | no establecer una escala única sin validación |
| Bios–Zoe | filosófico | distinción interpretativa sobre vida, desarrollo y condiciones de vulnerabilidad | no atribuir experiencia a IA por analogía |

## Pregunta ética diferencial
¿Qué condiciones verificables permiten que el ejercicio de capacidades inteligentes no diluya la imputabilidad ni suprima la facultad humana de revisar, detener y reparar consecuencias? No es un axioma empíricamente probado; es un programa de investigación normativa y de ingeniería.
