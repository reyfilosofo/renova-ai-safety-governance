# Instrucciones de ejecución — offline

Desde `04_SOFTWARE/` (Python >=3.10):

```bash
PYTHONPATH=. python -m unittest discover -s tests -v
PYTHONPATH=. python -m renova_stack.cli assess --request examples/request_read.json --trusted-context examples/trusted_context.json
PYTHONPATH=. python -m renova_stack.cli context --records examples/records.json --trusted-context examples/trusted_context.json
PYTHONPATH=. python -m renova_stack.cli handoff --source CJGR_EXECUTIVE --target NOUS --action "Solicitar revisión científica"
PYTHONPATH=. python -m renova_stack.cli score --data ../05_EVALUACION/casos_y_veredictos.jsonl
```

Para replicar el baseline: desde `11_REFERENCIA_EXISTENTE/enterprise_v1_3` ejecutar `PYTHONPATH=src python -m unittest discover -s tests -v`.

No hay conexión a red; no hay servidores MCP/A2A, LLM remoto, gestión de secretos ni side effects. Las solicitudes de aprobación nunca equivalen a acciones realizadas.
