"""RENOVA AI Safety & Governance Stack v2.0, offline research extension.
No live agent/tool execution or conformance certification is implemented.
"""
__version__="2.0.0-research"
