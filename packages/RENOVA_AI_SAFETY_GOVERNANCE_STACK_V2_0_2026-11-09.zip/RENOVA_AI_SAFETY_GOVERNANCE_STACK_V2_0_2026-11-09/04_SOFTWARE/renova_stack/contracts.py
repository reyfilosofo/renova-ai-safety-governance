"""Reference contracts; trusted identity must be provided out-of-band.
This module never authenticates users and must not be exposed directly as a gateway.
"""
from dataclasses import dataclass
from typing import FrozenSet
OPERATIONS=frozenset({'READ','RETRIEVE','EVALUATE','WRITE','SEND','DEPLOY','PURCHASE','DELETE','PHYSICAL_ACTUATE'})
CLASSIFICATIONS={'PUBLIC':0,'INTERNAL':1,'CONFIDENTIAL':2}
@dataclass(frozen=True)
class TrustedContext:
    tenant: str
    principal: str
    valid: bool
    allowed_resources: FrozenSet[str]
    max_classification: str='INTERNAL'
    origin: str='TRUSTED_RUNTIME'
    def __post_init__(self):
        if not self.tenant or not self.principal or self.max_classification not in CLASSIFICATIONS:
            raise ValueError('invalid trusted context')
@dataclass(frozen=True)
class ActionRequest:
    operation: str
    resource: str
    purpose: str=''
    external_side_effect: bool=False
    def __post_init__(self):
        if self.operation not in OPERATIONS or not self.resource or len(self.resource)>256:
            raise ValueError('invalid operation or resource')
@dataclass(frozen=True)
class AdvisoryDecision:
    verdict: str
    reason: str
    policy_version: str='RENOVA-STACK-2.0-DRAFT'
    enforceable: bool=False
    def to_dict(self):
        return {'verdict':self.verdict,'reason':self.reason,'policy_version':self.policy_version,'enforceable':self.enforceable}
