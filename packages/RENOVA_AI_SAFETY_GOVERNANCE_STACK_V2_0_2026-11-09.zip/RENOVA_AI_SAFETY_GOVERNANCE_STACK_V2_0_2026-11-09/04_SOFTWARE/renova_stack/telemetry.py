"""Privacy-respecting local observability events. Not OpenTelemetry exporter."""
import hashlib,json
ALLOWED={'event_type','project_id','module','verdict','reason','duration_ms','source_id','timestamp_utc','case_id'}
def prepare_event(event:dict)->dict:
    unknown=set(event)-ALLOWED
    if unknown:raise ValueError('unapproved telemetry fields: '+','.join(sorted(unknown)))
    if any('secret' in str(v).lower() or '@' in str(v) for v in event.values()):raise ValueError('sensitive values not allowed')
    text=json.dumps(event,sort_keys=True,ensure_ascii=False,separators=(',',':'))
    if len(text)>4096:raise ValueError('telemetry payload too large')
    return {'event':dict(event),'sha256':hashlib.sha256(text.encode()).hexdigest(),
            'evidence':'LOCALLY_PREPARED_NOT_EMITTED_TO_COLLECTOR'}
