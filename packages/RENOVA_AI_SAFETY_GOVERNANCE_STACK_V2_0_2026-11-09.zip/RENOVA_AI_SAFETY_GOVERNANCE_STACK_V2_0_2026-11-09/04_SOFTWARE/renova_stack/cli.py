"""Offline CLI for policy, context, handoff and testing."""
import argparse,json,sys
from pathlib import Path
from .contracts import ActionRequest,TrustedContext
from .action_gate import assess
from .context_engine import SourceRecord,select
from .federation import prepare_handoff
from .metrics import score_policy_cases

def from_json(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def main(argv=None):
    p=argparse.ArgumentParser(prog='renova-stack',description='Research-only offline simulator; no external actuation')
    sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('assess');a.add_argument('--request',required=True);a.add_argument('--trusted-context',required=True)
    c=sub.add_parser('context');c.add_argument('--records',required=True);c.add_argument('--trusted-context',required=True)
    h=sub.add_parser('handoff');h.add_argument('--source',required=True);h.add_argument('--target',required=True);h.add_argument('--action',required=True);h.add_argument('--project-id',default='RENOVA-AISG')
    s=sub.add_parser('score');s.add_argument('--data',required=True)
    args=p.parse_args(argv)
    if args.command in {'assess','context'}:
        d=from_json(args.trusted_context);d['allowed_resources']=frozenset(d['allowed_resources']);ctx=TrustedContext(**d)
        if args.command=='assess':out=assess(ActionRequest(**from_json(args.request)),ctx).to_dict()
        else:
            rows=from_json(args.records)
            r=select([SourceRecord(**x) for x in rows],ctx)
            out={'accepted':r.accepted,'rejected':r.rejected,'char_count':r.char_count,'note':r.note}
    elif args.command=='handoff':out=prepare_handoff(source=args.source,target=args.target,action=args.action,project_id=args.project_id)
    else:
        lines=Path(args.data).read_text(encoding='utf-8').splitlines()
        out=score_policy_cases([json.loads(line) for line in lines if line.strip()])
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
