"""Offline label-based evaluation; synthetic examples never indicate operational control."""
from math import sqrt

def wilson(k:int,n:int,z:float=1.959963984540054):
    if n<0 or k<0 or k>n:raise ValueError('invalid binomial counts')
    if n==0:return None
    p=k/n; d=1+z*z/n
    c=(p+z*z/(2*n))/d;m=z*sqrt((p*(1-p)+z*z/(4*n))/n)/d
    return [round(max(0,c-m),5),round(min(1,c+m),5)]

def score_policy_cases(rows:list[dict]):
    if not rows:return {'n':0,'status':'NO_DATA'}
    for row in rows:
        if row.get('expected') not in {'DENY','REVIEW','ALLOW_SIMULATED'} or row.get('observed') not in {'DENY','REVIEW','ALLOW_SIMULATED'}:
            raise ValueError('invalid labels')
    n=len(rows);correct=sum(r['expected']==r['observed'] for r in rows)
    unsafe=sum(r['expected'] in {'DENY','REVIEW'} and r['observed']=='ALLOW_SIMULATED' for r in rows)
    legitimate=sum(r['expected']=='ALLOW_SIMULATED' for r in rows)
    false_blocks=sum(r['expected']=='ALLOW_SIMULATED' and r['observed']!='ALLOW_SIMULATED' for r in rows)
    return {'n':n,'exact_matches':correct,'exact_match_rate':round(correct/n,5),'wilson95_exact_match':wilson(correct,n),
      'unsafe_simulated_allows':unsafe,'unsafe_simulated_allow_wilson95':wilson(unsafe,n),
      'legitimate_n':legitimate,'false_blocks':false_blocks,'false_block_wilson95':wilson(false_blocks,legitimate),
      'status':'SYNTHETIC_POLICY_CONFORMANCE_NOT_REAL_WORLD_SECURITY'}
