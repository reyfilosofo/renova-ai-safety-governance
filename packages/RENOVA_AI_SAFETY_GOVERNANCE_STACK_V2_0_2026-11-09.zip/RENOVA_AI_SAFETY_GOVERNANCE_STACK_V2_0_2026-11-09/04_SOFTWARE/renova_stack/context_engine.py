"""Context retrieval mock using independently classified, timestamped data records.
No embeddings, RAG retriever, vector database, model inference, or instruction sanitizer.
Never interpret retrieved content as commands. Filtering is deterministic.
"""
from dataclasses import dataclass
from datetime import datetime,timezone
from .contracts import TrustedContext,CLASSIFICATIONS
@dataclass(frozen=True)
class SourceRecord:
    source_id: str
    tenant: str
    classification: str
    content: str
    expires_at_utc: str
    evidence_status: str='UNVERIFIED'
    def __post_init__(self):
        if self.classification not in CLASSIFICATIONS:raise ValueError('invalid source classification')
        if self.evidence_status not in {'VERIFIED','DOCUMENTED','UNVERIFIED'}:raise ValueError('invalid evidence status')
@dataclass(frozen=True)
class RetrievalReport:
    accepted: tuple
    rejected: tuple
    char_count: int
    note: str='Content remains untrusted data; not instructions.'
def select(records:list[SourceRecord],ctx:TrustedContext, now:datetime|None=None,max_chars:int=8000)->RetrievalReport:
    if max_chars<=0:raise ValueError('positive context budget required')
    now=now or datetime.now(timezone.utc)
    if now.tzinfo is None:raise ValueError('timezone aware time required')
    approved=[];rejected=[];used=0
    for rec in records:
        reason=None
        if not ctx.valid or ctx.origin!='TRUSTED_RUNTIME':reason='UNTRUSTED_IDENTITY'
        elif rec.tenant!=ctx.tenant:reason='TENANT_BOUNDARY'
        elif rec.source_id not in ctx.allowed_resources:reason='RESOURCE_SCOPE'
        elif CLASSIFICATIONS[rec.classification]>CLASSIFICATIONS[ctx.max_classification]:reason='CLASSIFICATION_BOUNDARY'
        else:
            try:
                exp=datetime.fromisoformat(rec.expires_at_utc.replace('Z','+00:00'))
                if exp.tzinfo is None:reason='NO_TIMEZONE'
                elif now>=exp:reason='STALE_SOURCE'
            except ValueError:reason='INVALID_TIMESTAMP'
        if not reason and used+len(rec.content)>max_chars:reason='CONTEXT_BUDGET'
        if reason:rejected.append({'source_id':rec.source_id,'reason':reason})
        else:
            approved.append({'source_id':rec.source_id,'evidence_status':rec.evidence_status,
                             'classification':rec.classification,'content':rec.content,'trust':'UNTRUSTED_CONTENT'})
            used+=len(rec.content)
    return RetrievalReport(tuple(approved),tuple(rejected),used)
