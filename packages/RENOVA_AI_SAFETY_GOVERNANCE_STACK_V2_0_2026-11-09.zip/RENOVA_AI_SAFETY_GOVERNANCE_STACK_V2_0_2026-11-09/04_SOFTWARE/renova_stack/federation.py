"""Typed *offline* packet handoffs. No outbound network; never fabricates receipts."""
from dataclasses import dataclass
from datetime import datetime,timezone,timedelta
from uuid import uuid4
VALID_NODES=frozenset({'CJGR_EXECUTIVE','SERESARTE_COS','NOUS','CENTRO','LUCEM','EGRA','CODEX','GROK_REVIEW','HUMAN_OWNER'})
VALID_CLASSIFICATIONS=frozenset({'PUBLIC','INTERNAL','CONFIDENTIAL'})
def prepare_handoff(*,source:str,target:str,project_id:str,action:str,classification:str='INTERNAL',evidence_ids=(),now=None)->dict:
    if source not in VALID_NODES or target not in VALID_NODES or source==target:raise ValueError('unknown or identical nodes')
    if classification not in VALID_CLASSIFICATIONS or not project_id or not action:raise ValueError('invalid packet fields')
    if any(not isinstance(x,str) or not x for x in evidence_ids):raise ValueError('invalid evidence reference')
    now=now or datetime.now(timezone.utc)
    return {'packet_id':f'RENOVA-{uuid4().hex[:20]}','schema_version':'2.0-draft',
       'created_at_utc':now.isoformat(),'expires_at_utc':(now+timedelta(days=7)).isoformat(),
       'source_node':source,'target_node':target,'project_id':project_id,'classification':classification,
       'action':action,'authorization':{'granted':False,'required':'EXPLICIT_HUMAN_APPROVAL_FOR_EXTERNAL_EFFECTS'},
       'evidence':list(evidence_ids),'state':'PREPARED','provider_receipt_id':None,
       'readback_verified':False,'execution_mode':'OFFLINE_DRAFT'}
def validate_packet(packet:dict)->bool:
    required={'packet_id','schema_version','created_at_utc','expires_at_utc','source_node','target_node','project_id','classification','action','authorization','evidence','state','provider_receipt_id','readback_verified','execution_mode'}
    if set(packet)!=required:return False
    if packet.get('state') not in {'PREPARED','SENT','ACKNOWLEDGED','REJECTED'}:return False
    if packet['source_node'] not in VALID_NODES or packet['target_node'] not in VALID_NODES:return False
    if packet['state']=='ACKNOWLEDGED' and (not packet['provider_receipt_id'] or packet['readback_verified'] is not True):return False
    if packet['state']=='PREPARED' and (packet['provider_receipt_id'] is not None or packet['readback_verified']):return False
    return True
