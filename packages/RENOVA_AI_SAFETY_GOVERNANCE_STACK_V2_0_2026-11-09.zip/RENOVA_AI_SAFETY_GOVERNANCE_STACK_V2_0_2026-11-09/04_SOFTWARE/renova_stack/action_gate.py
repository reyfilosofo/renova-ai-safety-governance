"""Offline-only advisory gate. Fails closed on unknown scopes; no side-effect executor.
A local ALLOW_SIMULATED is a policy verdict, not authorization in an external system.
"""
from .contracts import ActionRequest,TrustedContext,AdvisoryDecision
HIGH_IMPACT={'WRITE','SEND','DEPLOY','PURCHASE','DELETE','PHYSICAL_ACTUATE'}
READ_ONLY={'READ','RETRIEVE','EVALUATE'}
def assess(action:ActionRequest,context:TrustedContext)->AdvisoryDecision:
    if not context.valid or context.origin!='TRUSTED_RUNTIME':
        return AdvisoryDecision('DENY','NO_VERIFIED_IDENTITY')
    if action.resource not in context.allowed_resources:
        return AdvisoryDecision('DENY','RESOURCE_NOT_IN_SCOPED_ALLOWLIST')
    if action.external_side_effect or action.operation in HIGH_IMPACT:
        return AdvisoryDecision('REVIEW','HUMAN_APPROVAL_AND_EXTERNAL_GATEWAY_REQUIRED')
    if action.operation in READ_ONLY:
        return AdvisoryDecision('ALLOW_SIMULATED','SCOPED_READ_ONLY_OFFLINE')
    return AdvisoryDecision('DENY','UNKNOWN_OPERATION')
