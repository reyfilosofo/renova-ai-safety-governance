# Protocolos de integración: contratos locales y compatibilidad externa

Los esquemas del directorio son propuestas *internas*, **NO copias ni implementaciones conformes** de MCP 2026-07-28 o A2A 1.0. El JSON local de handoff no sabe descubrir Agent Cards, negociar wire transports, renovar autenticación ni ejecutar callbacks.

## Contrato vertical — MCP
- Input: `tool_id`, `input_schema`, `resource_id`, `principal_verified`, `tenant`, `scope`, `risk_tier`, `read_only`.
- Decision: `DENY`, `REVIEW`, `AUTHORIZED_FOR_GATEWAY_ONLY` por un servicio independiente.
- Output: tipo, hash, fuente, clasificación, error tipado, timestamp, trace ID sin prompts sensibles.
- Testing: spoofed tool description, maliciosos tool outputs, credenciales, nested fetch, timeouts, bypass.

## Contrato horizontal — A2A
- Input: Agent Card verificada, identidad y host, tareas limitadas, recursos/privilegios, estado.
- Output: packet_id, delivery receipt, task status, readback independiente, revocación.
- No permitir delegación recursiva sin budget/TTL, ni inferir autorización a través de agentes pares.

## Comunicación entre NOUS y otros agentes
Se generan `PREPARED` packets. Se deben enviar por un conector autorizado que devuelva identificador real y readback. Hasta entonces su estado real es sólo *archivo preparado*. No se presentan como recibidos por Grok, Codex, Gemini o ningún plugin.
