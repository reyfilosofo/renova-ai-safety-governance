# Normativa y marcos — crosswalk inicial no acreditado

| Fuente | Naturaleza jurídica | Implementación RENOVA propuesta | Evidencia exigible |
|---|---|---|---|
| NIST AI RMF 1.0 (GOVERN/MAP/MEASURE/MANAGE) | voluntaria | inventario, registro de daños, evaluación, respuesta | decisión, métricas, propietarios, cambios |
| NIST AI 600-1 GenAI | guía voluntaria GenAI | inyección, confabulación, abuso, privacidad, ciberseguridad | pruebas, riesgos y salidas verificadas |
| ISO/IEC 42001:2023 | norma internacional de sistemas gestión | política AIMS, roles, objetivos, auditoría interna y mejora continua | registros controlados y auditoría; **sin certificación** |
| OWASP Agentic Top 10 2026 | marco comunitario técnico | amenazas de agentes, tools, privilegios, memorización | pruebas negativas y gateways |
| OWASP Agent Control Standard | marco técnico comunitario | controles de agentes, estados y autorizaciones | diseño y verificación por control |
| Unión Europea: AI Act | reglamento UE con aplicación por fases | clasificar rol, ámbito territorial y obligaciones por caso | análisis jurídico específico; versión consolidada |
| México: iniciativas 2026 | **iniciativa, no ley en vigor por ese expediente** | seguimiento legislativo diferenciado de normativa vigente | ficha SIL, DOF cuando proceda |

## Obligaciones sin simplificaciones
Una plataforma puede servir a diferentes roles (proveedor, deployer, importador, distribuidor, responsable de datos, integrador). Las obligaciones y fechas cambian según rol, uso, región y excepciones. Este crosswalk no es dictamen legal y no equivale a cumplimiento automático. 

## Registro de control
Para cada control: `control_id`, marco y artículo/elemento específico (cuando aplique), requisito, rol, riesgo, implementación, test, responsable, aprobación, caducidad de evidencia, URL/hash y estado.

## Protocolo de cambio
1. Revisar fuente primaria vigente (DOF, EUR-Lex, NIST, ISO, OWASP).
2. Separar texto normativo de propuesta/estándar voluntario.
3. Registrar fecha de publicación, fecha de aplicación y transición.
4. Decidir materialidad para una organización concreta.
5. Crear tarea de actualización; validar por especialista cuando sea necesario.

**Nota de revisión:** la cronología pública UE señala modificaciones aprobadas en 2026 y próximas transiciones en diciembre 2026 y 2027–2028; no fijar plazos exclusivamente por la versión original 2024.
