# Security operations y respuesta a incidentes — propuesta

**Amenaza prioritaria:** un componente generativo intenta convertir contenido de bajo nivel de confianza en una orden privilegiada con efectos reales. Otros riesgos: fuga de secretos, replay, errores de identidad, agentes en bucle, reportes falsos y daño físico.

## Principio de respuesta
**Detectar → detener ejecución en gateway externo → preservar evidencia mínima → revocar grants → investigar → aislar → restaurar desde estado verificado → documentar → autorizar reinicio humano.** El núcleo offline no ejecuta este procedimiento fuera de la simulación.

## Límites mínimos de seguridad
- Identidades por workload, nunca strings confiadas del modelo.
- Scopes mínimos, expiración, revocación, límites de rate y cuotas.
- Claves en almacén externo, rotación y firma de recibos.
- Logs desprovistos de PII y prompts privados salvo necesidad legal.
- Pruebas de interrupción, degradación segura, recuperación, RTO/RPO documentados.
- Revisión de contratos, licencias de datos, modelo e infraestructura.

## Prioridad crítica
No afirmar que 'ALLOW' convalida seguridad. La decisión de software es una señal para que otra pieza compruebe la autoridad y ejecute. La versión v1.3 y el kernel nuevo son deliberadamente no ejecutores.
