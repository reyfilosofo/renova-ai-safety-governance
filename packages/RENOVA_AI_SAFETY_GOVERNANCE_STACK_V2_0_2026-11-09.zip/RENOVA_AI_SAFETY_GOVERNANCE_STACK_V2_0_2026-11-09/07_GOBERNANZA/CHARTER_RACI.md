# Carta de encargo, autoridad y RACI

**Mandato:** transformar recursos RENOVA en productos y experimentos falsables con alta trazabilidad, sin auto-atribuir certificaciones ni permisos. **Producto principal:** RENOVA AI Safety & Governance Stack v2.0. **Propietario de decisión:** titular humano.

| Flujo | Responsable operativo | Valida/Escalación | Límite |
|---|---|---|---|
| Priorización portfolio | CJGR Executive Twin Ω | titular humano | decisiones vinculantes reservadas |
| Coordinación institucional | SERESARTE Chief of Staff Ω | titular humano | no representa toda la organización sin permiso |
| Investigación fuentes/LUCEM | NOUS + LUCEM | revisión independiente | no inferir verdad de un score |
| Ingeniería controles CENTRO | ingeniería local/Codex cuando conectado | QA humano | ningún despliegue sin gateway real |
| Evals y falsación EGRA | investigador + evaluador offline | revisor independiente | no inventar baselines |
| Contratos y business development | NOUS | titular + legal cuando aplique | no propuestas enviadas ni precios inventados |
| Interoperabilidad con Grok/Gemini | adaptador cuando accesible | dueño + readback | no conexión afirmada por etiqueta |
| Publicación externa y pagos | titular | titular | aprobación explícita imprescindible |

## Separación institucional
Fundación SERESARTE (entidad cultural), NOUS by SERESARTE (servicio de consultoría), ℛenova (marco filosófico y productos) y los clientes/usuarios finales mantienen derechos, licencias, consentimiento y registros independientes.

## Governance gates
No enviar correo, publicar, comprar cómputo, añadir credenciales a código, conectarse a robot, transferir datos sensibles, programar automatizaciones, publicar a GitHub o activar cron en este paquete. Toda futura acción debe tener `TASK_ID`, `scope`, `evidence_ref`, `approval`, `receipt`, `readback`.
