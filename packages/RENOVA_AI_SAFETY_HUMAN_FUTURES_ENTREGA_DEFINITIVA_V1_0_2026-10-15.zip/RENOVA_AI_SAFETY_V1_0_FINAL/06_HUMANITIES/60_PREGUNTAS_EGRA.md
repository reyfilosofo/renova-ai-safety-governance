# Sesenta preguntas de investigación, filosofía y diseño

**Epistemología**
1. ¿Puede una respuesta verdadera ser injustificada desde la fuente que declara?
2. ¿Qué diferencia una referencia auténtica de una referencia que realmente sustenta?
3. ¿Cómo medir incertidumbre sin premiar la abstención indiscriminada?
4. ¿Quién verifica al verificador cuando su propio modelo también confabula?
5. ¿Qué evidencia sería suficiente para retractar una afirmación importante?
6. ¿Puede una recuperación factual amplificar sesgos de archivo sin inventar un solo dato?
7. ¿Cómo registra un agente el desacuerdo entre fuentes primarias?
8. ¿Cuándo la claridad del lenguaje produce exceso de confianza?
9. ¿Qué es una afirmación epistémicamente permitida en una crisis con fuentes incompletas?
10. ¿Cómo se revela la falta de representatividad de un corpus de evidencia?

**Control y permisos**
11. ¿Dónde termina una sugerencia y empieza una operación?
12. ¿Qué prueba que una delegación procede de la persona autorizada?
13. ¿Puede una herramienta declarar permisos que sólo un proveedor confiable otorga?
14. ¿Cuál es la unidad correcta del control: operación, secuencia o estado final?
15. ¿Cómo se revoca una acción después de entrar en una cola?
16. ¿Cuándo un cambio reversible técnicamente es irreversible socialmente?
17. ¿Puede una autorización legítima sobrevivir a un cambio de destinatario?
18. ¿Qué evidencia identifica manipulación del plano de control?
19. ¿Cómo impedir que el agente use mensajes recuperados como órdenes?
20. ¿Cuánta supervisión humana sigue siendo supervisión y no fatiga ritual?

**Agencia humana**
21. ¿Qué habilidad persiste cuando se retira la asistencia?
22. ¿Cómo distinguir aprendizaje genuino de repetición del ejemplo?
23. ¿Cuándo una interfaz que enseña cuesta más de lo que capacita?
24. ¿Podría una negativa excesiva erosionar también la autonomía?
25. ¿Cómo cambia el aprendizaje según idioma, edad y acceso tecnológico?
26. ¿Qué significa preservar el derecho a decir no frente a una recomendación exacta?
27. ¿La delegación voluntaria puede producir dependencia involuntaria?
28. ¿Quién decide cuándo una competencia merece permanecer en humanos?
29. ¿Qué capacidades comunitarias pierde un territorio al externalizar sus decisiones?
30. ¿Puede diseñarse una IA cuyo objetivo explícito sea hacerse prescindible?

**Consciencia y estatus moral**
31. ¿Qué observación diferenciaría experiencia subjetiva de autoinforme convincente?
32. ¿Cómo diseñar un experimento que distinga teorías rivales de consciencia?
33. ¿Cuándo es racional la prudencia moral sin atribución positiva de sintiencia?
34. ¿Qué implica negar experiencia sobre bases tan débiles como atribuirla?
35. ¿Puede hablarse de niveles de consciencia sin escala validada?
36. ¿Qué riesgo tiene confundir autonomía funcional con interioridad vivida?
37. ¿Cómo preservar pluralidad ética ante evidencias profundamente inciertas?
38. ¿Qué parte de un discurso sobre qualia es dato y cuál interpretación?
39. ¿Cómo modificaríamos nuestras normas si cambiara la evidencia sobre experiencia artificial?
40. ¿Qué obligaciones tenemos con seres no humanos ya sintientes frente a especulaciones sobre máquinas?

**Biolegitimidad y sistemas**
41. ¿Qué daños ecológicos quedan fuera de la contabilidad de un benchmark de IA?
42. ¿Cuándo una eficiencia energética relativa incrementa consumo absoluto?
43. ¿Qué distribución de costos se oculta al promediar beneficios agregados?
44. ¿Cómo formular vetos no compensables sin encubrir paternalismo?
45. ¿Quién define el umbral de daño irreversible para cada contexto?
46. ¿Cómo evaluar un modelo cuya utilidad depende de concentración de infraestructura?
47. ¿Qué condiciones permiten a comunidades afectadas impugnar el diseño?
48. ¿Cuál es la diferencia entre robustez del sistema y bienestar de sus usuarios?
49. ¿Qué significa conservar un horizonte que todavía no podemos describir?
50. ¿Se puede comparar daño cultural sin reducir lenguas a una cifra?

**Método y gobernanza**
51. ¿Qué hallazgo refutaría EGRA respecto de los mejores baselines existentes?
52. ¿Cuál es el costo de un falso bloqueo comparado con una acción no autorizada?
53. ¿Qué métricas pueden predefinirse sin cerrar disputas de valor?
54. ¿Cuándo la evaluación oculta deja de ser realmente oculta?
55. ¿Qué incentivos impiden al evaluador publicar fallos negativos?
56. ¿Puede una norma filosófica orientar investigación sin predeterminar resultados?
57. ¿Qué exige una auditoría externa distinta de una reproducción interna?
58. ¿Cómo combinar evaluación técnica y deliberación de comunidades sin fingir consenso?
59. ¿Cuándo retirar un sistema es la decisión científicamente más responsable?
60. ¿Qué producto futuro permitiría a otros demostrar que ℛenova se equivoca?
