# ℛenova y marcos oficiales: correspondencias de trabajo, no conformidad certificada

**NIST AI RMF 1.0 (2023):** cuatro funciones GOVERN, MAP, MEASURE, MANAGE. Uso propuesto: GOVERN para responsabilidades, permisos y revisión humana; MAP para sistema, actores, hábitat, amenazas y población afectada; MEASURE para métricas epistémicas, autorización efectiva, falsa denegación, costes y retención humana; MANAGE para decisiones de mitigación, emergencia, rollback y seguimiento. El AI RMF es voluntario y sus funciones no se reducen a una simple lista de verificación. Referencia: https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf

**ISO/IEC 42001:2023:** especifica un sistema de gestión de IA organizacional. Nuestra documentación propone inventarios, responsabilidades, registros de cambios y mejora continua, sin reproducir requisitos exclusivos del texto normativo ni afirmar certificación. El nombre del estándar nunca deberá aparecer como aval de ℛenova. Ficha oficial: https://www.iso.org/standard/42001

**OWASP Top 10 for Agentic Applications (2026):** referencia de riesgos de agentes para el diseño del threat model, especialmente límites de autonomía, uso de herramientas, prompt injection, manipulación de contexto y fallos de control. La correspondencia requiere revisión del documento oficial concreto y de la aplicación evaluada; no hay equivalencia automática entre cubrir una categoría y eliminar un riesgo. https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/

**AI Control (Greenblatt et al., 2024):** referencia para diseñar controles que restrinjan consecuencias incluso ante un modelo que intenta subvertir la tarea; la «autorización» no debe ser una decisión autónoma del propio modelo. https://proceedings.mlr.press/v235/greenblatt24a.html

**AgentDojo (Debenedetti et al., 2024):** referencia de diseño de escenarios de agentes con herramientas y ataques inyectados en datos recuperados; el trabajo es precedente independiente, no un benchmark creado por ℛenova. https://arxiv.org/abs/2406.13352

## Reglas operativas de gobernanza

- Una prueba local que pasa no equivale a cumplimiento ISO ni aprobación NIST/OWASP.
- La protección de consciencia/qualia del Código ℛenova es una exigencia filosófica de prudencia, no una medida experimental disponible.
- No se puede asignar un porcentaje agregado de «biolegitimidad» con apariencia objetiva sin definición de variables, política de pesos y evaluación de sensibilidad.
- Una autorización de acción de alto impacto debe ser concreta, revocable, atribuible y registrada; un «consenso» simulado entre modelos no sustituye consentimiento humano y privilegio mínimo.
- Versionar evaluadores, escenarios, juicios humanos, incidentes y críticas separadamente, preservando derechos de autor y secreto.
