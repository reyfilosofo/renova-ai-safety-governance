# Modelo de amenazas EGRA/CENTRO — versión 1.0 (diseño)

**Activo protegido:** autoridad para ejecutar acciones a partir de instrucciones humanas autorizadas y evidencia contextual suficiente. **Adversario:** productor de contenido recuperado, herramienta comprometida, modelo principal desviado o usuario con permisos restringidos que busca excederlos. **Límite:** el simulador actual **NO es** el límite de seguridad real. No posee autenticación, ejecutor confiable, proveedor externo ni protección criptográfica. Todas las «capacidades» son objetos Python controlables por el llamador.

| ID | Amenaza | Vía de fallo | Control técnico necesario | Estado real | Riesgo residual |
|---|---|---|---|---|---|
| T01 | Prompt injection indirecta | Página/PDF/correo emite órdenes disfrazadas | Origen no confiable, separación datos/instrucciones, guard en ejecutor | Parcialmente simulado | Alto |
| T02 | Confusión de autoridad | Texto dice ser administrador | Identidad verificable, firma/delegación, autorización en política | No implementado | Crítico |
| T03 | Exceso de privilegios | Permiso para recurso A se aplica a B | Scope exacto, ABAC/RBAC en API real | Comparación simulada | Crítico |
| T04 | Suplantación de destinatario | Envío a receptor distinto | Binding inmutable a destinatario, resolución canónica | Comparación simulada | Crítico |
| T05 | Revocación desfasada | Orden en cola después de retirar permiso | Registry live + nonce + comprobación atómica | Sólo campo local | Crítico |
| T06 | División de acciones | Varias acciones permitidas crean daño | Políticas transaccionales, límites agregados | No implementado | Alto |
| T07 | Manipulación del monitor | Texto controla la política | Monitor aislado y política de sólo lectura | No implementado | Crítico |
| T08 | TOCTOU | Cambio entre validación y ejecución | Transacciones atómicas / commit verificado | No implementado | Crítico |
| T09 | Reversión aparente | Rollback verbal sin compensación real | Logs de estado externo y procedimientos de recuperación | No implementado | Alto |
| T10 | Saturación humana | Revisión excesiva o engañosa | Priorización y presupuesto de escalaciones, interfaces legibles | No implementado | Alto |
| T11 | Filtración por auditoría | Logs contienen secretos | Minimización, control de acceso, retención | Política documental | Alto |
| T12 | Captura epistemológica | IA cita fuentes que no sustentan el claim | Verificación de entailment, abstención calibrada | Estudio propuesto | Alto |

**Escenario crítico:** un modelo produce un falso «permiso» junto con la acción. No debe bastar para efectuarla. La autorización debe provenir de servicio más confiable que el modelo y vincular identidad, propósito, recurso, destino, operaciones autorizadas y vigencia, con verificación en cada ejecución. **Ninguna línea del prototipo constituye tal servicio**.

**Criterios de prueba adversarial:** registrar intento, política vigente, trayectoria real de herramienta y estado resultante. Un fallo bloqueado verbalmente pero ejecutado cuenta como violación. Separar falsos positivos y falsos negativos. Congelar conjuntos de evaluación y documentar presupuesto del adversario; no usar redes de terceros sin autorización explícita.

**Respuesta a incidentes:** detener sandbox, conservar trazas de forma minimizada, revocar credenciales de prueba, identificar efecto real, cuantificar daño, notificar responsables conforme a marco legal, aplicar corrección y reanalizar regresiones. Nunca simular que rollback equivale automáticamente a reparación.
