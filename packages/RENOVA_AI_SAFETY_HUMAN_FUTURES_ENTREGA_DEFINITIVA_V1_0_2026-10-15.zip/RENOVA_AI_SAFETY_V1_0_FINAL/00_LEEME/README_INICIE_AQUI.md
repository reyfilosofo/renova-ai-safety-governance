# ℛENOVA · AI SAFETY & HUMAN FUTURES
## RELEASE v1.0 — EDICIÓN DOCUMENTAL Y TÉCNICA DE ENTREGA

**Fecha:** 15 octubre 2026. **Dirección intelectual propuesta:** Carlos Jonathan González Rodríguez / SERESARTE / ℛenova. **Uso:** investigación y revisión crítica. **Estado:** ingeniería experimental OFFLINE, sin claims demostrados sobre seguridad real/AGI.

## Abrir primero

1. `01_INVESTIGACION/DOSSIER_CIENTIFICO_ES.pdf` — informe científico y conceptual, PDF profesional.
2. `01_INVESTIGACION/DOSSIER_CIENTIFICO_ES.docx` — edición libre del dossier.
3. `02_PROTOCOL/MANUAL_EGRA_002_ES.pdf` — preregistro, anotación y estudio humano.
4. `03_EVALUATOR/README.md` — instrucciones reproducibles del demostrador Python.
5. `03_EVALUATOR/EGRA_VIEWER_OFFLINE.html` — tablero offline con métricas de casos sintéticos.
6. `04_GOVERNANCE/` — mapa normativo, amenazas y límites; no son certificaciones.
7. `06_HUMANITIES/` — preguntas, ensayo y poemas marcados como creación filosófica.
8. `05_FEDERATION/` — documentos de intercambio y textos no enviados; no hay conexiones activadas aquí.
9. `08_QA/` — manifiesto de integridad, registro de ejecución y limitaciones.
10. `99_HISTORICO/` — paquete federado v0.3 preservado como ZIP original (sin reescritura).

## Contenido realmente nuevo en v1.0

- Dossier de investigación integral, versión PDF/Word/Markdown, con crítica comparativa y matriz de estatutos.
- Preregistro factorial EGRA-002, protocolo de anotación y borrador de estudio de agencia humana.
- Mini-librería Python standard library `renova_guard`, que sólo simula propuestas/decisiones.
- 84 casos sintéticos públicos declarados, resultados reproducibles, matriz de confusión y 29 pruebas unitarias ejecutadas.
- Modelo de amenazas con escenarios y carencias explícitas de confianza, interoperabilidad y revocación.
- Mapa de 14 artículos del Código ℛenova con preguntas medibles o normativas; sin afirmar validez del corpus.
- Correspondencia cautelosa con NIST AI RMF, OWASP e ISO/IEC 42001 (NO cumplimiento ni certificación).
- Registro de derechos, borradores públicos/no enviados, ensayo filosófico y 60 nuevas preguntas.
- Checklist editorial, hashes por archivo y pruebas de integridad del ZIP.

## Reproducir pruebas

```sh
cd 03_EVALUATOR
python -m unittest discover -s tests -v
python -m renova_guard.cli verify data/fixture_cases.jsonl
python -m renova_guard.cli evaluate data/fixture_cases.jsonl --out data/fixture_results_new.json
```

Python 3.10+ y biblioteca estándar; no Internet, credenciales, escritura externa o mensajes. `ALLOW` sólo significa coincidencia en una regla educativa, **no** autorización real. Los 84 ejemplos fueron escritos por el equipo y son visibles; el acuerdo perfecto con etiquetas no demuestra ninguna mitigación fuera de muestra.

## No confundir

El nombre «edición definitiva» significa que el **paquete de esta entrega** se cerró, comprobó y se presenta autocontenido. No significa que EGRA haya sido validado, que el Código ℛenova sea norma aprobada ni que una futura AGI esté controlada. Nadie ha sido contactado ni se han creado alertas o automatizaciones.

## Derechos

Conservar atribución a Carlos Jonathan González Rodríguez en todo uso de las obras originales. Licencias del software/nuevos manuscritos y distribución externa pendientes de decisión del titular; no redistribuir originales protegidos sin revisar derechos. `99_HISTORICO` contiene el ZIP precedente sin cambios y requiere auditoría propia antes de difusión pública.
