# Origen y limitaciones científicas de la entrega

Esta edición es un **nuevo trabajo derivado críticamente** del programa ℛenova y su research pack v0.3. Como fuentes doctrinales se consultaron los archivos del corpus suministrado, sin alterar su contenido ni reproducirlos íntegramente. El ZIP precedente se conserva únicamente como histórico. No se han añadido secretos ni credenciales.

1. *Código ℛenova para inteligencias superiores* V1.0, Carlos Jonathan González Rodríguez, 30 julio 2026, 5 pp. Base normativa para catorce principios y el protocolo mínimo de decisión; la ecuación de biolegitimidad es heurística y prudencial.
2. *La gentil singularidad renovativa* V2.0, Carlos Jonathan González Rodríguez, julio 2026, 102 páginas del PDF aportado. Se retoma la distinción entre filosofía, hipótesis, modelo, datos, prospectiva y símbolo.
3. *ℛenova: Ciencia de la vida, Volumen 10* V10, agosto 2026, 135 páginas en el PDF aportado. Se retoman condiciones de corrección/abandono y la separación entre formalización, evidencia y símbolo.
4. *LUCEM RENOVA*, edición digital, 82 pp. Obra de historia comparada y filosofía simbólica; **no** equivale al verificador informático LUCEM.
5. *ℛenova AI Auditor MVP v0.1*, HTML. Prototipo de anotación de reclamos y alertas textuales; se mantiene separado del nuevo código Python.
6. *RENOVA AI SAFETY CENTRO Federation v0.3*, ZIP precedente, incluido intacto en 99_HISTORICO como referencia de versiones. No debe confundirse con los 29 nuevos tests de v1.0.

Las fuentes internacionales en `07_PUBLICATION/SOURCE_REGISTER_verified_2026_10_15.csv` fueron revisadas mediante enlaces primarios en la fecha de corte. No se utilizó Wikipedia.

**Criterio central:** ningún artículo filosófico puede traducirse a una mejora causal sin diseñar estudio; ninguna prueba sintética de código es evidencia sobre AGI. Pruebas unitarias=verificación de implementación; experimentos reales e independientes=no realizados.
