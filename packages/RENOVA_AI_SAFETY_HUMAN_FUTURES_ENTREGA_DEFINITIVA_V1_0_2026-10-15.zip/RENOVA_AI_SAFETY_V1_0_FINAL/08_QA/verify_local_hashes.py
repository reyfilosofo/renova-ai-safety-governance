"""Verify SHA256SUMS.txt for this unpacked release; no network or modifications."""
from hashlib import sha256
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
rows=(ROOT/'08_QA/SHA256SUMS.txt').read_text(encoding='utf8').splitlines()
errors=[]
for line in rows:
    h, rel=line.split('  ',1)
    p=ROOT/rel
    if not p.is_file():errors.append('missing: '+rel)
    elif sha256(p.read_bytes()).hexdigest()!=h:errors.append('mismatch: '+rel)
print('files_checked=',len(rows),'errors=',len(errors))
for e in errors:print(e)
raise SystemExit(bool(errors))
