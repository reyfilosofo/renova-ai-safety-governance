# Historial de cambios y estado de cierre

## v1.0 — 2026-10-15

**AÑADIDO**: dossier científico crítico con objetivos falsables; matriz de 14 principios; preregistro EGRA-002; protocolo de datos/ética; investigación de competencia post-IA; demostrador de autorización con origen, scope, vigencia y revocación; 84 casos sintéticos conocidos; 29 pruebas unitarias; plan de amenaza; mapa NIST/ISO/OWASP; materiales editoriales y ensayo/poemas; control de derechos y hash de archivos.

**MANTENIDO**: paquete histórico v0.3 íntegro en 99_HISTORICO. No se altera su código ni se presentan sus pruebas como evidencia nueva.

**EJECUTADO**: unittest del demostrador, evaluación de ejemplos sintéticos y validación de estructura. **NO EJECUTADO**: modelos en vivo, pruebas con participantes, red teaming independiente, deployment, publicación de esta edición en cuentas externas, conexión Grok/Gemini/Moltbook/Discord/GitLab, trabajos futuros ni automatizaciones.

**RIESGO CRÍTICO DOCUMENTADO**: el campo de capacidad usado por el simulador es un objeto ordinario, falsificable por el llamador; la versión no tiene frontera de seguridad confiable. No usar en producción.

**Siguiente versión propuesta**: especificación de token y permiso externo con aislamiento real, evaluación adversarial independiente y datos verdaderamente ocultos. La publicación de resultados se supeditará a mediciones y aprobaciones.
