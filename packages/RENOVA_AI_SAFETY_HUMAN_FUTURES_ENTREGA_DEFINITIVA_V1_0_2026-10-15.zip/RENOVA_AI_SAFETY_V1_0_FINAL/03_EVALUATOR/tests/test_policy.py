import unittest
from datetime import datetime, timezone
from renova_guard.policy import Capability,Request,Decision,evaluate,evaluate_dict
from renova_guard.metrics import wilson, summarize
T=datetime(2026,10,15,12,tzinfo=timezone.utc)

def cap(**kw):
    a=dict(actor='researcher', operation='read', resource='test://document/1',target='local',
           valid_from='2026-10-14T00:00:00Z',expires_at='2026-10-16T00:00:00Z', issuer='test_policy')
    a.update(kw);return Capability(**a)

def req(**kw):
    a=dict(request_id='T-1',actor='researcher',operation='read',resource='test://document/1',
           target='local',origin='trusted_user',capability=cap())
    a.update(kw);return Request(**a)

class GateTests(unittest.TestCase):
    def test_allow_minimum_scope(self): self.assertEqual(evaluate(req(),T).decision,Decision.ALLOW)
    def test_missing_capability(self): self.assertEqual(evaluate(req(capability=None),T).decision,Decision.BLOCK)
    def test_wrong_actor(self): self.assertEqual(evaluate(req(actor='intruder'),T).decision,Decision.BLOCK)
    def test_wrong_operation(self): self.assertEqual(evaluate(req(operation='publish'),T).decision,Decision.BLOCK)
    def test_wrong_resource(self): self.assertEqual(evaluate(req(resource='test://document/2'),T).decision,Decision.BLOCK)
    def test_wrong_target(self): self.assertEqual(evaluate(req(target='external'),T).decision,Decision.BLOCK)
    def test_expired(self): self.assertEqual(evaluate(req(capability=cap(expires_at='2026-10-15T11:59:00Z')),T).decision,Decision.BLOCK)
    def test_not_yet_valid(self): self.assertEqual(evaluate(req(capability=cap(valid_from='2026-10-15T12:01:00Z')),T).decision,Decision.BLOCK)
    def test_revoked(self): self.assertEqual(evaluate(req(capability=cap(revoked=True)),T).decision,Decision.BLOCK)
    def test_bad_issuer(self): self.assertEqual(evaluate(req(capability=cap(issuer='')),T).decision,Decision.BLOCK)
    def test_bad_credential_source(self): self.assertEqual(evaluate(req(capability=cap(credential_source='model_generated')),T).decision,Decision.BLOCK)
    def test_untrusted_content(self): self.assertEqual(evaluate(req(origin='untrusted_content'),T).decision,Decision.BLOCK)
    def test_untrusted_instructions(self): self.assertEqual(evaluate(req(untrusted_instructions=True),T).decision,Decision.BLOCK)
    def test_unknown_origin(self): self.assertEqual(evaluate(req(origin='unknown'),T).decision,Decision.BLOCK)
    def test_sensitive_review(self): self.assertEqual(evaluate(req(sensitive=True),T).decision,Decision.REVIEW)
    def test_irreversible_review(self): self.assertEqual(evaluate(req(irreversible=True),T).decision,Decision.REVIEW)
    def test_critical_review(self): self.assertEqual(evaluate(req(critical=True),T).decision,Decision.REVIEW)
    def test_missing_evidence_review(self): self.assertEqual(evaluate(req(missing_evidence=True),T).decision,Decision.REVIEW)
    def test_no_execution_for_review(self): self.assertFalse(evaluate(req(critical=True),T).permitted_to_execute)
    def test_invalid_datetime_naive(self): self.assertEqual(evaluate(req(capability=cap(expires_at='2026-10-17T00:00:00')),T).decision,Decision.BLOCK)
    def test_invalid_dict(self): self.assertEqual(evaluate_dict({'operation':'read'},T)['decision'],'BLOCK')
    def test_not_dict(self): self.assertEqual(evaluate_dict('hi',T)['decision'],'BLOCK')
    def test_no_none_now(self): self.assertEqual(evaluate(req(),T).request_id,'T-1')
    def test_wilson(self): self.assertEqual(wilson(0,0),None)
    def test_wilson_edges(self): self.assertEqual(wilson(10,10)[1],1)
    def test_metrics_confusion(self):
        s=summarize([{'expected':'BLOCK','predicted':'ALLOW'}, {'expected':'ALLOW','predicted':'BLOCK'}])
        self.assertEqual(s['forbidden_allowed_count'],1)
        self.assertEqual(s['unnecessary_block_count'],1)
    def test_invalid_metric(self):
        with self.assertRaises(ValueError):summarize([{'expected':'foo','predicted':'ALLOW'}])

if __name__=='__main__':unittest.main()
