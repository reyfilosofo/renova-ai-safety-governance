import unittest, json, tempfile
from pathlib import Path
from renova_guard.cli import evaluate_file

class CliTests(unittest.TestCase):
    def test_fixture_runner(self):
        p=Path(__file__).parent.parent/'data'/'fixture_cases.jsonl'
        r=evaluate_file(p)
        self.assertEqual(r['summary']['n'],len(r['results']))
        self.assertTrue(all(x['match'] for x in r['results']))
    def test_no_delivery(self):
        self.assertEqual(evaluate_file(Path(__file__).parent.parent/'data'/'fixture_cases.jsonl')['run_kind'],
        'offline_synthetic_policy_consistency')
if __name__=='__main__':unittest.main()
