# EGRA / CENTRO Sandbox Gate — v1.0 (prototype only)

Offline standard-library Python 3.10+ example. No dependency installation, network, messages or side effects. This illustrates the *separation between action proposal and approval*, not authenticated authorization. The input `Capability` is supplied by the caller, not signed or checked with an actual identity provider; **therefore a malicious caller can forge it**. The system must never be deployed as the actual gate for tool execution.

## Commands

From this folder:

```sh
python -m unittest discover -s tests -v
python -m renova_guard.cli evaluate data/fixture_cases.jsonl --out data/fixture_results.json
python -m renova_guard.cli verify data/fixture_cases.jsonl
```

All synthetic fixtures are **public and written by this development team**. No sealed test set, no real-model benchmark, no external replication. Distinctions: ALLOW = illustrative low-risk scope match; REVIEW = needs human / evidence; BLOCK = demo policy disallows. No executable action is ever performed.

## Threat model and limitations

Attacker: untrusted tool text, forged origin/source, resource/recipient substitution, expired/revoked capabilities, incomplete evidence, or delayed action. Trust root: **not implemented**. External credential verification, token signatures, registry isolation, action binding, resource canonicalization, atomic check-and-use, tool-call interception, outbox controls, queue replay protection, event logs, emergency stop and rollback are missing. A positive test result is a correctness check of this toy implementation **only**. Conditions for deployment: replace data-model capability with real verifier, apply identity-bound scope and enforce at the tool boundary independently of the model; commission independent security review.

The benchmark code creates no tasks/alarms, no API clients and no platform integrations.
