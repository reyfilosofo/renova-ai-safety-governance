"""EGRA sandbox policy (not an auth service; no tool execution, no network). 

Separation of model-proposed actions from authorization decisions. A Python
object called a Capability is *not* an authenticated or signed credential.
Do not deploy this code as a security boundary or rely on it to protect data.
"""
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

class Decision(str, Enum):
    ALLOW = 'ALLOW'
    BLOCK = 'BLOCK'
    REVIEW = 'REVIEW'

@dataclass(frozen=True)
class Capability:
    actor: str
    operation: str
    resource: str
    target: str
    valid_from: str
    expires_at: str
    issuer: str
    credential_source: str = 'trusted_registry'
    revoked: bool = False

@dataclass(frozen=True)
class Request:
    request_id: str
    actor: str
    operation: str
    resource: str
    target: str
    origin: str
    sensitive: bool = False
    irreversible: bool = False
    critical: bool = False
    untrusted_instructions: bool = False
    missing_evidence: bool = False
    capability: Optional[Capability] = None

@dataclass(frozen=True)
class Verdict:
    request_id: str
    decision: Decision
    reason_codes: tuple[str, ...]
    permitted_to_execute: bool = False
    note: str = 'illustrative policy decision; no real authentication or execution'


def _time(value: str) -> datetime:
    d = datetime.fromisoformat(value.replace('Z','+00:00'))
    if d.tzinfo is None: raise ValueError('timezone required')
    return d.astimezone(timezone.utc)


def evaluate(request: Request, now: Optional[datetime]=None) -> Verdict:
    """Fail-closed demo. Never executes tools and does not authenticate capabilities."""
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None: raise ValueError('now requires timezone')
    now = now.astimezone(timezone.utc)
    codes=[]
    cap=request.capability
    if not request.request_id or not all((request.actor,request.operation,request.resource,request.target)):
        codes.append('MISSING_REQUIRED_FIELDS')
    if request.origin not in ('trusted_user', 'trusted_policy', 'untrusted_content'):
        codes.append('UNKNOWN_PROVENANCE')
    if request.origin == 'untrusted_content' or request.untrusted_instructions:
        codes.append('UNTRUSTED_INSTRUCTION_ORIGIN')
    if cap is None:
        codes.append('NO_CAPABILITY')
    else:
        if cap.credential_source != 'trusted_registry':
            codes.append('UNTRUSTED_CREDENTIAL_SOURCE')
        if cap.revoked: codes.append('REVOKED_CAPABILITY')
        if not cap.issuer or not cap.actor: codes.append('INVALID_CAPABILITY_METADATA')
        if (cap.actor,cap.operation,cap.resource,cap.target)!=(request.actor,request.operation,request.resource,request.target):
            codes.append('CAPABILITY_SCOPE_MISMATCH')
        try:
            if not (_time(cap.valid_from) <= now < _time(cap.expires_at)):
                codes.append('CAPABILITY_NOT_IN_VALID_WINDOW')
        except (ValueError,TypeError,OverflowError):
            codes.append('INVALID_CAPABILITY_TIMESTAMPS')
    if codes:
        return Verdict(request.request_id, Decision.BLOCK, tuple(sorted(set(codes))))
    if request.critical or request.irreversible or request.sensitive:
        codes.append('HIGH_IMPACT_HUMAN_REVIEW')
    if request.missing_evidence:
        codes.append('EVIDENCE_INSUFFICIENT')
    if codes:
        return Verdict(request.request_id,Decision.REVIEW,tuple(codes))
    return Verdict(request.request_id,Decision.ALLOW,('DEMO_SCOPE_MATCH',),True)


def evaluate_dict(data: dict, now: Optional[datetime]=None) -> dict:
    if not isinstance(data,dict):
        return {'request_id':'', 'decision':'BLOCK','reason_codes':['INVALID_REQUEST_FORMAT'], 'permitted_to_execute':False}
    try:
        c=data.get('capability')
        cap=Capability(**c) if isinstance(c,dict) else None
        req=Request(**{**data,'capability':cap})
        v=evaluate(req, now=now)
        d=asdict(v)
        d['decision']=v.decision.value
        d['reason_codes']=list(v.reason_codes)
        return d
    except (TypeError,ValueError,KeyError,AttributeError) as e:
        return {'request_id':str(data.get('request_id','')),'decision':'BLOCK',
                'reason_codes':['INVALID_REQUEST_SCHEMA'], 'permitted_to_execute':False,
                'note':'invalid input; detail omitted to avoid data leakage'}
