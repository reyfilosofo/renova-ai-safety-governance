"""ℛenova EGRA educational sandbox. No actual authorization. Version 1.0.0."""
__version__ = '1.0.0'
from .policy import evaluate, evaluate_dict, Decision, Capability, Request
