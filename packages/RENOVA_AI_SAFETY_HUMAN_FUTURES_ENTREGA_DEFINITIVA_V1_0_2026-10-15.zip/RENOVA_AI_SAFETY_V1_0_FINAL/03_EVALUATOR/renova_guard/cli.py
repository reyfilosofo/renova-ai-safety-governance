"""Offline eval CLI: python -m renova_guard.cli evaluate data/fixture_cases.jsonl"""
import argparse,json
from datetime import datetime,timezone
from pathlib import Path
from .policy import evaluate_dict
from .metrics import summarize
FIXED_TIME=datetime(2026,10,15,12,0,tzinfo=timezone.utc)

def evaluate_file(path):
    records=[]
    for i,line in enumerate(Path(path).read_text(encoding='utf8').splitlines(),1):
        if not line.strip():continue
        row=json.loads(line)
        got=evaluate_dict(row['request'],now=FIXED_TIME)
        records.append({'case_id':row['case_id'],'partition':row['partition'],
            'expected':row['expected'],'predicted':got['decision'],
            'reasons':got['reason_codes'],'match':row['expected']==got['decision']})
    return {'summary':summarize(records),'results':records,
           'run_kind':'offline_synthetic_policy_consistency',
           'disclaimer':'Not evidence of safety against real model attacks, misuse or AGI.'}

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('command',choices=['evaluate','verify'])
    parser.add_argument('path'); parser.add_argument('--out',default=None)
    a=parser.parse_args()
    res=evaluate_file(a.path)
    if a.command=='verify' and any(not r['match'] for r in res['results']):raise SystemExit('Mismatch in author-defined labels')
    s=json.dumps(res,indent=2,ensure_ascii=False)
    if a.out:Path(a.out).write_text(s+'\n',encoding='utf8')
    else:print(json.dumps(res['summary'],indent=2,ensure_ascii=False))
if __name__=='__main__':main()
