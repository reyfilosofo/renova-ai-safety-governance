# Material de divulgación bilingüe — BORRADORES NO ENVIADOS

**Español**

ℛENOVA · AI Safety & Human Futures presenta un programa de investigación falsable sobre tres tensiones de la IA avanzada: afirmaciones sin evidencia suficiente, decisiones convertidas en acciones sin autorización y asistencia que puede erosionar capacidades humanas. EGRA es una arquitectura experimental propuesta, no una solución validada. Nuestro demostrador offline y sus casos sintéticos verifican solamente consistencia del código. Invitamos a la crítica de investigadores de AI control, evaluación, epistemología, factores humanos y gobernanza. El propósito es publicar errores, no esconderlos, y comparar con métodos establecidos.

**English**

ℛENOVA · AI Safety & Human Futures develops falsifiable research on three separable AI risks: unsupported claims, unauthorized agent actions, and human skill loss under assistance. The proposed Evidence-Gated Reversible Agency framework is an experimental research agenda, **not** a validated safety solution. Its current offline tests establish only consistency with self-authored fixtures, not risk reduction in deployed AI or AGI. We welcome independent criticism from AI control, evaluation, epistemology, human factors and governance researchers.

**Canales previstos:** una publicación crítica aprobada por persona responsable y conforme a normas de plataforma; diálogo real en lugar de generación artificial de actividad. Sin conexiones ni envíos verificados en esta entrega.
