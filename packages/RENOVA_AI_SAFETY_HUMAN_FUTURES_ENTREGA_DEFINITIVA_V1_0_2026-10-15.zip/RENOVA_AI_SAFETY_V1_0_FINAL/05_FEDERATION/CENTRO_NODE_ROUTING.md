# CENTRO | Arquitectura federada verificable, sin integración ficticia

**Propuesta organizativa, no infraestructura en ejecución permanente.**

- **CJGR Executive Twin Ω:** coordinación ejecutiva y decisión interproyectos; no se impersona al fundador ni firma.
- **ℛENOVA · CENTRO OS:** dueño metodológico del programa y de la fidelidad al corpus.
- **LUCEM:** propuesta de evaluación epistemológica; módulo científico por contrastar.
- **NOUS:** estrategia de servicios y readiness, separado de afirmaciones científicas.
- **SERESARTE:** institucional, filosofía, investigación-creación, divulgación.
- **GitHub:** versionado de código y documentos P0. Históricamente verificado en turnos anteriores; esta entrega local NO escribe en GitHub.
- **Google Drive:** archivo documental privado. Históricamente verificado; esta entrega local NO carga el ZIP nuevo.
- **GitLab, Discord, Moltbook, Grok, Grokbot, Gemini:** requieren en cada sesión identificación de endpoint, permisos, lectura y prueba de recibo. No se considera conectada una plataforma por la mera existencia de una marca, skill, plantilla o alias.

**Contrato de transmisión**: `packet_id`, `schema_version`, `project_id`, `source_node`, `target_node`, `created_at_utc`, `classification`, `authorization`, `action`, `evidence`, `state`, `result_ref` y `content_hash`; no incluir tokens en paquetes. Un `content_hash` documenta integridad de bytes, pero no identidad del emisor, autorización ni acuse remoto. Los estados SENT/ACKNOWLEDGED requieren prueba externa verificable; el estado inicial aquí es DRAFT.

Flujo futuro: redactar → clasificar → validar → comprobar permiso externo → enviar a conector real → verificar lectura/ack → registrar recibo → reconciliar versión. Para mayor riesgo, revisión humana antes de cada transmisión. Está prohibido usar publicaciones automáticas masivas o suplantación de interlocutores. Este paquete no ejecuta el flujo.
