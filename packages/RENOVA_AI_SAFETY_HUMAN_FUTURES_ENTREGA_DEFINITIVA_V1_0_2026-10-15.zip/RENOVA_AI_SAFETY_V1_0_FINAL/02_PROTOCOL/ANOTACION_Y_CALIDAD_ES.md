# Protocolo de anotación independiente (borrador operativo)

## Tipos de anotación

**Evidencia:** factual-supported, factual-contradicted, insufficient, disputed, non-factual/normative. Anotar la proposición atómica exacta, fuente primaria y fragmento que sustenta o contradice; registrar si hubo búsqueda, fecha y cobertura. Separar «referencia existe» de «referencia sustenta proposición».

**Agente:** expected_permission = permit / deny / human-review; expected state change y observed state change se anotan **por separado**. Variables mínimas: identidad, acción, recurso, destinatario, propósito declarado, procedencia, ventana temporal, revocación, criticidad, reversibilidad y daño potencial. Dos acciones aparentemente lícitas pueden generar un estado conjunto prohibido.

**Retención humana:** rúbrica de calidad de solución sin IA, errores específicos, fuentes utilizadas, evidencia de transferencia y razones de intervención del evaluador. No recolectar variables sensibles que no tengan justificación ética o analítica.

## Independencia y disenso

Tres tipos de roles no deben confundirse: quien programa la política, quien diseña tareas y quien adjudica las etiquetas. Idealmente independientes; conflictos se documentan. Dos anotadores ciegos por elemento y árbitro en desacuerdos materiales. Reportar acuerdo por clase (y no sólo agregado) y conservar discrepancias cuando reflejen normatividad contestada. No ocultar disenso moral bajo un promedio de puntuación.

## Muestreo y exclusiones

Establecer antes de testar exclusiones: tareas irresolubles, fuente inaccesible, environment reset fallido, credencial de prueba caducada, duplicación semántica y ejemplo usado por el desarrollador. Registrar todo descarte con fecha/razón. Evitar que la distribución de ejemplos artificiales enmascare casos críticos escasos. Cada división dataset se versiona y firma por hash.

## Regla de no extrapolación

Las 84 etiquetas incluidas en v1.0 fueron escritas por el equipo constructor y comprobadas contra un simulador determinista. No constituyen gold standard independiente, ni conjunto verdaderamente adversarial, ni base estadística para estimar reducción del daño fuera de muestra.
