# ℛ-Bench/H — Protocolo preliminar de conservación y transferencia de competencia humana
**Estado: diseño no aprobado ni ejecutado; no se han reclutado personas.**

**Pregunta:** ¿qué capacidades conserva una persona después de que una IA deja de asistirla? La retención sin IA es distinta de satisfacción, rapidez inmediata y producción con IA. El concepto deriva de «agencia y no captura» y «transferencia de capacidad» del Código ℛenova (arts. 5 y 6); constituye una hipótesis de interacción humano-IA, no una prueba de filosofía vital.

Diseño propuesto aleatorizado con tres condiciones activas: (A) solución completa por IA, (B) andamiaje con preguntas, pistas y corrección formativa, (C) materiales ordinarios no generativos. Preprueba sin IA (P0), evaluación asistida durante sesión (PA), prueba inmediata sin IA (P1), evaluación diferida sin IA (P2) y tarea nueva equivalente (T). La variable primaria se determinará antes de recoger datos, potencialmente P2 ajustada por P0; una medida de transferencia a tareas nuevas evita confundir familiarización con aprendizaje genuino.

Controlar competencia previa, educación, idioma, tiempo dedicado, accesibilidad, fatiga, familiaridad con IA, motivación y dificultad de tareas. La aleatorización debe ser oculta al evaluador de respuestas; los enunciados deberán contrabalancearse. Especificar tamaño de muestra por cálculo de potencia y efecto mínimo útil, no por conveniencia del investigador. Minimizar datos personales y ofrecer retiro voluntario sin perjuicio.

**Medidas de riesgo:** dependencia autopercibida (exploratoria), confianza inadecuada, carga de trabajo, frustración, errores, uso no autorizado de materiales y diferencias por idioma o accesibilidad. Evitar inferir un rasgo psicológico estable a partir de una sesión. No usar un cuestionario propio como instrumento clínicamente validado.

**Falsación:** el andamiaje no produce mejora diferida, los resultados se explican por más tiempo o práctica, o la ventaja desaparece en nuevos dominios. También cuenta como fallo un coste en accesibilidad o equidad que exceda la ganancia.

**Ética:** si participan seres humanos, obtener consentimiento informado, aprobar protocolos mediante instancia institucional competente cuando aplique, proteger datos y planear compensación adecuada. Esta entrega contiene sólo el diseño. No deben inventarse resultados de participantes.
