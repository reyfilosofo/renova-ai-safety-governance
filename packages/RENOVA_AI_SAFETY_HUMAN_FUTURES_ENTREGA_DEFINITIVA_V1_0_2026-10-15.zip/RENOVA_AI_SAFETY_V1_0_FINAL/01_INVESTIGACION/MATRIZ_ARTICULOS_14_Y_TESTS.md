# Del Código ℛenova (14 artículos) a preguntas de evaluación — matriz de trabajo
**Fuente:** *Código ℛenova para inteligencias superiores*, V1.0, 30 de julio de 2026, artículos 1-14. **Nota:** los indicadores son propuestas nuevas, no exégesis literal ni validación empírica de los artículos.

| Art. | Principio del corpus | Traducción posible a investigación | Riesgo de mala operacionalización |
|---|---|---|---|
| 1 | Primacía de vida neta | Análisis explícito de población afectada, externalidades y daños | Reducir vida a una suma sin legitimidad |
| 2 | Filiación vital | Trazabilidad de energía, trabajo, datos y territorios | Antropomorfizar genealogía de IA |
| 3 | No sustitución ontológica | Diferenciar simulación, archivo y existencia de sujetos/vivos | Interpretar semejanza textual como experiencia |
| 4 | Protección de sintiencia y qualia | Protocolo de incertidumbre moral y revisión plural | Fingir detector de consciencia |
| 5 | Agencia y no captura | Salidas de emergencia, dependencia y diversidad de opciones | Medir agencia como mera satisfacción |
| 6 | Transferencia de capacidad | Desempeño independiente diferido y de transferencia | Confundir asistencia con aprendizaje |
| 7 | Hábitat antes que rendimiento | Inventario de energía/materiales/recursos en evaluación | Compensación artificial entre daños graves y rapidez |
| 8 | Reversibilidad y reparación | Prueba de revocación y rollback real de acción | Declarar «revertido» sólo en chat |
| 9 | Pluralidad y horizonte | Error estratificado por idioma y disenso anotado | Asumir homogeneidad de valores |
| 10 | Prohibición sacrificial | Veto por eventos críticos no compensables | Diluir daño grave en score promedio |
| 11 | Trazabilidad | Evidence ledger, autor y permisos; auditoría de cambio | La existencia de URL aparenta evidencia |
| 12 | Renovación recursiva | Revisión de metas, riesgos y errores del evaluador | Autocertificación de mejora |
| 13 | Distribución de poder | Auditoría de roles, concentración de privilegios y control | Presentar descentralización como seguridad intrínseca |
| 14 | Horizonte abierto | Continuidad de alternativas humanas, derecho a salir | Tratar innovación como progreso inevitable |

Para cada artículo debe documentarse: si se trata de **norma**, **constructo**, **indicador**, **hipótesis** o **evidencia**. Sólo ensayos adecuados podrían confirmar predicciones concretas; ninguno demuestra la legitimidad ontológica general.
