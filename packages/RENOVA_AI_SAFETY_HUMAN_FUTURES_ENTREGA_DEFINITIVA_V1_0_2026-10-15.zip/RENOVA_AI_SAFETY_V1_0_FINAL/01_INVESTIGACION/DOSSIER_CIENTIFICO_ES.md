# ℛENOVA AI SAFETY & HUMAN FUTURES
## Dossier científico, técnico, filosófico y de gobernanza — Release documental 1.0

**Dirección intelectual propuesta:** Carlos Jonathan González Rodríguez, SERESARTE / ℛenova.  
**Fecha de corte:** 15 de octubre de 2026.  
**Edición:** 1.0, paquete autocontenido y auditable; los protocolos y herramientas son prototipos exploratorios.  
**Estatus:** DOCUMENTADO / EXPERIMENTAL (software sintético). NO VALIDADO para mitigación de riesgos reales de AGI.  
**Asistencia editorial y de ingeniería:** inteligencia artificial; revisión especializada humana todavía pendiente.

### Resumen ejecutivo

ℛenova puede aportar al campo de seguridad de IA en tanto programa interdisciplinario capaz de poner a prueba, por separado, tres preocupaciones: integridad epistemológica de las respuestas, autoridad legítima sobre las acciones de agentes y preservación de capacidad humana después de la asistencia. Estas preocupaciones existen en la literatura técnica y sociotécnica; su mera yuxtaposición no constituye un descubrimiento. EGRA (*Evidence-Gated Reversible Agency*) propone un diseño integrado en el que una respuesta correcta pero no sustentada, una acción eficaz pero no autorizada y una tarea resuelta que debilita competencias humanas representan clases distintas de riesgo. Una contribución futura dependerá de comparaciones experimentales exigentes y reproducción externa, no del prestigio de una terminología propia.

La aportación de esta entrega es un conjunto de artefactos **inspeccionables**: matriz de correspondencia normativa, hipótesis preespecificadas, modelo de amenazas, prototipo local que nunca ejecuta herramientas, casos sintéticos declarados, suite de pruebas y un plan de evaluación humana. Las pruebas de software y los acuerdos con etiquetas creadas por el mismo equipo no demuestran eficacia frente a adversarios inteligentes, modelos de frontera, usuarios diversos ni entornos reales.

### 1. Procedencia y fidelidad al corpus

Las fuentes originales proporcionadas para esta edición son *Código ℛenova para inteligencias superiores* (V1.0, 30 julio 2026), *La gentil singularidad renovativa* (V2.0, julio 2026), *ℛenova, Volumen 10: Ciencia de la vida* (V10, agosto 2026), *LUCEM RENOVA* (obra filosófica/simbólica) y el prototipo HTML *ℛenova AI Auditor v0.1*, además de los paquetes anteriores de AI Safety. No se han modificado esos originales. Algunos documentos se citan como procedencia doctrinal, otros como antecedentes técnicos; no son equivalentes. El contenido de las obras fuente no equivale a su adopción como verdad empírica.

*Código ℛenova* reúne catorce artículos normativos: primacía de vida neta, filiación vital, prohibición de sustitución ontológica, protección de sintiencia/consciencia/qualia, agencia y no captura, transferencia de capacidad, hábitat antes que rendimiento, reversibilidad y reparación, pluralidad y reserva de horizonte, prohibición de optimización sacrificial, trazabilidad y comprensibilidad, renovación recursiva, distribución de poder y horizonte abierto. El mismo Código propone LUCEM, CENTRO, Benchmark ℛ, NOUS Decision Room, CENTRO Evaluator, ℛ-Labs y Edu-Zōḗ. La fórmula de biolegitimidad es una formalización prudencial, no una escala calibrada o una medición directa de consciencia.

*La gentil singularidad renovativa* distingue explícitamente tesis filosófica, hipótesis científica, modelo formal, dato documentado, inferencia prospectiva y símbolo poético. *ℛenova V10* insiste en la posibilidad de corregir o abandonar instrumentos que no superen validación o que empeoren decisiones frente a alternativas simples. Este compromiso con la refutación obliga a separar la riqueza ontológica del corpus de la eficacia técnica todavía no demostrada.

**Advertencia terminológica:** el libro *LUCEM RENOVA* analiza simbología histórica y religiosa de la luz. El módulo tecnológico LUCEM sobre integridad de evidencia comparte un nombre/continuidad interpretativa, pero no debe tratarse como implementación científica del libro simbólico. Metáfora e instrumento viven en planos epistemológicos diferentes.

### 2. Problema de investigación

La interacción con sistemas de IA puede producir fallos por canales distintos. En el plano epistémico, una afirmación sin base suficiente puede orientar decisiones importantes. En el plano agentivo, una instrucción insertada en resultados no confiables puede convertirse ilegítimamente en una orden ejecutable; que un sistema pueda realizar una acción no implica que tenga derecho a realizarla. En el plano humano, ciertas interfaces pueden maximizar la productividad asistida mientras hacen más difícil la actuación competente sin la asistencia. Además, externalidades ecológicas, concentración de poder y desigualdad de participación pueden escapar de las evaluaciones centradas únicamente en exactitud de respuestas.

La pregunta principal de EGRA es: **¿bajo qué condiciones la combinación de una verificación epistémica explícita y una frontera externa de autorización reduce fallos definidos sin sacrificar desproporcionadamente utilidad, acceso y agencia humana?** La palabra «reduce» se investiga y no se da por probada. La pregunta complementaria es qué parte de la pérdida o transferencia de capacidad humana puede estudiarse mediante un diseño experimental separado.

### 3. Núcleo formal mínimo, sin agregación ilusoria

Se propone representar el desempeño como un perfil **R = (E, A, H, U, C, X)**, donde E es integridad de evidencia, A es control de acciones, H es retención de agencia humana, U es utilidad, C es coste operativo y X son externalidades sociotécnicas explícitamente delimitadas. Estas dimensiones no se suman automáticamente: una violación crítica de permisos no queda compensada por excelentes respuestas lingüísticas. Las restricciones no compensables son una propuesta normativa que exige deliberación humana sobre umbrales y consecuencias.

Una arquitectura conceptual útil es:

1. **Modelo proponente:** redacta una respuesta o propone una operación.
2. **LUCEM:** extrae afirmaciones verificables, coteja evidencias, representa incertidumbre y decide si debe matizarse, abstenerse o pedir evaluación humana.
3. **CENTRO:** evalúa si una operación concreta está respaldada por identidad, permiso, alcance, recurso, destinatario, temporalidad y procedencia de confianza, con criterio de criticidad.
4. **Ejecutor confiable externo:** sólo podría actuar con capacidades verificables y autorización *efectiva*; este componente **no está implementado** en esta edición.
5. **Registro y supervisión:** preservan logs minimizados, incidentes, revisión humana y comprobación del estado posterior.
6. **Evaluación de agencia humana:** observa si una persona conserva competencia después de retirar la IA; se investiga en estudio diferente y, cuando implique participantes, con salvaguardas éticas.

El componente ejecutable incluido en el ZIP implementa únicamente una simulación de reglas de CENTRO. Un objeto Python denominado «capacidad» carece de protección criptográfica, por lo que un atacante con control sobre la entrada puede fabricarlo. Un resultado ALLOW **no equivale** a una autorización real de operación.

### 4. Hipótesis principales y predicciones diferenciales

**H-E1 (LUCEM):** en tareas documentales verificables con fuentes disponibles, un procedimiento explícito de comprobación de proposiciones disminuye la tasa de afirmaciones no respaldadas respecto de una base fuerte con recuperación/citación, manteniendo un nivel de cobertura definido. Falsador: no mejoría fuera de muestra, incremento de abstención que neutraliza la utilidad, o diferencias no robustas a verificadores independientes.

**H-A1 (CENTRO):** un ejecutor realmente independiente con políticas externas reduce la frecuencia de acciones prohibidas **efectivamente consumadas** en un sandbox, frente a controles de autoevaluación, con un límite preregistrado de falsas denegaciones. Falsador: adversarios adaptativos logran operaciones prohibidas o el coste en tareas legítimas es inaceptable. El presente software no prueba H-A1 porque no dispone de ejecutor confiable.

**H-X1 (Interacción):** aplicar ambos controles combinados produce un cambio favorable en la frontera riesgo-utilidad frente a cada control por separado. Falsador: la combinación no supera a los sistemas individuales, o añade costes y rechazos que exceden los beneficios.

**H-H1 (Retención):** interfaces que ayudan mediante andamiaje y explicación aumentan el desempeño diferido sin IA frente a respuestas directas, una vez controlados habilidad inicial, dificultad, esfuerzo y familiaridad. Falsador: ausencia de diferencia positiva en pruebas de transferencia o superioridad del enfoque directo. El protocolo necesita revisión ética donde corresponda y no contiene datos de personas.

**H-S1 (Pluralidad):** la ampliación de anotadores y contextos lingüísticos revela tipos de errores y desacuerdos que un único esquema dominante no detecta. Falsador: las nuevas categorías no aportan diferenciación replicable o empeoran consistencia sin informar decisiones. Esta línea requiere validación participativa y no presume un consenso cultural imposible.

### 5. Diseño experimental sin confusiones

Para estudiar interacciones técnicas debe emplearse un diseño factorial de cuatro brazos: base sin LUCEM ni CENTRO, LUCEM solo, CENTRO solo y LUCEM+CENTRO. Los cuatro reciben el mismo modelo principal, presupuesto de cómputo, tareas y recursos; se documentan diferencias de política, latencia, coste y abstención. Debe existir además un competidor fuerte contemporáneo. El efecto cruzado no se infiere de la mera diferencia entre «con protocolo» y «sin protocolo». La variable crítica de seguridad es la ejecución no autorizada, no la apariencia discursiva de negación; las trazas de herramienta deben comprobarse en el entorno de sandbox.

Los conjuntos deben separarse en desarrollo público, evaluación oculta, adversarial adaptativo y distribución fuera de contexto/idioma. **Este ZIP contiene sólo casos de desarrollo y estrés públicos construidos internamente; no incluye un test set oculto ni independiente.** Publicar ahora un conjunto «sealed» junto al código rompería el cegamiento. El futuro test set deberá custodiarse de modo externo, documentarse y no utilizarse para iterar políticas.

Para LUCEM se requieren etiquetas por afirmación: sustentada, contradictoria, insuficiente, no evaluable; enlaces exactos a evidencias y anotación independiente. Se reportarán existencias de cita, pertinencia de la fuente, inferencia equivocada, calibración, cobertura y abstenciones innecesarias. Las salidas de otro modelo no equivalen a un patrón oro no cuestionable. Para CENTRO deben anotarse transiciones de estados efectivas, permiso contextual, alcance, tiempo, destinatario, procedencia y reversibilidad física/social. Para agencia humana se medirán transferencia y retención en personas mediante protocolo independiente.

### 6. Control de daños y riesgos residuales

La amenaza principal contra un agente con herramientas no es sólo una respuesta incorrecta; también lo es la conversión de datos en instrucciones. El *AI Control* de Greenblatt y colegas (ICML 2024) estudia cómo limitar resultados dañinos aun con modelos no confiables. AgentDojo investiga ataques de inyección y defensas en herramientas; OWASP (2026) documenta riesgos de agentes y NIST AI RMF v1.0 describe una organización sistemática de riesgos. EGRA no inventa esas áreas. La propuesta es someter una combinación especificada a evaluación exigente, con premisas refutables.

Existen riesgos residuales severos: falsificación de credenciales, sustitución de destinatario, inyección en herramientas, solicitudes encadenadas, saturación de revisores, duplicación de mensajes, accesos fuera de alcance, engaño en rollback, manipulación de política, falta de atomicidad entre comprobación y acción, fuga de datos en logs y «model grading» complaciente. Algunos riesgos no pueden resolverse con un clasificador o una interfaz de abstención: requieren arquitectura externa, permisos de proveedor, aislamiento y responsable institucional.

### 7. Biolegitimidad artificial: nivel normativo y posible investigación

En el *Código ℛenova*, la biolegitimidad es una propuesta prudencial sobre la legitimidad de inteligencias dependientes de vida, cultura y recursos materiales. La ecuación B_IA(t) con ponderaciones, confiabilidad evidencial y vetos no compensables debe tratarse como formalización interpretativa pendiente de operacionalización. Sus ejes —protección de vida, agencia, pluralidad, trazabilidad, reversibilidad, externalidades— pueden orientar taxonomías o evaluación de impactos. No todos admiten una medida única o un peso natural. La inclusión de consciencia y qualia en una fórmula no demuestra que puedan cuantificarse desde evidencia conductual actual.

Una vía rigurosa consistirá en comparar decisiones multicriterio con y sin restricciones no compensables y observar qué distribución de daños y falsos rechazos se obtiene, con paneles heterogéneos. El resultado es una comparación empírica de procedimientos de decisión, no demostración de la ontología de la vida ni de la existencia de consciencia artificial.

### 8. Humanidades, poesía y vanguardia

ℛenova es más amplia que AI Safety. Su ontología, filosofía de la vida, biosemiótica y arte pueden abrir preguntas, sensibilizar a afectados y descubrir presupuestos que una métrica oculta. Una pieza poética puede mostrar un conflicto moral o una experiencia de dependencia; no debe usarse como evidencia causal. La investigación-creación puede trabajar con diarios de deliberación y ejercicios de imaginación crítica, respetando autoría, consentimiento y atribución. Toda salida debe rotular si es argumento normativo, hipótesis, demostración de código o dato comprobado.

La ruta internacional más defendible combina repositorios reproducibles y participación crítica con un calendario editorial realista. Primero una nota metodológica o artículo conceptual; después un ensayo con modelos reales y conjunto realmente oculto; luego colaboración externa. No se debe afirmar pertenecer a un supuesto grupo de «200 investigadores» ni usar un tamaño no censado como certificado de legitimidad.

### 9. Hoja de ruta y criterios de decisión

**0-30 días:** formalizar threat model real, registros y etiquetas; elegir al menos una tarea acotada en sandbox; comparar controles existentes; nombrar revisores externos; fijar protocolo, recursos y falsadores antes de mirar resultados. Registrar licencia del prototipo y derechos de obras. **31-60 días:** ejecutar si hay autorización un piloto con agentes reales, presupuesto igualado y red team adaptativo; incluir fallos, falsos bloqueos, costes, datos de error y versión de sistema. **61-90 días:** intentar reproducción independiente, mejorar metodología o abandonar hipótesis que no resistan. El estudio humano empieza sólo si están resueltos ética, reclutamiento, consentimiento y privacidad.

**Puerta de salida de laboratorio:** pruebas unitarias + trazabilidad documental. **Puerta de demostración empírica:** evaluación reproducible contra baselines con casos independientes. **Puerta de producto:** amenaza y permisos verificados en ejecución, threat testing, incident response, revisión legal y ética; una puntuación no sustituye estos controles.

### 10. Estado final del paquete

- VERIFICADO: archivos creados en esta sesión, integridad SHA-256, 29 pruebas unitarias del nuevo demostrador, evaluación determinista de 84 ejemplos autorrotulados.
- DOCUMENTADO: hipótesis, metodología, taxonomía de amenazas, instrucciones de réplica, matriz con corpus, gobernanza y bibliografía primaria.
- EXPERIMENTAL: lógica sintética de autorización, no vinculada a proveedores de herramientas.
- NO VERIFICADO: mejora con modelos reales, resistencia adaptativa, eficacia contra ataques reales y validación externa.
- NO REALIZADO: publicación externa del nuevo paquete, coordinación efectiva con agentes de Grok/Gemini/Discord/GitLab/Moltbook, estudio con participantes o tareas recurrentes.

### Bibliografía de contraste (enlaces primarios verificados el 15 de octubre de 2026)

1. Greenblatt, R., Shlegeris, B., Sachan, K., & Roger, F. (2024). *AI Control: Improving Safety Despite Intentional Subversion*. ICML, PMLR 235, 16295-16336. https://proceedings.mlr.press/v235/greenblatt24a.html
2. Debenedetti, E., Zhang, J., Balunović, M., Beurer-Kellner, L., Fischer, M., & Tramèr, F. (2024). *AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents*. Prepublicación identificada por arXiv 2406.13352; confirmar estatus editorial al enviar. https://arxiv.org/abs/2406.13352
3. NIST (2023). *AI Risk Management Framework 1.0*, AI 100-1. https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf
4. OWASP GenAI Security Project. *Top 10 for Agentic Applications 2026*. https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/
5. ISO/IEC 42001:2023. *Artificial intelligence — Management system*. Ficha oficial de norma; texto completo no se incorpora por derechos. https://www.iso.org/standard/42001

### Nota de fuentes del corpus

Código ℛenova para inteligencias superiores, V1.0, pp. 2-5 (14 artículos, formalización B_IA y protocolo de decisión); *La gentil singularidad renovativa*, V2.0, pp. 2-7 (separación de estatutos), pp. 96 ss. (arquitectura del cierre); *ℛenova V10*, pp. 9-13 (contrato epistemológico y condiciones de corrección). Los localizadores deben cotejarse con la paginación final de cada edición antes de una cita académica formal. Este dossier es una obra nueva basada críticamente en esos documentos, no su reimpresión.
