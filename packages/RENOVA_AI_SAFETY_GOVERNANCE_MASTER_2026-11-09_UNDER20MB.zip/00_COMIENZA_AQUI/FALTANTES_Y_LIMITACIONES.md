# FALTANTES Y MATERIAL NO EXPORTADO

El objetivo de 20 MB se cumple mediante expansión de materiales importantes y omisión de duplicados/binarización histórica pesada. Ningún faltante debe declararse incorporado.

| Recurso | Estado | Razón / referencia |
|---|---|---|
| RENOVA AI SAFETY & GOVERNANCE Federation OS Codex Kit v0.1.0 ZIP (26/oct) | LOCALIZADO, BINARIO NO RECUPERADO | El registro Drive afirma que el ZIP sólo quedó en la conversación original. https://docs.google.com/document/d/1xS1LfvD8Hsdo9BmDxjJhYZc6sq-ez5XVcGeFSd112S0/edit |
| Plugin privado RENOVA AI SAFETY & GOVERNANCE v0.1 ZIP (26/oct) | LOCALIZADO, BINARIO NO RECUPERADO | En el registro figura plugin privado, sin exportación de bytes en esta sesión. |
| GitHub completo `reyfilosofo/renova-agent`, 613 entradas en `main` | CONSULTADO, NO EXPORTADO | Se verificó metadato/árbol y PR #19/#52/#63 mediante conector; no se recuperó snapshot completo por descarga. https://github.com/reyfilosofo/renova-agent |
| Archivos completos de TODAS las conversaciones ChatGPT, otros proyectos y sus adjuntos | NO DISPONIBLES EN SU TOTALIDAD | No existe acceso universal o exportación íntegra autorizada; índice temático sólo refleja conversación accesible. |
| Presentación de ventas Governance Sales Deck PPTX original (10,435,016 bytes) | SUSTITUIDA POR PDF VISUAL | Versión PDF generada desde el PPTX accesible, conservando contenido visual, perdiendo editabilidad. Archivo original en `ARCHIVO_MAESTRO_2026-10-22_V1.zip`, no en este compacto. |
| ZIP maestro V1 original de 53 MB / ZIP CENTRO master de ~18MB / ZIP editorial de ~13MB | OMITIDOS COMO CONTENEDORES | Su contenido sustancial ya está representado por V2.2/ediciones seleccionadas; anidar todas las versiones rompería 20MB. No se reclama exhaustividad de cada archivo visual. |
| Raster de portada extendida Lucem PNG de 4.7MB | OMITIDO POR PRESUPUESTO | Se incluye PDF editorial de cubierta; versión PNG permanece en el archivo editorial original. |
| Algunos materiales de proyecto adjuntados en conversaciones anteriores, p. ej. plugin CENTRO v1.0.2, Evaluator Horizonte Áureo, RENOVA V10 | INVENTARIADOS EN REFERENCIAS, BINARIOS NO RECUPERADOS | Materialización de copias de Project devolvió 'no authorized uploaded backing file'; no se falsificaron bytes. |
| Experimentos externos, datasets held-out independientes, cartas de aceptación, certificaciones ISO | NO VERIFICADOS / NO APLICABLE | La ausencia de evidencias no equivale a validación. |

Se mantienen hashes de los materiales efectivamente incorporados; no se inventan huellas para los omitidos.
