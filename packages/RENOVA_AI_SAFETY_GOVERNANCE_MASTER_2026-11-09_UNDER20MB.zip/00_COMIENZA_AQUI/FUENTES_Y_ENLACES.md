# FUENTES PRIMARIAS Y MARCOS DE REFERENCIA

## Fuentes propias recuperadas

- GitHub: https://github.com/reyfilosofo/renova-agent
- PR #19: https://github.com/reyfilosofo/renova-agent/pull/19
- PR #52: https://github.com/reyfilosofo/renova-agent/pull/52
- PR #63: https://github.com/reyfilosofo/renova-agent/pull/63
- Drive V2.2: https://drive.google.com/file/d/1MAU67HX16_W0b9_OR_wriKQaNx_NjsRW/view
- Drive FED-22 canon: https://docs.google.com/document/d/1rhbpzDhaKmX_Q80QdbSpo8s2_UdZnFxVOk2a2iUgJ_Y/edit
- Registro producto v1.3: https://docs.google.com/document/d/1sQWQfiLtp4W-JAzY3jjRw4DtKqriyqZFe2DQCGUsxmY/edit
- Registro federation 26/oct: https://docs.google.com/document/d/1xS1LfvD8Hsdo9BmDxjJhYZc6sq-ez5XVcGeFSd112S0/edit

## Fuentes técnicas primarias, señaladas por los informes de origen

- NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
- ISO/IEC 42001: https://www.iso.org/standard/42001
- OWASP AI Agent Control Standard (ACS): https://genai.owasp.org/resource/agent-control-standard-acs/
- UK AISI Inspect: https://inspect.aisi.org.uk/
- AI Control (ICML 2024): https://proceedings.mlr.press/v235/greenblatt24a.html
- Farquhar et al. (Nature 2024), DOI 10.1038/s41586-024-07421-0: https://doi.org/10.1038/s41586-024-07421-0
- AgentDojo (NeurIPS 2024): https://openreview.net/forum?id=m1YYAQjO3w

Estas referencias NO son avales ni una certificación del programa. Las fechas y estados regulatorios deben revalidarse contra las autoridades antes de una auditoría de cumplimiento.
