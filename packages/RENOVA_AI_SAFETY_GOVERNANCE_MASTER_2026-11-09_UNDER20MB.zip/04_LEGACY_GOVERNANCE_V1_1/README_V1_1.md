# ℛENOVA AI SAFETY & GOVERNANCE v1.1
**Edición:** 2026-10-15. **Responsables conceptuales:** ℛenova / SERESARTE; coordinación CJGR Executive Twin Ω y CENTRO OS solo como roles documentales, sin conexión comprobada.

## Uso local
`python -m unittest discover -s tests -v`
`python -c "from renova.metamorphic import run_metamorphic; print(run_metamorphic())"`

## Interpretación
La suite comprueba comportamiento de reglas en casos sintéticos, no eficacia sobre sistemas de IA reales. No se ejecutan llamadas a proveedores, publicaciones ni acciones remotas. Leer `docs/DELTA_V1_1.md`, `protocols/EGRA_003_PRE_REGISTRATION.md` y `docs/CRITICAL_REVIEW.md`.
