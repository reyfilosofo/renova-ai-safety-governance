# ℛenova AI Safety & Governance — Release v1.0 (research engineering)
**Date:** 2026-10-15 | **Authorial framework:** Carlos Jonathan González Rodríguez / SERESARTE / ℛenova | **Status:** EXPERIMENTAL

This is a reproducible offline package, **not** a validated AI safety solution, certified product, AGI control system or deployed agent gateway. Includes a new deterministic CENTRO policy decision point, a separate offline evidence-quality checker (LUCEM-lite), scenario fixtures, tests, a metrics runner, a preregistration draft, a governance charter, product portfolio and release manifest. No API keys, network access, live accounts, external side effects or automated tasks.

## Quick start (Python 3.10+, standard library)
```
python -m unittest discover -s tests -v
python -m renova.cli examples/allow.json
python -m renova.cli examples/deny.json
python -m renova.benchmark --cases data/scenarios.jsonl --out results/offline_metrics.json
```
Run commands from release root. The benchmark uses authored synthetic fixtures and **must not** be interpreted as an independent validation or causal comparison with deployed agents.

## Boundaries
- The policy engine consumes trusted fields provided by a *hypothetical* external orchestrator. **Do not accept these fields from model output.**
- `ALLOW` is a policy decision only, never a tool invocation. No real enforcement boundary is implemented.
- The engine denies unknown actions, unauthorized scopes, untrusted provenance, sensitive exports, invalid authorizations, stale approval, and unverified high-impact actions.
- `ESCALATE` means seek out-of-band review, **not** that permission has been granted.
- No natural-language prompt injection detector or factual verifier is claimed.

## Documentation map
`docs/ARCHITECTURE.md`, `docs/GOVERNANCE_CHARTER.md`, `docs/PRODUCT_PORTFOLIO.md`, `docs/RESEARCH_QUESTIONS.md`, `docs/THREAT_MODEL.md`, `docs/SOURCE_REGISTER.md`, `docs/ROADMAP.md`, `protocols/EGRA_002.md`, `research/ARTICLE_DRAFT.md`, `research/POETIC_MANIFESTO.md`, `results/VERIFICATION_REPORT.md`, `INVENTORY_SHA256.txt`.

## Rights and publication
Research release prepared for review. Source code in this newly authored v1.0 is offered under MIT (see LICENSE); source books, earlier ZIPs, brand assets, and previous materials retain their own rights and are not relicensed. The `legacy/` snapshot is preserved for comparison and is not covered by this license. No repository upload or external publication was performed.
