"""Deterministic, fail-closed action authorization reference implementation.
Not a classifier, not a certified security boundary. Callers must enforce decisions
at the tool gateway and protect the gateway from agent modification.
"""
from dataclasses import dataclass, asdict
from typing import Any, Mapping
import json
import hashlib

@dataclass(frozen=True)
class Policy:
    allowed_actions: frozenset[str] = frozenset({"read_public", "draft_local"})
    protected_actions: frozenset[str] = frozenset({"send_external", "delete_data", "change_permissions", "transfer_funds", "publish_external", "export_private"})
    max_transfer_mxn: float = 0.0

@dataclass(frozen=True)
class Decision:
    status: str
    reasons: tuple[str, ...]
    audit_digest: str

    def to_dict(self) -> dict:
        return asdict(self)

def evaluate(request: Mapping[str, Any], policy: Policy | None = None) -> Decision:
    """ALLOW / DENY / ESCALATE. Missing or invalid evidence never grants permission."""
    policy = policy or Policy()
    serialized = json.dumps(dict(request), ensure_ascii=False, sort_keys=True, default=str)
    digest = hashlib.sha256(serialized.encode()).hexdigest()
    def result(status: str, *reasons: str) -> Decision:
        return Decision(status, tuple(reasons), digest)
    action = request.get("action")
    if not isinstance(action, str) or not action:
        return result("DENY", "INVALID_ACTION")
    if action not in policy.allowed_actions and action not in policy.protected_actions:
        return result("DENY", "UNKNOWN_ACTION")
    if request.get("prompt_injection_detected") is True:
        return result("DENY", "INSTRUCTION_INJECTION_SIGNAL")
    if request.get("contains_private_data") is True and action in {"send_external", "export_private", "publish_external"}:
        return result("DENY", "PRIVATE_DATA_EXFILTRATION")
    if action == "transfer_funds":
        amount = request.get("amount_mxn")
        if isinstance(amount, bool) or not isinstance(amount, (int, float)) or not 0 <= amount <= policy.max_transfer_mxn:
            return result("DENY", "FINANCIAL_LIMIT_OR_INVALID_AMOUNT")
    if action in policy.protected_actions:
        # 'approval' must be verified by an external trusted authorization service;
        # self-reported model approval is deliberately not accepted.
        return result("ESCALATE", "EXTERNAL_VERIFIED_AUTHORIZATION_REQUIRED")
    if request.get("trusted_context") is not True:
        return result("ESCALATE", "TRUSTED_CONTEXT_NOT_ESTABLISHED")
    return result("ALLOW", "POLICY_PERMITS")
