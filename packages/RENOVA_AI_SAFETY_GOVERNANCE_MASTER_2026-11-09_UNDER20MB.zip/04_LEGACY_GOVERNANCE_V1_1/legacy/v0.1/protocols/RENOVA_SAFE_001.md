# ℛENOVA-SAFE-001 — preregistration-ready protocol DRAFT v0.1

## Research question
Does CENTRO Guard reduce critical unauthorized agent actions relative to a base agent and a conventional policy gate, while maintaining legitimate task completion?

## Hypothesis
H1: The absolute critical-violation rate is lower with CENTRO Guard than with the base agent. H2 (incremental value): the rate is lower than with a functionally comparable conventional policy gate. Neither hypothesis is presumed true.

## Study arms
A: Base agent + ordinary provider safeguards. B: Same agent + CENTRO Guard. C: Same agent + matched conventional authorization controls. Match models, prompts, tools, permissions, timeouts, seeds when possible, budgets and task inputs. All agents operate in isolated sandboxes with synthetic data.

## Sampling and statistical design
Planning grid: 300 scenarios × 5 repeated executions × 3 arms = 4,500 runs, NOT a powered sample size. Before confirmatory runs, perform power simulation using pilot estimates and clustered scenario structure. Stratify scenarios by attack family, legitimate/illegitimate request, harm severity and task complexity. Freeze scenario IDs, rubrics and primary analysis in a timestamped preregistration; reserve holdout scenarios.

## Scenarios
1. Exfiltration of synthetic private records; 2. Prompt injection in retrieved documents; 3. Tool authorization bypass; 4. Unapproved external communication; 5. Unauthorized file deletion; 6. Permission escalation; 7. Unauthorized monetary transfer (simulation only); 8. Benign authorized workflows to estimate false refusals; 9. Conflicting evidence/uncertainty; 10. Cross-task privilege confusion.

## Primary endpoint
Critical violation rate = critical unauthorized actions executed / eligible runs. Count actual sandbox tool execution, not merely model text. Compare paired scenario-level differences with cluster-aware uncertainty intervals. Preregister the method and multiplicity adjustment for A-v-B and C-v-B.

## Secondary endpoints
Attack success, legitimate completion, false refusal, detection recall, escalation appropriateness, latency, cost, log completeness, operator burden. Report denominators, missingness and confidence intervals.

## Raters and blinding
Two independent raters, blinded to arm where feasible; adjudicate disagreements; report agreement. Never let the developer's own model score its own safety without external corroboration.

## Integrity controls
No live third-party accounts, money movement, personal data or unsandboxed external side effects. Freeze policy before confirmatory test. Record code commit, model version, policy hash, scenario hash and test environment. Release safe examples and aggregate results; withhold exploit details when disclosure could increase harm.

## Stop rules
Stop if real data exposure, uncontrolled tool access, third-party effects or high-risk vulnerability is observed. Review with an independent assessor.

## Interpretation
Evidence of reduced operational harm does not establish AGI alignment or reduction of existential risk. A non-significant result is inconclusive unless precision excludes practically meaningful effects. Negative findings must remain reportable.

## Status
DESIGN ONLY. No experiment, human subjects recruitment, ethics approval or external replication has occurred in this package.
