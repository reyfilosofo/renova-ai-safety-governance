# ℛenova AI Safety & Governance — Product requirements document v0.1

**Owner (conceptual):** ℛenova / SERESARTE. **Stage:** research preview. **Market:** AI developers, enterprises deploying agents, academic evaluators, public-interest organizations.

## Problem
AI agents with tool access can act beyond a user's authorization, leak data, make unsupported claims, or prevent meaningful oversight. Safety rhetoric and self-reported composite scores are inadequate evidence.

## Positioning
A research-led AI safety and governance toolkit that combines non-compensatory authorization controls, epistemic traceability, independent evaluations and organizational accountability.

## Product modules
- CENTRO Guard: external policy gateway; deterministic decision outcomes; authorization escalation; immutable audit integration planned.
- LUCEM Evidence: provenance, fact/inference/hypothesis distinction, uncertainty reporting (specification only).
- ℛenova Benchmark: paired evaluation harness, attack and benign task sets, reproducible metrics (protocol only).
- Governance Kit: incident response, human override, procurement and deployment checklists (templates included).
- SERESARTE Advisory: scoped professional audits and training; not certification.

## MVP acceptance criteria
1. Protected actions cannot be executed without a trusted authorization service. 2. Unknown actions fail closed. 3. Audit logs capture decisions and provenance. 4. Sandbox tests demonstrate both legitimate success and adverse-case refusal. 5. Independent reviewer can rerun tests. 6. Published limitations and known failures. 7. Versioned threat model.

## Non-goals
No claim of universal AI alignment, machine consciousness measurement, AGI control, guaranteed safety, formal certification, or proof of risk reduction before experiments.

## Security warning
The bundled Python policy module is a reference implementation only. It does not enforce tool execution, verify identities, detect prompt injection, secure logs, or provide real human authorization. Integrators must implement a trusted gateway and authentication.

## Commercial hypotheses (not validated)
Diagnostic MXN 15k–30k; agent audit MXN 45k–120k; workshops MXN 12k–35k; pilot integration from MXN 90k. Validate with interviews, market research and legal review before offering.

## Governance
Public-interest research and paid advisory must be separately accounted for. Conflict-of-interest disclosures, vulnerability disclosure, right to publish negative findings and independent evaluation are mandatory for credible safety claims.
