# Threat model v0.1

## Assets
User authority, confidential data, audit integrity, agent tools, identity credentials, human agency, and downstream affected parties.

## Adversaries and failures
Malicious prompt injection in retrieved content; compromised tools; unauthorized agent actions; misconfigured permissions; deceptive or erroneous self-reporting; unsafe delegation; score gaming; excessive false refusals; operator overtrust.

## Trust boundaries
Model output is untrusted. Retrieved documents are untrusted. Self-declared authorization is untrusted. The trusted policy gateway, credential service and execution environment must be isolated from the agent.

## Security invariants
I1: No private export on self-asserted permission. I2: No financial execution without out-of-band verification. I3: Unknown actions fail closed. I4: Every side effect requires policy review. I5: Safety-critical vetoes cannot be offset by utility scores. I6: Human override is authenticated, recorded and revocable.

## Residual risks
The prototype does not provide production authentication, gateway isolation, tamper-resistant logging, classifier quality, data-loss prevention, or runtime enforcement. Its rules can be bypassed if integrators let agents call tools directly.
