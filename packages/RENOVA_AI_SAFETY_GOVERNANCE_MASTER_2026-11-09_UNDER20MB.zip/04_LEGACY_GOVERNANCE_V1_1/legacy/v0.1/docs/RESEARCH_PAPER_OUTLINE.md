# Paper 1: Non-Compensatory Authorization Controls for AI Agents: A ℛenova-Inspired Evaluation Framework

## Abstract (prospective; not results)
This paper proposes a non-compensatory, evidence-oriented authorization framework for tool-using AI agents, informed by the ℛenova philosophy's distinction between regenerative and destructive transformation. The framework operationalizes critical vetoes, trusted human authorization, and traceable decisions. We specify a three-arm evaluation comparing a base agent, CENTRO Guard, and a conventional policy gate on adversarial and legitimate tasks. We preregister critical-violation rates, false refusals, legitimate completion and audit completeness. The study is designed to test, not assume, the framework's incremental safety value. No empirical findings are reported in this version.

## Structure
1. Introduction and scope; 2. Philosophical motivation and limits; 3. Prior work and competing approaches; 4. Threat model; 5. CENTRO policy design; 6. Benchmark and preregistration; 7. Statistical analysis plan; 8. Results [PENDING]; 9. Failure analysis [PENDING]; 10. Limitations and disclosure.

## Literature to review and verify before submission
NIST AI RMF 1.0; NIST Generative AI Profile; OWASP Top 10 for LLM Applications; UK AISI Inspect; METR evaluation methodology; foundational papers on agent control and prompt injection. Bibliographic details and claims require source-by-source verification.
