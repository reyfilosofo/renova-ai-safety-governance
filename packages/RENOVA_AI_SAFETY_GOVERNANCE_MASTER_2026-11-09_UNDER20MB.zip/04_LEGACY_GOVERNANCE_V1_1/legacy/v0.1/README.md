# ℛenova AI Safety & Governance
### SERESARTE × ℛenova · Research Preview v0.1 · 2026-10-15

A reproducible **research starter package** for non-compensatory AI-agent action authorization and the ℛENOVA-SAFE-001 controlled evaluation protocol.

## What is implemented
- `src/renova_safety/guard.py`: deterministic reference policy engine with ALLOW, DENY and ESCALATE.
- `tests/test_guard.py`: executable unit tests.
- `examples/`: JSON requests for CLI demonstration.

## What is specified but NOT implemented
- Trusted authorization server, actual agent-tool gateway, tamper-resistant audit storage, LUCEM provenance service, benchmark runner, real attack-detection model, organizational deployment, external validation.

## Quickstart (Python 3.10+, no dependencies)
```bash
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python -m renova_safety.cli examples/allowed.json
PYTHONPATH=src python -m renova_safety.cli examples/denied.json
```

## Scientific status
The tests check **implementation invariants**, not safety efficacy. No claims of reduction in real-world AI harm or AGI risk are made. See `protocols/RENOVA_SAFE_001.md`.

## Source distinction
Philosophical inspiration: ℛenova–Gewalt, Bios·Zōḗ, Hábitat–Herida–Horizonte and CENTRO/LUCEM, as presented in user-provided ℛenova materials. The code, experiment plan and product specification in this package are **new proposed engineering artifacts**, not proven derivations from ontological equations. The existing `Renova-CENTRO-Evaluator-v2.1-Horizonte-Aureo.zip` was inspected for conceptual continuity, but was not silently modified or bundled.

## Licensing
No license is granted in this preview. Before public repository publication, select and add an explicit license after reviewing rights and dependencies.
