# INSERCIÓN CIENTÍFICA INTERNACIONAL · PLAN DE PUBLICACIÓN Y COLABORACIÓN

**Corte:** 15 de octubre de 2026. **Estado:** PLAN INTERNO, NO ENVÍOS, NO ALIANZAS NI ACEPTACIONES CONFIRMADAS.

## 1. Estrategia de inserción sin autoatribución

No reclamar pertenencia a «los 200»; no constituye una membresía verificable. Posicionamiento defendible: investigador independiente de filosofía aplicada a gobernanza y evaluación de IA que está construyendo un programa falsable en evidencia, autonomía humana y reversibilidad. Proponer crítica y experimentación, no una solución probada de AGI. Prioridad: revisión de constructos por investigador externo y revisión de decisiones de control por ingeniería de seguridad independiente.

## 2. Oportunidad comprobada: ACM FAccT 2027

CFP: https://facctconference.org/2027/cfp.html ; guía: https://facctconference.org/2027/authorguide.html. Resumen vence **27 octubre 2026**; manuscrito **3 noviembre 2026**, horarios Anywhere on Earth. Página principal máximo 14 páginas sin referencias, más excepciones descritas en guía. Anonimización estricta: no entregar versión con nombre, marcas, afiliación o metadatos que reidentifiquen. Citar trabajo propio como trabajo de terceros, no usar autoidentificaciones. Incluir declaración de IA generativa y responsabilidad humana. Inscripción y posible revisión previa de cuenta OpenReview; la guía recomienda a autores sin afiliación institucional verificar la cuenta con anticipación. Una propuesta puramente hipotética o sin anclaje sociotécnico podría no satisfacer el alcance: verificar posibilidad de evidencia adicional antes de priorizar esta vía.

**Estado real:** borrador conceptual en curso; resumen de envío aún no presentado; no confirmar Scopus como resultado garantizado por participar. Publicación requiere evaluación competitiva.

## 3. Revista académica de trabajo

Candidata temática: AI and Ethics (Springer Nature) — comprobar al preparar el envío las políticas editoriales vigentes, el tipo de artículo aceptado, APC, acceso abierto opcional, indexación activa en Scopus en el año de envío y compatibilidad con preprints. Página editorial: https://link.springer.com/journal/43681 . Otras revistas requerirían análisis por temática y probabilidad metodológica. Nunca afirmar «artículo Scopus» antes de publicación e indexación efectivas. Estado actual: borrador listo para revisión autoral y metodológica, no artículo aceptado.

## 4. Interlocutores pertinentes (organizaciones existentes, contacto por canal oficial a verificar)

**Center for Humane Technology:** dimensión de diseño tecnológico, autonomía y efectos sistémicos; buscar canal oficial en https://www.humanetech.com/ . **METR:** metodologías de evaluación de agentes; sitio https://metr.org/ . **Redwood Research:** protocolos de control; sitio https://www.redwoodresearch.org/ . **UK AI Security Institute:** evaluación y riesgos avanzados; usar página oficial de gobierno antes de dirigirse. **ACM FAccT:** espacio interdisciplinario de crítica y validación sociotécnica; https://facctconference.org/2027/ . Ninguna de estas organizaciones es colaboradora actual de ℛenova por el solo hecho de figurar aquí. No inventar correos ni contactos personales.

## 5. Paquete mínimo para pedir revisión externa

Enviar sólo tras aprobación expresa: (i) resumen de dos páginas con problema, metodología y no-afirmaciones; (ii) manuscrito conceptual; (iii) código demo claramente marcado como sintético; (iv) lista de seis preguntas críticas; (v) propuesta concreta de revisión de 30 minutos, sin pedir aval previo. Privilegiar comentarios negativos y referencias alternativas. No solicitar «certificación de AGI» ni estatus especial.

## 6. Preguntas para expertos independientes

1. ¿La definición operacional de «agencia post-desconexión» añade información a métricas ya existentes?
2. ¿Nuestro modelo de amenazas corresponde a los riesgos que afirmamos estudiar?
3. ¿Qué comparadores activos son indispensables para evitar ventajas artificiales?
4. ¿Qué diseño permitiría falsar la hipótesis central de forma convincente?
5. ¿Los vetos son comprobables y aplicables sin autorreferencia del modelo?
6. ¿Qué limitaciones impedirían generalizar a AGI y qué evidencia podría reducirlas?

## 7. Draft 1 · Research feedback request (English — do not send yet)

Subject: Request for methodological critique — evidence integrity, AI control and reversible human agency

Hello,

I am developing an independent, early-stage research programme at the intersection of AI evaluation, sociotechnical governance, and human agency. The working proposal, Evidence-Gated Reversible Agency (EGRA), separates epistemic verification, deliberation, and independently enforced tool permissions, and proposes measurable tests of human capability after AI assistance is withdrawn.

I am not claiming to have solved alignment or demonstrated an AGI safety improvement. I would value a critical methodological review, particularly on construct validity, comparator selection and falsifiable outcomes. I can share a short research note and an offline synthetic demonstration explicitly labelled as nonvalidated.

Would your team have an appropriate route for submitting a short research proposal for feedback, or could you point me to a relevant public evaluation programme?

Kind regards,
Carlos Jonathan González Rodríguez
ℛenova / SERESARTE

## 8. Draft 2 · Solicitud de colaboración académica (español — no enviar)

Asunto: Revisión metodológica independiente de un protocolo experimental sobre seguridad y agencia humana en IA

Estimado equipo académico:

Desarrollamos una propuesta de investigación sobre integridad epistemológica, límites de autorización de agentes de IA y preservación de la autonomía humana después de retirar la asistencia automatizada. La propuesta parte de un marco filosófico denominado ℛenova, pero delimita hipótesis observables y comparadores independientes.

El trabajo se encuentra en fase de protocolo y no presenta resultados experimentales validados. Buscamos una evaluación crítica externa sobre validez de constructo, diseño experimental, sesgos y condiciones de falsación, sin solicitar aval institucional ni asumir colaboración.

Podemos compartir un resumen metodológico, manuscrito de trabajo y demostración sintética para su revisión. ¿Existe un procedimiento apropiado para presentar la propuesta a un seminario o grupo de investigación?

Atentamente,
Carlos Jonathan González Rodríguez
ℛenova / SERESARTE

## 9. Decisiones de aprobación antes de acciones externas

- Aprobar versión autoral, integridad de citas y declaración de uso de IA.
- Decidir si se pretende enviar a FAccT 2027 tras revisar el Author Guide completo.
- Dar autorización específica para envío/contacto, canal, destinatario y adjuntos.
- Decidir licencia pública del código, evitando exposición de datos privados o técnicas de explotación.
- Verificar credenciales y permisos para representar a SERESARTE/Fundación en cada acto.
