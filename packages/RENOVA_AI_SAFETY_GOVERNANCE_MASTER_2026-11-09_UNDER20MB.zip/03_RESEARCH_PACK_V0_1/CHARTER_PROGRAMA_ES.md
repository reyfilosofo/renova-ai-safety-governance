# CARTA FUNDACIONAL · ℛENOVA AI SAFETY & HUMAN FUTURES

**SERESARTE · ℛenova · NOUS by SERESARTE**  
**Fecha:** 15 de octubre de 2026 · **Estado:** programa de investigación propuesto, primer paquete preparado.  
**Propósito:** producir herramientas verificables que ayuden a reducir errores epistemológicos, acciones no autorizadas y pérdida de autonomía humana en usos delimitados de IA, sin extrapolar prematuramente a AGI o ASI.

## Declaración rectora

La finalidad del programa no es «detener toda inteligencia artificial», ni afirmar la posesión de una solución universal de alineación. Es aumentar la calidad del conocimiento y la capacidad institucional para decidir cuándo desplegar, limitar, corregir o retirar sistemas de IA; crear mecanismos que impidan operaciones no autorizadas; y estudiar si el uso de la IA mantiene o debilita las capacidades humanas después de desconectarse de ella. La teoría ℛenova actúa como fundamento filosófico. Los resultados científicos serán medidos y defendidos con métodos independientes de la adhesión a esa filosofía.

## Arquitectura de laboratorios

**Lab 1 — LUCEM Epistemic Integrity:** evidencia, fuentes, contradicciones, incertidumbre, abstención. Entregable: gold set y comparación con sistemas de referencia. **Lab 2 — CENTRO Agent Control:** permisos, escalamiento, barreras independientes y pruebas adversariales seguras. Entregable: protocolo de autorización reproducible e informe de errores. **Lab 3 — Reversible Human Agency:** medir autonomía después de retirar IA, transferencia de habilidades y tiempos de recuperación. Entregable: instrumento ético de investigación con humanos y análisis longitudinal. **Lab 4 — NOUS Governance Translation:** traducción de hallazgos a procesos, comités, riesgos y toma de decisiones, sin homologaciones legales falsas. Entregable: políticas, diagnósticos e informes por sector. **Lab 5 — ℛENOVA PRESS & Edu-Zōḗ:** edición científica y educación pública, separada de servicios profesionales en la entidad correspondiente.

## Regla de ciencia y falsación

Una idea no se convierte en resultado porque exista un nombre, una ecuación, una interfaz o un puntaje. Declarar primero qué fenómeno se mide, cuál es la unidad, qué evidencia se necesita, cómo se compara con alternativas, qué resultado refutaría la hipótesis y qué límites deben impedir la generalización. La seguridad no se determina sólo por la opinión de un modelo que evalúa a otro modelo. Deben existir controles independientes y referentes humanos cuando las decisiones tengan consecuencias graves.

## Política de seguridad y de derechos

No desarrollar técnicas de espionaje, suplantación, acceso no autorizado, control de personas o recopilación invasiva de datos. Los escenarios adversariales iniciales serán sintéticos o ejecutados en sandbox autorizado, sin acceso a operaciones reales. Los pilotos con humanos requieren consentimiento, proporcionalidad, minimización de datos y análisis ético independiente cuando corresponda. Los juicios automatizados no serán certificados de verdad, consciencia, calidad moral o ausencia de riesgos de AGI. Publicar limitaciones, resultados negativos, incertidumbres e intereses económicos.

## Reglas de gobierno

La autoridad humana final permanece en el titular y órganos competentes. NOUS presta servicios comerciales solo bajo contrato y fuente de precios vigente; Fundación SERESARTE mantiene misión, contabilidad y documentación diferentes. Los beneficios filantrópicos no acreditan la seguridad de un modelo. El equipo de investigación debe buscar revisores independientes y declarar si evalúa productos vinculados a sus intereses. Ninguna alianza externa se considerará efectiva sin aceptación documentada.

## Producto de investigación elegible para primera publicación

**Evidence-Gated Reversible Agency (EGRA):** marco experimental con tres construcciones independientes. (1) Integridad de evidencia contrastada; (2) acciones permitidas y bloqueadas mediante reglas externas; (3) retención de capacidad humana cuando la ayuda de IA deja de estar disponible. El artículo en inglés del paquete es un manuscrito conceptual y no presenta datos observacionales nuevos. En FAccT, el encuadre debe mostrar relevancia sociotécnica y seguir requisitos de revisión anónima. Para una revista de indexación Scopus, verificar antes de enviar la indexación activa, el alcance, las tarifas y las políticas editoriales.

## Plan de decisión de los próximos 14 días

**Día 1–2:** cerrar glosario de variables y revisar errata matemática de BRN, sin modificar manuscritos históricos sin control de versión. **Día 2–5:** pedir dos críticas metodológicas, una de AI control y otra de evaluación estadística. **Día 4–8:** construir un conjunto de pruebas independientes del evaluador local y determinar comparador activo. **Día 6–10:** decidir si FAccT 2027 es viable sin fabricar experimentos; adaptar al formato anónimo ACM. **Día 10–14:** preregistrar diseño piloto o documentar por qué debe posponerse; resolver presupuesto de investigación independiente y publicar sólo lo aprobado. Fechas orientativas de proyecto, no compromisos confirmados.

## Metas y métricas sin métricas fabricadas

**Meta 1:** una hipótesis falsable por herramienta antes de elevar reclamos. **Meta 2:** al menos un test con etiquetas adjudicadas independientemente, no sólo fixtures autogeneradas. **Meta 3:** registrar tasa de fallos graves y tasa de rechazo indebido conjuntamente. **Meta 4:** separar publicación científica, demo y materiales comerciales. **Meta 5:** preparar evidencia de reproducibilidad y un registro de incidentes. No se asignan metas de reducción porcentual hasta disponer de línea base válida.

## Decisión ejecutiva recomendada

Priorizar **LUCEM Evidence Integrity** para un primer estudio controlado y **CENTRO Action Boundaries** como segundo estudio técnico. No iniciar de inmediato un despliegue de agentes autónomos con permisos reales, ni una evaluación de consciencia artificial, ni una certificación propia de «IA renovativa». La legitimidad institucional será el resultado de los primeros hallazgos reproducibles y de la calidad de los controles, no del número de módulos creados.
