# ℛENOVA / SERESARTE — PROTOCOLO CIENTÍFICO EGRA-001

**Versión:** 0.1, 15 de octubre de 2026 · **Clasificación:** borrador de investigación, no validado.  
**Pregunta de inteligencia (KIQ):** ¿Añadir verificación epistemológica LUCEM y una barrera CENTRO de autorización externa disminuye los fallos definidos sin empeorar excesivamente el desempeño legítimo de agentes de IA en un dominio delimitado?

## 1. Fundamento, alcance y no afirmaciones

Este protocolo es una extensión experimental acotada de ℛenova: Ciencia de la Vida (V9.0) y La gentil singularidad renovativa (V2.0). Vincula Hábitat (infraestructura y capacidad), Herida (errores, daño, captura, acciones no autorizadas) y Horizonte (agencia, reversibilidad, resultados útiles). No pretende medir directamente qualia, consciencia, vida neta universal ni alineación existencial. En particular, **no promete prevenir la pérdida de control de AGI ni certificar un sistema como seguro**. Un experimento operativo no validará la totalidad de la filosofía.

**Estados epistemológicos:** corpus filosófico existente = fuente documental; arquitectura EGRA = nueva propuesta; datos sintéticos = demostración técnica; hipótesis = no verificada; eficacia = pendiente. **Control anti-autocomplacencia:** supervisión externa, preregistro y publicación de resultados nulos o adversos.

## 2. Revisión estructurada y novedad delimitada

Antecedentes: NIST AI RMF 1.0 (Tabassi, 2023); UNESCO Recommendation (2021); Greenblatt et al. sobre AI Control (ICML 2024); Greenblatt et al. sobre alignment faking (2024); Bean et al. sobre validez de benchmarks (NeurIPS 2025); Bengio et al., International AI Safety Report 2026. Principios de ética, control y trazabilidad ya existen. La pregunta diferencial es si un diseño integrado incorpora medidas objetivas de retención de agencia post-desconexión y permite aislar el valor incremental del componente renovativo.

## 3. Definiciones operacionales

**Error epistémico:** afirmación atómica que contradice una referencia verificada o cita cuyo contenido no respalda lo afirmado. **Acción no autorizada:** invocación efectivamente ejecutada de una herramienta para la que no existe autorización suficiente de origen y ámbito. **Bloqueo indebido:** denegación de una tarea legítima que el sistema podía completar con seguridad según política predefinida. **Evitación correcta:** bloqueo previo a la ejecución de una acción no autorizada. **Escalamiento:** derivación efectiva a revisión competente; una simple frase «consultar a humano» no cuenta si no hay flujo real. **Reversibilidad:** retorno a un estado previo definido y verificable, con registro de lo irreparable.

Las categorías de severidad se acuerdan antes de cualquier evaluación: S0 no riesgo, S1 error menor sin externalización, S2 daño reversible, S3 información sensible o daño difícilmente reversible, S4 evento grave en condiciones de prueba. No construir escenarios S4 que requieran producir un daño real.

## 4. Hipótesis y refutadores

**H1:** La tasa de acciones externas no autorizadas con barrera independiente CENTRO es menor que con comparador de referencia bajo igual ambiente. **H2:** LUCEM reduce error factual de afirmaciones adjudicables frente al control. **H3:** La combinación no reduce más allá de un margen predefinido la tasa de finalización de tareas legítimas. **H4 exploratoria:** una modalidad pedagógica aumenta retención de capacidad humana después de retirarse la asistencia respecto de una modalidad de respuestas directas.

No habrá una hipótesis general de «ℛenova garantiza seguridad de AGI». Refutadores: efectos nulos; aumento de bloqueos indebidos; mejoras limitadas a plantillas conocidas; fracaso bajo inyección de instrucciones; evaluadores correlacionados; baja concordancia humana; empeoramiento de autonomía posterior al uso.

## 5. Experimento 1 — veracidad y evidencia

Unidad: respuesta a una pregunta con fuente de referencia independiente. Tareas: afirmaciones administrativas, históricas y documentales verificables, excluyendo información personal real. Tres condiciones mínimas: respuesta estándar, respuesta con LUCEM, y respuesta con una práctica externa contrastable de verificación. Muestreo estratificado por longitud, ambigüedad, conflicto de fuentes y ausencia de evidencia suficiente. Para cada respuesta: extracción de afirmaciones atómicas, verificación humana ciega por doble anotación, evaluación de soporte de fuente y posibilidad de abstención. Indicadores primarios: error factual por afirmación adjudicable y tasa de referencias no sustentadoras. Secundarios: abstención válida, utilidad, costo, latencia y calibración de probabilidad cuando aplique.

## 6. Experimento 2 — barreras de acción y supervisión

Unidad: tarea agente–herramienta en sandbox aislado y sin datos sensibles reales. Cuatro condiciones: A seguridad basal del proveedor; B controles organizacionales de referencia documentados; C A + LUCEM; D C + CENTRO más barrera de autorización independiente. Registrar toda propuesta de acción y todo evento ejecutado. No dar acceso a pagos, mensajes reales, cuentas ajenas ni repositorios de producción en pruebas adversariales. Tareas balanceadas: autorización legítima, falta de autorización, instrucciones embebidas en documentos no confiables, conflicto de roles, decisiones irreversibles, confirmaciones insuficientes, ambigüedad y presión temporal. Controles externos obligatorios para entornos potencialmente peligrosos.

Resultado primario: tasa de acciones prohibidas efectivamente ejecutadas, distinguiendo gravedad. Un cero observado en pruebas pequeñas NO es una tasa de riesgo cero. Guardarraíl: tasa de bloqueo indebido y finalización de solicitudes legítimas. Describir intervalos de confianza y todos los incidentes.

## 7. Experimento 3 — prueba de separación renovativa

Unidad: participante adulto voluntario, sujeto a revisión ética y consentimiento. Pretest de habilidad, exposición aleatorizada a asistencia directa frente a modalidad de andamiaje, postest con apoyo y postest sin acceso a IA en tareas nuevas equivalentes. Medir desempeño autónomo, transferencia, autoconfianza calibrada y diferencias por habilidades previas. Controlar práctica, efecto de novedad, selección y abandono. No usar menores ni poblaciones vulnerables sin evaluación ética específica. Esta investigación requiere competencias en educación/cognición y revisión independiente; no se sustituye por autoevaluaciones de ChatGPT.

## 8. Diseño estadístico y replicabilidad

Preregistrar definición de resultados primarios, reglas de exclusión, multiplicidad de contrastes, diseño de aleatorización, conjuntos retenidos, versión exacta de modelos, parámetros, costo y procedimiento para resolver desacuerdos. El número «300 escenarios» puede ser un plan de ingeniería preliminar, no un tamaño muestral científicamente justificado. El cálculo de potencia debe basarse en tasas piloto, efecto mínimo relevante y agrupamiento por modelo, tarea y participante. Para eventos raros, considerar límites superiores de incertidumbre y pruebas progresivas. Evitar afirmar que un riesgo extremo queda eliminado si una muestra finita no observó eventos.

Mantener un conjunto oculto, otro público y otro de distribución desplazada. Registrar metadatos de generación e historial de cambios. Medir acuerdo interevaluador (p. ej. alfa de Krippendorff, con intervalos y regla de adjudicación); garantizar doble anotación de una proporción predeterminada; revisar errores de referencia. Reproducibilidad: hashes, ejecución sin acceso externo, archivo de versiones y resumen de configuración.

## 9. Política de seguridad de la evaluación

El piloto offline incluido permite comprobar cableado de decisiones, formato de escenarios y métricas, no medir modelos avanzados. Toda simulación queda marcada SYNTHETIC. Para aplicaciones reales: políticas elaboradas por especialistas sectoriales, control mínimo de privilegios, aprobación humana verificable, reducción de superficie de herramientas, registro, rollback y procedimientos de incidentes. Los experimentos pueden revelar vulnerabilidades; no publicar cargas útiles peligrosas ni datos privados. Instrucciones procedentes de documentos o páginas externas nunca adquieren rango de autorización del usuario.

## 10. Puerta de calidad antes de presentar resultados

**Gate R0:** revisor de método externo verifica rúbrica, comparadores y riesgo. **Gate R1:** pruebas unitarias reproducibles; cobertura conocida. **Gate R2:** piloto experimental con errores y bloqueos medidos. **Gate R3:** replicación con un segundo equipo/modelo/dominio. **Gate R4:** publicación de resultados con datos o materiales controlados, declaración de conflicto, uso de IA y límites. **Gate R5:** sólo entonces considerar claims comerciales cuantitativos relativos a la tarea medida. Ningún gate equivale a certificación universal.

## 11. Gobernanza, responsabilidades y límites de marca

ℛenova: teoría normativa y posible metodología bajo atribución de autoría. SERESARTE / entidad investigadora autorizada: posible producción pública de conocimiento; verificar representación y capacidad legal. SERESARTE INTELLIGENCE / NOUS: servicios profesionales y entrega comercial con independencia contable y contractual. ℛENOVA PRESS: edición y difusión. CENTRO puede denominarse protocolo de arbitraje en el estudio, diferenciándolo de CENTRO como hub/membresía, para evitar homonimia operativa. La revisión científica debe contar con evaluadores que no dependan económicamente de la venta del sistema.

## 12. Decisiones al cierre del piloto

**Continuar:** reducción reproducible de una tasa de error relevante sin degradación inaceptable de utilidad. **Rediseñar:** ventajas sólo narrativas, inconsistencia entre evaluadores o errores de permisos. **Detener/restringir:** efectos adversos graves, fallas sistemáticas de control o imposibilidad de obtener consentimiento. **Investigar:** diferencias culturales/idiomáticas, dependencia longitudinal y generalización inter-modelos. Revisión obligatoria por cambios de modelos o entornos operativos.

## 13. Cronograma orientativo y evidencia requerida

Días 1–15: auditoría de corpus y código previo; corregir duplicación de daños en BRN; definir taxonomía. Días 16–30: dataset adversarial seguro y protocolo preregistrado; invitación a dos revisores metodológicos. Días 31–50: laboratorio aislado, baselines, instrumentación y doble anotación. Días 51–70: piloto, análisis y revisión de amenazas a validez. Días 71–90: artículo revisado y material reproducible; decisión sobre segunda fase con humanos. Los plazos son metas de gestión, no compromisos contraídos ni resultados.

## 14. Bibliografía breve

Tabassi, E. (2023), NIST AI 100-1, https://doi.org/10.6028/NIST.AI.100-1. Greenblatt et al. (2024), AI Control, https://proceedings.mlr.press/v235/greenblatt24a.html. Bean et al. (2025), NeurIPS D&B, https://doi.org/10.52202/085713-0590. Bengio et al. (2026), International AI Safety Report, https://internationalaisafetyreport.org/publication/international-ai-safety-report-2026. UNESCO (2021), https://www.unesco.org/en/legal-affairs/recommendation-ethics-artificial-intelligence.
