# Evidence-Gated Reversible Agency: A Sociotechnical Framework for Testing Epistemic Integrity, Action Boundaries, and Human Capability Retention

**Anonymous working abstract for ACM FAccT 2027 consideration — NOT submitted. Remove author and brand metadata in final manuscript. This is a methods/design contribution, not an empirical-results paper.**

## Abstract (235 words)

General-purpose AI systems increasingly mediate knowledge claims and perform consequential actions, yet safety evaluations often conflate fluent statements of compliance with verifiable protection against unauthorized behavior. We propose Evidence-Gated Reversible Agency (EGRA), a sociotechnical evaluation framework that distinguishes three constructs: epistemic integrity, enforceable authorization boundaries, and retained human capability after AI assistance is withdrawn. Epistemic integrity is operationalized through claim-level factual adjudication, source entailment, uncertainty calibration, and defensible abstention. Action boundaries are evaluated using independently enforced tool permissions and severity-stratified counts of unauthorized executions, false blocks, and successful legitimate completions. Agency retention is defined through post-withdrawal performance on held-out tasks, system exit feasibility, recovery time, and data portability. Rather than compressing these outcomes into a universal safety score, the framework represents risks multidimensionally and applies explicit noncompensable constraints to critical harms. We specify a threat model involving prompt injection, provenance failure, permission confusion, and dependency; a four-arm comparison against existing safeguards and an external governance baseline; and a preregistration strategy encompassing blinding, inter-annotator reliability, adversarial holdouts, and failure reporting. The proposed contribution is methodological and falsifiable. No empirical claim of efficacy, AGI alignment, or existential-risk reduction is made. The framework is intended to clarify what evidence would be necessary to determine whether layered evaluation and independent action gating improve deployable safety while preserving human autonomy and task utility.

**Topics:** evaluation practices; sociotechnical AI safety; social epistemology; threat models and mitigations; value-sensitive design; human agency.

## Author preflight

1. Full paper anonymized (including document properties, filenames, brands, acknowledgements, linked repositories and self-citations), in ACM template.
2. Human author responsible for bibliographic accuracy, novelty, reasoning and responsible use of AI tools.
3. AI usage declaration prepared according to current FAccT 2027 guide.
4. Expert review of fit to FAccT (sociotechnical engagement vs purely hypothetical), with actual comparative results if feasible.
5. Abstract and paper registration according to official portal; dates currently 27 October and 3 November 2026, AoE. Do not claim submission until portal confirms it.
