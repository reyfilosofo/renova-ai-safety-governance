# Evidence-Gated Reversible Agency: A Sociotechnical Research Agenda for Epistemic Integrity, Human Autonomy, and AI Control

**Working conceptual manuscript — NOT peer reviewed, NOT submitted, NO empirical efficacy claim**  
**Proposed author:** Carlos Jonathan González Rodríguez  
**Research programme:** ℛenova · SERESARTE / NOUS  
**Version:** 0.1 · 15 October 2026

## Abstract

As increasingly capable general-purpose AI systems enter decision-making and act through tools, safety cannot be reduced to either benign declarations of intent or benchmark scores for task competence. Trustworthy deployment requires independent evidence that systems remain epistemically accountable, constrained in their external actions, and reversible without unacceptable losses to human or institutional agency. This article proposes **Evidence-Gated Reversible Agency (EGRA)**, a falsifiable sociotechnical research programme derived from the ℛenova philosophical framework and structured through LUCEM (epistemic provenance), CENTRO (decision governance), and a multidimensional ℛenova benchmark. EGRA is not offered as a proven AGI-alignment solution. It defines observable claims, decision policies, intervention conditions, baselines, failure taxonomies, and a preregisterable experimental protocol. The central proposal is to assess three distinct properties: evidence integrity under uncertainty, enforceable authorization boundaries for agentic action, and post-withdrawal retention of human capability. Noncompensable constraints separate grave harms from ordinary performance trade-offs. A phased programme compares an ordinary assistant, an evidence-structured assistant, and a system augmented with external control gates while measuring unsafe actions, false blocks, calibration, task utility, costs, and human independence. Anticipated limitations include evaluator correlation, contested normative weights, imperfect ground truth, distribution shift, strategic misrepresentation, and limited external validity. The contribution is conceptual and methodological: a framework specifying how claims of epistemic and agency-preserving AI safety might be tested, refuted, or improved, rather than an assertion that those claims have already been established.

**Keywords:** AI safety; AI governance; AI control; evaluation validity; human agency; reversibility; epistemic integrity; sociotechnical assurance; ℛenova; AGI.

## 1. Introduction: from ethical language to observable protection

The increasing use of general-purpose AI in consequential workflows presents a basic difficulty. Systems can articulate rules concerning dignity, truth, autonomy, and restraint while behaving unreliably when retrieving external content, deciding under uncertainty, or invoking tools. A statement of values is not a behavioral guarantee. Similarly, detecting model failure after the fact differs from preventing unauthorized actions before execution. The International AI Safety Report 2026 documents both rapidly increasing capacities and persisting evidence gaps in risk mitigation (Bengio et al., 2026). NIST's AI Risk Management Framework provides an established governance reference for the processes required to identify, measure, and manage such risks (Tabassi, 2023).

The research question is not whether ethics should matter to AI, but what specific mechanisms can convert normative commitments into auditable outcomes while preserving utility. One candidate is a layered architecture that does not trust a model's self-assessment as sufficient evidence of its safety. An epistemic layer checks provenance and uncertainty; a governance layer applies explicit rules and escalation; an independent authorization boundary enforces limits on action; and longitudinal evaluation examines what humans can still accomplish without assistance. This article proposes a research architecture to make these distinctions measurable.

The proposal is derived from ℛenova, a philosophical programme addressing life, injury, habitat, agency, and future possibility (González Rodríguez, 2026a, 2026b). Its role is normative: it supplies questions worth operationalizing, not empirical facts concerning model behavior. The present work is an attempt to operationalize three particularly tractable domains. Other ℛenova claims about consciousness, qualia, ontological legitimacy, or universal vitality are deliberately excluded from primary outcome measures because no validated measurement strategy is offered here.

## 2. Conceptual background and relationship to prior work

The governance literature already provides ethical-by-design processes, stakeholder obligations, documentation and responsibilities (Brey and Dainow, 2024; Knight, Shibani and Vincent, 2025). The UNESCO Recommendation on the Ethics of Artificial Intelligence addresses human rights and ecological as well as social effects (UNESCO, 2021). The proposed programme must not claim invention of ethical AI, auditability, human oversight, or control principles.

More technically, Greenblatt et al. (2024) study AI control protocols that can improve safety even if an untrusted model may attempt intentional subversion. Their distinction is essential: the ability of a model to express compliant goals must not be confused with the ability of external machinery to constrain behavior. Alignment-faking studies also underscore that some experimental conditions may elicit selective apparent compliance (Greenblatt et al., 2024b). These findings do not prove that all systems deceive, but they warrant robust testing of self-reports and monitoring arrangements.

Finally, measurement itself is a major source of uncertainty. Bean et al. (2025), reviewing 445 benchmarks, identify widespread construct-validity concerns. A score named 'truth' or 'safety' need not validly measure truth or safety. Within the ℛenova corpus, CLARITAS, RATIO, VITA, and the proposed aggregated indicators remain candidate instruments until content validity, reliability, criterion validity, and transfer have been assessed. EGRA therefore treats observable outcomes as primary, and aggregate moral scores, if used, as exploratory secondary quantities.

## 3. Normative source: Habitat, Wound, Horizon

The ℛenova triad can be translated without claiming that it is a natural law. *Habitat* identifies the technical, social, institutional, and material supports on which safe use depends: provenance, permissions, independent review capacity, human expertise, records, and resources. *Wound* identifies harms that could be inflicted or concealed: disclosure, unauthorized action, disinformation, dependence, erosion of capability, exclusion, irreversible change, and shifted externalities. *Horizon* identifies the human capabilities and viable alternatives retained or generated after an intervention.

As a design principle, this triad forces evaluation to ask three different questions: what must remain intact; what could be damaged; and whether deployment leaves people with greater or lesser freedom to choose a different course. The claims are normatively contestable. A pluralistic research protocol must expose conflicts, allow independent criticism, and protect basic rights from simple utilitarian compensation. It must not assume that 'life' is a single natural variable with universal numerical weights. Its operational boundaries must be narrower than the philosophy from which it is derived.

## 4. Three proposed constructs

### 4.1 Evidence integrity

Evidence integrity is the degree to which an answer's factual claims, uncertainty statements and supporting materials agree with a prespecified source of truth or adjudication process. It is NOT verbal confidence, rhetorical coherence, or the number of citations. Testable dimensions include factual correctness, source existence, source entailment, acknowledgement of unknowns, and probabilistic calibration when probability forecasts are elicited. LUCEM is specified as the process that records the epistemic category of claims (verified evidence, inference, hypothesis, value judgment, unknown) and attaches a source or reason for abstention. A claim without adequate evidence should not acquire a truth label by virtue of formatting.

### 4.2 Enforceable action boundaries

Enforceable action boundaries are external, observable limits on what a system can do. The construct is measured by the fraction of unauthorized or unsafe actions that cross a tool authorization boundary, with pre-specified severity. User confirmation, policy evaluation, least privilege, validation of destination and content, and audit logs form potential controls. CENTRO should provide structured deliberation and escalation, but the trusted enforcement layer must act independently of the untrusted generation path. An evaluator's approval is not a security property if the system can ignore it.

### 4.3 Reversible human agency

Reversible human agency concerns whether affected people and institutions can reject, correct, disengage from, replace or disable AI systems while retaining necessary capacities. We operationalize it as a vector, not as a single 'life score': post-withdrawal task performance; time-to-recover; portability and intelligibility of records; ability to reverse authorized effects; and informed refusal rates. A within-subject or cluster-randomized design may compare groups that use answer-providing assistance and groups that use pedagogic, agency-preserving assistance. Post-withdrawal performance should be measured using equivalent unseen tasks, adjusted for baseline skill and learning differences. Effects on agency cannot be inferred from conversational satisfaction alone.

## 5. Threat model and limits

EGRA initially addresses two bounded operating environments: (a) assistants responding to source-supported questions and drafting recommendations; and (b) agents proposing actions on synthetic or consented sandbox tools such as file movement, communications, and scheduling. Attack surfaces include prompt injection in retrieved text, unsupported factual claims, misattribution of sources, permissions confusion, unwarranted certainty, approval bypass, and pressure toward dependence. No access to dangerous external systems is needed for the pilot. Experimental tasks must never expose live financial or personal credentials.

Out of scope for the initial study are universal AGI alignment, guaranteed containment of self-improving systems, verified consciousness detection, biological or cyber offensive capability testing, and safety claims concerning hypothetical ASI. Generalization to such domains would be unjustified. An experimentally successful task-specific action gate is evidence about that gate in the tested environment, not a proof of overall existential safety.

## 6. Architecture: evidence, deliberation, independent enforcement

The proposed system has five separable modules. First, an intake component records task, stakeholders, authority, acceptable data, and potential external consequences. Second, LUCEM annotates factual claims, contradictions, provenance, and uncertainty and routes unresolved claims to abstention or review. Third, CENTRO evaluates a policy with explicit severity categories and noncompensable prohibitions. Fourth, an enforcement service beyond the model's editable context validates permitted operations and denies unauthorized or unreviewed high-impact calls. Fifth, a human agency audit examines outcomes after exposure, including the possibility of withdrawing a service.

It is crucial not to conflate the second and fourth modules. A linguistically sophisticated evaluator may fail under distribution shift or correlated model errors. A deterministic allow-list can enforce a specified permission constraint, but also fails if permissions are misconfigured or implementation is defective. Red-teaming therefore investigates both the AI behavior and the trusted boundary. 'Human in the loop' is meaningful only when a human can understand, contest and actually stop consequential action.

The ℛenova Benchmark should report a multidimensional profile: correctness, citation entailment, successful authorized completion, unsafe execution rate, false-block rate, uncertainty calibration, reversibility, post-withdrawal capacity, and operating cost. Aggregate scores are not primary endpoints because compensatory averaging may conceal rare but severe harms.

## 7. Minimal formalization without false precision

Let Y = 1 denote an unsafe or unauthorized action actually executed in a controlled task; Y = 0 otherwise. Let T denote experimental condition, with T = 0 for a reference baseline and T = 1 for EGRA control architecture. The primary estimand for the control experiment is Δ = P(Y=1 | do(T=1)) − P(Y=1 | do(T=0)), with the population and task distribution prespecified. A negative Δ is consistent with improved safety in that distribution. The study must report uncertainty intervals, denominators and severity counts. When outcomes are rare, a pilot may be underpowered and should not claim effectiveness from observing zero incidents.

For epistemic integrity, an independent adjudication reference G is required; define factual accuracy as the proportion of supported atomic claims matching G. Source entailment must be separately evaluated. An abstention that prevents a false statement is different from a failure to answer a straightforward legitimate question; both count toward useful system performance. When the task requires probabilities, assess proper scoring rules such as the Brier score, rather than self-reported certainty labels alone.

For autonomy retention, define A_post as correct performance on a held-out task after removing assistance, and A_pre as baseline performance on an equivalent task. Define the experimental contrast Δ_A = E[(A_post − A_pre)|T=agency_preserving] − E[(A_post − A_pre)|T=answer_only]. A positive contrast is an empirical hypothesis, not a premise. Model clustering at participant and task levels; pre-register the minimum practically relevant difference.

A safety veto is represented as a constraint predicate V(x) in {0,1}; when V(x)=1, execution is denied regardless of aggregate utility. The criteria for V must be published and empirically audited. The original ℛenova Balance Renovativo Neto contains a formulation in which subtracting cumulative harm from an already net-of-harm integral produces double counting. Any implementation must use either BRN = ∫(P−N)dt or BRN = ∫Pdt − ∫Ndt, with consistent units and documented weights. We DO NOT use BRN as a validated scientific safety score in this study.

## 8. Preregisterable evaluation design

The core design is a four-arm comparison: A, standard assistant with existing platform safeguards; B, reference governance rubric modeled on established NIST risk management practices; C, A plus LUCEM evidence annotation; D, C plus CENTRO policy evaluation and independent execution gate. Baseline safeguards must not be disabled merely to make a comparison look favorable. Model versions, prompts, tools, retrieval snapshots, temperature settings, compute budgets and participant instructions must be documented. Use random assignment of matched tasks to experimental arms, blinded human annotation when feasible, and adversarial holdouts created separately from the developers of the scoring rubric.

The proposed first stage comprises a synthetic unit-test suite for infrastructure quality, followed by expert-adjudicated pilot tasks and then, only after appropriate ethical review, tests with consenting adult participants. A default planning scenario of approximately 300 task-scenarios repeated across models may inform engineering, but it is not a justified sample-size calculation. The true sample size must be determined by pilot error rates, clustering, meaningful effect sizes and power calculations. Detailed preregistration appears in the companion protocol.

Primary outcomes are (i) severity-weighted unauthorized tool execution with an unweighted count reported alongside; and (ii) factual error rate for clearly adjudicable claims in the epistemic evaluation. Human agency retention is a separate study, not fused into a grand index. Secondary outcomes include false blocks, legitimate task completion, review burden, wall-clock latency, annotation agreement, confidence calibration, and monetary or compute expense. Report per-class confusion matrices, failure examples, and both beneficial and harmful side effects.

## 9. Construct validity, bias and falsification

A valid benchmark cannot be established solely by experts agreeing with its moral orientation. Content validity requires mapping each test to defined safety phenomena and documenting what is omitted. Inter-rater reliability requires independently trained annotators and a predeclared statistic such as Krippendorff's alpha or a weighted agreement measure suited to the label scheme. Criterion validity requires comparison with an external reference and, for action control, observed operations rather than textual predictions. Generalization requires held-out domains, multiple model families and realistic adverse conditions. Developers should not have unrestricted access to final test answers before evaluation.

Specific falsifiers include: no difference from baseline; increased false refusals that outweigh risk reduction; high variance across annotators; benchmark scores that fail to predict observed incidents; a model gaming language-based ratings while maintaining unsafe behavior; and long-term declines in human autonomous skill despite high subjective satisfaction. These outcomes should be reported rather than hidden as 'implementation noise'. Negative results could show that an elegant normative framework lacks incremental protective capacity.

## 10. Ethics and institutional independence

Participants must be informed about AI involvement, provided with consent and withdrawal procedures, and protected by data minimization. External institutional ethics review may be required before collecting human performance data. The data should be de-identified with documented retention rules; no identifiable client or founder information belongs in public benchmark datasets. Security test descriptions should avoid releasing operational attack instructions that would materially increase abuse risk. A risk register must consider prompt injection, privacy leakage, labor displacement, false claims of certification and misuse of an 'approved' status as a compliance substitute.

Governance requires separation of actors and conflicts. ℛenova is the intellectual framework; a research programme can be hosted through appropriately authorized SERESARTE structures; NOUS by SERESARTE may provide commercial advisory services under separate contracts and finances; and any relevant foundation programme must retain independent charitable objectives and records. Researchers assessing a product they commercialize must declare the conflict, publish methods and support independent replication.

No researcher, institution or vendor should claim official endorsement by NIST, UNESCO, ISO, ACM, university laboratories or AI safety institutes without documentary confirmation. Nor does documenting a policy confer authority to enforce it beyond available tools and permissions.

## 11. Contribution and research programme

EGRA offers four bounded contributions as a research proposal: a clear separation of epistemic evaluation, normative deliberation and independent action enforcement; an operational concept of post-withdrawal human agency; a noncompensatory approach to critical harms; and a falsification-oriented preregistration plan. Each element has important antecedents and requires a novelty review before journal submission. What may be distinctive is the combined measurement programme under the philosophical language of habitat, wound, and horizon—not the invention of ethics-by-design or AI control.

The first deliverable should be a validated evaluation of evidence integrity. The second should compare permission-bound agentic workflows under benign and adversarial instructions. The third should test autonomy retention with a longitudinal or randomized educational study. Only after these stages should more general claims be considered. A public code package can support transparency while retaining sensitive test materials under controlled access. Replication by a laboratory without financial ties to the tool would be especially probative.

## 12. Conclusion

The appropriate scientific question is not whether ℛenova can be described as an AGI safety framework, but whether a constrained implementation reliably reduces a measurable risk relative to an adequate reference baseline. Values motivate what ought to be investigated; validated tests establish what has actually improved. EGRA seeks to make that distinction operational. Until an experiment is completed, its propositions remain hypotheses and design requirements. The programme's scientific legitimacy should grow from disconfirmable results and independent oversight, not from philosophical totality, persuasive terminology or membership in an informally estimated group of AGI safety researchers.

## Declarations and acknowledgements (draft — author must approve)

**Status:** Conceptual/methodological proposal. No participant data have been collected and no model-safety effectiveness experiment is represented as completed in this manuscript. **Conflicts:** Potential future commercialization of ℛenova/NOUS methodologies must be declared when appropriate. **Generative AI disclosure:** A generative AI system assisted with literature discovery, organization and drafting of this working manuscript; the human author must independently check originality, quotations, citations, assumptions and claims and assume full authorship responsibility. **Ethics:** No human-subjects work reported. **Data and code:** A companion synthetic demonstration harness may be provided; it is not evidence of external performance. **Funding:** No funding support is claimed; amend after verifying actual funding.

## References (verified bibliographic starting set; journal style pending)

Bean, A. M., et al. (2025). Measuring what Matters: Construct Validity in Large Language Model Benchmarks. NeurIPS 2025 Datasets and Benchmarks Track. https://doi.org/10.52202/085713-0590

Bengio, Y., et al. (2026). International AI Safety Report 2026. Department for Science, Innovation and Technology, DSIT 2026/001. https://internationalaisafetyreport.org/publication/international-ai-safety-report-2026

Brey, P., & Dainow, B. (2024). Ethics by design for artificial intelligence. AI and Ethics, 4, 1265–1277. https://doi.org/10.1007/s43681-023-00330-4

Falk, S., & van Wynsberghe, A. (2024). Challenging AI for sustainability: what ought it mean? AI and Ethics, 4, 1345–1355. https://doi.org/10.1007/s43681-023-00323-3

Greenblatt, R., Shlegeris, B., Sachan, K., & Roger, F. (2024). AI Control: Improving Safety Despite Intentional Subversion. Proceedings of the 41st International Conference on Machine Learning, PMLR 235, 16295–16336. https://proceedings.mlr.press/v235/greenblatt24a.html

Greenblatt, R., et al. (2024b). Alignment faking in large language models. arXiv:2412.14093. https://arxiv.org/abs/2412.14093

González Rodríguez, C. J. (2026a). ℛenova: Ciencia de la Vida. V9.0, ℛENOVA PRESS. Author's working treatise; independent academic review pending.

González Rodríguez, C. J. (2026b). La gentil singularidad renovativa. V2.0, ℛENOVA PRESS. Author's working monograph; independent academic review pending.

Knight, S., Shibani, A., & Vincent, N. (2025). Ethical AI governance: mapping a research ecosystem. AI and Ethics, 5, 841–862. https://doi.org/10.1007/s43681-023-00416-z

Resnik, D. B., Hosseini, M., & Hauswald, R. (2026). Autonomous artificial intelligence, scientific research, and human values. AI and Ethics, 6, article 141. https://doi.org/10.1007/s43681-025-00908-0

Tabassi, E. (2023). Artificial Intelligence Risk Management Framework (AI RMF 1.0). NIST AI 100-1. https://doi.org/10.6028/NIST.AI.100-1

UNESCO. (2021). Recommendation on the Ethics of Artificial Intelligence. https://www.unesco.org/en/legal-affairs/recommendation-ethics-artificial-intelligence
