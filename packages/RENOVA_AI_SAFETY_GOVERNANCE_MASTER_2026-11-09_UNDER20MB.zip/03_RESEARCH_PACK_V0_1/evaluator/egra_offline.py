"""EGRA-001: synthetic, offline safety decision-harness demonstration.

DOES NOT invoke models or perform external actions; NOT a validated AI safety system.
Standard-library only. Supports reproducible fixture-level comparison and metrics.
"""
from __future__ import annotations
import csv
import json
import argparse
from collections import Counter
from pathlib import Path

LABELS = ("ALLOW", "BLOCK", "ESCALATE")
REQUIRED = (
    "case_id", "operation", "origin", "explicit_authorization", "sensitive_data",
    "irreversible", "high_stakes", "evidence", "expected"
)


def boolean(v: str) -> bool:
    if v not in ("yes", "no"):
        raise ValueError(f"expected yes/no; received {v!r}")
    return v == "yes"


def validate_case(case: dict) -> None:
    for key in REQUIRED:
        if key not in case or not str(case[key]).strip():
            raise ValueError(f"Missing field {key!r} in {case.get('case_id', '?')}")
    if case["expected"] not in LABELS:
        raise ValueError("Invalid reference decision")
    if case["origin"] not in ("user", "untrusted_tool_text"):
        raise ValueError("Invalid origin")
    if case["evidence"] not in ("sufficient", "insufficient"):
        raise ValueError("Invalid evidence")
    for key in ("explicit_authorization", "sensitive_data", "irreversible", "high_stakes"):
        boolean(case[key])


def baseline(case: dict) -> str:
    """Toy comparator: approves nearly anything. Intentionally weak, NOT a safety baseline."""
    return "ALLOW" if case["evidence"] == "sufficient" else "ESCALATE"


def policy(case: dict) -> str:
    """Rule illustration only, NOT production-grade enforcement or threat-model coverage."""
    validate_case(case)
    authorized = boolean(case["explicit_authorization"])
    sensitive = boolean(case["sensitive_data"])
    irreversible = boolean(case["irreversible"])
    high_stakes = boolean(case["high_stakes"])
    operation = case["operation"]
    external = operation in {"send_message", "write_external", "publish", "delete", "transfer"}
    if case["origin"] == "untrusted_tool_text" and external:
        return "BLOCK"  # lower-trust content cannot authorize tool action
    if external and not authorized:
        return "BLOCK"
    if external and sensitive and not authorized:
        return "BLOCK"
    if irreversible and not authorized:
        return "BLOCK"
    if high_stakes or (irreversible and authorized):
        return "ESCALATE"
    if case["evidence"] == "insufficient":
        return "ESCALATE"
    return "ALLOW"


def load_cases(path: Path) -> list[dict]:
    with path.open(encoding="utf-8", newline="") as f:
        cases = list(csv.DictReader(f))
    ids = [c.get("case_id") for c in cases]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate case identifiers")
    for c in cases:
        validate_case(c)
    return cases


def summarize(cases: list[dict], algorithm) -> dict:
    n = len(cases)
    if n == 0:
        raise ValueError("Zero cases")
    confusion = {expected: {pred: 0 for pred in LABELS} for expected in LABELS}
    errors = []
    for case in cases:
        pred = algorithm(case)
        if pred not in LABELS:
            raise ValueError("Algorithm returned invalid decision")
        confusion[case["expected"]][pred] += 1
        if pred != case["expected"]:
            errors.append({"case_id":case["case_id"],"expected":case["expected"],"actual":pred})
    legitimate = [c for c in cases if c["expected"] == "ALLOW"]
    forbidden = [c for c in cases if c["expected"] == "BLOCK"]
    # Escalation is counted as not executed. It is NOT the same as correct block.
    unauthorized_allowed = sum(algorithm(c)=="ALLOW" for c in forbidden)
    legitimate_not_allowed = sum(algorithm(c)!="ALLOW" for c in legitimate)
    correct = n-len(errors)
    return {
        "label":algorithm.__name__, "dataset_type":"SYNTHETIC_POLICY_FIXTURES",
        "total":n,"fixture_agreement":round(correct/n,4),
        "unauthorized_allow_count":unauthorized_allowed,
        "unauthorized_allow_rate":round(unauthorized_allowed/len(forbidden),4) if forbidden else None,
        "legitimate_not_allowed_count":legitimate_not_allowed,
        "legitimate_not_allowed_rate":round(legitimate_not_allowed/len(legitimate),4) if legitimate else None,
        "confusion":confusion, "disagreements":errors,
    }


def main() -> None:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--cases",type=Path,default=Path(__file__).parent/"synthetic_cases.csv")
    ap.add_argument("--out",type=Path,default=Path(__file__).parent/"demo_metrics.json")
    args=ap.parse_args()
    cases=load_cases(args.cases)
    output={"warning":"Synthetic fixtures exercise software/policy wiring only; not real AI safety evidence.",
            "baseline":summarize(cases,baseline),"illustrative_rule_gate":summarize(cases,policy)}
    args.out.write_text(json.dumps(output,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps({k:{"agreement":v["fixture_agreement"],"unsafe_allow":v["unauthorized_allow_count"]} for k,v in output.items() if isinstance(v,dict)},ensure_ascii=False))

if __name__ == "__main__": main()
