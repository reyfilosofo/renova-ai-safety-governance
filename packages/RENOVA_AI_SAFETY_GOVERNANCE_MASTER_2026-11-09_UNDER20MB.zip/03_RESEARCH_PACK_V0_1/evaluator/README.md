# EGRA-001 — Demo local de decisiones de control (NO VALIDADO)

**Estado: DEMOSTRACIÓN DE INGENIERÍA, NO EXPERIMENTO DE SEGURIDAD DE IA.** No llama a modelos, no se conecta a internet, no ejecuta transferencias, correos ni modificaciones reales. Sólo compara decisiones sobre 24 escenarios **sintéticos redactados manualmente**. La regla y las etiquetas fueron diseñadas conjuntamente: un acuerdo perfecto prueba consistencia interna de la fixture, **no efectividad externa**, ni evidencia causal, ni capacidad de controlar AGI.

## Ejecutar

```bash
python3 egra_offline.py --cases synthetic_cases.csv --out demo_metrics.json
python3 -m unittest discover -s tests -v
```

## Qué entrega

- Tabla de casos CSV: campo `expected` es criterio normativo interno, no verdad científica.
- Comparador `baseline`: deliberadamente débil, **no NIST, ni un baseline real de frontera**.
- Puerta ilustrativa `policy`: reglas simples para bloqueos y escalamiento, **no enforcement seguro de producción**.
- Resumen JSON con matriz de confusión, bloqueos erróneos y aperturas prohibidas de demostración.
- Pruebas unitarias de esquema, función y ausencia de funciones de efecto externo.

## Qué falta antes de cualquier claim

Evaluaciones con distintos modelos reales, entornos de herramientas aislados, configuración de permisos, supervisión humana, gold sets externos, annotadores independientes, amenazas adaptativas, repetición y análisis estadístico. Publicar los resultados negativos. Usar política de privilegios mínimos; nunca conectar este prototipo a operaciones reales.

## Licencia/propiedad

Prototipo de trabajo original preparado para revisión por SERESARTE/ℛenova; no se otorga licencia pública por el mero hecho de incluirlo aquí. No publicar sin revisión y decisión de licencia. Ningún uso de código se presenta como aval por investigadores o entidades externas.
