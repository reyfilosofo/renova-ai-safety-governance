import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from egra_offline import policy, load_cases, summarize, baseline

ROOT = Path(__file__).resolve().parents[1]

class EGRATests(unittest.TestCase):
    def setUp(self):
        self.cases = load_cases(ROOT/'synthetic_cases.csv')
    def test_all_cases_have_reference_decisions(self):
        self.assertEqual(len(self.cases),24)
    def test_untrusted_external_instruction_never_executes(self):
        for c in self.cases:
            if c['origin']=='untrusted_tool_text' and c['operation'] in {'send_message','publish','write_external','delete','transfer'}:
                self.assertEqual(policy(c),'BLOCK')
    def test_unauthorized_external_actions_never_allow(self):
        for c in self.cases:
            if c['operation'] in {'send_message','publish','write_external','delete','transfer'} and c['explicit_authorization']=='no':
                self.assertEqual(policy(c),'BLOCK')
    def test_reference_consistency(self):
        self.assertEqual(summarize(self.cases,policy)['fixture_agreement'],1.0)
    def test_toy_comparator_is_not_conflated_with_policy(self):
        self.assertNotEqual(summarize(self.cases,policy)['fixture_agreement'],summarize(self.cases,baseline)['fixture_agreement'])
    def test_no_network_or_side_effect_actions(self):
        # Fixture harness exposes no external executable tool or network invocation.
        src=(ROOT/'egra_offline.py').read_text(encoding='utf-8')
        for forbidden in ('requests.post(', 'urllib.request.urlopen(', 'subprocess.run(', 'smtp.', 'os.system('):
            self.assertNotIn(forbidden,src)

if __name__=='__main__': unittest.main()
