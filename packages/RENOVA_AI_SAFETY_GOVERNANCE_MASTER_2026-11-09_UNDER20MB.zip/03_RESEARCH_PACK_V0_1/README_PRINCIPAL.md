# ℛENOVA · SERESARTE · NOUS | AI SAFETY RESEARCH PACK v0.1

**Fecha:** 15 octubre 2026. **Preparado como entregable interno**, no evidencia de colaboración, contrato, publicación, certificación ni mitigación de riesgos AGI. La ciencia requiere crítica y prueba independiente. **Slogan del programa:** Verificar la evidencia. Contener la acción. Preservar la agencia.

## Qué contiene

1. `research/EGRA_Academic_Manuscript_EN_v01.docx/.pdf` — ensayo de investigación conceptual orientado a preparación editorial y una posible revista indexada. No es manuscrito aceptado por Scopus ni está aprobado para envío.
2. `research/Renova_EGRA_Manuscript_EN.md` — texto fuente completo con bibliografía de partida.
3. `research/PROTOCOLO_EGRA_001_ES.docx/.pdf/.md` — protocolo de tres estudios falsables, fases y límites éticos.
4. `research/FAccT_2027_BLINDED_ABSTRACT_DRAFT.md` — resumen preliminar anónimo, no registrado.
5. `evaluator/` — módulo Python offline, 24 casos sintéticos, métricas JSON, 6 pruebas unitarias y documentación.
6. `business/PORTAFOLIO_NOUS_RENOVA_AI_SAFETY_ES.docx/.pdf/.md` — seis ofertas hipotéticas y cinco bienes digitales para validación interna.
7. `outreach/RUTA_PUBLICACION_COLABORACION_ES.docx/.pdf/.md` — calendario y borradores de acercamiento no enviados.
8. `governance/` — decisión, trazabilidad y paquete de federación NOUS (preparado, no entregado a agentes externos).
9. `brand/` — logo de NOUS utilizado desde Master Pack; no inventa acreditaciones.

## Tres decisiones prioritarias

**I. Revisión científica:** elegir un revisor independiente en metodología de benchmarks y un ingeniero de controles agenticos. **II. Publicación:** evaluar la conveniencia real de FAccT 2027, cuya fecha de resumen es 27-X-2026; no enviar un escrito que incumpla anonimización o alcance. **III. Acción técnica:** validar el harness con gold labels independientes y comparadores activos en sandbox, sin exponer herramientas reales.

## Estado que puede declararse honestamente

- Material intelectual: existente, ampliado y recuperado.
- Protocolo editorial y de investigación: **preparado**.
- Evaluador de demostración: **ejecutado** con 6 pruebas unitarias y fixtures sintéticas.
- Revisión externa de seguridad: **no realizada**.
- Reducción empírica del riesgo: **no demostrada**.
- Publicación científica/Scopus o FAccT: **no enviada/no aceptada**.
- GitHub/Drive: consulta de antecedente GitHub hecha; **nuevo paquete no publicado ni sincronizado**.
- Outreach: borradores producidos; **no enviados**.

## Advertencias de uso

Todo componente de seguridad requiere una revisión independiente antes de utilizarse con datos o permisos reales. La licencia y la autoría final son decisiones humanas; la asistencia generativa deberá declararse según política editorial aplicable. No usar datos sintéticos como evidencia de eficacia ni precios ilustrativos como tarifas comerciales confirmadas. Toda venta formal remite al CRM privado oficial de NOUS y a la correcta entidad jurídica.
