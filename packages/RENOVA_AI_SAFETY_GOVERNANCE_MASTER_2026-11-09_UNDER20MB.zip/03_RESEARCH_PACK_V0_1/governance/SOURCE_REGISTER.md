# Registro mínimo de trazabilidad · EGRA-001

## Fuentes del corpus ℛenova revisadas

- *ℛenova: Ciencia de la Vida* V9.0 (14 julio 2026), manuscrito/edición del usuario, 808 páginas en copia accesible. Clasificación: FUENTE DEL AUTOR; no revisión por pares acreditada.
- *La gentil singularidad renovativa* V2.0 (30 julio 2026), capítulo 29 y Apéndices D/E, copia de biblioteca, 102 páginas. Clasificación: FUENTE DEL AUTOR; reconoce límites de validación.
- *Renova AI Governance Studio*, brochure; *ℛenova Governance Test v2.0*; catálogos NOUS. Clasificación: MATERIAL INTERNO; no prueba ventas ni eficacia.
- GitHub `reyfilosofo/renova-agent`, `04_NOUS/MANIFEST.md` y `04_NOUS/PRODUCT_MAP.yaml`, leídos el 15 octubre 2026 mediante conexión autorizada. Clasificación: REGISTRO TÉCNICO, fuente canónica pública-safe; precios privados en CRM.
- Paquetes maestros NOUS proporcionados al proyecto: marcas y reglas operativas. Clasificación: FUENTE INTERNA.

## Referencias externas verificadas al preparar este paquete

- NIST AI RMF 1.0, Tabassi (2023): https://doi.org/10.6028/NIST.AI.100-1. Uso: comparador de gobernanza, no certificación.
- Bengio et al., International AI Safety Report 2026: https://internationalaisafetyreport.org/publication/international-ai-safety-report-2026. Uso: panorama y límites de evidencias.
- Greenblatt et al., AI Control, ICML 2024: https://proceedings.mlr.press/v235/greenblatt24a.html. Uso: comparador técnico de controles ante modelo adversarial.
- Greenblatt et al., Alignment Faking (2024): https://arxiv.org/abs/2412.14093. Uso: amenaza al evaluador; no prueba universal.
- Bean et al., construct validity, NeurIPS 2025: https://doi.org/10.52202/085713-0590. Uso: metodología de benchmarks.
- UNESCO, Recommendation on the Ethics of AI (2021): https://www.unesco.org/en/legal-affairs/recommendation-ethics-artificial-intelligence. Uso: norma ética no vinculante automáticamente.
- Brey & Dainow, AI and Ethics (2024): https://doi.org/10.1007/s43681-023-00330-4. Uso: antecedente de ethics by design.
- Knight et al., AI and Ethics (2025): https://doi.org/10.1007/s43681-023-00416-z. Uso: antecedente de gobernanza.
- FAccT 2027 CFP: https://facctconference.org/2027/cfp.html; author guide: https://facctconference.org/2027/authorguide.html. Uso: plazos y requisitos de presentación; fecha de consulta 15 octubre 2026.

## Estatus general

No existe aquí censo validado de «200 investigadores» ni acreditación de pertenencia. No se revisaron exhaustivamente todas las publicaciones del campo ni todo el código previo de ℛenova. El experimento offline sólo demuestra funcionamiento de software local sobre datos sintéticos. Los porcentajes de fixture no se deben citar como tasa real de reducción de riesgo. Toda bibliografía debe revisarse por autor antes de publicación.
