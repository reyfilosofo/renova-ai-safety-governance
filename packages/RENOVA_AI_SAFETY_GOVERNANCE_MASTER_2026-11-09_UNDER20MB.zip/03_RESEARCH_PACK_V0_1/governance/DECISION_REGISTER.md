# REGISTRO EJECUTIVO Y EPISTÉMICO · EGRA-001

Date: 2026-10-15 · Packet: NOUS-AI-SAFE-2026-001 · Owner proposed: Carlos Jonathan González Rodríguez · Classification: RESERVADO PARA MIEMBROS (research coordination); commercial catalogue CONFIDENCIAL PARA CLIENTE/INTERNO.

| ID | Decisión / acción | Estado | Evidencia / restricción | Responsable propuesto | Siguiente control |
|---|---|---|---|---|---|
| D-01 | Reconocer ℛenova como programa amplio y EGRA como línea aplicada | DOCUMENTADO | Tratados ℛenova V9 y La gentil singularidad V2 | Autor | Revisión filosófica externa |
| D-02 | Corregir doble conteo algebraico de daño en BRN para cualquier fórmula experimental | DIAGNOSTICADO / CAMBIO NO APLICADO A FUENTES ORIGINALES | Definiciones del Apéndice D, libro V2 | Autor + matemático externo | Versión mayor con errata y pruebas |
| D-03 | Crear manuscrito y protocolo preregistrable | PREPARADO LOCALMENTE | Archivos de esta entrega | Investigador principal | Revisión bibliográfica/autoría |
| D-04 | Preparar eval offline sintético | EJECUTADO LOCALMENTE | 24 fixtures, 6 unit tests en 2026-10-15 | Desarrollo | Auditoría externa y muestras reales controladas |
| D-05 | Acreditar reducción de errores, daño o riesgos existenciales | NO ACREDITADO | Sin piloto comparativo con modelos reales ni replicación | Equipo científico independiente | Diseño de experimento y permisos |
| D-06 | Publicar artículo o enviar a FAccT | NO AUTORIZADO / NO REALIZADO | Fechas oficiales de CFP, requiere version ciega, validación de fuentes y decisión humana | Autor | Aprobar el envío concreto |
| D-07 | Publicar código en GitHub | NO REALIZADO | Código demostrativo local, licencia y revisión de divulgación pendientes | Responsable repositorio | Aprobar rama y licencia |
| D-08 | Reconciliar ofertas nuevas con CRM maestro privado NOUS | PENDIENTE | Manifest público GitHub exige catálogo privado como fuente | NOUS / ejecutivo | Leer CRM autorizado antes de cualquier cotización |
| D-09 | Contactar CHT, METR, Redwood u otros | NO REALIZADO | Sólo destinatarios institucionales propuestos, no alianzas | Autor | Elegir canal oficial y aprobar texto |
| D-10 | Abrir colaboración con una universidad | PENDIENTE | Ningún acuerdo acreditado | Fundación/operador, según objeto legal | Verificar entidad y objeto del convenio |

**No afirmar:** «somos parte de los 200», «evitamos AGI catastrófica», «aprobado por NIST/ISO/ACM», «sistema certificado», «artículo indexado Scopus», «código publicado», «experimento validado».

**Criterios de avance:** R0 método revisado; R1 ensayo piloto reproducible; R2 comparadores activos; R3 revisión externa; R4 publicación aceptada o informe negativo; R5 sólo métricas comerciales estrechamente fundamentadas.
