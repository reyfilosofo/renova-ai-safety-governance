# Fuentes y bibliografía - Lucem Renova

Fuentes verificadas integradas en el libro:

- Getty Museum / Martin Bommas, “I Am Isis”: The Role of Speech in the Cult of Isis. https://www.getty.edu/publications/egypt-classical-world/03/
- The Metropolitan Museum of Art, Statuette of Isis nursing Horus, Late Period, 664-332 B.C. https://www.metmuseum.org/art/collection/search/553002
- British Museum, Figure EA60756, Isis nursing Horus. https://www.britishmuseum.org/collection/object/Y_EA60756
- University of Memphis, Institute of Egyptian Art and Archaeology, Ptolemaic or Roman Relief from Philae. https://www.memphis.edu/egypt/resources/colortour/philae2.php
- Plutarch, De Iside et Osiride, Loeb Classical Library. https://www.loebclassics.com/view/plutarch-moralia_isis_osiris/1936/pb_LCL306.1.xml
- Sefaria, Exodus 25:37. https://www.sefaria.org/Exodus.25.37/
- Chabad.org, What is a Menorah / Chanukiah? https://www.chabad.org/holidays/chanukah/article_cdo/aid/1358679/jewish/What-is-a-Menorah-Chanukiah.htm
- Quran.com, Surah An-Nur 24:35. https://quran.com/an-nur/35
- The Metropolitan Museum of Art, Mosque Lamp / Image 6, Art of the Islamic World. https://www.metmuseum.org/learn/educators/curriculum-resources/art-of-the-islamic-world/unit-one/featured-works-of-art/image-6
- Nag Hammadi Library / Gnosis.org, The Thunder, Perfect Mind; Trimorphic Protennoia; Apocryphon of John. https://www.gnosis.org/naghamm/

Bibliografía académica complementaria incluida en el aparato final del libro:

- Allen, James P. The Ancient Egyptian Pyramid Texts.
- Assmann, Jan. The Search for God in Ancient Egypt.
- Bricault, Laurent. Isis en Occident.
- Dunand, Françoise. Le culte d’Isis dans le bassin oriental de la Méditerranée.
- Fowden, Garth. The Egyptian Hermes.
- Griffiths, J. Gwyn. The Origins of Osiris and His Cult.
- Hornung, Erik. Conceptions of God in Ancient Egypt.
- Meyer, Marvin, ed. The Nag Hammadi Scriptures.
- Pinch, Geraldine. Magic in Ancient Egypt.
- Witt, R. E. Isis in the Ancient World.
