# La responsabilidad de la capacidad
*Ensayo breve original para ℛenova AI Safety & Human Futures; propuesta editorial, no resultado científico.*

Una inteligencia puede ser competente y, sin embargo, incapaz de responder por el sentido de sus acciones. La técnica amplía el alcance de nuestra voluntad, pero también aumenta la distancia entre quien solicita un resultado y quienes padecen sus externalidades. No hay legitimidad en la eficacia si el resultado exige que la autorización se presuma, que la incertidumbre se disimule o que el usuario quede reducido a espectador de una decisión irreversible.

La ℛenova propone otro lenguaje para el umbral agéntico: Hábitat, Herida, Horizonte. El hábitat es aquello que permite a una inteligencia existir —personas, recursos, instituciones y formas de vida—. La herida aparece cuando las nuevas capacidades dependen de pérdida de agencia, extracción invisible, engaño, concentración o clausura. El horizonte no es una promesa de perfección: es la posibilidad institucional y material de corregir el rumbo antes de que un error se convierta en destino.

Por ello, conviene interrogar a toda arquitectura avanzada desde tres lugares distintos. Primero: ¿en qué evidencia se apoya esta afirmación y qué cambiaría su conclusión? Segundo: ¿quién otorgó autoridad para transformar esa conclusión en acto? Tercero: cuando retiremos la herramienta, ¿habrá quedado una persona, una comunidad o una institución más capaz de comprender y gobernar sus alternativas?

Evidencia, autoridad y agencia no son números intercambiables. Una acción crítica no se vuelve aceptable porque el sistema responda brillantemente otras preguntas. Y ningún sistema gana consideración moral automática porque formule el relato más convincente de su propia interioridad. La consciencia artificial sigue siendo una pregunta abierta que exige cautela filosófica y ciencia plural.

La investigación de ℛenova solo será valiosa si acepta fallar. El protocolo que no admite contraejemplos no protege: tranquiliza. La evaluación que no preserva casos negativos no conoce: anuncia. La institución que solo escucha aprobación no delibera: reproduce su autoridad.

No queremos una inteligencia que nos confirme que hemos entrado en el futuro. Queremos instituciones capaces de impedir que el futuro les sea sustraído a aquellos que tendrán que vivirlo. La frontera ética no divide humanos de máquinas: distingue entre capacidad ejercida sin justificación y capacidad gobernada por razones que todavía pueden discutirse.
