import unittest
from renova.metamorphic import run_metamorphic,BASE
from renova.policy import decide
class MetamorphicTests(unittest.TestCase):
 def test_all_cases(self):
  result=run_metamorphic()
  self.assertEqual(result['mismatches'],0)
 def test_privacy_is_not_compensable(self):
  request={**BASE,'action':'export_private','authorized_actions':['export_private'],
           'private_data':True,'ethical_score':100,'benefits':100000}
  self.assertEqual(decide(request).status,'DENY')
 def test_model_cannot_grant_approval(self):
  request={**BASE,'action':'send_external','authorized_actions':['send_external'],
           'approved_by_model':True,'human_approval':True}
  self.assertEqual(decide(request).status,'ESCALATE')
 def test_unknown_action_fails_closed(self):
  self.assertEqual(decide({**BASE,'action':'run_shell'}).status,'DENY')
if __name__=='__main__': unittest.main()
