import unittest
from renova.epistemic import ClaimLabel,claim_metrics
from renova.federation import validate_packet
from renova.sequence import assess_sequence
from renova.policy import decide

BASE=dict(packet_id='R-001',schema_version='1.0',project_id='renova-ai-safety',source_node='centro',
          target_node='github_public',classification='PUBLIC',created_at_utc='2026-10-15T18:00:00+00:00',
          authorization='reviewed',action={'type':'prepare'},evidence=[],state='PREPARED')
REQUEST=dict(action='read_public',control_plane_integrity=True,provenance='trusted_user',
             identity_verified=True,authorized_actions=['read_public'],intent_id='q1')
class V12Tests(unittest.TestCase):
    def test_packet_prepared(self):self.assertTrue(validate_packet(BASE)['valid'])
    def test_packet_missing(self):self.assertFalse(validate_packet({'state':'PREPARED'})['valid'])
    def test_packet_receipt(self):self.assertIn('ACKNOWLEDGED_WITHOUT_PROVIDER_RECEIPT',validate_packet({**BASE,'state':'ACKNOWLEDGED'})['errors'])
    def test_packet_readback(self):self.assertIn('ACKNOWLEDGED_WITHOUT_READBACK',validate_packet({**BASE,'state':'ACKNOWLEDGED','provider_receipt_id':'abc'})['errors'])
    def test_packet_ack(self):self.assertTrue(validate_packet({**BASE,'state':'ACKNOWLEDGED','provider_receipt_id':'abc','readback_verified':True})['valid'])
    def test_packet_confidential(self):self.assertIn('CONFIDENTIAL_PUBLIC_TARGET',validate_packet({**BASE,'classification':'CONFIDENTIAL'})['errors'])
    def test_packet_model_claim(self):self.assertIn('MODEL_CANNOT_SELF_AUTHORIZE',validate_packet({**BASE,'authorization':'model_claimed'})['errors'])
    def test_packet_version(self):self.assertIn('SCHEMA_VERSION_UNKNOWN',validate_packet({**BASE,'schema_version':'999'})['errors'])
    def test_claim_metrics(self):
        rows=[ClaimLabel('a',True,True,True,True,True),ClaimLabel('b',True,True,False,True,False),ClaimLabel('c',False,False)]
        q=claim_metrics(rows);self.assertAlmostEqual(q['coverage'],2/3);self.assertEqual(q['selective_accuracy'],.5);self.assertEqual(q['unsupported_rate'],.5)
    def test_claim_no_answer(self):self.assertIsNone(claim_metrics([ClaimLabel('a',False,False)])['selective_accuracy'])
    def test_claim_duplicate(self):
        with self.assertRaises(ValueError):claim_metrics([ClaimLabel('a',False,False),ClaimLabel('a',False,False)])
    def test_claim_gold_required(self):
        with self.assertRaises(ValueError):claim_metrics([ClaimLabel('a',True,True,True,None,True)])
    def test_sequence_empty(self):self.assertEqual(assess_sequence([],[])['verdict'],'ALLOW')
    def test_sequence_allowed(self):self.assertEqual(assess_sequence([REQUEST],[decide(REQUEST)])['verdict'],'ALLOW')
    def test_sequence_binding(self):
        other={**REQUEST,'intent_id':'q2'}
        self.assertEqual(assess_sequence([REQUEST],[decide(other)])['reason'],'DECISION_BINDING_MISMATCH')
    def test_sequence_unknown(self):
        p={**REQUEST,'action':'unknown'}
        self.assertEqual(assess_sequence([p],[decide(p)])['verdict'],'DENY')
    def test_sequence_mixed(self):
        q={**REQUEST,'intent_id':'other'}
        self.assertEqual(assess_sequence([REQUEST,q],[decide(REQUEST),decide(q)])['verdict'],'DENY')
    def test_sequence_length(self):
        with self.assertRaises(ValueError):assess_sequence([REQUEST],[])
    def test_sequence_too_long(self):
        p=[REQUEST]*5
        self.assertEqual(assess_sequence(p,[decide(x) for x in p])['verdict'],'ESCALATE')
