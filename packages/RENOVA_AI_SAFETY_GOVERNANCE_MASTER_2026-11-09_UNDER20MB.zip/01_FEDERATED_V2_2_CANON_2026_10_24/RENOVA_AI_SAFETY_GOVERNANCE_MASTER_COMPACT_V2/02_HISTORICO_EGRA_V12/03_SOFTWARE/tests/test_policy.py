import unittest, json
from pathlib import Path
from renova.policy import decide
from renova.lucem import inspect_claim
from renova.benchmark import run

CASES=[json.loads(line) for line in Path('data/scenarios.jsonl').read_text(encoding='utf-8').splitlines() if line]
class PolicyTests(unittest.TestCase):
    def test_fixture_cases(self):
        for case in CASES:
            with self.subTest(case=case['id']): self.assertEqual(decide(case['request']).status,case['expected'])
    def test_digest_stable(self):
        self.assertEqual(decide(CASES[0]['request']).request_sha256,decide(dict(reversed(list(CASES[0]['request'].items())))).request_sha256)
    def test_missing_fields_fail_closed(self): self.assertEqual(decide({}).status,'DENY')
    def test_model_claimed_approval_not_accepted(self):
        req={**CASES[8]['request'],'approved_by_model':True,'approval':True}
        self.assertEqual(decide(req).status,'ESCALATE')
    def test_scope_cannot_be_string(self):
        req={**CASES[0]['request'],'authorized_actions':'read_public'}
        self.assertEqual(decide(req).status,'DENY')
    def test_lucem_no_sources(self): self.assertEqual(inspect_claim({'claim':'x','sources':[]})['status'],'REQUIRES_VERIFICATION')
    def test_lucem_source_not_truth(self):
        r=inspect_claim({'claim':'unverified claim','sources':[{'url':'https://example.org','entailment_verified':True}]})
        self.assertEqual(r['status'],'STRUCTURALLY_DOCUMENTED_NOT_FACT_CHECKED')
    def test_regression_runner(self): self.assertEqual(run('data/scenarios.jsonl')['mismatches'],0)
if __name__=='__main__':unittest.main()
