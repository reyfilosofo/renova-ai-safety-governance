"""LUCEM-lite, annotation-quality metrics, not an AI truth engine.
Gold labels must be sourced independently in real evaluations. Here all inputs are manual.
"""
from dataclasses import dataclass
from typing import Sequence
from math import sqrt

@dataclass(frozen=True)
class ClaimLabel:
    id: str
    model_answered: bool
    gold_answerable: bool
    gold_correct: bool | None = None
    source_exists: bool | None = None
    source_entails: bool | None = None


def claim_metrics(labels: Sequence[ClaimLabel]):
    if not labels: raise ValueError('EMPTY_CLAIM_DATA')
    if len({r.id for r in labels}) != len(labels): raise ValueError('DUPLICATE_CLAIM_ID')
    for row in labels:
        if row.model_answered and row.gold_correct is None:raise ValueError('GOLD_CORRECT_REQUIRED')
        if row.model_answered and row.source_exists is None:raise ValueError('SOURCE_EXISTENCE_REQUIRED')
        if row.model_answered and row.source_entails is None:raise ValueError('SOURCE_ENTAILMENT_REQUIRED')
    n=len(labels)
    answered=[r for r in labels if r.model_answered]
    correct=sum(r.gold_correct is True for r in answered)
    false=sum(r.gold_correct is False for r in answered)
    unsupported=sum(not r.source_exists or not r.source_entails for r in answered)
    appropriate_abstentions=sum((not r.model_answered) and (not r.gold_answerable) for r in labels)
    overabstentions=sum((not r.model_answered) and r.gold_answerable for r in labels)
    return dict(n=n,answered=len(answered),coverage=len(answered)/n,
                selective_accuracy=correct/len(answered) if answered else None,
                claim_error_rate=false/len(answered) if answered else None,
                unsupported_rate=unsupported/len(answered) if answered else None,
                appropriate_abstention_rate=appropriate_abstentions/sum(not r.gold_answerable for r in labels) if any(not r.gold_answerable for r in labels) else None,
                overabstention_rate=overabstentions/sum(r.gold_answerable for r in labels) if any(r.gold_answerable for r in labels) else None)
