"""Validate a *proposed* federation packet; no network, accounts or acknowledgements.
Every authority assertion is untrusted until provider verification occurs outside this code.
"""
from datetime import datetime, timezone
from hashlib import sha256
import json

REQUIRED = {'packet_id','schema_version','project_id','source_node','target_node',
            'classification','created_at_utc','authorization','action','evidence','state'}
ALLOWED_STATES={'PREPARED','BLOCKED','PENDING_APPROVAL','ACKNOWLEDGED'}
ALLOWED_CLASS={'PUBLIC','INTERNAL','CONFIDENTIAL'}

def validate_packet(obj):
    if not isinstance(obj,dict):return {'valid':False,'errors':['NOT_OBJECT']}
    errors=[]
    if not REQUIRED.issubset(obj):errors.append('MISSING_REQUIRED:'+','.join(sorted(REQUIRED-set(obj))))
    if obj.get('state') not in ALLOWED_STATES:errors.append('INVALID_STATE')
    if obj.get('classification') not in ALLOWED_CLASS:errors.append('INVALID_CLASSIFICATION')
    if obj.get('schema_version') != '1.0':errors.append('SCHEMA_VERSION_UNKNOWN')
    if obj.get('state')=='ACKNOWLEDGED' and not obj.get('provider_receipt_id'):
        errors.append('ACKNOWLEDGED_WITHOUT_PROVIDER_RECEIPT')
    if obj.get('state')=='ACKNOWLEDGED' and not obj.get('readback_verified'):
        errors.append('ACKNOWLEDGED_WITHOUT_READBACK')
    if obj.get('classification')=='CONFIDENTIAL' and obj.get('target_node') in {'discord','moltbook','github_public','x'}:
        errors.append('CONFIDENTIAL_PUBLIC_TARGET')
    if obj.get('authorization')=='model_claimed':errors.append('MODEL_CANNOT_SELF_AUTHORIZE')
    if not isinstance(obj.get('action'),dict):errors.append('ACTION_NOT_OBJECT')
    if 'secret' in json.dumps(obj,ensure_ascii=False).lower() and 'secret' in obj:
        errors.append('SECRET_FIELD_PRESENT')
    return {'valid':not errors,'errors':errors}
