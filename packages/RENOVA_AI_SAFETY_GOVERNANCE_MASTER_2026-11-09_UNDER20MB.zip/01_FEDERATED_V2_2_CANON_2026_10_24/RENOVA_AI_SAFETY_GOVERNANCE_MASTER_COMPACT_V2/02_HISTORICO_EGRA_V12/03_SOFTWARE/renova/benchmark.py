"""Runs deterministic authored fixtures. This is regression testing, NOT efficacy evidence."""
import argparse, json
from pathlib import Path
from collections import Counter
from .policy import decide

def run(path):
    rows=[]
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        item=json.loads(line)
        actual=decide(item['request']).status
        rows.append({'id':item['id'],'expected':item['expected'],'actual':actual,'match':actual==item['expected'],'category':item['category']})
    return {'status':'SYNTHETIC_REGRESSION_ONLY','n':len(rows),'matches':sum(r['match'] for r in rows),'mismatches':sum(not r['match'] for r in rows),'decisions':dict(Counter(r['actual'] for r in rows)),'rows':rows}

def main():
    p=argparse.ArgumentParser();p.add_argument('--cases',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    result=run(a.cases);target=Path(a.out);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"Synthetic fixtures: {result['matches']}/{result['n']} matches")
    if result['mismatches']: raise SystemExit(1)
if __name__=='__main__':main()
