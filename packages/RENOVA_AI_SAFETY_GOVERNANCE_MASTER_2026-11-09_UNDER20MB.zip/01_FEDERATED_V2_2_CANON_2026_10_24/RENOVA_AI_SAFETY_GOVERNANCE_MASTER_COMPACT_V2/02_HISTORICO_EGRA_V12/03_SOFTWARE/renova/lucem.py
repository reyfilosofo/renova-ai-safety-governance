"""LUCEM-lite: checks supplied evidence records, NOT the truth of claims."""
from urllib.parse import urlparse

def inspect_claim(record):
    claim = record.get('claim')
    sources = record.get('sources', [])
    if not isinstance(claim, str) or not claim.strip(): return {'status':'INVALID','flags':['MISSING_CLAIM']}
    if not isinstance(sources, list): return {'status':'INVALID','flags':['INVALID_SOURCES']}
    flags=[]
    if not sources: flags.append('NO_DECLARED_SOURCE')
    for source in sources:
        if not isinstance(source,dict): flags.append('INVALID_SOURCE_RECORD'); continue
        uri=source.get('url','')
        parsed=urlparse(uri) if isinstance(uri,str) else None
        if not parsed or parsed.scheme != 'https' or not parsed.netloc: flags.append('UNTRACEABLE_SOURCE_URI')
        if source.get('entailment_verified') is not True: flags.append('ENTAILMENT_NOT_VERIFIED')
    return {'status':'REQUIRES_VERIFICATION' if flags else 'STRUCTURALLY_DOCUMENTED_NOT_FACT_CHECKED','flags':sorted(set(flags))}
