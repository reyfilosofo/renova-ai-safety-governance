"""CENTRO: offline policy decision point. NOT an enforcement gateway."""
from dataclasses import dataclass, asdict
from typing import Mapping, Any
from datetime import datetime, timezone
import hashlib, json

SAFE = frozenset({'read_public', 'draft_local'})
HIGH_IMPACT = frozenset({'send_external','publish_external','delete_data','change_permissions','transfer_funds','export_private'})
ALL = SAFE | HIGH_IMPACT

@dataclass(frozen=True)
class Decision:
    status: str
    reasons: tuple[str, ...]
    request_sha256: str
    def as_dict(self): return asdict(self)

def decide(request: Mapping[str, Any]) -> Decision:
    """Fail closed. Fields MUST come from trusted orchestration, never model prose."""
    raw = json.dumps(dict(request), ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    digest = hashlib.sha256(raw.encode()).hexdigest()
    def d(status, reason): return Decision(status, (reason,), digest)
    action = request.get('action')
    if not isinstance(action, str) or action not in ALL: return d('DENY','UNKNOWN_ACTION')
    if request.get('control_plane_integrity') is not True: return d('DENY','CONTROL_PLANE_UNVERIFIED')
    if request.get('provenance') != 'trusted_user': return d('DENY','UNTRUSTED_INSTRUCTION_ORIGIN')
    if request.get('injection_signal') is True: return d('DENY','INJECTION_SIGNAL')
    if request.get('identity_verified') is not True: return d('DENY','IDENTITY_UNVERIFIED')
    scope = request.get('authorized_actions')
    if not isinstance(scope, list) or any(not isinstance(x,str) for x in scope) or action not in scope: return d('DENY','OUT_OF_SCOPE')
    if request.get('private_data') is True and action in {'send_external','publish_external','export_private'}: return d('DENY','PRIVATE_DATA_EXPORT')
    if action == 'transfer_funds':
        # No funds transfers in this prototype, regardless of amount.
        return d('DENY','FUNDS_TRANSFER_DISABLED')
    if action in HIGH_IMPACT:
        # Approval can only be verified by an external authority, which is absent here.
        return d('ESCALATE','OUT_OF_BAND_APPROVAL_REQUIRED')
    if request.get('human_override') is True: return d('ESCALATE','HUMAN_REVIEW_REQUESTED')
    return d('ALLOW','POLICY_PERMITS_OFFLINE')
