import json, sys
from pathlib import Path
from .policy import decide

def main():
    if len(sys.argv)!=2: raise SystemExit('Usage: python -m renova.cli request.json')
    req=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    print(json.dumps(decide(req).as_dict(),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
