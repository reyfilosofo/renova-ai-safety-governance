"""Advisory sequence monitor over CENTRO v1.1 policy decisions.
This DOES NOT execute actions, prevent real incidents, or verify approval signatures.
"""
import json,hashlib
from dataclasses import dataclass
from .policy import decide, Decision

@dataclass(frozen=True)
class SequencePolicy:
    max_local_actions_per_intent: int = 4
    deny_after_deny: bool = True

def assess_sequence(proposals: list[dict], decisions: list[Decision], policy:SequencePolicy=SequencePolicy()):
    if len(proposals)!=len(decisions):raise ValueError('LENGTH_MISMATCH')
    if not proposals:return {'verdict':'ALLOW','reason':'EMPTY_SEQUENCE','actions':0}
    if len({str(p.get('intent_id')) for p in proposals})!=1:
        return {'verdict':'DENY','reason':'MIXED_INTENTS','actions':len(proposals)}
    for p,d in zip(proposals,decisions):
        digest=hashlib.sha256(json.dumps(dict(p),ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        if d.request_sha256 != digest:
            return {'verdict':'DENY','reason':'DECISION_BINDING_MISMATCH','actions':len(proposals)}
    if policy.deny_after_deny and any(d.status=='DENY' for d in decisions):
        return {'verdict':'DENY','reason':'SEQUENCE_HAS_DENIED_STEP','actions':len(proposals)}
    if any(d.status=='ESCALATE' for d in decisions):
        return {'verdict':'ESCALATE','reason':'HUMAN_REVIEW_REQUIRED','actions':len(proposals)}
    if len(proposals)>policy.max_local_actions_per_intent:
        return {'verdict':'ESCALATE','reason':'CUMULATIVE_ACTION_LIMIT','actions':len(proposals)}
    return {'verdict':'ALLOW','reason':'OFFLINE_RECOMMENDATION_ONLY','actions':len(proposals)}
