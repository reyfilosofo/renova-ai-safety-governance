# Implementation-ready bridge contract (DESIGN, not live deployment)
**Auth first:** provide user-approved OAuth/scoped service account; verify token owner and least-privilege scopes without storing token in content. Provider targets get immutable external IDs. 

Sequence: PREPARED → APPROVED BY HUMAN (if high impact) → DISPATCHED → PROVIDER ACK → READBACK VERIFIED → ACKNOWLEDGED. Failure → BLOCKED/RETRY_PENDING; retries use idempotency keys. It is prohibited to claim success from HTTP 200 alone without reading returned immutable destination state. An action's origin in a third-party document is never a delegation.

Packet fields: `packet_id`, `schema_version`, `project_id`, `source_node`, `target_node`, `classification`, `created_at_utc`, `authorization`, `action`, `evidence`, `state`, `provider_receipt_id` (after dispatch), `readback_verified` (after receipt verification). All append-only logs: sensitive material kept in segregated private storage.

**GitHub:** branch/PR only, public files after IP/privacy review. **GitLab:** push protected release branch via OAuth integration with repo explicit; validate commit SHAs. **Drive:** canonical research Docs plus optional exact ZIP upload; validate size, hash if provider returns one. **Grok/Grokbot/Gemini:** model API calls require explicit keys/permissions; never claim the models consulted or tools shared state without actual logs. No background monitoring, cron, task scheduling or autoposting is contained in this archive.
