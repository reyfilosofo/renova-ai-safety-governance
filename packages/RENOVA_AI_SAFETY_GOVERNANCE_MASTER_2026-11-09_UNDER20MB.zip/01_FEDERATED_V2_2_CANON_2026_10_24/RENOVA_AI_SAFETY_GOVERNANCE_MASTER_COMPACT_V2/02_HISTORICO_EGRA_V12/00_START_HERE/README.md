# ℛENOVA AI SAFETY & GOVERNANCE | MASTER RESEARCH RELEASE v1.2
**Cutoff:** 2026-10-15 | **Originating author / philosophical framework:** Carlos Jonathan González Rodríguez (SERESARTE / ℛenova)
**Engineering status:** OFFLINE DEMONSTRATION / SYNTHETIC TESTING (E2) — NOT CERTIFIED, DEPLOYED OR PEER REVIEWED.

## What is newly delivered in v1.2

- Preserved CENTRO v1.1 policy engine and tests, **plus** newly authored LUCEM annotation metrics, one-packet federation validation, sequence-collision risk checker, and independent tests for the new functions.
- Synthetic development dataset with 128 crafted action proposals and explicitly marked self-authored expected decisions. No held-out evaluation and **no simulated real model**.
- A falsifiable design for EGRA dimensions **E** (epistemic), **A** (action authority), **H** (unaided human capability), **U** (task utility) and **C** (cost).
- Literature and preregistration documents, conceptual manuscript (English), Spanish executive report, annotated threats, 64 philosophical questions, a poem, six product specifications and publication drafts.
- Authenticated source preservation: immutable v1.1 archive, Research Pack v0.1, the 33-page ℛenova position paper, and previous v0.4 master as separate archives. These items retain their authorial rights.
- Connector specification and integration-status register. A tool/connector being present in ChatGPT is **NOT** an external agent bridge or autonomous synchronization.

## Quick start — offline, Python >=3.10
From `03_SOFTWARE`:
```shell
python -m unittest discover -s tests -v
```
From this package's root you can inspect the notes and versioned files without invoking network services.

**Safety boundary:** Neither `ALLOW` nor a successful test grants real permission or executes actions. NEVER bind to actual tools without an independently authenticated control-plane, external policy enforcement point, system security review, scope limitation, replay protection, rollback, immutable audit and adaptive red-team testing.

**Level E2:** Development-team synthetic engineering tests. This is not evidence of reduction in real-world accidents, adversarial success, model hallucinations, human cognitive dependency, or risks of AGI.

## Rights
The original author's books, previous ZIPs and proprietary materials are **archived with their existing rights**; the presence of an MIT license inside the v1.1 archive does not extend that license to these items or to all of v1.2. New code in this package is supplied for independent review; licensing before third-party redistribution requires a separate author decision. Do not upload the private archive to a public GitHub repository.

## Top-level contents
- `01_RESEARCH`: research protocols and source register
- `02_EXPERIMENTS`: threat model and measurement plan
- `03_SOFTWARE`: executable offline examples and tests
- `04_BENCHMARK`: development-only fixtures and dataset card
- `05_PRODUCTS`: bounded product proposals
- `06_EDITORIAL`: essays, 64 questions, poetry, public drafts
- `07_FEDERATION`: connector contracts and verifiable integration ledger
- `08_PROVENANCE`: checksums, origin log and executed tests
- `09_SOURCE_ARCHIVE`: unchanged previous versions / author-provided primary files

**No scheduled task is created or deployed.**
