# Six product release gates — 2026-10-15
| Product | Actual state | What can be offered | What cannot be asserted |
|---|---|---|---|
| CENTRO Guard offline | unit-tested demo E2 | prototype code + bounded policy-review workshop | working live tool interception / certified agent safety |
| LUCEM Evidence Audit | annotated metric code E1–E2 | claim-evidence review with human adjudication | automatic truth detection |
| EGRA Comparison Study | design only E0–E1 | methodological study protocol | causally proven superiority |
| Reversible Human Agency | protocol only E0 | research proposal after ethical approval | increased human skill proven |
| NOUS Governance Readiness | documentation E1 | gap analysis for defined standards | ISO certification / legal compliance guarantee |
| ℛenova Academy AI Safety | curricular concept E0 | literature-based educational workshop | professional accreditation |

**Commercial boundary:** no prices, sales, signatures, insurance, certifications or external endorsements are implied by these files. Disclose conflicts and preserve scientific independence from commercial pressure.
