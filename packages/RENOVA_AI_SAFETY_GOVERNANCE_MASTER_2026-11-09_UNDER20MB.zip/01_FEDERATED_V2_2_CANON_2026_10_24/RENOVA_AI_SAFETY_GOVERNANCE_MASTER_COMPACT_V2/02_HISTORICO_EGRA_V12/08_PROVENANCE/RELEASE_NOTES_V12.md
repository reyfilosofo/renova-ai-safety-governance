# Release notes / delta — 2026-10-15
The v1.1 code and corpus remain unchanged in `09_SOURCE_ARCHIVE`. The v1.1 offline baseline is extracted without bytecode; this v1.2 adds a claim-label metric module, provider-receipt packet checker, composite-sequence monitor and unit tests, plus epistemic and action-control preregistration protocols, expanded publication/ethics boundaries and all-source provenance.

**New deterministic tests:** additional test methods in `tests/test_v12.py`, executed together with v0.5 tests. This is a developer regression check only; not evidence of effectiveness on external AI systems. A public repository should host the public-code-only subset, never this full rights-bearing ZIP.
