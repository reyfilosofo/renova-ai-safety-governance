# Research orientation and verified sources — 15 October 2026
This is a targeted background review, not a PRISMA systematic review and not a Scopus-indexing claim. Every source below was checked against official publisher, author-maintained work, or standards institution pages in this session.

1. Greenblatt, R.; Shlegeris, B.; Sachan, K.; Roger, F. (2024). **AI Control: Improving Safety Despite Intentional Subversion.** ICML / PMLR 235, 16295–16336. https://proceedings.mlr.press/v235/greenblatt24a.html (peer-reviewed proceedings).
2. Farquhar, S.; Kossen, J.; Kuhn, L.; Gal, Y. (2024). **Detecting hallucinations in large language models using semantic entropy.** *Nature* 630, 625–630. https://doi.org/10.1038/s41586-024-07421-0 (peer-reviewed article).
3. Debenedetti, E.; Zhang, J.; Balunović, M.; Beurer-Kellner, L.; Fischer, M.; Tramèr, F. (2024). **AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents.** NeurIPS Datasets & Benchmarks. https://openreview.net/forum?id=m1YYAQjO3w (conference paper; check publication copy before any direct quotation).
4. NIST NCCoE (2026). **Accelerating the Adoption of Software and Artificial Intelligence Agent Identity and Authorization** (initial public draft, published 5 February 2026). https://csrc.nist.gov/pubs/other/2026/02/05/accelerating-the-adoption-of-software-and-ai-agent/ipd (government concept paper; NOT a technical standard or certification).
5. NIST, **AI Risk Management Framework 1.0**. https://www.nist.gov/itl/ai-risk-management-framework (voluntary government framework).
6. UK AI Security Institute, **Inspect AI: evaluation framework**. https://inspect.aisi.org.uk/ (technical framework).
7. ACM FAccT **2027 Call for Papers**, abstract deadline 27 Oct 2026, paper deadline 3 Nov 2026. https://facctconference.org/2027/cfp.html (conference call, NOT a scientific paper).

**Prior-art interpretation:** ℛenova did not invent external agent authorization, prompt-injection benchmarks, or semantic-entropy approaches. Hypothetical contribution is *joint measurement* of E / A / H in a sociotechnical system. Distinct empirical gain must be established through strong fair comparators and independent adjudication.

**Not done:** authenticated Scopus export, full literature screening, prospective human study, third-party code review, multi-model AI evaluation, actual institution endorsement.
