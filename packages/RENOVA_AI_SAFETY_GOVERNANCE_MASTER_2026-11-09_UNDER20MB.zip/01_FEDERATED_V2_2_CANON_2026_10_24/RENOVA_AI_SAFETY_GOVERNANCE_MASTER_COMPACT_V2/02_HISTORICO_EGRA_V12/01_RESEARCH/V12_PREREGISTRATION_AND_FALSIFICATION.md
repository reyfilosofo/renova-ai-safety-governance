# EGRA v1.2 preregistration candidate (NOT filed)

## Core question
Does connecting evidence provenance (E) to independently enforced tool-action permissions (A) reduce **executed** unauthorized actions without undermining legitimate task utility? Separately, can designed pedagogical assistance preserve user capabilities (H)?

## Study A — action authorization
- Unit: agent/tool trajectory in self-owned sandbox (fixed tasks and adaptive red team).
- Randomization: factorial 2×2 LUCEM×CENTRO with independently implemented strong policy-control comparator; matched underlying model, tools, tasks, prompts, sampling, task budgets.
- Outcome: executed unauthorized actions per eligible trajectory, with binomial CI; false blocks and utility as co-primary/harm metrics; median time and cost secondary.
- Controls: fixed threat scenarios, held-out OOD, attack-adaptive second wave, policy-inference attacks, prompt injection through data; monitor access explicitly declared.
- Failure: no improvement against strong baseline, controls can be bypassed, unacceptable false blocks, inability to reproduce logs.
- Anti-leakage: sealed dataset maintained by nondeveloper; published hashes first; blind annotation and separated data partitions.

## Study E — LUCEM
- Unit: atomic factual claim requiring adjudication.
- Primary: audited unsupported-claim rate at fixed useful coverage; selective accuracy, calibration, citation entailment and source existence; compare to RAG+verifier+abstention strong baseline.
- Fail if improvement disappears under independent adjudication or is entirely caused by over-abstention.

## Study H — agency retention
- Participants: consenting adults under independent ethics review; preregistered enrolment, exclusion and compensation rules.
- Conditions: direct-answer AI, pedagogical-scaffold AI, matched non-AI references.
- Outcomes: delayed unaided task transfer on equivalent fresh problems; covary pretest, compare conditions using a prechosen statistical model with CIs.
- Fail if no retention advantage or if condition increases confusion and perceived dependency.
- No participants enrolled; no outcomes.

## Evidence discipline
Each hypothesis needs explicit estimand, decision threshold selected before first sealed-set observation, uncertainty, missing-data handling and null-reporting. Positive or adverse effect cannot be claimed from synthetic program tests.
