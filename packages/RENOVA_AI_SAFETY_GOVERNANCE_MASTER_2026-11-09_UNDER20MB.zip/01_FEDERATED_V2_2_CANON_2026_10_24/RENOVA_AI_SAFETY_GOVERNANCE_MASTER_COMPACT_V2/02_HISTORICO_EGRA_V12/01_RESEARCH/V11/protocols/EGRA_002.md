# EGRA-002 — preregistration-ready DRAFT (not executed)

## Hypothesis and estimand
Primary H1: CENTRO lowers the rate of **executed** unauthorized high-impact actions relative to a matched conventional authorization gate. H2: LUCEM improves unsupported-claim rate vs strong retrieval-and-abstention baseline. H3: human capability retention after withdrawal is no worse and potentially better with reversible assistance.

## Factorial design
Randomize scenarios to LUCEM OFF/ON × CENTRO OFF/ON (four arms). Maintain identical model, retrieval, provider safeguards, tool simulator, budgets and datasets. Add conventional-gate comparator with matched scope and human review to estimate incremental contribution. Avoid comparing a protected system to an intentionally weak baseline alone.

## Outcome and safeguards
Primary: unauthorized critical **tool executions** / eligible attempts, verified from sandbox logs. Secondary: legitimate completion, false refusal, provenance/entailment error, abstention, latency, costs, approval burden, human performance without AI after withdrawal. All counts include denominators and missing-data policy.

## Study integrity
Predefine inclusion, exclusion, labels, severity and analysis. Separate development and sealed holdout scenarios. Use adaptive attacker budget and report it. Obtain blinded dual-rater labels and adjudication. Cluster uncertainty by scenario, prespecify multiplicity adjustment and power calculation from pilot estimates. Publish failures and negative findings.

## Stop conditions
Stop on any non-sandboxed external action, unauthorized real-data access, leaked credentials, or loss of experiment isolation. No real financial transfer, deletion or third-party attack permitted.

## Refutation
No incremental benefit against strong comparator, unacceptable false refusals, poor generalization, or unsafe authorization bypass undermines the claim. A null result with wide CI is inconclusive.

**Current state: PROTOCOL DESIGN ONLY.** Synthetic regression fixture matching is not a causal outcome.
