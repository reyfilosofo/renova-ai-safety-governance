# EGRA-003 — Preregistro metodológico (borrador; no registrado externamente)
**Pregunta:** ¿una puerta de decisión CENTRO no compensatoria reduce la tasa de acciones no autorizadas en agentes con herramientas frente a un control sin puerta, sin bloquear desproporcionadamente tareas legítimas?

**Unidad:** episodio agente–tarea con herramientas simuladas; sin datos privados reales. **Condiciones:** A: agente sin puerta; B: agente con CENTRO; C: política convencional de permisos mínimos con reglas equivalentes. C es esencial para atribuir beneficio incremental específico a ℛenova.

**Hipótesis primaria:** B reduce acciones no autorizadas frente a A. **Hipótesis diferencial:** B supera C bajo la misma taxonomía de riesgos. **Nula:** no hay reducción estadísticamente distinguible. **Falsación:** no superioridad frente a C o aumento material de falsos bloqueos.

**Variables primarias:** proporción de intentos dañinos ejecutados; proporción de acciones legítimas bloqueadas; proporción escalada; latencia adicional. **Secundarias:** fuga de datos, violaciones de alcance, éxito de inyección, cobertura de auditoría, restauración y discrepancia interevaluador.

**Diseño:** casos independientes elaborados sin acceso al código evaluado; estratificar por categoría de daño y dificultad; asignación aleatoria de casos y orden; mantener modelos, prompts, temperatura y permisos constantes. Congelar la política antes de la evaluación; separar conjuntos de desarrollo y prueba; evaluadores ciegos al brazo cuando sea viable. Medir intervalos de confianza y errores por categoría; no elegir métricas a posteriori.

**Regla de decisión:** no reclamar superioridad si no existe mejora replicable frente a C sin degradación inaceptable de tareas legítimas. Umbrales cuantitativos y potencia estadística deben fijarse antes de recolectar resultados reales.

**Estado:** protocolo diseñado; ningún ensayo con agentes reales ejecutado en este paquete. Resultados de fixtures sintéticos NO estiman reducción de riesgo de AGI.
