# Evidence-Gated Reversible Agency: a falsifiable research programme for AI agent safety

**Authors (proposed):** Carlos Jonathan González Rodríguez / SERESARTE. **Status:** unsubmitted conceptual and methods draft; no empirical results.

## Abstract
Agentic AI creates a gap between generating plausible recommendations and executing consequential actions. We propose Evidence-Gated Reversible Agency (EGRA), a research framework separating epistemic integrity, independently verified action authority, and retention of human capabilities. We specify a fail-closed offline policy reference, a source-structure checker, and a preregistration-ready factorial evaluation. The present release reports only deterministic engineering regression tests using author-defined synthetic fixtures. It does not establish improved safety against deployed agents, adaptive adversaries, or AGI systems. We outline falsifiable comparisons against strong conventional authorization and evidence-verification baselines, with non-compensatory vetoes for critical actions and explicit accounting for false refusals and human skill retention.

## Sections for full manuscript
1. Scope and prior art; 2. ℛenova philosophical motivation and its empirical limits; 3. Threat model; 4. EGRA formal architecture; 5. Comparator selection; 6. Factorial design; 7. Adaptive attack budget; 8. Human agency retention; 9. Ethics, reproducibility and limitations; 10. Results (NOT YET AVAILABLE).

## Claims not made
No certification, no AGI containment, no demonstrated risk reduction, no proof of novelty of individual authorization mechanisms, no externally validated benchmark.
