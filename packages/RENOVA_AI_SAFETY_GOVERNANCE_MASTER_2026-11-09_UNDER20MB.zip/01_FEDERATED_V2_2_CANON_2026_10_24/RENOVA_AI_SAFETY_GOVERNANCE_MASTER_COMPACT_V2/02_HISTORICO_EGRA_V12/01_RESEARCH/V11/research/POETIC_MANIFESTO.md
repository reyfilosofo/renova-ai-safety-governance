# El umbral de la acción

No toda palabra es una orden.  
No toda certeza es conocimiento.  
No toda capacidad concede derecho.  

Que el cálculo no se haga permiso;  
que la velocidad no sustituya el juicio;  
que la máquina proponga  
y la responsabilidad conserve su nombre.  

Entre el impulso y el mundo,  
un umbral:  
prueba, límite, memoria, cuidado.  

**Estatuto:** creación poética original para esta entrega; no constituye evidencia científica.
