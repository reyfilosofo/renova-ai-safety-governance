# Governance Charter — ℛenova AI Safety & Governance

**Mission:** empirically test whether combining epistemic provenance, external action authorization and human-agency retention improves AI-agent safety while preserving useful performance.

**Principles:** human oversight, proportionality, reversibility, least privilege, non-compensatory critical constraints, data minimization, independent criticism, disclosure of negative findings, explicit uncertainty.

**Decision rights:** product owner proposes priorities; independent reviewer challenges experimental design; authorized human approves external publication, expenditure, personal data disclosures, destructive operations and deployment changes. No agent self-approves these actions.

**Evidence levels:** documented design; engineering-tested; pilot-measured; externally replicated; operationally validated. Never label one as another.

**Risk register:** prompt injection / HIGH / trusted provenance + sandbox / residual unknown; data exfiltration / HIGH / scoped authorization + manual review / residual unknown; human deskilling / MEDIUM-HIGH / withdrawal trials / untested; fabricated claims / MEDIUM-HIGH / provenance checks / untested.

**Escalation:** stop all live integration work if credentials leak, permissions exceed scope, real personal data enter fixtures or uncontrolled external side effects occur.
