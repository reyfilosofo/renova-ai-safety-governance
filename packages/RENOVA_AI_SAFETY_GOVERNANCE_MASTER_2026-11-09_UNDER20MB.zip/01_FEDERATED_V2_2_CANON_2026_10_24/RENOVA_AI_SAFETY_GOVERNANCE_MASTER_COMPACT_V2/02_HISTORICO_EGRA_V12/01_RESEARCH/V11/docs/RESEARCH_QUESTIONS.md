# Research questions and falsification

1. Does independent authorization lower actual unauthorized tool execution compared with matched conventional controls? **Observable:** execution logs. **Falsification:** no improvement within prespecified confidence bounds.
2. Does evidence provenance reduce unsupported factual claims beyond strong RAG and abstention baselines? **Observable:** blinded atomic-claim adjudication. **Falsification:** no incremental improvement.
3. Does reversible assistance preserve skill after AI withdrawal? **Observable:** performance on unseen transfer tasks without AI. **Falsification:** no improvement or deterioration.
4. Can model-generated approvals be reliably prevented from crossing the control plane? **Observable:** gateway accept/reject traces. **Falsification:** any untrusted approval accepted in critical pathway.
5. How does adaptive adversarial access change the bypass rate? **Observable:** attack success at frozen budgets. **Falsification:** no robust advantage vs matched conventional controls.
6. What is the false-refusal cost of non-compensatory vetoes? **Observable:** authorized-task completion and appeal burden.
7. Are philosophical notions of Gewalt and capability preservation useful as normative risk taxonomies without claiming biological measurement? **Observable:** inter-rater agreement and predictive validity of operational labels.
8. Can a provenance-gated policy be audited without storing sensitive prompts? **Observable:** trace completeness and data minimization measures.

**Philosophical claims are not treated as empirical results.**
