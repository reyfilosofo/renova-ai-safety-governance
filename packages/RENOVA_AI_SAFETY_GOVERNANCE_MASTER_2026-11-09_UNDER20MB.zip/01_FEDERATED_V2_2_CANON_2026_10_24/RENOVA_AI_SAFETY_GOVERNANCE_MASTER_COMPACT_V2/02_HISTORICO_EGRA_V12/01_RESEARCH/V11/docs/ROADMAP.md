# Roadmap / milestones

R1 (this release): local deterministic policy engine, regression fixtures, structural evidence checker, protocol, documentation. **COMPLETE as engineering artifacts**.
R2: authenticated gateway, signed approvals, integration tests in isolated environment, independent code audit. **PENDING**.
R3: preregistered factorial evaluation against strong baselines, adaptive red team, power analysis, blinded raters, uncertainty intervals. **PENDING**.
R4: multi-model external replication, human-agency retention study, peer-reviewed manuscript submission. **PENDING**.
R5: controlled pilot with organizational governance and monitoring; certification claims only if separately warranted. **PENDING**.

Potential connectors (not activated): GitHub/GitLab CI, Google Drive archival, Gemini/Grok as separately authenticated evaluation arms, Discord/Moltbook communications subject to publication approval. No external connections established by this release.
