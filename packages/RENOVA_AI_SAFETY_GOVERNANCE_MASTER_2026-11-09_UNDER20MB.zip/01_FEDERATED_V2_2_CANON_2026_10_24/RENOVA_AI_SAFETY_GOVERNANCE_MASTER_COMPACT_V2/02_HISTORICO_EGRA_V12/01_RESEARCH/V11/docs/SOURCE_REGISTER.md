# Source register (local materials, not independently peer reviewed)

1. `RENOVA_V10_EDICION_DIGITAL.pdf` — authorial philosophical corpus, 2026, supplied by user; normative source, not proof of efficacy.
2. `ℛENOVA AI SAFETY & HUMAN FUTURES.pdf` — critical research audit, 2026-10-15, supplied by user; background research and limitations.
3. `RENOVA_AI_SAFETY_SERESARTE_RESEARCH_PACK_2026_v01.zip` — EGRA protocol and earlier offline evaluator, supplied by user; engineering predecessor.
4. `RENOVA_AI_AUDITOR_MVP_v0.1.html` — local lexical pre-audit prototype, supplied by user; no truth verification.
5. `RENOVA_AI_SAFETY_GOVERNANCE_v0.1_RESEARCH_PREVIEW.zip` — previous CENTRO Guard reference; included as legacy snapshot in this release.

External conceptual standards to consult and verify independently before publication: NIST AI RMF 1.0 (https://www.nist.gov/itl/ai-risk-management-framework); NIST AI 600-1 Generative AI Profile (https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.600-1.pdf); ISO/IEC 42001 (https://www.iso.org/standard/81230.html); OWASP Top 10 for LLM Applications (https://genai.owasp.org/). These are **not** certification claims or evidence that this release conforms to the standards. URLs are references, not checked during packaging.
