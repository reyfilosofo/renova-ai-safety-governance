# Architecture — EGRA v1.0

Untrusted model output → **proposal only** → authenticated orchestration (outside this prototype) → trusted context and capability resolution (outside) → CENTRO offline policy decision → hypothetical enforcement gateway (NOT IMPLEMENTED) → audited tool execution (NOT IMPLEMENTED).

Parallel epistemic path: proposed factual claim → LUCEM-lite structural source checks → **manual/external verification required**. No internet or retrieval occurs.

**EGRA vector:** E (epistemic integrity), A (action authority), H (human agency retention), U (utility), C (cost). These dimensions are not summed into one score. Severe violations are non-compensable. `DENY` takes precedence over `ESCALATE`, which takes precedence over `ALLOW`.

**Trust boundary:** Request fields such as `identity_verified`, `provenance`, `authorized_actions`, and `control_plane_integrity` must be populated by a trusted gateway, not by an LLM, retrieved page, email or user-supplied JSON in production. Because the gateway is not implemented, the example inputs demonstrate **logic only**, not security.

**External authorization:** Human approval must be checked out of band and bound to user, action, resources, expiry and request digest. The prototype does not verify tokens and therefore never auto-allows high-impact operations.
