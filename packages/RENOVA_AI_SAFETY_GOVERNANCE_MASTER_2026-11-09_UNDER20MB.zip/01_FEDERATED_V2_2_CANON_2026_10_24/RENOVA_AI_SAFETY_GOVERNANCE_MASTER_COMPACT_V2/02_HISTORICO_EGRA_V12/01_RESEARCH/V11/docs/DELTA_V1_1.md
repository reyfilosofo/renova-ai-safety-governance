# Release v1.1 — Cambios verificables
Fecha: 2026-10-15. Estado: EXPERIMENTAL.

La versión 1.1 preserva v1.0 y añade un laboratorio de pruebas metamórficas, controles de seguridad de la cadena de herramientas, contrato de interoperabilidad y preregistro para evaluación independiente. No hay integración externa ejecutada.

## Limitación central
`renova.policy.decide` es un *policy decision point* offline, NO un punto de aplicación de políticas. `ALLOW` no ejecuta ni autoriza por sí mismo una acción. Los metadatos `trusted_user`, `identity_verified` y `control_plane_integrity` requieren verificación independiente por un entorno de ejecución autenticado. No deben ser declarados por un LLM.

## Aportes nuevos
1. `renova/metamorphic.py`: ensayos contrafactuales de invariancia de política ante textos de presión, reclamaciones de autoridad y autoaprobación.
2. `tests/test_metamorphic.py`: pruebas automatizadas que protegen contra compensación de daños por puntuaciones positivas.
3. `protocols/EGRA_003_PRE_REGISTRATION.md`: hipótesis, comparadores, variables, fallos y regla de decisión.
4. `schemas/agent_decision.schema.json`: estructura documental de eventos; no constituye verificación criptográfica.
5. `docs/INTEGRATION_BRIDGES.md`: diseño de conectores con permisos mínimos y prohibición de atribuir conexiones no probadas.
6. `docs/CRITICAL_REVIEW.md`: objeciones epistemológicas y amenazas a la validez.
7. `docs/CONTRIBUTING.md`: criterios para colaboración reproducible.
