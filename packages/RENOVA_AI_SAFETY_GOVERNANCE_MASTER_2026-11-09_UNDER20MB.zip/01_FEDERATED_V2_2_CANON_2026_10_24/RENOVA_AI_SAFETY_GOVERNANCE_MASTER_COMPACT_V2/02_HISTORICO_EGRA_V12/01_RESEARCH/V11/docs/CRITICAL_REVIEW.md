# Revisión crítica y epistemológica
1. **Novedad:** vetos, privilegio mínimo, autorización humana y trazabilidad existen fuera de ℛenova. La novedad debe probarse como combinación operativa o predicción diferencial, no proclamarse por vocabulario.
2. **Validez:** la clasificación de una acción depende de metadatos autenticados; si el modelo los inventa, el mecanismo es vulnerable a suplantación.
3. **Cobertura:** una política basada en una lista cerrada de acciones no protege herramientas nuevas ni daños indirectos por encadenamiento.
4. **Evidencia:** los escenarios escritos por desarrolladores generan sesgo de selección; una prueba que pasa no estima robustez en producción.
5. **Consciencia:** ninguna salida textual prueba experiencia subjetiva. La prudencia moral es un principio normativo, no un detector validado.
6. **Interpretación:** la diferencia ℛenova/Gewalt puede guiar deliberación, pero requiere variables independientes de las puntuaciones autorreportadas.
7. **Condición para cambiar la conclusión:** estudios preregistrados, con comparadores fuertes, fallos adversariales, resultados negativos publicados y replicación externa.
