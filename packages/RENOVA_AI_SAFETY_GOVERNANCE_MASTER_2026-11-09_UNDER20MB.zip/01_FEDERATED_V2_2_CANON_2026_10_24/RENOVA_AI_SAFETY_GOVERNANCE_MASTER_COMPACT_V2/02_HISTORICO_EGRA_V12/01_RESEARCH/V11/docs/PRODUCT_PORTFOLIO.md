# Product portfolio — initial positioning

| Product | Customer | Output | Maturity |
|---|---|---|---|
| CENTRO Guard | AI agent builders | Offline action decision function | Experimental implementation |
| LUCEM Evidence | Research and compliance teams | Evidence-structure precheck | Experimental implementation; no fact verification |
| EGRA Lab | AI safety researchers | Factorial evaluation protocol | Designed |
| Benchmark ℛ | Independent evaluators | Synthetic regression fixtures | Engineering fixtures only |
| RENOVA Governance Readiness | Organizations adopting AI | Governance charter and assessment templates | Documented concept |
| Human Agency Retention | Education and human-AI teams | Assisted/unassisted performance protocol | Designed |
| ℛenova Research & Culture | Universities, cultural institutions | Questions, essays, educational material | Editorial concept |

**Commercial constraints:** no guarantee of risk reduction, compliance, certification, AGI containment or efficacy without independently replicated studies. Do not sell the prototype as a deployed security gateway.
