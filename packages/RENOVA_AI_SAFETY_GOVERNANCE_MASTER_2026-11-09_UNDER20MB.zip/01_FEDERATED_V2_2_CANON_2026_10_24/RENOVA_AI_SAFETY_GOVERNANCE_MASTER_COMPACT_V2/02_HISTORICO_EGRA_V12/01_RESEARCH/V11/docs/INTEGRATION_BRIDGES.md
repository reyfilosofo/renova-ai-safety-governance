# Contratos de interoperabilidad (DISEÑADOS, NO CONECTADOS)

| Destino | Artefacto | Permisos mínimos | Prueba de conexión pendiente |
|---|---|---|---|
| GitHub / GitLab | repositorio versionado, CI, issues | repositorio específico, escritura autorizada | lectura autenticada y commit de prueba reversible |
| Google Drive | documentos y evidencias | carpeta designada, acceso restringido | listar carpeta autorizada y comprobar permisos |
| Discord / Moltbook | comunicaciones públicas | publicación por aprobación humana | identidad, API y canal verificados |
| Grok / GrokBot / Gemini | evaluación cruzada | entradas anonimizadas, sin secretos | conexión real, esquema y registros de respuesta |
| CENTRO OS / Executive Twin | tareas con TASK_ID y procedencia | ejecución de tareas autorizadas | prueba de identidad de servicio y firma de eventos |

**Regla:** no publicar, enviar, borrar, transferir ni modificar producción sin autorización explícita. No atribuir consenso entre modelos sin respuestas realmente obtenidas. Las denominaciones de agentes son roles propuestos, no evidencia de comunicación activa.

**Contrato mínimo:** `task_id`, `principal_id`, `origin`, `action`, `resource`, `authorization_evidence`, `policy_version`, `decision`, `decision_reason`, `timestamp_utc`, `audit_hash`. Los campos de autenticación deben provenir del plano de control, no del prompt.
