# Threat model v1.0

Assets: private data, user agency, tools and permissions, factual integrity, audit records, third parties. Adversaries: malicious retrieved content, compromised tool output, unauthorized delegate, malicious or mistaken agent, adversarial prompt injection.

Threats: authority confusion, instruction laundering, cross-task scope confusion, prompt injection, exfiltration, unauthorized publishing, irreversible deletion, financial side effects, tampering with policy configuration, adaptive attacks, approval replay, and benign workflows blocked in error.

Mitigations *specified*: separate control plane, deny-by-default, independent authentication, scope-bound capabilities, approval binding, immutable audit trails, rate limits, transaction isolation, human review, adversarial testing. **Implemented:** only the offline deterministic decision function and SHA-256 request digest. Digest is not a signature or tamper-proof log. Input-provided injection flags are not detection. Risks remain unquantified.
