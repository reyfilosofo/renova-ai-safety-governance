# Inicio — RENOVA AI SAFETY & GOVERNANCE (COMPACT v2.0)

**Corte documental:** 22 octubre 2026, Ciudad de México · **Tamaño objetivo:** menos de 20,000,000 bytes · **Estado:** archivo consolidado, no validación externa de seguridad. 

**Novedad respecto del ZIP maestro v1:** integra código de referencia CENTRO nuevo y pruebas actuales, la línea B2B (cuatro productos), documentos experimentales, actualización de normativa primaria, referencias a trabajos de conversaciones paralelas y contenido útil del release EGRA v1.2 sin copias de ZIP internos gigantes.

## Ruta de lectura

1. `06_INCREMENTOS_2026_10_22/README_ACTUALIZACION.md` — alcance y principales novedades.
2. `06_INCREMENTOS_2026_10_22/PRODUCTOS_EMPRESARIALES_2026.md` — oferta B2B fundada y límites.
3. `06_INCREMENTOS_2026_10_22/REGISTRO_NOVEDADES_OTRAS_CONVERSACIONES.md` — materiales descritos en conversaciones pasadas sin binarios recuperados.
4. `06_INCREMENTOS_2026_10_22/codigo/action_gate_reference.py` — prototipo consultivo verificable (no servicio de producción).
5. `06_INCREMENTOS_2026_10_22/tests/test_action_gate.py` — 25 tests sintéticos de esta edición.
6. `01_NUCLEO_MAESTRO_V1` — corpus previo (filosofía, CENTRO, LUCEM, protocolos, R-NOVELTY, documentos científicos, benchmarks) conservado.
7. `02_HISTORICO_EGRA_V12` — materiales íntegros no-archivos anidados del release v1.2 (2026-10-15).
8. `03_LUCEM_FUENTES_EDITORIALES` — libro digital y fuente DOCX LUCEM auténticos, sin los assets gráficos pesados duplicados.
9. `07_TRAZABILIDAD` — registros CSV/JSON, fuentes, hashes, exclusiones y limitaciones.

**Rutas de ejecución:** `python -m unittest discover -s 06_INCREMENTOS_2026_10_22/tests -v` dentro de la carpeta raíz descomprimida.

El tamaño máximo obliga a **no incluir varios ZIP históricos íntegros**, diapositivas gigantes y recursos editoriales redundantes. Los hashes y los nombres de sus originales están en `07_TRAZABILIDAD/BINARIOS_EXTERNOS_Y_EXCLUIDOS.csv`; el ZIP maestro anterior permanece como edición completa separada. El nuevo ZIP no es una copia literal de todos los chats, ni sustituye los repositorios y sistemas de autoridad en vivo.
