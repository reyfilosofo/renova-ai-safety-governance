from pathlib import Path
import zipfile,io,shutil,hashlib,json,csv,os,datetime,html,subprocess
BASE=Path('/mnt/data');STAGE=BASE/'RENOVA_COMPACT_V2_STAGE';PREV=BASE/'RENOVA_AI_SAFETY_GOVERNANCE_ARCHIVO_MAESTRO_2026-10-22_V1.zip';HIST=BASE/'RENOVA_AI_SAFETY_GOVERNANCE_MASTER_DEFINITIVO_v1.2_2026-10-15.zip';OUT=BASE/'RENOVA_AI_SAFETY_GOVERNANCE_MASTER_COMPACT_V2_2026-10-22.zip'
if STAGE.exists():shutil.rmtree(STAGE)
STAGE.mkdir()
logs=[]; excluded=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def put(rel,data,origin,source_name=None,notes=''):
    rel=str(rel).replace('\\','/')
    if rel.startswith('/') or '..' in Path(rel).parts:raise ValueError(rel)
    p=STAGE/rel;p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():raise ValueError('Collision: '+rel)
    p.write_bytes(data)
    logs.append({'path':rel,'bytes':len(data),'sha256':sha(data),'provenance':origin,'source':source_name or '', 'notes':notes})
    return p
with zipfile.ZipFile(PREV) as zp:
    for info in zp.infolist():
        if info.is_dir():continue
        name=info.filename; old=name.split('/',1)[1]
        # Exact copies except size-dominating duplicates/historic binary archives.
        omit = ('Renova_AI_Governance_Sales_Deck.pptx' in old or
                'SERESARTE_Group_Master_Portfolio_Deck.pptx' in old or
                'SERESARTE_Group_Master_Portfolio_Deck.pdf' in old or
                'source_archive_lucem_editorial_source.zip' in old or
                'RENOVA_AI_SAFETY_CENTRO_MASTER_PACK_V04' in old)
        # Old master retains some source zip duplicates; preserve smaller unique components.
        if old.startswith('06_ZIPS_HISTORICOS_AUTENTICOS/') and info.file_size > 500_000:omit=True
        if omit:
            excluded.append({'historical_file':name,'original_bytes':info.file_size,'reason':'Large redundant original retained in historical full master','sha256':sha(zp.read(info))})
            continue
        put('01_NUCLEO_MAESTRO_V1/'+old,zp.read(info),'ZIP maestro del 22-oct, copia original',name)
with zipfile.ZipFile(HIST) as zh:
    for info in zh.infolist():
        if info.is_dir():continue
        old=info.filename.split('/',1)[1]
        if old.startswith('09_SOURCE_ARCHIVE/'):
            excluded.append({'historical_file':info.filename,'original_bytes':info.file_size,'reason':'Nested duplicate of historic archive, content already represented elsewhere','sha256':sha(zh.read(info))})
            continue
        put('02_HISTORICO_EGRA_V12/'+old,zh.read(info),'Release EGRA v1.2, 2026-10-15',info.filename)
# selected source editorial material from inside excluded historic zip (no loss of source content below)
with zipfile.ZipFile(PREV) as zp:
    candidate=next(x for x in zp.namelist() if 'source_archive_lucem_editorial_source.zip' in x)
    with zipfile.ZipFile(io.BytesIO(zp.read(candidate))) as ze:
        keep=['Lucem_Renova_LIBRO_DIGITAL_con_portada.pdf','Lucem_Renova_Isis_Menora_Lampara_Coranica_LIBRO_FINAL.docx','FUENTES_Y_BIBLIOGRAFIA_Lucem_Renova.md','LEEME_PREPRENSA_Lucem_Renova.txt']
        for name in keep:
            if name in ze.namelist():put('03_LUCEM_FUENTES_EDITORIALES/'+name,ze.read(name),'Fuente editorial auténtica extraída de ZIP histórico LUCEM','source_archive_lucem_editorial_source.zip::'+name)
# now new research & business instruments
NEW=BASE/'renova_compact_new'
for p in sorted((NEW/'06_INCREMENTOS_2026_10_22').rglob('*')):
    if p.is_file():put(str(p.relative_to(NEW)),p.read_bytes(),'Creado y probado para actualización 2026-10-22',str(p))
# Add authoritative old original full-pack descriptor, not the big zip itself
bigfiles=[BASE/'RENOVA_AI_SAFETY_GOVERNANCE_ARCHIVO_MAESTRO_2026-10-22_V1.zip',BASE/'RENOVA_AI_SAFETY_CENTRO_MASTER_PACK_V04_2026-10-15.zip',HIST]
for file in bigfiles:
    excluded.append({'historical_file':file.name,'original_bytes':file.stat().st_size,'reason':'Se conserva por separado para limitar el nuevo ZIP a 20MB','sha256':sha(file.read_bytes())})
# metadata on retrieved sources with provenance and exclusions
idx='''# Inicio — RENOVA AI SAFETY & GOVERNANCE (COMPACT v2.0)

**Corte documental:** 22 octubre 2026, Ciudad de México · **Tamaño objetivo:** menos de 20,000,000 bytes · **Estado:** archivo consolidado, no validación externa de seguridad. 

**Novedad respecto del ZIP maestro v1:** integra código de referencia CENTRO nuevo y pruebas actuales, la línea B2B (cuatro productos), documentos experimentales, actualización de normativa primaria, referencias a trabajos de conversaciones paralelas y contenido útil del release EGRA v1.2 sin copias de ZIP internos gigantes.

## Ruta de lectura

1. `06_INCREMENTOS_2026_10_22/README_ACTUALIZACION.md` — alcance y principales novedades.
2. `06_INCREMENTOS_2026_10_22/PRODUCTOS_EMPRESARIALES_2026.md` — oferta B2B fundada y límites.
3. `06_INCREMENTOS_2026_10_22/REGISTRO_NOVEDADES_OTRAS_CONVERSACIONES.md` — materiales descritos en conversaciones pasadas sin binarios recuperados.
4. `06_INCREMENTOS_2026_10_22/codigo/action_gate_reference.py` — prototipo consultivo verificable (no servicio de producción).
5. `06_INCREMENTOS_2026_10_22/tests/test_action_gate.py` — 25 tests sintéticos de esta edición.
6. `01_NUCLEO_MAESTRO_V1` — corpus previo (filosofía, CENTRO, LUCEM, protocolos, R-NOVELTY, documentos científicos, benchmarks) conservado.
7. `02_HISTORICO_EGRA_V12` — materiales íntegros no-archivos anidados del release v1.2 (2026-10-15).
8. `03_LUCEM_FUENTES_EDITORIALES` — libro digital y fuente DOCX LUCEM auténticos, sin los assets gráficos pesados duplicados.
9. `07_TRAZABILIDAD` — registros CSV/JSON, fuentes, hashes, exclusiones y limitaciones.

**Rutas de ejecución:** `python -m unittest discover -s 06_INCREMENTOS_2026_10_22/tests -v` dentro de la carpeta raíz descomprimida.

El tamaño máximo obliga a **no incluir varios ZIP históricos íntegros**, diapositivas gigantes y recursos editoriales redundantes. Los hashes y los nombres de sus originales están en `07_TRAZABILIDAD/BINARIOS_EXTERNOS_Y_EXCLUIDOS.csv`; el ZIP maestro anterior permanece como edición completa separada. El nuevo ZIP no es una copia literal de todos los chats, ni sustituye los repositorios y sistemas de autoridad en vivo.
'''
put('00_COMIENZA_AQUI/README.md',idx.encode(),'Índice original nuevo')
# restore references with dates, status and links
links=[
('GitHub repo','https://github.com/reyfilosofo/renova-agent','public verified 2026-10-22'),
('PR #57','https://github.com/reyfilosofo/renova-agent/pull/57','open draft checked'),
('PR #58','https://github.com/reyfilosofo/renova-agent/pull/58','open draft checked'),
('PR #59','https://github.com/reyfilosofo/renova-agent/pull/59','open draft checked'),
('Google Drive master v0.4','https://drive.google.com/file/d/1VJH_QH3S742fy7QJCFC6bzQoogTK1844/view','historical binary archived'),
('Google Drive release v1.2','https://drive.google.com/file/d/1M4pALPOqsXhLFoyw86yAzheAgihVVPx5/view','historical binary archived'),
('EGRA Registry 0.3','https://docs.google.com/document/d/1ELAlgwNgLeUuqNYz8vXlvXB1rc-b3FINqnf9grVM0TY/edit','research 2026-10-15'),
('EGRA Registry 0.2','https://docs.google.com/document/d/1jHXzWH7jY3VfRBUrNXovCMaOocwALw9kWGnNy34LlKU/edit','research 2026-10-15'),
('ISO/IEC published standards catalogue','https://www.iso.org/committee/6794475/x/catalogue/','checked 2026-10-22'),
('ISO 42001','https://www.iso.org/standard/42001','checked 2026-10-22'),
('EU AI Act Commission','https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai','checked 2026-10-22'),
('EU AI Act EUR-LEX','https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=LEGISSUM%3A4762484','checked 2026-10-22'),
('NIST AI Agent Standards Initiative','https://www.nist.gov/news-events/news/2026/02/announcing-ai-agent-standards-initiative-interoperable-and-secure','checked 2026-10-22')]
import io as IO
buf=IO.StringIO();w=csv.writer(buf);w.writerow(['source','uri','status']);w.writerows(links)
put('07_TRAZABILIDAD/ENLACES_FUENTES.csv',buf.getvalue().encode(),'Registro de enlaces comprobados')
buf=IO.StringIO();w=csv.DictWriter(buf,fieldnames=['historical_file','original_bytes','reason','sha256']);w.writeheader();w.writerows(excluded)
put('07_TRAZABILIDAD/BINARIOS_EXTERNOS_Y_EXCLUIDOS.csv',buf.getvalue().encode(),'Inventario de exclusiones trazables')
# provenance item-level report, include itself excluded from checksumming itself
buf=IO.StringIO();w=csv.DictWriter(buf,fieldnames=['path','bytes','sha256','provenance','source','notes']);w.writeheader();w.writerows(logs)
(STAGE/'07_TRAZABILIDAD/INVENTARIO_SHA256.csv').write_text(buf.getvalue(),encoding='utf-8')
# HTML nav all filenames, no remote scripts or dynamic dependencies
categories=sorted({x['path'].split('/')[0] for x in logs})
bycat={c:[a['path'] for a in logs if a['path'].startswith(c+'/')] for c in categories}
parts=['<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RENOVA AI SAFETY & GOVERNANCE · Compact v2.0</title><style>body{margin:0;background:#f4f1e9;color:#1b1917;font-family:system-ui,-apple-system,Segoe UI,sans-serif}header,main{max-width:1130px;margin:auto;padding:28px}h1{font-family:Georgia,serif;font-size:clamp(35px,5vw,64px);font-weight:400;line-height:1.02}h2{font-size:23px;border-bottom:1px solid #777;padding-bottom:6px}input{padding:12px;max-width:620px;width:95%;font-size:16px}li{line-height:1.65;overflow-wrap:anywhere}a{color:#394d64}section{margin:28px 0}small{color:#665e59}</style></head><body><header><p><b>SERESARTE / ℛENOVA PRESS · RESEARCH</b></p><h1>AI Safety & Governance<br>Archivo Maestro Compacto</h1><p>Corte: 22 octubre 2026 · edición documental experimental, no certificación.</p><input id="q" placeholder="Buscar archivo por nombre o tema" oninput="document.querySelectorAll(\'li\').forEach(e=>e.hidden=!e.textContent.toLowerCase().includes(this.value.toLowerCase()))"></header><main>']
for cat,names in bycat.items():
    parts.append(f'<section><h2>{html.escape(cat)} <small>({len(names)} archivos)</small></h2><ul>')
    for n in names:
        # HTML in root; use paths relative
        parts.append(f'<li><a href="{html.escape(n,quote=True)}">{html.escape(n)}</a></li>')
    parts.append('</ul></section>')
parts.append('</main></body></html>')
(STAGE/'ABRIR_ARCHIVO_MAESTRO.html').write_text('\n'.join(parts),encoding='utf-8')
# include reproduction script as internal source, preserving exact bytecopy
shutil.copy2(BASE/'renova_compact_new/assemble_compact.py',STAGE/'07_TRAZABILIDAD/ENSAMBLADOR.py')
# use compression deflate; preserves original binary ones already compressed
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
    for p in sorted(STAGE.rglob('*')):
        if p.is_file():z.write(p,arcname='RENOVA_AI_SAFETY_GOVERNANCE_MASTER_COMPACT_V2/'+str(p.relative_to(STAGE)))
with zipfile.ZipFile(OUT) as z:
    corrupt=z.testzip()
    total=len(z.infolist());allfiles=z.namelist()
    # Check payload exact digests against filesystem
    verified=all(hashlib.sha256(z.read(i)).digest()==hashlib.sha256((STAGE/Path(i).relative_to('RENOVA_AI_SAFETY_GOVERNANCE_MASTER_COMPACT_V2')).read_bytes()).digest() for i in allfiles)
print(json.dumps({'path':str(OUT),'bytes':OUT.stat().st_size,'MB_decimal':round(OUT.stat().st_size/1e6,3),'files':total,'digest':sha(OUT.read_bytes()),'corrupt':corrupt,'sha_check':verified,'exclusions':len(excluded),'target_under_20000000':OUT.stat().st_size<20_000_000},ensure_ascii=False,indent=2))
if OUT.stat().st_size>=20_000_000:raise SystemExit('FAILED: Too large')
if corrupt or not verified:raise SystemExit('FAILED: Integrity')
