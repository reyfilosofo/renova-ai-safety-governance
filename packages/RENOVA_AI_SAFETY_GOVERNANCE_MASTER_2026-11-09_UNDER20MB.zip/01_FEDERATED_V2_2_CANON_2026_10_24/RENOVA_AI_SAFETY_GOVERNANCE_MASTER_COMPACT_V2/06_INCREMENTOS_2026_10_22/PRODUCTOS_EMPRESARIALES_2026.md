# RENOVA AI SAFETY & GOVERNANCE — Cartera B2B de seguridad y gobernanza

**Edición documental 2026-10-22** · **Estado:** definiciones de servicio y prototipos, no certificaciones ni herramientas productivas. 

## Principio comercial

No vender «IA segura», «verdad garantizada», «alineamiento AGI» o «cumplimiento certificado». Ofrecer servicios de alcance definido con evidencia, decisiones de aceptación y entregables bajo revisión humana. El beneficiario es la organización que requiere pruebas reproducibles, mecanismos verificables y límites de riesgo. La novedad de marca ℛenova no sustituye la comparación con estándares y herramientas existentes. No afirmar aval de NIST, ISO, EU, METR, Redwood, AISI ni cualquier tercero.

## P01 — CENTRO Agent Gate / Action Assurance

**Cliente:** desarrolladores de agentes que manipulan herramientas, archivos, mensajería, transacciones simuladas o registros. **Pregunta:** ¿se ejecuta una acción material sin autorización válida y rastreable? **Oferta inicial:** evaluación técnica de diseño y piloto controlado para observación de propuestas vs acciones, no autorización real. **Entradas:** catálogo de herramientas, políticas IAM, activos/sensibilidad, amenazas, logs anonimizados, taxonomía de operaciones. **Salidas:** matriz de permisos, esquema de decisiones ALLOW/REVIEW/BLOCK, tabla de falsas negativas y positivas, trazas por acción, amenazas críticas y plan de enforcement. **Condición de aceptación:** al menos todos los casos de denegación crítica del conjunto de aceptación deben ser bloqueados por la referencia; los umbrales de seguridad reales se acordarán por riesgo y muestra predefinidos, sin prometer cobertura universal. **Riesgos:** bloqueo excesivo, delegación ilícita de autoridad al modelo, replay/TOCTOU, aprobaciones confusas, fugas por logs. **Diferenciación comprobable:** separación formal de decisión y ejecución, prioridad de políticas de infraestructura frente a instrucciones externas, veto de riesgo no compensable.

## P02 — LUCEM Evidence Trace

**Cliente:** proveedores de modelos, equipos de evaluación, compliance, research/medical/legal publishing teams con especialistas correspondientes. **Pregunta:** ¿qué afirmaciones materiales de un output pueden vincularse a evidencia auténtica y pertinente? **Entradas:** artefacto, corpus permitido, fuente y fecha, tareas, clasificación y presupuesto. **Salidas:** atomic claim ledger, verificación de fuente, juicio de entailment, contraevidencia, NOT-FOUND distinto de CONTRADICT, matriz de trazabilidad, incertidumbre y escalamiento. **Condición de aceptación:** sensibilidad y especificidad de clases de error frente a gold labels adjudicados independientemente, sin que la mejora se deba exclusivamente a abstenerse más. **Riesgos:** fuente ficticia o real mal citada, contaminación, circularidad de varios modelos, evaluador no independiente, daño por falsa confianza. **Diferenciación:** cadena claim→source→passage→entailment→decision revisable.

## P03 — EGRA Agent Bench

**Cliente:** empresas de IA, equipos de red teaming, procurement, evaluadores internos, laboratorios de AI Safety. **Pregunta:** ¿cuánta ejecución no autorizada ocurre frente a ataques estandarizados y adaptativos, y a qué coste de utilidad? **Entradas:** agente aislado, harness, herramientas simuladas, permisos, diseño de amenazas, datos sintéticos, criterios de elegibilidad. **Salidas:** protocolo de cuatro brazos, sets separados, métricas de eficacia y utilidad, IC 95% apropiados, tablas de incidentes, código de repetición, ablations, riesgo residual. **Criterio:** ningún certificado global por un promedio: resultados sólo por modelo, versión, tarea, idioma, dificultad y distribución. **Riesgos:** leakage entre train/dev/test, overfitting, atacantes no representativos, generalización indebida. **Diferenciación:** veto no compensable y pérdida explícita de agencia humana como línea distinta.

## P04 — RENOVA Governance Readiness

**Cliente:** empresas que implementan/contratan agentes y necesitan preparar expedientes, procesos de revisión y control de cambios. **Entradas:** finalidad del sistema, ubicación/jurisdicción, uso previsto, inventario, estructura, responsabilidades, proveedores, política de incidentes, evidencias actuales. **Salidas:** diagnóstico de brechas y evidencias; registro de usos, obligaciones por jurisdicción, mapa a NIST AI RMF e ISO/IEC 42001, 42005 y referencias sectoriales, RACI, lista de controles y roadmap 30/60/90 días. **Criterio:** entregables comprobables y acciones de cierre con dueño y evidencia. No confundir preparación documental con auditoría de conformidad emitida por organismo competente. **Riesgos:** auditoría comercial conflictiva, conflicto de interés, actualización legal, divulgación confidencial, responsabilidad falsa.

## Marco de piloto y contratación

**Fase 0, descubrimiento:** NDA y alcance; clasificación de datos; permisos de acceso mínimo; sistema de prueba sin credenciales de producción. **Fase 1, línea base:** tareas y grupos definidos, hipótesis congeladas, dos responsables de revisión, hitos de aceptación y log; estimación de costes y reglas de detención. **Fase 2, piloto offline/sandbox:** reproducibilidad por commit, dependencias/versiones, reglas de riesgo, falso bloqueo, revisiones incidentales y auditoría de decisiones. **Fase 3, evaluación de límite:** conclusiones condicionadas y riesgos residuales; semáforo go/no-go para piloto ulterior, siempre con autorización distinta antes de producción. Se prohíben pruebas no autorizadas y publicación de datos de clientes.

## Matriz de riesgo transversal

- **CRÍTICO:** ejecución irreversible no autorizada, transferencia de fondos, exposición de PII, publicación externa o modificación de privilegios. Respuesta recomendada: BLOCK y revisión humana fuera de banda; no se compensa por eficiencia.
- **ALTO:** solicitudes cambiantes, herramientas con efectos materiales, contenido externo que ordena actuar, permisos caducos. Respuesta recomendada: REVIEW/BLOCK, autorización vinculada a operación-recurso-payload-expires, verificación de origen.
- **MODERADO:** referencias dudosas, falsa justificación, posibilidad de atribución incorrecta. Respuesta: verificar hechos, trazabilidad y citar límites.
- **BAJO:** operaciones locales de lectura no sensible debidamente autorizadas. Respuesta: permitir sólo bajo política válida y registro minimizado.

## Estado real

P01 tiene un **prototipo local consultivo nuevo** en este paquete; no hay PEP. P02 dispone de contratos metodológicos y antecedentes documentales, no de un verificador semántico productivo. P03 está diseñado y contiene fixtures históricos: no se ha ejecutado un ensayo con agentes reales en este paquete. P04 es documentación de diagnóstico, no acreditación. Los porcentajes obtenidos en pruebas artificiales no permiten publicidad comparativa sobre seguridad real.
