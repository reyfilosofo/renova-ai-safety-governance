# Índice de novedades identificadas en conversaciones anteriores — 22 octubre 2026

**Tipo de evidencia:** referencias recuperadas de resúmenes de conversaciones accesibles, **no transcripciones literales ni copias verificadas de los archivos de esas conversaciones**. Algunos trabajos sucedieron en conversaciones paralelas casi simultáneas; esta lista no presume que sean versiones sucesivas de una única rama o que se hayan fusionado.

| Trabajo referido | Descripción disponible | Estado en este ZIP |
|---|---|---|
| `RENOVA_CENTRO_RESEARCH_INCREMENT_v1.2_2026-10-22.zip` | 15 archivos, 17/17 pruebas, 4 demos, gate ALLOW/REVIEW/BLOCK, vetos, SHA-256 y EGRA-004 | REFERENCIA; bytes exactos no accesibles; no afirmar inclusión del código original |
| CENTRO Agent Action Assurance | Motor local, scopes de permisos, revisión por acción, trazas, 38 pruebas y 48 casos sintéticos | REFERENCIA; se incorpora especificación derivada y nuevo prototipo offline propio, no se imputa sus tests |
| RENOVA GUARD 0.3 | 46 pruebas / 144 regresiones sintéticas, separación de política confiable del texto generado | REFERENCIA; principios tomados para nuevo prototipo independiente, no equivalencia de código |
| Laboratorio EGRA/RENOVA | 52 pruebas, 64 bloqueos y 8 escalaciones legítimas sintéticas | REFERENCIA; no hay registro bruto verificable de esa corrida en este ZIP |
| v1.3 comercial/técnico | Permisos firmados ligados a acciones, prevención de replay, SQLite/cadena, métricas, API local, 52 tests | REFERENCIA; sin bytes para importar sin alteración; contratos reproducidos como **nueva propuesta** en este paquete |
| Cuatro productos B2B | CENTRO Agent Gate, LUCEM Evidence Trace, EGRA Agent Bench, RENOVA Governance Readiness | DOCUMENTADO NUEVAMENTE en `PRODUCTOS_EMPRESARIALES_2026.md` |
| ℛ-Bench/H 2026 | Retención de habilidades con y sin asistencia de IA y necesidad de diseño experimental | REFERENCIA; no se reproducen afirmaciones de estudios sin comprobación individual de sus fuentes |
| Research & Career Pack V2 | Dossier y EGRA-004 con referencias a pruebas 25/41 | REFERENCIA; ZIP no recuperado por identidad de bytes |

**Conclusión epistemológica:** recuperar nombres/versiones/test-counts desde un chat previo no demuestra que el archivo fuente se haya recuperado. Este paquete incrementa cobertura mediante documentación explícita y nuevo prototipo, sin «completar» archivos ausentes fabricándolos.
