# RENOVA AI SAFETY & GOVERNANCE — Corte compacto 2026-10-22

**Objeto:** integrar el archivo maestro consolidado v1, el incremento técnico documentado v1.2 (15 oct), y los desarrollos/decisiones recuperables del 22 oct bajo un límite de **20,000,000 bytes por ZIP**. La compresión no implica recortar silenciosamente el significado científico. La versión incluye contenido fuente esencial y enlaces/hashes de binarios históricos grandes que quedaron fuera.

## Actualizaciones incorporadas

- **CENTRO:** controlador offline consultivo original de esta edición (`action_gate_reference.py`), separación entre propuesta de modelo y contexto de políticas confiable, autorización de un solo uso, vinculación al hash exacto de la acción, plazo, riesgo no compensable y rechazo ante fallas; **25 pruebas sintéticas ejecutadas en el entorno local de elaboración**. No es un gateway de producción, no intercepta herramientas y su criptografía demostrativa no equivale a revisión de seguridad.
- **LUCEM:** diseño B2B de `LUCEM Evidence Trace` para descomposición en claims, contrastación de fuentes, trazabilidad de decisiones, incertidumbre, rechazo de consenso como criterio de verdad y estudio comparativo con verificador externo.
- **EGRA:** `EGRA Agent Bench`, protocolo RAS-EXP-01, separación de tasas de ejecución no autorizada/terminación legítima/abstención, correlaciones, falsos bloqueos, sensibilidad y validez externa. Se añade expediente de pilotaje empresarial con métricas y criterios de retirada.
- **RENOVA Governance Readiness:** oferta empresarial de diagnóstico y preparación frente a marcos de gestión y deberes regulatorios, no certificación de cumplimiento.
- **Aportes de otras conversaciones del 22 de octubre:** diseños recientes de CENTRO Agent Action Assurance, RENOVA GUARD 0.3, desarrollos descritos como 38/46/52 pruebas y 144 regresiones, v1.2 Research Increment 17/17, v1.3 B2B con SQLite y contratos, cuatro productos B2B. Se preservan en **REGISTRO_NOVEDADES_OTRAS_CONVERSACIONES.md** con categoría `REFERENCIA RECUPERADA, SIN BINARIO VERIFICADO EN ESTE PAQUETE`. Sus cifras NO se suman a las 25 pruebas nuevas ni se atribuyen al código aquí presente.
- **Referencias normativas primarias revisadas el 22 oct:** EU AI Act, ISO/IEC 42001, 42005, 42006, ISO/IEC TR 42106:2026 y NIST iniciativa de estándares de agentes. No se incluyen textos completos protegidos por licencia.

## Reglas de lectura

1. `VERIFICADO_LOCAL`: archivo legible y/o prueba corrida ahora.
2. `DOCUMENTADO`: fuente recuperada o expediente escrito; no se infiere rendimiento.
3. `REFERENCIADO`: existe mención/link/historia, pero no están los bytes o la ejecución para reproducirla aquí.
4. `PROPUESTO`: diseño y/o protocolo no ejecutado.
5. `NO_VALIDADO`: ausencia de réplica independiente/benchmark real o evaluación industrial.

## Limitaciones esenciales

No es copia literal de todas las conversaciones; no es exportación del historial entero de Git; ningún PR se fusionó ni se modificaron cuentas. El riesgo residual de agentes reales, resultados de investigación y madurez de producto requieren ensayos fuera de muestra y controles independientes. No incluye librería privada ni claves.
