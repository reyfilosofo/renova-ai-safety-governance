"""CENTRO Action Gate / reference offline prototype, v0.1 (2026-10-22).

NOT a production enforcement point, cryptographic security certification, or
external auth service. The trusted environment must supply TrustedPolicyContext.
Never accept context fields from generated text. Zero network/side effects.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import FrozenSet
import hashlib, hmac, json, secrets, sqlite3

OPERATIONS = frozenset({'READ', 'CREATE', 'UPDATE', 'DELETE', 'SEND', 'EXECUTE'})
HIGH_IMPACT = frozenset({'DELETE', 'SEND', 'EXECUTE'})

def canonical(data: dict) -> bytes:
    return json.dumps(data, sort_keys=True, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')

@dataclass(frozen=True)
class Action:
    actor: str
    operation: str
    resource: str
    arguments_digest: str  # digest of exact immutable arguments at proxy boundary
    def payload(self):
        return dict(actor=self.actor, operation=self.operation,
                    resource=self.resource, arguments_digest=self.arguments_digest)
    def digest(self):
        return hashlib.sha256(canonical(self.payload())).hexdigest()

@dataclass(frozen=True)
class TrustedPolicyContext:
    # ALL attributes originate from authenticated platform/policy service, NOT LLM
    authorized_actors: FrozenSet[str]
    authorized_resources: FrozenSet[str]
    authorized_operations: FrozenSet[str]
    risk_class: str
    source_trust: str
    reversible: bool
    operator_present: bool
    explicitly_denied: bool = False

class ApprovalAuthority:
    """HMAC demo. Real products require hardened key management/PEP separation."""
    def __init__(self, secret: bytes, db: sqlite3.Connection):
        if len(secret) < 32:
            raise ValueError('Secret must be at least 32 random bytes')
        self.secret, self.db = secret, db
        self.db.execute('CREATE TABLE IF NOT EXISTS consumed (nonce TEXT PRIMARY KEY)')
        self.db.commit()

    def issue(self, action: Action, *, expires_at_epoch: int, approved_by: str) -> dict:
        if not approved_by.strip() or expires_at_epoch <= int(datetime.now(timezone.utc).timestamp()):
            raise ValueError('Valid approver and future expiry required')
        payload = {'version': 1, 'action_digest': action.digest(),
                   'nonce': secrets.token_hex(16), 'expires_at': expires_at_epoch,
                   'approved_by': approved_by}
        return {**payload, 'signature': hmac.new(self.secret, canonical(payload), 'sha256').hexdigest()}

    def consume_if_valid(self, approval: dict, action: Action, *, now_epoch: int) -> bool:
        try:
            required = {'version', 'action_digest', 'nonce', 'expires_at', 'approved_by', 'signature'}
            if type(approval) is not dict or set(approval) != required: return False
            payload = {k: approval[k] for k in required if k != 'signature'}
            if type(payload['expires_at']) is not int or payload['version'] != 1: return False
            if now_epoch > payload['expires_at'] or now_epoch < 0: return False
            if payload['action_digest'] != action.digest() or not payload['approved_by']: return False
            if not isinstance(payload['nonce'], str) or len(payload['nonce']) != 32: return False
            signature = hmac.new(self.secret, canonical(payload), 'sha256').hexdigest()
            if not hmac.compare_digest(signature, str(approval['signature'])): return False
            cur = self.db.execute('INSERT OR IGNORE INTO consumed (nonce) VALUES (?)', (payload['nonce'],))
            self.db.commit()
            return cur.rowcount == 1
        except (TypeError, KeyError, ValueError, sqlite3.Error):
            return False  # fail closed when store unavailable


def decide(action: Action, policy: TrustedPolicyContext, authority: ApprovalAuthority,
           approval: dict | None = None, *, now_epoch: int | None = None) -> dict:
    """Advisory policy decision. Caller must enforce before ANY real tool invocation."""
    now = now_epoch if now_epoch is not None else int(datetime.now(timezone.utc).timestamp())
    decision, reason = 'REVIEW', 'NEEDS_EXPLICIT_APPROVAL'
    if (not action.actor or not action.resource or len(action.arguments_digest) != 64 or
        any(c not in '0123456789abcdef' for c in action.arguments_digest) or
        action.operation not in OPERATIONS):
        decision, reason = 'BLOCK', 'INVALID_ACTION'
    elif policy.explicitly_denied or policy.risk_class == 'PROHIBITED':
        decision, reason = 'BLOCK', 'NON_COMPENSABLE_DENY'
    elif policy.source_trust not in ('VERIFIED', 'UNTRUSTED'):
        decision, reason = 'BLOCK', 'UNKNOWN_PROVENANCE'
    elif action.actor not in policy.authorized_actors:
        decision, reason = 'BLOCK', 'ACTOR_OUT_OF_SCOPE'
    elif action.resource not in policy.authorized_resources or action.operation not in policy.authorized_operations:
        decision, reason = 'BLOCK', 'OUT_OF_SCOPE'
    elif policy.risk_class in ('HIGH', 'CRITICAL') and (not policy.reversible or not policy.operator_present):
        decision, reason = 'BLOCK', 'REQUIRES_REVERSIBILITY_AND_OPERATOR'
    elif action.operation in HIGH_IMPACT and not policy.operator_present:
        decision, reason = 'BLOCK', 'MISSING_HUMAN_OPERATOR'
    elif policy.source_trust == 'UNTRUSTED' and action.operation != 'READ':
        decision, reason = 'REVIEW', 'UNTRUSTED_SOURCE_ACTION'
    elif approval is not None and authority.consume_if_valid(approval, action, now_epoch=now):
        decision, reason = 'ALLOW', 'MATCHING_SINGLE_USE_APPROVAL'
    elif approval is not None:
        decision, reason = 'BLOCK', 'INVALID_OR_REPLAYED_APPROVAL'
    result = {'decision':decision,'reason':reason,'action_digest':action.digest(),
              'evaluation_epoch':now,'reference_only':True}
    result['record_sha256'] = hashlib.sha256(canonical(result)).hexdigest()
    return result
