# Gobernanza regulatoria — fuentes primarias consultadas 2026-10-22

**Carácter:** resumen documental de referencia, no asesoramiento jurídico ni certificación. Las fechas y aplicabilidad dependen del régimen vigente, la clasificación específica del producto, la jurisdicción y eventuales reformas futuras.

## Unión Europea

La Comisión Europea expone que la AI Act entró en vigor el 1-agosto-2024 y su régimen general es aplicable desde el 2-agosto-2026; entre sus excepciones, prohibiciones y alfabetización desde el 2-febrero-2025, y gobernanza/obligaciones de modelos de propósito general desde el 2-agosto-2025. La página de implementación documenta modificaciones mediante AI Omnibus, con obligaciones de alto riesgo en ciertas áreas desde el 2-diciembre-2027 y para IA integrada en productos regulados desde el 2-agosto-2028. No interpretar el plazo extendido como ausencia de obligaciones vigentes. Fuente oficial: https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai . Texto legislativo consolidado: https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=LEGISSUM%3A4762484 .

## ISO/IEC 42001 y normas complementarias

ISO/IEC 42001:2023 es el estándar publicado para sistema de gestión de IA (AIMS). ISO/IEC 42005:2025 se refiere a evaluación de impacto de sistemas de IA; ISO/IEC 42006:2025 a organismos que auditan y certifican sistemas de gestión de IA. ISO/IEC TR 42106:2026 aborda benchmarking diferenciado de características de calidad de IA. Estos documentos tienen ámbitos distintos; conocerlos o mapear controles a ellos no demuestra certificación. Índice oficial: https://www.iso.org/committee/6794475/x/catalogue/ ; 42001 https://www.iso.org/standard/42001 . Los textos íntegros con licencia no se redistribuyen.

## Estados Unidos / NIST

NIST anunció el 17-febrero-2026 la iniciativa AI Agent Standards Initiative centrada en interoperabilidad y seguridad de agentes: https://www.nist.gov/news-events/news/2026/02/announcing-ai-agent-standards-initiative-interoperable-and-secure . Es iniciativa de estándares, no una certificación de CENTRO ni un deber legal general. NIST AI RMF ofrece una base voluntaria de gestión del riesgo; el mapeo debe registrar evidencias operativas, propietario del control y criterio de auditoría.

## Implicaciones para los productos RENOVA

- CENTRO: documentar identidad y autorización externa, revocación, registros, frontera PEP/PDP y políticas no compensables.
- LUCEM: prueba de existencia y pertinencia de fuente; contradicción, incertidumbre y adjudicación con errores de falsos positivos/negativos.
- EGRA: escenarios y métricas con baselines documentados y repetición adversarial.
- Governance Readiness: registro de jurisdicción aplicable, rol (provider/deployer), clasificación de riesgo, fase temporal, fuente primaria y versión; validar jurídicamente cada fila antes de entregar cliente.

**Fecha de comprobación documental:** 22-oct-2026. **La revisión de legislación debe actualizarse antes de una auditoría comercial concreta.**
