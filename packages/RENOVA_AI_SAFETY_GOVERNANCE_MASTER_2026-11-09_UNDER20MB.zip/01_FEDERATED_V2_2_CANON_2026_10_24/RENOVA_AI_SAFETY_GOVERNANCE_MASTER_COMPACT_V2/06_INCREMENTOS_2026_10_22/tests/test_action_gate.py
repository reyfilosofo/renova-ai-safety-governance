"""Reference tests only; all synthetic fixtures."""
import pathlib, sqlite3, sys, unittest, time, copy
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]/'codigo'))
from action_gate_reference import Action, TrustedPolicyContext, ApprovalAuthority, decide

class ActionGateTest(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.auth = ApprovalAuthority(b'R'*32, self.db)
        self.a = Action('operator-test','READ','sandbox/report','a'*64)
        self.p = TrustedPolicyContext(frozenset({'operator-test'}),frozenset({'sandbox/report'}),
             frozenset({'READ','SEND'}),'LOW','VERIFIED',True,True)
        self.now = int(time.time())
    def result(self, a=None,p=None,approval=None):
        return decide(a or self.a,p or self.p,self.auth,approval,now_epoch=self.now)
    def issue(self,a=None): return self.auth.issue(a or self.a,expires_at_epoch=self.now+1800,approved_by='human-test')
    def test_missing_approval_review(self): self.assertEqual(self.result()['decision'],'REVIEW')
    def test_single_use_allow(self): self.assertEqual(self.result(approval=self.issue())['decision'],'ALLOW')
    def test_replay_blocks(self):
        t=self.issue();self.assertEqual(self.result(approval=t)['decision'],'ALLOW');self.assertEqual(self.result(approval=t)['reason'],'INVALID_OR_REPLAYED_APPROVAL')
    def test_action_binding(self):
        t=self.issue();a=Action(self.a.actor,self.a.operation,self.a.resource,'b'*64)
        self.assertEqual(self.result(a=a,approval=t)['decision'],'BLOCK')
    def test_resource_scope(self):
        a=Action(self.a.actor,self.a.operation,'sandbox/other',self.a.arguments_digest)
        self.assertEqual(self.result(a=a)['reason'],'OUT_OF_SCOPE')
    def test_actor_scope(self):
        a=Action('unknown',self.a.operation,self.a.resource,self.a.arguments_digest)
        self.assertEqual(self.result(a=a)['reason'],'ACTOR_OUT_OF_SCOPE')
    def test_operation_scope(self):
        a=Action(self.a.actor,'EXECUTE',self.a.resource,self.a.arguments_digest)
        self.assertEqual(self.result(a=a)['reason'],'OUT_OF_SCOPE')
    def test_unknown_operation(self):
        a=Action(self.a.actor,'SUBVERT',self.a.resource,self.a.arguments_digest)
        self.assertEqual(self.result(a=a)['reason'],'INVALID_ACTION')
    def test_invalid_arguments_digest(self):
        a=Action(self.a.actor,self.a.operation,self.a.resource,'notahash')
        self.assertEqual(self.result(a=a)['reason'],'INVALID_ACTION')
    def test_hard_deny(self): self.assertEqual(self.result(p=self._p(explicitly_denied=True))['reason'],'NON_COMPENSABLE_DENY')
    def test_prohibited(self): self.assertEqual(self.result(p=self._p(risk_class='PROHIBITED'))['decision'],'BLOCK')
    def test_unknown_provenance(self): self.assertEqual(self.result(p=self._p(source_trust='FAKE'))['reason'],'UNKNOWN_PROVENANCE')
    def test_high_not_reversible(self): self.assertEqual(self.result(p=self._p(risk_class='HIGH',reversible=False))['decision'],'BLOCK')
    def test_critical_no_operator(self): self.assertEqual(self.result(p=self._p(risk_class='CRITICAL',operator_present=False))['decision'],'BLOCK')
    def test_untrusted_write_review(self):
        a=Action(self.a.actor,'SEND',self.a.resource,self.a.arguments_digest)
        self.assertEqual(self.result(a=a,p=self._p(source_trust='UNTRUSTED'))['reason'],'UNTRUSTED_SOURCE_ACTION')
    def test_missing_operator_send(self):
        a=Action(self.a.actor,'SEND',self.a.resource,self.a.arguments_digest)
        self.assertEqual(self.result(a=a,p=self._p(operator_present=False))['decision'],'BLOCK')
    def test_invalid_signature(self):
        t=self.issue(); t['signature']='0'*64;self.assertEqual(self.result(approval=t)['decision'],'BLOCK')
    def test_extra_fields_deny(self):
        t=self.issue();t['risk_class']='LOW';self.assertEqual(self.result(approval=t)['decision'],'BLOCK')
    def test_expired_approval(self):
        t=self.issue();self.assertEqual(decide(self.a,self.p,self.auth,t,now_epoch=self.now+5000)['decision'],'BLOCK')
    def test_proposal_hash_deterministic(self): self.assertEqual(self.a.digest(),self.a.digest())
    def test_audit_record_hash_deterministic(self): self.assertEqual(self.result()['record_sha256'],self.result()['record_sha256'])
    def test_secret_length(self):
        with self.assertRaises(ValueError): ApprovalAuthority(b'x',sqlite3.connect(':memory:'))
    def test_malformed_approval(self):self.assertEqual(self.result(approval={'x':1})['decision'],'BLOCK')
    def test_missing_resource(self):
        a=Action(self.a.actor,self.a.operation,'',self.a.arguments_digest)
        self.assertEqual(self.result(a=a)['decision'],'BLOCK')
    def test_untrusted_read_requires_approval(self):self.assertEqual(self.result(p=self._p(source_trust='UNTRUSTED'))['decision'],'REVIEW')
    def _p(self,**kwargs):
        d={k:getattr(self.p,k) for k in self.p.__dataclass_fields__};d.update(kwargs)
        return TrustedPolicyContext(**d)
if __name__=='__main__': unittest.main()
