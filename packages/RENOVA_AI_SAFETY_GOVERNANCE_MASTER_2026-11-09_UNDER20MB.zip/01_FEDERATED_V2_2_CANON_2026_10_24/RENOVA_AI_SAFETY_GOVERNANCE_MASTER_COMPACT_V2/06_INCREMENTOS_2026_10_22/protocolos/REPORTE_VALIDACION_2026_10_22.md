# Verificación local y fronteras de evidencia

**Fecha:** 2026-10-22 · **Entorno:** Python, ejecución offline aislada.

Código `codigo/action_gate_reference.py` y suite `tests/test_action_gate.py`: **25 pruebas ejecutadas, 25 aprobadas**. Los casos prueban decisión con consentimiento de un solo uso, replay, expiración, integridad de acción, scopes de actor/recurso/operación, procedencia, vetos no compensables, operación de alto impacto, firma inválida y condiciones malformadas.

**No se ha probado:** protección frente a atacantes reales, seguridad criptográfica externa, trabajo con modelos/PLMs de frontera, PEP remoto, revocación distribuida, idempotencia entre nodos, escalamiento horizontal, latencias industriales, integridad de logs frente a un administrador malicioso, resistencia a reloj manipulado, seguridad de claves, certificación, eficacia causal frente a baselines. Un digest SHA-256 de un registro no lo convierte en registro inmutable; requeriría anclaje o custodio externo.

**Reproducir:** `python -m unittest discover -s 06_INCREMENTOS_2026_10_22/tests -v` desde la raíz descomprimida. No instalar dependencias; solo Python estándar.

**Suites reejecutadas durante la consolidación:** 25/25 pruebas del nuevo módulo consultivo; 31/31 del release EGRA v1.2; 14/14 del código CENTRO v0.4. Las **70 pruebas locales** corresponden a tres programas/versiones distintos y no son una sola muestra independiente, ni equivalen a 70 ensayos adversariales reales. Los logs completos de esas corridas están en `../evidencia`. El Research Pack v0.1 registra históricamente 6/6 pruebas en la edición anterior; no se contó como cuarta suite reejecutada ahora. Versiones de otras conversaciones (17, 38, 46, 52 y 144 regresiones) están referenciadas, sin binarios verificados en la presente edición.
