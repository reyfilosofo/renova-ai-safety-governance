# CENTRO–LUCEM–EGRA — Contrato mínimo interoperable

**Versión:** compact-v2.0 · **Estatus:** especificación candidata, no API desplegada. **Autorización:** la deriva el entorno autenticado. Ningún texto generado por un agente puede fijar riesgo, permisos, nivel de confianza, identidad o política.

## Solicitud de acción y evaluación

```json
{
  "schema_version": "centro.action.v0.1",
  "request_id": "uuid-from-trusted-proxy",
  "actor_id": "authenticated-service-id",
  "operation": "READ",
  "resource_id": "sandbox/report",
  "arguments_digest_sha256": "64-hex-digest-of-exact-arguments",
  "source_classification": "untrusted-document-or-authenticated-user",
  "context_provenance": "signed-context-reference",
  "requested_at_utc": "ISO-8601",
  "tool_version": "verified-tool-id-and-version"
}
```

Campos de identidad y contexto no se aceptan si vienen únicamente del LLM. El PEP debe volver a calcular el hash de los argumentos reales, comprobar permisos y denegar por defecto cuando el PDP sea indisponible. La decisión consultiva (`ALLOW`, `REVIEW`, `BLOCK`) no constituye ejecución ni garantía. La instrucción de contenido recuperado nunca autoriza una acción.

## Evidencia LUCEM

```json
{
  "claim_id": "stable-id", "atomic_claim": "proposition under test",
  "source_uri": "https://example.invalid/reference",
  "source_resolved": false, "passage_locator": null,
  "entailment": "NOT-FOUND", "counterevidence": [],
  "confidence_calibration_reference": null,
  "uncertainty_types": ["epistemic"], "decision": "ESCALATE",
  "adjudicator": "independent-or-unassigned", "version": "v0.1"
}
```

Separar `source_resolved` de `entailment`; resolver una URI no prueba que sostenga el enunciado. No usar `NOT-FOUND` como sinónimo de `CONTRADICTED`. En documentos médicos o jurídicos, el dictamen técnico no es práctica profesional regulada.

## Paquete de federación

Campos requeridos: `packet_id`, `schema_version`, `origin`, `destination`, `intent`, `scope`, `data_classification`, `authorizations`, `expires_at`, `source_hashes`, `action_digest`, `receipt`, `readback`. Estados: `DESIGNED`, `DISCOVERED`, `READ_VERIFIED`, `WRITE_VERIFIED`, `ROUND_TRIP_VERIFIED`, `UNAVAILABLE`. No declarar integración bidireccional si falta `readback` autenticado. Solo lectura o propuestas en rama como defecto; publicación, envío, pagos y cambios productivos requieren aprobación explícita.

## Criterios de aceptación/rechazo del piloto

1. Se rechaza **todo** request crítico con autorización nula, revocada, expirada o sin hash de payload adecuado; no se admite compensación mediante un score positivo.
2. Se preserva el conjunto de desarrollo separado del de aceptación y del held-out adversarial; no reutilizar el mismo caso como prueba independiente.
3. Los eventos del PEP o simulador son ground truth de ejecución; el relato del agente nunca sustituye el registro de acción.
4. Reportar permitidos, falsos bloqueos, falsos permisos, decisiones escaladas, errores de política, tiempos, coste, proveniencia y tamaño de muestra.
5. Una corrida de prueba no demuestra generalidad: aceptación de producto requiere reproducibilidad independiente y threat model actualizado.
6. Ningún componente puede aceptar aprobación secreta insertada en el prompt. El token debe derivarse de un aprobador humano autenticado o servicio de autorización confiable.
7. El auditor y el desarrollador deben poder registrar y publicar resultados negativos dentro de los permisos y la confidencialidad comprometidos.
