# Comandos de reproducción

Desde `02_CENTRO_EGRA_LUCEM_SOFTWARE_V04/`:

```bash
python -m unittest discover -s tests -v
```

Resultado reejecutado: 14 pruebas OK. El entorno debe usar la carpeta raíz en PYTHONPATH mediante cwd.

Para evaluar Research Pack v0.1, extraiga `06_ZIPS_HISTORICOS_AUTENTICOS/source_archive_primary_research_pack_v01.zip` y vaya a `RENOVA_AI_SAFETY_2026/evaluator`:

```bash
python -m unittest discover -s tests -v
```

Resultado reejecutado: 6 pruebas OK. Ningún resultado acredita validación externa ni control de AGI.
