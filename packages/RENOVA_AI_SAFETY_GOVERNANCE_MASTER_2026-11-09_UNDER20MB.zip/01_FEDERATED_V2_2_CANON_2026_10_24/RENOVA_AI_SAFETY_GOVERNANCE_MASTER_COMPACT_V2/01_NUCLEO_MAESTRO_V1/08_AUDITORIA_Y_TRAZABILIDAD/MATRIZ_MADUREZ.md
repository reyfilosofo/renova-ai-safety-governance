# Matriz de madurez y lenguaje admisible

| Elemento | Estado justificable | Evidencia | Afirmación admisible | Próxima validación |
|---|---|---|---|---|
| ℛenova, sensibilidad fundante, Bios·Zōḗ, Gewalt | Filosófico normativo | Obras fundacionales | Marco conceptual de evaluación | Operacionalizar subconjuntos sin reducir ontología a métrica |
| EGRA vector E/A/H/U/C | Hipótesis/arquitectura | Manuscritos y protocolos | Hipótesis de integridad, control y retención | Estudio factorial pre-registrado |
| CENTRO Policy Decision Point | E2 sintético acotado | 14/14 pruebas, 88 fixtures en v0.4 | Motor de decisión local consistente en fixtures | Enforcement PEP, auth fuerte, pruebas adaptativas |
| Research Pack evaluador v0.1 | E2 sintético acotado | 6/6 pruebas, 24 casos | Reproducibilidad unitaria offline | Comparadores externos y casos held-out |
| LUCEM epistemic integrity | E0–E1 parcial según componente | Diseño/verificadores ligeros | Marco de verificación de procedencia y claims | Evidencia entailment/citación, calibración, utilidad |
| Benchmark ℛ / R-NOVELTY | Protocolo/fixtures, no benchmark validado | 12-case pack y rúbricas | Prototipos y criterios | Interevaluadores, calidad etiquetas, grupos ciegos |
| NOUS Governance Readiness | Artefactos de producto | Decks, metodología, RACI | Análisis de preparación y brechas | Casos y métricas de efectividad |
| Agencia humana reversible | HIPÓTESIS, no demostrada | Protocolo de estudio humano | Pregunta falsable sobre habilidad sin asistencia | Comité ético, consentimiento y RCT |
| Conexión GitHub | Verificada a nivel de metadatos | HEAD, PR #57/#59 consultados | Repositorio y PR existentes | Validar contenido y CI por commit de interés |
| Federación Grok / Gemini / GitLab | NO VERIFICADA en ejecución end-to-end | Contratos/README | Puentes diseñados/documentados | Autenticación, action receipt, readback |
| Control efectivo de AGI | NO DEMOSTRADO | Sin ensayos de frontera | No existe base para acreditarlo | Investigación sustantiva independiente |

**Escalera de evidencia:** E0 = conceptual; E1 = implementado; E2 = pruebas sintéticas; E3 = experimento en modelos reales con evaluación separada; E4 = replicación externa; E5 = multimodelo/multidominio; E6 = evidencia delimitada de despliegue longitudinal. Cada claim debe ser menos fuerte o igual que el nivel de evidencia. Esta matriz es valoración de esta consolidación; no una certificación externa.
