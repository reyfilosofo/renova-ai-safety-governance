# GitHub / repositorio comprobado

- Repositorio: https://github.com/reyfilosofo/renova-agent
- Visibilidad pública, rama por defecto `main` (consulta autenticada con conexión GitHub el 22 de octubre de 2026).
- HEAD `main`: `dece4bf7a2acef225c1932588f09725be9d9cd18`; commit fecha `2026-10-22T21:34:42Z`; mensaje `MONEY: refresh public resource discovery`.
- PR #57: https://github.com/reyfilosofo/renova-agent/pull/57 — abierta, borrador de AI Safety Lab, rama `research/renova-ai-safety-v0.1-20261015`, HEAD `e14493ff21a31b99d738eab2fa85171bcf860116`.
- PR #59: https://github.com/reyfilosofo/renova-agent/pull/59 — abierta, borrador EGRA v1.2, rama `research/egra-ai-safety-v02-20261015`, HEAD `62a28f509479d6a8afcda54e1c8693a38a0debf7`.
- Módulo observado en árbol de `main`: `05_AI_SAFETY_EGRA/` con `evaluator/policy_demo.py`, `evaluator/test_policy_demo.py`, documentación de research, governance y federation.
- También se observó `labs/renova-nous-rsr-lab` y documentación `LUCEM` asociada al laboratorio.

**Alcance:** se verificaron metadatos y árbol del repositorio, pero **no se incluyó una clonación Git completa** en este ZIP porque los endpoints accesibles permitían leer texto y metadatos, no exportar un tarball/ZIP del repo por la conexión utilizada. Los binarios/código históricos verificables están dentro de las copias v0.4 y Governance V3 del paquete actual. El estado de `main` puede cambiar después de este corte.
