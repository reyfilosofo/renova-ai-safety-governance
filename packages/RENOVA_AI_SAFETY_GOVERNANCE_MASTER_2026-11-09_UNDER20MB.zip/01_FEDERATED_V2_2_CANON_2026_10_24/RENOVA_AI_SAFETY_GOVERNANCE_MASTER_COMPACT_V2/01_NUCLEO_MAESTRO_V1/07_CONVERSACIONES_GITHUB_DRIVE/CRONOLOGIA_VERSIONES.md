# Índice de versiones: no fusionar indebidamente

- Mayo 2026 — Governance OS V3 (138 entradas dentro del ZIP original archivado; situativity, Kammerer, protocolos, benchmark, documentos y aplicación web).
- Septiembre 2026 — R-NOVELTY v0.2 (12 casos documentales en Drive), OBS Q-series, ℛenova AI Audit v1.0 (rúbrica y producto congelados).
- 8 octubre 2026 — CENTRO OS/plugin v1.0.1–v1.0.2 **referidos en memoria; no todos descargados**.
- 15 octubre 2026 — Research Pack v0.1 (36 entradas en ZIP recuperado; 6 pruebas, 24 casos sintéticos).
- 15 octubre 2026 — EGRA/AI Safety v0.2–v0.3 (ZIP histórico v0.4 contiene fuente, código, 88 acciones sintéticas y 14 pruebas).
- 15 octubre 2026 — Master v0.4 (63 entradas directas, archivos anidados, documentos editoriales y código).
- 15 octubre 2026 — otras versiones v0.5, v1.0, v1.1, v1.2, V5: registros históricos indirectos, **sin bytes comprobados para todas**.
- 22 octubre 2026 — esta edición maestra de consolidación v1.0, que no modifica los originales previos. La nomenclatura v1.0 corresponde al trabajo de integración, no a reiniciar la versionado de cada módulo.
