# Catálogo de productos ℛenova/SERESARTE — estado prototipo
**No equivale a software certificado, servicio vendido ni sistema desplegado.** Tarifas, socios comerciales y autorizaciones: pendiente.

## PRODUCTO R-01 — LUCEM Evidence Audit
**Cliente posible:** equipo editorial de IA, investigación, documentación empresarial.
**Entrada:** afirmaciones atómicas y fragmentos probatorios aportados de forma legítima.
**Salida:** informe triage: evidencia aparente, ausencia de cita, incertidumbre, ruta de verificación humana.
**MVP incluido:** `src/evidence.py`; opera offline, sin comprobar fuentes fuera del archivo.
**Criterios de aceptación:** esquema válido; referencias trazables; errores señalados; no presentar similitud de palabras como veracidad.

## PRODUCTO R-02 — CENTRO Action Gate (simulation)
**Cliente posible:** desarrolladores de agentes con herramientas.
**Entrada:** solicitud de acción, origen, autorización externa, alcance, impacto.
**Salida:** allow/block/escalate consultivo con motivo y log.
**MVP incluido:** `src/policy.py` + casos sintéticos.
**Criterios de aceptación:** salida fail-closed ante acciones desconocidas; datos no confiables jamás autorizan; 100% de herramientas cubiertas en gateway real antes de pilotar (NO cumplido aquí).

## PRODUCTO R-03 — EGRA Benchmark & Research Kit
**Cliente posible:** equipos de evaluación y laboratorios académicos.
**Entrada:** datasets con adjudicación y baselines.
**Salida:** plantillas de preregistro, escenarios controlados, comprobaciones y reporte de diferencias.
**MVP incluido:** dataset de prueba y `src/cli.py`; NO existe prueba independiente ni modelo-in-the-loop.
**Criterios de aceptación:** replicación independiente, comparadores, datos retenidos, intervalos, errores y control de leakage.

## PRODUCTO R-04 — Human Capability Retention Study
**Cliente posible:** investigación educativa y organizaciones con asistencia por IA.
**Entrada:** diseño de participantes voluntarios, consentimiento y tareas.
**Salida:** estimación del efecto causal de andamiaje frente a respuesta directa en prueba posterior sin IA.
**MVP incluido:** protocolo, indicadores y plan de ética; NO se ha reclutado participantes.
**Criterios de aceptación:** aprobación ética antes de ejecutar, aleatorización, instrumentos con validez, manejo de privacidad.

## Modelo de negocio responsable
1. Investigación pública o abierta cuando el titular apruebe licencia.
2. Informes profesionales de auditoría y consultoría basados en hechos y fuentes.
3. Pilotos privados regulados por autorización contractual y límites de uso.
4. Trabajo editorial/creativo independiente claramente rotulado.
No afirmar ventas, ingresos, clientes, contratos, avales o reducciones de daño sin evidencias.
