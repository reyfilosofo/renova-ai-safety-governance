# Alcance, faltantes y contradicciones — control de completitud

1. **No existe acceso programático exhaustivo a todos los chats de ChatGPT** desde esta sesión. Se consultó el contexto personal permitido y los registros recientes; el archivo `CONVERSACIONES_RECUPERADAS_NO_TRANSCRIPCION.md` es síntesis y no exportación literal.
2. Varios adjuntos del proyecto actual mostraron índice, texto y títulos, pero el sistema de archivos negó materializar bytes crudos. Se recuperaron copias idénticas o cercanas de ciertos documentos mediante el ZIP v0.4 existente en Drive (código para inteligencias superiores, gentil singularidad, auditoría científica, governance V3, Lucem bundle, research v0.1). No puede inferirse identidad SHA-256 con cada adjunto original si no fue posible leerlo.
3. Otros ZIP mencionados en chats (varias ediciones v0.5, v1.0, v1.1, v1.2, V5, plugin privado v1.0.2, auditor v2.1 y Activation Kit) no pudieron recuperarse por identidad exacta. Su existencia histórica es distinta de incluir sus bytes aquí.
4. No se incluyó una imagen externa supuestamente idéntica a `fig_02_arquitectura_protocolos.png`; el archivo directo no tenía respaldo descargable, por lo que sólo se documenta la arquitectura con texto.
5. El repositorio GitHub fue examinado por metadatos, no clonado íntegramente. Los PR #57 y #59 estaban abiertos, no fusionados, al momento de consulta.
6. La documentación original contiene algunas afirmaciones y métricas de ejecución reportadas en chats anteriores; **no se equiparan a pruebas replicadas en esta sesión**. Sólo las suites de 14 y 6 se reejecutaron aquí.
7. La carpeta incluye documentos de producto y propiedad intelectual no publicados; su distribución debe permanecer privada hasta revisión legal y autoral.
8. Los ejemplos históricos son locales y sintéticos. No implican control robusto, certificación, cumplimiento de ISO/AI Act ni detección automática fiable de consciencia.
9. Todo documento que afirme que consenso de modelos equivale a verdad necesita contraste independiente y evidencia no correlacionada.

**Criterio de mejora:** incorporar versiones faltantes únicamente al recuperar sus bytes reales, anotar fuente/corte y recalcular hashes; no recrear artificialmente una versión histórica bajo el mismo nombre.
