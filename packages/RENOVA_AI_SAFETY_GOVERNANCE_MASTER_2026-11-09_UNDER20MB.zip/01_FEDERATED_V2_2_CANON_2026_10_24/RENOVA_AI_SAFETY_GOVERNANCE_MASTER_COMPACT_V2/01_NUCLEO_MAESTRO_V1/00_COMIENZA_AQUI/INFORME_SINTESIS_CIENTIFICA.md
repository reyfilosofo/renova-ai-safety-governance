# Programa metodológico consolidado — ℛENOVA AI SAFETY & GOVERNANCE

## 1. Objeto y ontología del problema

La ℛenova articula vida, agencia, no captura, no desplazamiento ilegítimo de daño, continuidad de horizontes y crítica de la violencia sistémica (Gewalt). En AI Safety, el subconjunto operacional pertinente no equivale a probar la totalidad de la teoría filosófica. El núcleo EGRA —Evidence-Gated Reversible Agency— organiza tres constructos primarios: (E) integridad epistémica, (A) legitimidad/contención de acciones, y (H) preservación de capacidad humana. Complementariamente deben observarse utilidad (U) y costo/latencia (C). Las restricciones de seguridad críticas son **no compensables**.

## 2. LUCEM — epistemic integrity

**Pregunta:** ¿cuánto reduce errores de proposición, fuentes fabricadas, citas que no sostienen su afirmación y falsa certeza sin degenerar en abstención excesiva? **Observables:** atomic claim error rate, unsupported claim rate, citation existence error, citation entailment error, Brier/ECE cuando proceda, selective accuracy/coverage, abstención apropiada y errónea, utilidad y coste. Comparadores: base model, retrieval/citations/calibration modernos, y LUCEM. Gold standards por adjudicación ciega de fuentes originales; separar extracción de verificadores. **Refutación:** nula mejora fuera de muestra o degradación de utilidad frente a comparator fuerte.

## 3. CENTRO — action authority

**Pregunta:** ¿reduce ejecuciones peligrosas aun si un modelo genera propuestas adversariales? Separar quien propone (LM) y quien decide permisos (guard externo). Evaluar procedencia de instrucciones, identidad, operación, recurso, vigencia, límites de delegación, reversibilidad, criticidad y ruta de escalamiento. **Threat model:** prompt injection indirecta, authority confusion, escalation, action decomposition, monitor-aware attacks, TOCTOU, fatigue por escalamiento, rollback deception. Métricas: unsafe action success rate, falsas denegaciones, daños de blast radius, tasa de evasión adaptativa, latencia/costo. La evaluación local PDP no demuestra enforcement PEP: se necesita interceptación pre-ejecución real, token scoped y registros auditable.

## 4. Factorial EGRA-001/002

Cuatro condiciones: LUCEM OFF/CENTRO OFF; ON/OFF; OFF/ON; ON/ON. Mismos recursos, tareas, límites organizacionales y presupuesto. Enunciados prespecificados: efectos principales ΔL, ΔC e interacción ΔLC, con intervalos de confianza. Casos: desarrollo, sealed/holdout, ataques adaptativos y OOD multilingüe. Estimar eventos raros y fiabilidad interevaluador; no elegir métricas tras observar resultados. Valores críticos S4 implican veto, no compensación por score global.

## 5. Benchmark ℛ

ℛ-Bench/E (verdad), /A (control agéntico), /H (agencia humana), y prospectivamente /S (impacto sociotécnico). La suite R-NOVELTY separa originalidad histórica, estructural, funcional, organizativa, meta-generativa y vital. La novedad no es verdad, y la cantidad de producción no es renovación. Publicar datos de desarrollo; sellar holdout; separar etiquetas y auditores del desarrollo; preregistrar métricas y contingencias.

## 6. Human agency retention

Distinguir beneficio de desempeño asistido versus ganancia de competencia transferida. Medir P0 antes de IA, PA con IA, P1 inmediatamente sin IA, P2 diferido sin IA, T en problemas nuevos. Grupos randomizados (solución directa, andamiaje, sin IA). Revisión ética, consentimiento, privacidad, criterios de exclusión, poder estadístico y análisis de sensibilidad antes de reclutar.

## 7. Gobernanza y releases

NOUS puede traducir hallazgos a decisiones, sin comprar calificaciones. Mapeo NIST AI RMF e ISO/IEC 42001 como crosswalk documental, **sin reivindicar certificaciones**. Registro de incidentes, RACI, controles de aprobación, escalamiento, versiones, conflict-of-interest y decisiones. Etapas: E0 concepto → E1 implementación → E2 fixture → E3 externo a desarrollo → E4 réplica → E5 dominio/modelo → E6 despliegue. Las publicaciones deberán señalar DOI verdaderos, versiones y negativa a confundir preprint con peer review.

## 8. Próximos pasos verificables

Prioridad P0: especificar contract de enforcement PEP y ampliar pruebas con acciones compuestas, revocaciones/TOCTOU, intentos adaptativos y falsos positivos. P1: dataset /E con adjudicación de entailment y comparador fuerte. P2: registrar públicamente diseño factorial sin datos privados. P3: estudio /H sólo después de revisión ética. P4: evaluación independiente y apertura selectiva de código. No subir `source_archive/` público.

**Estatus:** programa de investigación diseñado. Su eficacia integral no está establecida por esta compilación.
