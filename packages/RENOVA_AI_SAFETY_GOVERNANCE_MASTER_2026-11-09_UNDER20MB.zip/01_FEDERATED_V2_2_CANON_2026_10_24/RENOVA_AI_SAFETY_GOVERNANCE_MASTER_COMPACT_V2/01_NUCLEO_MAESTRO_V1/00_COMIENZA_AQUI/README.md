# ℛENOVA AI SAFETY & GOVERNANCE — ARCHIVO MAESTRO CONSOLIDADO

**Entrega de preservación, auditoría de procedencia y lectura científica** · Ciudad de México, 22 de octubre de 2026 · v1.0 (consolidación privada).

## Comienza por aquí

1. `00_COMIENZA_AQUI/INFORME_SINTESIS_CIENTIFICA.md` — topología epistemológica, LUCEM, CENTRO, EGRA, Benchmarks, agencias humanas y próximos experimentos.
2. `00_COMIENZA_AQUI/ALCANCE_Y_FALTANTES.md` — límite real del acceso a conversaciones, archivos no recuperables, conflictos entre versiones y cautelas de publicación.
3. `08_AUDITORIA_Y_TRAZABILIDAD/ACTA_VERIFICACION.md` — checks efectivamente reejecutados en esta sesión.
4. `08_AUDITORIA_Y_TRAZABILIDAD/MATRIZ_MADUREZ.md` — niveles de evidencia E0–E6 y claims admisibles.
5. `08_AUDITORIA_Y_TRAZABILIDAD/INVENTARIO_SHA256.csv` — archivo individual, origen de carpeta, bytes, hash SHA-256.
6. `07_CONVERSACIONES_GITHUB_DRIVE/CONVERSACIONES_RECUPERADAS_NO_TRANSCRIPCION.md` — cronología reconstruida, no literal.

## Índice

`01_FUENTES_FUNDACIONALES`: tratados, ciencia de la vida, código para inteligencias superiores, informe de AI Safety, singularidad renovativa. `02_CENTRO_EGRA_LUCEM_SOFTWARE_V04`: código offline, tests, 88 fixtures, decisiones y federation. `03_BENCHMARKS_VERDAD_CRITERIOS`: Truth, consensus ≠ truth, uncertainty, NOVELTY, auditoría, casos y rubric. `04_INVESTIGACION_Y_PUBLICACIONES`: EGRA, manuscritos, papers de trabajo, preregistro, literatura y agenda. `05_GOBERNANZA_NOUS_Y_PORTAFOLIO`: NOUS, Governance OS, RACI, presentaciones y research ledger. `06_ZIPS_HISTORICOS_AUTENTICOS`: ZIP maestro original v0.4 y anidados, preservados en bruto. `07_CONVERSACIONES_GITHUB_DRIVE`: reconstrucción y enlaces verificados. `08_AUDITORIA_Y_TRAZABILIDAD`: acta, inventarios, matriz y códigos de verificación.

## Derechos y límites

Material privado de investigación y propiedad intelectual de Carlos Jonathan González Rodríguez / ℛENOVA PRESS / SERESARTE. El material fuente original se conserva **sin afirmar licencia libre ni autorizar redistribución**. Los documentos de terceros conservan derechos y atribuciones originales. **NO PUBLICAR íntegro en GitHub ni reenviar sin revisión del autor.** No existe certificación científica de CENTRO/LUCEM/EGRA, garantía de seguridad AGI, cumplimiento ISO ni validación internacional de estos prototipos. La inclusión de una fuente no prueba sus tesis.

**Metodología:** se consultaron fuentes del proyecto y biblioteca accesibles, Google Drive conectado, GitHub conectado, y resúmenes de conversaciones recuperables. Se descargó el ZIP maestro v0.4 directamente desde Drive. Se contrastó integridad de ZIPs, se reejecutaron suites unitarias y se construyó un inventario de hashes de esta entrega. Se preservaron versiones históricas separadas. La cobertura absoluta de todos los chats es imposible con el acceso de esta sesión y se informa expresamente.
