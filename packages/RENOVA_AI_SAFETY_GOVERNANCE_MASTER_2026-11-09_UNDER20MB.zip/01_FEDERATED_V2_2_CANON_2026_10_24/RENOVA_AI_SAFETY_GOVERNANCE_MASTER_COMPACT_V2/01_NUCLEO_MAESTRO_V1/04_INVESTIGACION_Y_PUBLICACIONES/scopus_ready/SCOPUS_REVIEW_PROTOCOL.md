# Protocolo de búsqueda bibliográfica apto para Scopus (NO ejecutado dentro de Scopus)
Fecha diseño: 2026-10-15. Investigador: Carlos Jonathan González Rodríguez.
**Estado: estrategia lista para importar; NO es una revisión Scopus ejecutada ni una revisión sistemática completada.** Las once referencias base se cotejaron selectivamente con páginas editoriales, OpenAlex y documentación primaria, pero NO se comprobó su indexación individual en Scopus.

## Objetivo y PICO/PEO adaptado
Población: sistemas de IA generativa, agentes con herramientas y personas que interactúan con IA. Exposición: verification/authorisation/scaffolding. Comparador: ausencia de intervención y controles contemporáneos equivalentes. Outcome: errores factuales, invocaciones no autorizadas, bloqueo falso y desempeño humano posterior sin asistencia. Periodo principal: 2021–15 Oct 2026; antecedentes seminales anteriores admisibles y marcados.

## Strings reproducibles (pegar en búsqueda avanzada Scopus)
Q1 — Control y agentes:
TITLE-ABS-KEY(("AI control" OR "agentic AI" OR "language model agent*" OR "LLM agent*") AND ("authorization" OR "tool use" OR "prompt injection" OR "untrusted model" OR "policy enforcement")) AND PUBYEAR > 2020

Q2 — Integridad epistémica:
TITLE-ABS-KEY(("large language model*" OR "generative AI") AND ("hallucination" OR "factuality" OR "citation attribution" OR "uncertainty calibration" OR "semantic entropy") AND ("evaluation" OR "verification" OR "benchmark")) AND PUBYEAR > 2020

Q3 — Preservación de agencia humana:
TITLE-ABS-KEY(("generative AI" OR "AI assistance" OR "human AI interaction") AND ("skill retention" OR "independent performance" OR "cognitive offloading" OR "automation bias" OR "human agency" OR "learning transfer")) AND PUBYEAR > 2020

Q4 — Validez sociotécnica:
TITLE-ABS-KEY(("AI governance" OR "AI safety") AND ("construct validity" OR "human oversight" OR "sociotechnical" OR "contestability" OR "reversibility")) AND PUBYEAR > 2020

## SOP de revisión
1. Ejecutar cada query en Scopus con credenciales institucionales válidas; registrar hora, filtros, recuentos y URL de consulta.
2. Exportar RIS/CSV con Scopus EID, DOI, título, abstract, año, fuente, autores y fecha de descarga.
3. Deduplicar por DOI y título normalizado sin descartar preprints versus versiones de revista sin identificación manual.
4. Dos evaluadores independientes filtran título/resumen y texto completo; resolución de discrepancias documentada.
5. Incluir originales, revisiones sistemáticas y evaluaciones relevantes; excluir opinión sin método sólo para síntesis empírica, pero conservar en corpus normativo etiquetado.
6. Extraer diseño, población, modelo, baseline, datos retenidos, métricas de acción ejecutada, reproducción, incertidumbre y limitaciones.
7. Registrar sesgo, conflictos de interés, versión de modelos y riesgo de contaminación.
8. Reportar PRISMA 2020 con cifras REALES; no fabricar recuentos ni meta-análisis.
9. Registrar búsqueda complementaria en ACM DL, IEEE Xplore, OpenAlex, arXiv y editoriales sin equiparar sus coberturas.
10. Congelar fecha, consultas, criterios y versión, y conservar evidencia auditable antes de afirmar 'Scopus-indexed'.

## Estado actual
- Scopus directo: **NO DISPONIBLE / NO EJECUTADO**.
- OpenAlex: búsqueda temática exploratoria realizada; resultados de relevancia variable, requiere cribado.
- Fuentes primarias puntuales: cotejadas (véase CSV y Research Brief).
- Systematic review / PRISMA: **NO COMPLETADA**.
- DOI de cada artículo e indexación de cada revista: auditar uno a uno antes de citar o postular.
- No atribuir la publicación de artículos a CJGR ni colaboración con autores externos.
