# Rutas de publicaciones académicas — no confundir objetivo con aceptación

**ACM FAccT 2027**: CFP verificado: abstract 27-10-2026, full paper 03-11-2026, formato 14 páginas excluyendo referencias, revisión anónima y declaración de uso de IA. https://facctconference.org/2027/cfp.html. Riesgo: el repositorio público de EGRA afecta anonimato; decidir estrategia autoría/cita según guía y comité editorial. Se requiere OpenReview y revisión del original.

**AI & Society (Springer Nature)**: candidata para filosofía y análisis sociotécnico; indexación Scopus actual y guidelines: pendiente de verificación con fuente Scopus y revista. https://link.springer.com/journal/146

**Philosophy & Technology (Springer Nature)**: candidata para filosofía de la técnica, agencia y biolegitimidad; indexación Scopus actual y guidelines: pendiente. https://link.springer.com/journal/13347

**Minds and Machines (Springer Nature)**: candidata para epistemología, consciencia y agencia artificial; indexación Scopus actual y guidelines: pendiente. https://link.springer.com/journal/11023

**ACM Transactions on Interactive Intelligent Systems**: candidata para evaluaciones humano-IA; indexación y vigencia de convocatoria pendiente. https://dl.acm.org/journal/tiis

**NeurIPS Datasets and Benchmarks / ICML**: sólo tras validación de benchmark y comparadores sólidos; no hay datos suficientes hoy para afirmar contribución empírica.

**NO AFIRMAR:** 'Scopus accepted', 'Scopus published', 'indexed' en trabajos de CJGR sin ID, DOI y fuente editorial real.
