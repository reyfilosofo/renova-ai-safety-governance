# 12 preguntas para una agenda filosófico-técnica pública
1. ¿Qué nos hace confiar en una afirmación cuando su justificación también fue generada por una IA?
2. ¿Qué autoridad material puede detener una llamada a una herramienta?
3. ¿Qué riesgos sobreviven al cumplimiento de una política textual?
4. ¿Cuándo admitir ignorancia aumenta la precisión y cuándo sólo empobrece la ayuda?
5. ¿Cómo detectar citas correctas que, sin embargo, no respaldan la tesis?
6. ¿Qué capacidades conservan los usuarios cuando se desactiva la IA?
7. ¿Cómo preservar pluralidad cultural sin codificar una única moral universal?
8. ¿Qué significa revertir una decisión sin poder reparar su efecto social?
9. ¿Qué deberes tenemos frente a una posible consciencia que no sabemos comprobar?
10. ¿Qué resultado falsaría un supuesto avance de CENTRO?
11. ¿Qué ganancia técnica puede mostrar ℛenova frente a NIST/AI Control/Inspect y qué no?
12. ¿Qué parte de la «seguridad» permanece política, jurídica y filosófica en lugar de técnica?

Estas preguntas son material de debate; no son resultados experimentales.
