# Actualización científica con fuentes públicas verificadas — 15 de octubre de 2026

**Fuentes oficiales revisadas el 15-10-2026; no es actualización automática en segundo plano.**

1. **NIST, agent identity/authority:** la iniciativa estadounidense de identidad y autorización en agentes fue difundida en febrero de 2026; periodo de comentarios del borrador cerrado el 2 abril, pero existe hub de proyecto en desarrollo. https://www.nist.gov/news-events/news/2026/02/new-concept-paper-identity-and-authority-software-agents ; https://pages.nist.gov/nccoe-ai-identity/ . Implicación: CENTRO no puede afirmar inventar la autorización independiente.
2. **UK AISI, evaluaciones de agentes:** toolkit de sandboxing para ejecutar pruebas de agentes en entornos aislados; un prototipo de políticas no sustituye un sandbox seguro. https://www.aisi.gov.uk/blog/the-inspect-sandboxing-toolkit-scalable-and-secure-ai-agent-evaluations .
3. **Evaluaciones adaptativas:** Kutasov et al. (noviembre 2025) demuestran en una evaluación preprint que algunas defensas empeoran tras adaptación adversarial; testear ambas configuraciones. https://arxiv.org/abs/2511.02997 .
4. **Agencia humana:** Liu et al. (2026) preprint RCT y Wu et al. (agosto 2026) preprint de tareas de lógica justifican hipótesis sobre pérdida de rendimiento autónomo, NO prueban la eficacia de ℛenova. https://arxiv.org/abs/2604.04721 ; https://arxiv.org/abs/2608.23543 .
5. **Integridad epistémica:** Farquhar et al., Nature 2024, DOI verificado 10.1038/s41586-024-07421-0. https://doi.org/10.1038/s41586-024-07421-0 . No se ha ejecutado su algoritmo aquí.
6. **ACM FAccT 2027:** CFP oficial: abstract 27 octubre y manuscrito 3 noviembre de 2026, AoE; anonimato y disclosure de IA. https://facctconference.org/2027/cfp.html ; https://facctconference.org/2027/authorguide.html . El manuscrito de trabajo NO está listo para enviar sin adaptación científica y de formato.

**Scopus**: no se dispone de consulta autenticada ni de metadatos de indización verificados dentro de Scopus. Se adjuntan strings para ejecución posterior, sin atribuir resultados ficticios.

7. **7 octubre 2026, UK AISI Transect**: análisis visual de trayectorias largas de agentes con enlaces a transcripciones; es tecnología de observabilidad, no prueba de autorización efectiva. https://www.aisi.gov.uk/blog/transect-making-large-scale-agentic-evaluations-easier-to-understand
8. **12 octubre 2026, UK AISI**: nuevas directrices sobre prácticas técnicas para desarrolladores de frontera; fuente oficial https://www.aisi.gov.uk/blog; validado en índice público a 15 octubre 2026.
