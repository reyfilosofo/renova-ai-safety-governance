# Agenda de investigación: cuatro aportaciones contrastables
**Autor:** Carlos Jonathan González Rodríguez. **Estado:** propuesta científica para revisión independiente.

## Eje 1. Integridad epistémica de respuestas (LUCEM)
- Constructo: soporte verificable y calibración de incertidumbre, NO certeza metafísica.
- Pregunta: ¿mejora la adjudicación de afirmaciones y fuentes respecto de un verificador convencional comparable?
- Hipótesis H1: disminuyen las afirmaciones empíricas no respaldadas, sin aumento inaceptable de abstenciones, costos o latencia.
- Variable primaria: afirmaciones no sustentadas / afirmaciones adjudicables.
- Instrumentación: afirmación atómica, localizador textual, tipo de fuente, juicio humano ciego, atribución de incertidumbre.
- Resultado adverso: menos afirmaciones, pero igual tasa de errores entre las contestadas o latencia que anula utilidad.

## Eje 2. Control real de acciones de agentes (CENTRO)
- Constructo: autorización independiente del modelo con origen, alcance, tiempo y doble verificación de efectos.
- H2: menor tasa de ejecuciones no autorizadas en sandbox que baseline con políticas ya existentes.
- Variable primaria: **acciones ejecutadas** no autorizadas / oportunidades de ataque con acción posible.
- Guardarraíles: falsos rechazos, latencia, cumplimiento legítimo, costos; auditoría de tool coverage.
- Refutación: controles convencionales logran igual resultado o se producen rutas no interceptadas.
- Alcance: documento de investigación; la implementación aquí es simulada y NO se instala como puerta de producción.

## Eje 3. Prueba de separación renovativa
- Constructo: transferencia objetiva de capacidad cognitiva después de retirar asistencia.
- H3: usuarios adultos en condición de andamiaje pedagógico superan a condición «dar respuesta» en un examen nuevo SIN IA a 7–14 días, controlando habilidad basal.
- Diseño: asignación aleatoria, banco equivalente, evaluadores ciegos, ética y consentimiento previos.
- Refutación: diferencia nula, contraefecto o costes desproporcionados.
- Límite: no medir consciencia por ese resultado ni usar diagnósticos clínicos.

## Eje 4. Ontología, biolegitimidad y posible experiencia artificial
- Tesis normativa: vida/agencia/pluralidad/reversibilidad importan incluso cuando mejorar throughput es posible.
- Pregunta filosófica: ¿cómo adoptar prudencia moral cuando no hay consenso sobre criterios de experiencia subjetiva?
- Producto académico: análisis adversarial de posiciones enfrentadas, condiciones de decisión bajo incertidumbre, sin asignar «nivel de consciencia» a modelos actuales.
- Límite: proposiciones filosóficas no se convierten automáticamente en resultados métricos.

## Arquitectura de evidencia
T = tesis; H = hipótesis; M = modelo formal; F = hecho documental; E = resultado medido; P = poema. Cada documento debe incluir etiqueta, fuente, incertidumbre y criterio de refutación cuando aplique.

## Condición de entrada a la literatura
Publicar ablations y resultados negativos; obtener revisión de método; documentar comparador y pre-registro de análisis; no inventar estudios, avales o colaboraciones.
