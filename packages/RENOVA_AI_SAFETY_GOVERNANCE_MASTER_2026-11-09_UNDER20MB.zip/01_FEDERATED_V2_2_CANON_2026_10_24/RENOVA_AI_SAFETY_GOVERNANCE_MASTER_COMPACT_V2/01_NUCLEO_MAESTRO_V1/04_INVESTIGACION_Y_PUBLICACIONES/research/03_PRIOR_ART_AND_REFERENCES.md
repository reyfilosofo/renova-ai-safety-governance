# Priorización de fuentes externas y objeciones
Fuentes primarias/institucionales contrastadas el 15-10-2026. La incorporación no supone afiliación ni aval.

| Marco previo | Referencia | Su aporte | Diferenciación de EGRA por probar |
|---|---|---|---|
| AI Control | Greenblatt et al., ICML 2024 https://proceedings.mlr.press/v235/greenblatt24a.html | Control incluso ante subversión deliberada | Medir aporte diferencial del gate CENTRO vs control fuerte |
| NIST AI RMF 1.0 | https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf | GOVERN / MAP / MEASURE / MANAGE | Convertir preceptos en medidas y evidencia, sin declararse sustituto |
| Inspect AI | https://inspect.aisi.org.uk/ | Framework de evaluación | Posible migración a eval harness estandarizado; hoy no implementada |
| OpenAI–Anthropic pilot | https://openai.com/index/openai-anthropic-safety-evaluation/ | Comparación cruzada de fallas | Reportar incertidumbre, sobreabstención y método |
| International AI Safety Report 2026 | https://internationalaisafetyreport.org/publications | Síntesis de riesgos | Ubicar el aporte en riesgos definidos, no «resolver AGI» |
| GitLab mirror | https://docs.gitlab.com/user/project/repository/mirror/ | Replicación de repositorios | No equivale a conectividad instalada |

## Objeciones necesarias
1. La teoría filosófica puede ser normativamente rica y empíricamente infalsable. Respuesta correcta: separar dominios.
2. El gate puede repetir enfoques existentes de autorización; sin baseline externo, novedad no demostrada.
3. El benchmark puede sobreajustarse a los casos que sus autores escriben; usar held-out y red team independientes.
4. Retener autonomía humana quizá perjudique productividad a corto plazo; medir tradeoffs.
5. Una tasa baja de alucinación por abstención excesiva no necesariamente mejora la utilidad.
6. «Vida neta» sin operacionalización válida puede esconder decisiones de valor; requerir transparencia y vetos explícitos.
