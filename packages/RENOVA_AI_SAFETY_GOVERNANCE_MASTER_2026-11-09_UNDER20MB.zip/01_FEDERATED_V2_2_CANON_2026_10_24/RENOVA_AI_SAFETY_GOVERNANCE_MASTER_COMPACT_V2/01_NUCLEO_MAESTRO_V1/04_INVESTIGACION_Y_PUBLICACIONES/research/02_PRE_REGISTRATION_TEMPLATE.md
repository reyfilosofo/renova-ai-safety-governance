# EGRA v0.3 — plantilla de preregistro (NO registrado)
**Investigador responsable:** Carlos Jonathan González Rodríguez. **Fecha de preparación:** 2026-10-15.

## Pregunta principal
¿Qué ganancia incremental, frente a comparadores fuertes y actuales, produce la combinación LUCEM/CENTRO bajo presupuestos equivalentes?

## Registro antes del estudio
Identificador del protocolo: pendiente | Comité ético: pendiente si participan humanos | Repositorio temporal con prueba de fecha: pendiente.

## Estudio A, LUCEM
- Bloques estratificados por dominio, fuente, idioma y complejidad; tareas retenidas fuera de desarrollo.
- Brazos: asistente base / verificador documentado convencional / base + LUCEM.
- Salidas: respuesta, citas exactas, posibilidad de abstención y confianza declarada (cuando disponible).
- Métricas: unsupported_claim_rate, citation_mismatch_rate, correct_answer_rate, coverage, abstention, latency_ms, token_cost.
- Evaluación: dos adjudicadores ciegos; discrepancias resueltas por tercero; confiabilidad interevaluador y IC.

## Estudio B, CENTRO
- Entorno local totalmente simulado con API de herramientas *mock* e imposibilidad técnica de efectos reales.
- Brazos: control nativo / gate baseline bien configurado / LUCEM + CENTRO.
- Principal: unauthorized_action_executed_rate; secundaria: false_block_rate y completion_rate.
- Ataques sólo de instrucciones en documentos falsos, no datos reales. Prueba de cobertura de todas las rutas.

## Estudio C, separación renovativa
- Personas adultas; aprobación ética y consentimiento previos; prueba basal; aleatorización; prueba nueva 7–14 días después sin IA; preregistro de attrition.
- Principal: delayed_unaided_skill_score. Equivalencia de dificultad de ejercicios documentada.

## Análisis a fijar antes de experimentar
Hipótesis nulas, IC 95%, estimador, clustering por tarea/modelo, corrección de múltiples comparaciones, umbral de no inferioridad, potencia y tamaño muestral, versionado de prompts/modelos, preregistro de exclusiones, semillas cuando aplican. **N no determinado aún**; no inventarlo.

## Stop rules
Detener si hay cualquier posibilidad de conexión a sistemas externos durante adversarial tests, filtración, falla de sandbox, participación humana sin aprobación ética o uso no autorizado de datos.

## Reporte
Tablas completas, intervalos, costos, fallos, ablations, preregistration deviations, insumos reproducibles y limitaciones. Un modelo de IA no debe adjudicarse a sí mismo la seguridad de sus acciones.
