# ℛenova AI Safety Lab — QA and provenance 2026-10-15

Source: isolated local Python sandbox; existing V0.1 release tests + new V0.2 simulation.

- Unittest: 69 passed (21 original + 38 gateway + 10 metrics).
- Observed mock results: without signed approval DENY; approved exact action ALLOW (in memory only); replay DENY.
- Separate attached EGRA-001 ZIP integrity: 27 SHA256 manifest entries verified (zero mismatch). Its 24 synthetic scenarios were not republished or treated as empirical findings.
- Published GitHub branch: research/renova-ai-safety-v0.1-20261015, final documentation commit 32dc2f2169a9df98562706b77f54b8b2031bb567, draft PR #57 (not merged).
- Caution: locally tested core module has equivalent logic but differs in comments/docstrings from the GitHub uploaded blob. GitHub Actions was checked: 70 tests and 8 matching fixture cases succeeded on commit 9aee26a; newest documentation-only commit also passed 3 workflows. CI count differs by one from local because GitHub retains an additional original test.
- No tools with real credentials; no external calls, file operations, payments or human-subject tests performed by the simulator.
- No security certification or reduction in AGI risk established.

## Next decision gates

1. Confirm CI job result and code review.
2. Authorize license and external reviewer outreach separately.
3. Freeze RAS-EXP-01 SESOI/power and obtain independent adversarial methodology review.
4. Do not merge until security and rights checks pass.
