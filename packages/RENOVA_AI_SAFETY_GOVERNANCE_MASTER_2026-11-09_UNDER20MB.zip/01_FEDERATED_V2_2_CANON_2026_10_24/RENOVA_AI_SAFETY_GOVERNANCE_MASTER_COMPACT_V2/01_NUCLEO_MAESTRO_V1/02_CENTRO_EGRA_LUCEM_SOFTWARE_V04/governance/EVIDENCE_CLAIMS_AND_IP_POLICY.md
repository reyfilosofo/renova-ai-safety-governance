# Claim taxonomy, publication controls and intellectual property

A: direct quotation from user-authored identified page; B: supported paraphrase; C: original analysis; D: falsifiable hypothesis; E: empirical result with dataset and comparator; F: artistic/poetic expression.

Current stages (research opinion, not third-party certification): normative ℛenova E0; conceptual EGRA E0–E1; 14 offline unit tests in v0.3 = synthetic engineering test E2; model-in-the-loop efficacy E3 NOT achieved; external replication E4 NOT achieved; cross-model E5 NOT achieved; deployment E6 NOT achieved.

No AGI containment guarantees. No clinical application. No diagnosis of consciousness. No selling a certification. Never take money for a better score. Prior literature on controls and epistemic verification must be acknowledged. External publication of unpublished book chapters or corporate trade secrets requires author decision. Always append material uncertainty and pre-registration info where appropriate.
