# ℛENOVA AI SAFETY & HUMAN FUTURES — DELIVERY v0.4
**Date:** 2026-10-15. **Author:** Carlos Jonathan González Rodríguez. **Source basis:** 7 provided reference files, unchanged and preserved in `source_archive/` with SHA-256 hashes. **Coordinator:** CJGR Executive Twin Ω / ℛENOVA · CENTRO OS as instruction/skills, not independent external bot-to-bot integration.

## Finished artifacts
- `papers/EGRA_RESEARCH_MANUSCRIPT_EN_V04.docx` and PDF — scholarly working paper with explicit limitations.
- `papers/FAccT_2027_SUBMISSION_NOTES.md` — verified CFP dates, anonymity/AI-declaration gating.
- `scopus_ready/SCOPUS_REVIEW_PROTOCOL.md` — executable (by an authorised researcher) Scopus advanced search strings; **not executed in Scopus**.
- `scopus_ready/EVIDENCE_SEED_CANDIDATES.csv` — bibliographic seeds; NOT proven Scopus indexed.
- `scopus_ready/TARGET_VENUES.md` — submission targets; journal indexing to verify.
- v0.3 `src/`, `datasets/`, `tests/`, `research/`, `products/`, `publication/`, `federation/` — working offline MVP + protocol, 14 Python tests.
- `governance/` — honest claim/IP and security gates.
- `reports/` — research report PDF carried from v0.3.
- `source_archive/` — exact previously supplied inputs (private distribution only).

## Limitations
*NO* Scopus submission, *NO* journal acceptance, *NO* peer review, *NO* independent model-in-the-loop demonstration, *NO* cross-app real-time synchronization. GitHub and Drive are only those connectors demonstrated with authenticated write receipts; other platforms are documented as `not_connected` until actual write + readback.

Reproduce tests from this directory: `python -m unittest discover -s tests -v` (Python 3.10+). A local synthetic demo is NOT an AI safety certification. This package should not be pushed wholesale to public repositories because `source_archive/` contains unpublished protected material.
