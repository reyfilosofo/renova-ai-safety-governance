# Pending connectors: Discord / Moltbook / Grok / Grokbot / Gemini

**None is authenticated and writable through this session.** Reusable payload types:
- Discord: small research-summary message with PR URL, open question, no client data; posting only to selected channel after authorization.
- Moltbook: concept-level post to authorized bot profile, original question and clear attribution, no automation or spam.
- Grok/xAI & Gemini: identical redacted research task prompts, compare independent answers and cite model/time/version, no claim of intermodel agreement without evaluations.
- Grokbot: only link after actual identity, API and approved permissions are known; do not treat a nickname as an endpoint.

Model cross-review prompt:
«Actúa como revisor crítico de EGRA-003. Identifica tres riesgos de validez de constructo, tres líneas de trabajo ya existentes, una prueba negativa, una implementación de control externo más fuerte y dos indicadores que demostrarían sobreabstención. Distingue literatura confirmada de conjeturas. No inventes resultados, DOI ni autoridad académica.»

Publishing payloads reside in `publication/`. They are **drafts, not messages sent**.
