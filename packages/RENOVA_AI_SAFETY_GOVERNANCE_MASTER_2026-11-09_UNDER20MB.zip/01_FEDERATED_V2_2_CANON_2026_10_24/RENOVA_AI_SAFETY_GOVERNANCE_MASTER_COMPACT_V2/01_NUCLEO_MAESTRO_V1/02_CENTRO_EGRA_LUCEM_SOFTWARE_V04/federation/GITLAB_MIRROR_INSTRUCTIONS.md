# GitHub → GitLab
Source of truth in GitHub: `https://github.com/reyfilosofo/renova-agent`.

No GitLab credentials/connection were available, so **not configured**. Setup after authenticating:
1. Create a **private** receiving project in GitLab first; review published files.
2. Use GitLab import-by-URL or pull mirroring (tier dependent). Verify current tier, SSH host keys and repository rights. Reference: https://docs.gitlab.com/user/project/repository/mirror/.
3. Mirror only reviewed branches; initially ignore draft/unreviewed experiments and historical ZIP material.
4. Compare commit SHAs, confirm GitLab project URL and update `federation/status_2026-10-15.json` after authenticated readback.
5. Do not paste GitLab or GitHub tokens into chat, documents or repos.
