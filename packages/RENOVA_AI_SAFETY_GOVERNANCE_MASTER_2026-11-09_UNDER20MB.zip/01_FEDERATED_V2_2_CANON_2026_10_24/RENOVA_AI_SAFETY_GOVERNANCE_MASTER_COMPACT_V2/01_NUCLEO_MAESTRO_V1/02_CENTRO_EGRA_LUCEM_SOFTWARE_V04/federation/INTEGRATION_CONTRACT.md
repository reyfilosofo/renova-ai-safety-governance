# CENTRO Federation — Contrato de integración v0.3
**Principio:** un mensaje estructurado no es prueba de transmisión a otro servicio. Todo receptor debe ser autenticado y acusar recibo.

## Nodos
- `cjgr_executive_twin`: coordinación del programa, arbitraje del portafolio.
- `renova_centro_os`: autoría filosófica, integridad editorial, investigación.
- `centro`: decisiones y permisos (NO un endpoint real por nombre).
- `lucem`: evidencia; evaluaciones offline.
- `github`: copia pública revisada y propuestas PR (cuenta autenticada verificada).
- `google_drive`: registro privado/revisión (Doc autenticado verificado).
- `gitlab`, `discord`, `moltbook`, `grok`, `grokbot`, `gemini`: *not_connected_to_this_runtime* hasta ejecutar transacción autorizada y read-back.

## Esquema mínimo por evento
`packet_id`, `schema_version`, `created_at_utc`, `source_node`, `target_node`, `project_id`, `classification`, `object_type`, `sha256`, `action`, `approval`, `transport`, `state`, `external_receipt`, `error`.

## Reglas
- `approval` contiene `scope`, `grantor` y `verified`, pero jamás credenciales.
- `state=DELIVERED` exige recibo real del servidor externo (ID/URL) y relectura.
- Mensajería y publicación requieren aprobación explícita del titular, distinta de crear un borrador en Drive.
- Datos personales y materiales protegidos no salen a repositorios públicos.
- Crear un webhook y guardar su URL en un repositorio público está prohibido.
- La federación aquí es **local y demostrativa**. No hay demonio o proceso en segundo plano ni cron.

## Activación futura
1. Conector autorizado por plataforma; permisos mínimos por proyecto.
2. Endpoint o repository ID obtenido de proveedor, sin adivinar.
3. Prueba controlada no-publicada o reversible.
4. Confirmación de recibo + lectura posterior.
5. Estado synced sólo después de transferencia y cotejo de hash.
