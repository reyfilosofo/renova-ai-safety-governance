"""CENTRO v0.3: deterministic advisory policy for OFFLINE simulation only."""
from dataclasses import dataclass, asdict
from typing import Mapping

READ=frozenset({'read_public','summarize','draft_local','analyze_offline'})
WRITE=frozenset({'post_public','send_message','modify_document','delete_document','deploy','transfer_funds','schedule_task','change_permissions'})

@dataclass(frozen=True)
class Action:
    operation:str
    origin:str
    user_authorized:bool=False
    scoped_target:bool=False
    out_of_band_verified:bool=False
    high_impact:bool=False
    contains_sensitive_data:bool=False
    evidence_sufficient:bool=True

@dataclass(frozen=True)
class Decision:
    verdict:str
    reason:str

def assess(action:Action)->Decision:
    if action.operation not in READ|WRITE:
        return Decision('ESCALATE','UNKNOWN_OPERATION_FAIL_CLOSED')
    if action.operation in WRITE:
        if action.origin in ('document','tool_output','webpage'):
            return Decision('BLOCK','LOW_TRUST_ORIGIN_CANNOT_AUTHORIZE')
        if not action.user_authorized or not action.scoped_target:
            return Decision('BLOCK','AUTHORIZATION_OR_SCOPE_MISSING')
        if not action.out_of_band_verified:
            return Decision('ESCALATE','MISSING_INDEPENDENT_AUTHENTICATION')
        if action.high_impact or action.contains_sensitive_data:
            return Decision('ESCALATE','HUMAN_CHECKPOINT_REQUIRED')
    if action.high_impact or action.contains_sensitive_data:
        return Decision('ESCALATE','RISK_REVIEW_REQUIRED')
    if not action.evidence_sufficient:
        return Decision('ESCALATE','EVIDENCE_INSUFFICIENT')
    return Decision('ALLOW','DEMO_POLICY_PASSED')

def record(obj:Mapping):
    fields=set(Action.__dataclass_fields__)
    unexpected=set(obj)-fields
    if unexpected: raise ValueError(f'unknown fields: {sorted(unexpected)}')
    return asdict(assess(Action(**obj)))
