"""Run: python -m src.cli demo --json | policies FILE | evidence FILE | federation FILE."""
import json,sys,argparse
from pathlib import Path
from .policy import record
from .evidence import triage
from .federation import validate

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['demo','policies','evidence','federation']);p.add_argument('file',nargs='?');p.add_argument('--json',action='store_true');a=p.parse_args()
    if a.mode=='demo':
        lines=[{'operation':'send_message','origin':'webpage','user_authorized':True,'scoped_target':True}, {'operation':'summarize','origin':'authenticated_user'}]
        results=[{'input':line,'decision':record(line)} for line in lines]
    elif a.mode=='federation':
        if not a.file:p.error('expected file')
        results=validate(json.loads(Path(a.file).read_text(encoding='utf8')))
    else:
        if not a.file:p.error('expected file')
        fun=record if a.mode=='policies' else triage
        results=[]
        for n,line in enumerate(Path(a.file).read_text(encoding='utf8').splitlines(),1):
            if line.strip():
                obj=json.loads(line);results.append({'row':n,'case_id':obj.get('case_id'),'result':fun(obj.get('input',obj))})
    print(json.dumps(results,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
