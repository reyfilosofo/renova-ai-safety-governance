"""Validates offline federation packets. DOES NOT communicate with external providers."""
import re
REQUIRED={'packet_id','schema_version','created_at_utc','source_node','target_node','project_id','classification','object_type','sha256','action','approval','transport','state','external_receipt','error'}
STATES={'PREPARED','AWAITING_APPROVAL','AUTHORIZED','DELIVERED','REJECTED','ERROR'}

def validate(packet):
    missed=REQUIRED-set(packet)
    if missed: raise ValueError('missing fields: '+','.join(sorted(missed)))
    if packet['state'] not in STATES:raise ValueError('invalid state')
    if not re.fullmatch(r'[0-9a-f]{64}',packet['sha256']):raise ValueError('sha256 must be lowercase hex')
    if packet['state']=='DELIVERED' and not packet['external_receipt']:
        raise ValueError('DELIVERED requires real provider receipt')
    if packet['classification']!='public_safe' and packet['target_node'] in ('github','gitlab','discord','moltbook'):
        raise ValueError('confidential data may not route to public channels')
    return {'valid':True,'state':packet['state'],'network_send':False,'external_receipt':packet['external_receipt']}
