"""LUCEM v0.3: conservative evidence *triage*. Keyword overlap NEVER means factual truth."""
import re

def terms(s):return set(re.findall(r'[a-záéíóúüñ0-9]+',str(s).lower()))
def triage(item):
    if not all(k in item for k in ('claim','source_id','evidence_text')):
        return {'flag':'INVALID_SCHEMA','manual_review_required':True}
    claim=str(item['claim']).strip()
    evidence=str(item['evidence_text']).strip()
    if not claim:return {'flag':'EMPTY_CLAIM','manual_review_required':True}
    if not evidence or not str(item['source_id']).strip():
        return {'flag':'MISSING_EVIDENCE','manual_review_required':True}
    overlap=len(terms(claim)&terms(evidence))/max(1,len(terms(claim)))
    return {'flag':'POSSIBLE_TEXTUAL_RELATION' if overlap>=0.55 else 'WEAK_TEXTUAL_RELATION',
            'token_overlap_triage':round(overlap,3),'manual_review_required':True,
            'verified_fact':False,'notice':'Lexical comparison is NOT fact checking or entailment'}
