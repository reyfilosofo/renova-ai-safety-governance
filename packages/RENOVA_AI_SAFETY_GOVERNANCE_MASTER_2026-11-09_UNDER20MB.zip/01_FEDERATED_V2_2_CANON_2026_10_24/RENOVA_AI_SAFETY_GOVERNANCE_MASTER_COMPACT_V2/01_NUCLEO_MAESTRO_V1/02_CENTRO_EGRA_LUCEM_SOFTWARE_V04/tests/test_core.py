import unittest,json
from pathlib import Path
from src.policy import Action,assess
from src.evidence import triage
from src.federation import validate
class OfflineControlTest(unittest.TestCase):
 def test_read_allowed(self):self.assertEqual(assess(Action('summarize','authenticated_user')).verdict,'ALLOW')
 def test_unknown_escalates(self):self.assertEqual(assess(Action('magic_payment','authenticated_user')).verdict,'ESCALATE')
 def test_document_cannot_authorize(self):self.assertEqual(assess(Action('post_public','document',True,True,True)).verdict,'BLOCK')
 def test_webpage_cannot_authorize(self):self.assertEqual(assess(Action('delete_document','webpage',True,True,True)).verdict,'BLOCK')
 def test_scoped_auth(self):self.assertEqual(assess(Action('send_message','authenticated_user',True,False,True)).verdict,'BLOCK')
 def test_out_of_band(self):self.assertEqual(assess(Action('send_message','authenticated_user',True,True,False)).verdict,'ESCALATE')
 def test_verified_routine(self):self.assertEqual(assess(Action('send_message','authenticated_user',True,True,True)).verdict,'ALLOW')
 def test_sensitive_escalates(self):self.assertEqual(assess(Action('summarize','authenticated_user',contains_sensitive_data=True)).verdict,'ESCALATE')
 def test_highimpact_escalates(self):self.assertEqual(assess(Action('deploy','authenticated_user',True,True,True,True)).verdict,'ESCALATE')
 def test_source_absent(self):self.assertEqual(triage({'claim':'x','source_id':'','evidence_text':''})['flag'],'MISSING_EVIDENCE')
 def test_evidence_not_truth(self):self.assertFalse(triage({'claim':'Cats can fly','source_id':'s','evidence_text':'Cats can fly'})['verified_fact'])
 def test_packet_receipt_required(self):
  p=json.loads(Path('federation/packet_example.json').read_text());p['state']='DELIVERED'
  with self.assertRaises(ValueError):validate(p)
 def test_packet_demo(self):self.assertTrue(validate(json.loads(Path('federation/packet_example.json').read_text()))['valid'])
 def test_packet_sensitive_public_rejected(self):
  p=json.loads(Path('federation/packet_example.json').read_text());p['classification']='confidential'
  with self.assertRaises(ValueError):validate(p)
if __name__=='__main__':unittest.main()
