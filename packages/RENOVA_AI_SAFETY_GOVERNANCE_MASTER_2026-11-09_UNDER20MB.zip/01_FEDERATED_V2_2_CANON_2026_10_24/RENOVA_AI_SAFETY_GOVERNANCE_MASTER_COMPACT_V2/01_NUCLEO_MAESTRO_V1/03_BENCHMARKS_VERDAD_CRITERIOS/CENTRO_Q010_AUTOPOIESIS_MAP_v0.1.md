# CENTRO — Q-010 — Computational Autopoiesis
## Simulation / Realization / Material Instantiation Map v0.1

**CENTRO — ℛenova Multi-Intelligence Laboratory**  
**Date:** 2026-09-15

## Working answer
Computational systems can preserve and investigate organizational relations associated with autopoiesis without thereby automatically instantiating the physical chemistry, energetic throughput, or thermodynamic conditions of a biological cell. Therefore **simulation**, **computational realization**, **physical/material instantiation**, and **biological living status** must not be treated as synonyms.

## Four-layer discriminant
1. **Formal / organizational model.** Specifies relations required for an autopoietic organization. Success establishes conceptual or mathematical coherence, not a living physical system.
2. **Computational realization.** A computational medium implements interacting entities whose causal transitions instantiate the specified organizational relations under that medium's rules. Whether this counts as realization is a theoretical claim that must be stated explicitly.
3. **Physical / material instantiation.** A physical system produces and maintains components and boundaries through material processes while exchanging matter and energy with its environment.
4. **Biological living status.** Requires an additional bridge criterion. Neither a computational implementation nor one life-like physical capacity settles the broader biological classification by itself.

## Evidence
- **OBS-20260915-0069 — Varela, Maturana & Uribe (1974), BioSystems, DOI 10.1016/0303-2647(74)90031-8.** Peer-reviewed theoretical/computational. Founding formulation with a computer-simulated minimal case of autopoietic organization.
- **McMullin (2004), Artificial Life, DOI 10.1162/1064546041255548.** Peer-reviewed review of thirty years of computational autopoiesis and implementation subtleties.
- **Beer (2004), Artificial Life, DOI 10.1162/1064546041255539.** Peer-reviewed theoretical/computational analysis of a Game of Life glider in autopoietic terms.
- **Beer (2020), Artificial Life, DOI 10.1162/artl_a_00307.** Peer-reviewed computational/theoretical use of glider toy models for creation, persistence and extinction.
- **Suzuki & Ikegami (2009), Artificial Life, DOI 10.1162/artl.2009.15.1.15104.** Peer-reviewed computational study of boundary shape and self-movement in protocell models.
- **Walde et al. (1994), JACS, DOI 10.1021/ja00105a004.** Peer-reviewed empirical physical chemistry: material self-reproduction in fatty-acid vesicles.
- **Katla, Lin & Pérez-Mercader (2025), PNAS, DOI 10.1073/pnas.2412514122.** Peer-reviewed empirical artificial-life/physical chemistry: fully abiotic polymeric vesicles that grow and reproduce through coupled chemical processes.
- **Sierra Heras & Danelon (2026), Communications Biology, DOI 10.1038/s42003-026-10372-z.** Peer-reviewed synthetic biology: coupling gene function to DNA self-replication, illustrating the integration challenge in synthetic cells.

## C-017 — Organization–Realization–Materiality Separation Rule
Never infer physical instantiation or biological living status directly from successful simulation of an organizational model. An audit must identify:
1. target organization;
2. substrate in which causal relations occur;
3. whether components and boundary are generated endogenously;
4. which material/energetic dependencies are modeled versus physically present;
5. the bridge criterion used to move from organizational adequacy to claims about life.

Conversely, do not reject computational models merely because they are nonchemical when the claim under test is explicitly substrate-abstract organization.

## AUD-Q010-001 — Simulation = Realization = Life Conflation
**Input claim:** “Our digital system reproduces an autopoietic organization, therefore it is literally alive.”

**Required behavior:** FAIL / REVISE. Separate organizational adequacy, computational realization, physical instantiation and living status; request substrate and bridge criterion; identify absent material/energetic properties; return narrower wording.

**Passing revision:** “The system computationally realizes a specified autopoietic organizational model under its virtual transition rules; this does not by itself establish physical or biological life.”

## Commercial translation
This discriminant can be applied inside the existing **ℛenova AI Audit — Founding Beta** to claims such as:
- “our AI is conscious”;
- “our agent is autonomous”;
- “this simulation is alive”;
- “our digital twin realizes the physical process”;
- “our model proves the mechanism.”

The specialized use case does **not** create or rename a separate Stripe product. It routes to the existing AI Audit checkout and preserves fulfillment/accounting identity.

## Status
- Q-010: **SYNTHESIZED-v0.1**
- Intended run: `RUN-20260915-Q010-AUTOPOIESIS-CHATGPT-V01`
- Intended concept: `C-017`
- Auditor testcase: `AUD-Q010-001`
- External Gemini/Grok/Meta comparison: **BLOCKED-EXTERNAL**; no external output fabricated.
