import copy
import json
import tempfile
import unittest
from datetime import datetime,timedelta,timezone
from pathlib import Path
import relay

def sample():
    n=datetime.now(timezone.utc)
    return dict(packet_id='FED22-TEST-0001',schema_version='2.2',created_at=n.isoformat(),expires_at=(n+timedelta(hours=4)).isoformat(),source_node='CENTRO',target_node='GEMINI',project_id=relay.PROJECT,data_classification='PUBLIC',mission='Evaluate source fidelity and falsification criteria',requested_operation='REVIEW',source_refs=['https://github.com/reyfilosofo/renova-agent'],state='PREPARED',provider_receipt_id=None,readback_verified=False)
class RelayTests(unittest.TestCase):
    def test_valid(self):self.assertEqual([],relay.validate(sample()))
    def test_missing(self):p=sample();p.pop('mission');self.assertTrue(relay.validate(p))
    def test_extra(self):p=sample();p['secret']='abc';self.assertTrue(relay.validate(p))
    def test_bad_op(self):p=sample();p['requested_operation']='DELETE_DRIVE';self.assertTrue(relay.validate(p))
    def test_source_allowlist(self):p=sample();p['source_refs']=['https://example.org/leak'];self.assertTrue(relay.validate(p))
    def test_bad_refs(self):p=sample();p['source_refs']=['file:///tmp/private'];self.assertTrue(relay.validate(p))
    def test_bad_expiry(self):p=sample();p['expires_at']=p['created_at'];self.assertTrue(relay.validate(p))
    def test_future(self):p=sample();n=datetime.now(timezone.utc)+timedelta(hours=1);p['created_at']=n.isoformat();p['expires_at']=(n+timedelta(hours=1)).isoformat();self.assertTrue(relay.validate(p))
    def test_too_long(self):p=sample();n=datetime.now(timezone.utc)+timedelta(days=3);p['expires_at']=n.isoformat();self.assertTrue(relay.validate(p))
    def test_expired(self):p=sample();n=datetime.now(timezone.utc)-timedelta(days=2);p['created_at']=n.isoformat();p['expires_at']=(n+timedelta(hours=3)).isoformat();self.assertTrue(relay.validate(p))
    def test_ack_without_receipt(self):p=sample();p['state']='ACKNOWLEDGED';self.assertTrue(relay.validate(p))
    def test_fake_prep_receipt(self):p=sample();p['provider_receipt_id']='fake';self.assertTrue(relay.validate(p))
    def test_duplicate(self):
        with tempfile.TemporaryDirectory() as t:
            with relay.ledger(Path(t)/'ledger.db') as cx:
                relay.register(cx,sample())
                with self.assertRaises(ValueError):relay.register(cx,sample())
    def test_dry_run(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'packet.json';p.write_text(json.dumps(sample()))
            self.assertEqual(0,relay.main([str(p)]))
            self.assertFalse((Path(t)/'fed22_ledger.sqlite').exists())
    def test_missing_key(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'packet.json';p.write_text(json.dumps(sample()))
            from unittest.mock import patch
            with patch.dict('os.environ',{},clear=True):
                self.assertEqual(4,relay.main([str(p),'--provider','GEMINI','--model','gemini-some-verified-model','--confirm-send','--db',str(Path(t)/'ledger.db')]))
    def test_private_block(self):
        with tempfile.TemporaryDirectory() as t:
            o=sample();o['data_classification']='CONFIDENTIAL';p=Path(t)/'packet.json';p.write_text(json.dumps(o))
            self.assertEqual(3,relay.main([str(p),'--provider','GEMINI','--model','gemini-model','--confirm-send']))
    def test_no_network_in_tests(self):
        from unittest.mock import patch
        with patch('urllib.request.build_opener') as o:
            p=sample();self.assertEqual([],relay.validate(p));o.assert_not_called()
    def test_short_id(self):p=sample();p['packet_id']='x';self.assertTrue(relay.validate(p))
    def test_wrong_project(self):p=sample();p['project_id']='OTHER';self.assertTrue(relay.validate(p))
    def test_mission_limit(self):p=sample();p['mission']='x'*9000;self.assertTrue(relay.validate(p))
    def test_not_prep_submission(self):
        with tempfile.TemporaryDirectory() as t:
            p=sample();p['state']='ACKNOWLEDGED';p['provider_receipt_id']='fake';p['readback_verified']=True
            f=Path(t)/'p.json';f.write_text(json.dumps(p))
            self.assertEqual(2,relay.main([str(f)]))
if __name__=='__main__':unittest.main()
