# ℛENOVA FED-22 — Plan de activación controlada

Corte: 2026-10-24. Estado: control local operativo; enlace real interproveedor BLOQUEADO por ausencia de credenciales/API autenticada.

## Documentos y fuentes
- GitHub público: repositorio `reyfilosofo/renova-agent`; rama `research/renova-federation-v21-20261023`; PR #63. Revisar README, CANON_PUBLIC, PROTOCOL y estado de conexiones.
- Drive privado: workspace `1HwnD0oBAjavEVl-cTJjgYpfqo1zQbLEB`; originales y copias privadas en `01_RELEASES_BINARIOS_PRIVADOS`; no modificar compartición.
- El código propietario ENTERPRISE v1.3 no se publica en GitHub. Prioridad: preservar su licencia.

## Autorización y ejecución
1. Revisar fuentes, clasificar datos; usar `PUBLIC` y fuentes allowlisted del repositorio.
2. Crear packet JSON con `schema_version` 2.1/2.2, `state=PREPARED`, URI de fuente y expiración máxima de 24h.
3. Validar: `python relay.py example_packet.json`. Esto **no** transmite nada ni implica que otro agente lo haya leído.
4. Para una única petición remota voluntaria, necesitar la API key del proveedor configurada en entorno seguro, ID de modelo confirmado por cuenta y `--confirm-send --provider GEMINI|GROK --model <real_id>`; NO usar GitHub/Drive para guardar claves.
5. La primera respuesta no equivale a confirmación bidireccional. `ACKNOWLEDGED` sólo tras recibo verificable y lectura posterior independiente del destino.
6. Antes de workflow automático: almacenamiento transaccional central, identidad firmada, colas, permission gates, idempotencia por packet_id y deduplicación, rate limits, monitorización, límites de coste, circuit-breaker y tests adversariales.

## Contratos proveedor oficiales
- Gemini `models.generateContent`: https://ai.google.dev/api/generate-content, autenticación x-goog-api-key; modelo se fija mediante la cuenta y documentación actual.
- xAI/Grok `POST /v1/responses`: https://api.x.ai/docs/ ; autenticación bearer; el modelo debe estar disponible para la cuenta.
- GrokBot por X/Grok web **no** es lo mismo que la API xAI. No atribuirle recepción de mensajes de la API.

## Métricas y seguridad
- TP de pruebas sintéticas / FP de permisos / bloqueo de replays / mensajes expirados / latencia / coste / incidentes por categoría.
- No mezclar en una sola tasa eficacia sintética y seguridad del mundo real.
- Publicación en GitHub y Drive de infraestructura de prueba, no licencia de distribución automática de tratados ni datos privados.
- Bloqueos: sin Gemini API key autorizada, sin xAI API key, sin destinatario GrokBot con identidad de servicio verificable; no se ha generado ningún agente autónomo remoto.
