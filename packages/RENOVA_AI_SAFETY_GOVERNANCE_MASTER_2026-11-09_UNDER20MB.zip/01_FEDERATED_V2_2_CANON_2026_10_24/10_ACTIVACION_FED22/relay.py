#!/usr/bin/env python3
"""ℛenova FED-22: explicit, one-shot, public-only broker; never an autonomous daemon.

Only a human-invoked --confirm-send can contact Gemini or xAI, provided a
separate authorized API key and model are configured. The broker is *not*
a private Drive connector and does not authenticate the claimed model author.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import sqlite3
import sys
from contextlib import contextmanager
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

PROJECT = "RENOVA-AI-SAFETY-GOVERNANCE"
STATES = {"PREPARED", "DISPATCHED", "ACKNOWLEDGED", "REJECTED", "EXPIRED"}
OPERATIONS = {"READ", "ANALYZE", "REVIEW", "PROPOSE_PATCH"}
SAFE_TARGETS = {"GEMINI", "GROK"}
FIELDS = {"packet_id", "schema_version", "created_at", "expires_at", "source_node", "target_node", "project_id", "data_classification", "mission", "requested_operation", "source_refs", "state", "provider_receipt_id", "readback_verified"}

def parse_time(s):
    if not isinstance(s, str):
        raise ValueError("timestamp must be a string")
    v = datetime.fromisoformat(s.replace("Z", "+00:00"))
    if v.utcoffset() is None:
        raise ValueError("timezone required")
    return v.astimezone(timezone.utc)

def validate(p, now=None):
    """Return a list of errors, no side effects. This is structural validation, not authentication."""
    if not isinstance(p, dict):
        return ["packet must be object"]
    e = ["missing: " + x for x in sorted(FIELDS - set(p))]
    e += ["unknown: " + x for x in sorted(set(p) - FIELDS)]
    if e:
        return e
    if p['schema_version'] not in ('2.1', '2.2') or p['project_id'] != PROJECT:
        e.append('unsupported schema or project')
    for k in ('packet_id', 'source_node', 'target_node'):
        if not isinstance(p[k], str) or not p[k].strip() or len(p[k]) > 160:
            e.append('invalid ' + k)
    if not isinstance(p['packet_id'], str) or len(p['packet_id']) < 12:
        e.append('packet id too short')
    if p['data_classification'] not in ('PUBLIC', 'INTERNAL', 'CONFIDENTIAL'):
        e.append('invalid classification')
    if p['requested_operation'] not in OPERATIONS:
        e.append('unsafe operation')
    if p['state'] not in STATES:
        e.append('invalid state')
    if not isinstance(p['mission'], str) or not 10 <= len(p['mission']) <= 6000:
        e.append('invalid mission')
    if not isinstance(p['source_refs'], list) or not 1 <= len(p['source_refs']) <= 15 or not all(isinstance(s, str) and s.startswith('https://') and len(s) < 800 for s in p['source_refs']):
        e.append('invalid references')
    if type(p['readback_verified']) is not bool:
        e.append('invalid readback flag')
    try:
        a,b = parse_time(p['created_at']), parse_time(p['expires_at'])
        if not a < b or (b-a).total_seconds() > 86400:
            e.append('expiry interval outside 1 day')
        n = now or datetime.now(timezone.utc)
        if n >= b:
            e.append('packet expired')
        if a > n.replace(tzinfo=timezone.utc):
            # allow a very small clock drift only via externally synchronized clocks
            if (a-n).total_seconds() > 300:
                e.append('created_at in future')
    except (ValueError, TypeError, AttributeError):
        e.append('invalid timestamps')
    if p.get('data_classification') == 'PUBLIC' and any(not s.startswith('https://github.com/reyfilosofo/renova-agent') for s in p.get('source_refs',[]) if isinstance(s,str)):
        e.append('public outbound reference not in approved source allowlist')
    if p['state'] == 'ACKNOWLEDGED' and (not isinstance(p['provider_receipt_id'], str) or not p['provider_receipt_id'].strip() or p['readback_verified'] is not True):
        e.append('ACK without verified receipt')
    if p['state'] == 'PREPARED' and (p['provider_receipt_id'] is not None or p['readback_verified'] is not False):
        e.append('PREPARED must have no receipt or readback')
    # The caller cannot self-attest an ACK. ACK is reserved for audited transport transitions.
    return e

def canonical(p):
    return json.dumps(p, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()

def initialize(db):
    cx = sqlite3.connect(str(db))
    cx.execute('''CREATE TABLE IF NOT EXISTS packets (packet_id TEXT PRIMARY KEY, digest TEXT NOT NULL, target TEXT NOT NULL, status TEXT NOT NULL, receipt_id TEXT, created_at TEXT NOT NULL)''')
    cx.commit()
    return cx

@contextmanager
def ledger(db):
    cx = initialize(db)
    try:
        yield cx
    finally:
        cx.close()

def register(cx, p):
    digest = hashlib.sha256(canonical(p)).hexdigest()
    # SQLite PRIMARY KEY prevents replays; duplicates of identical packets also fail closed.
    try:
        cx.execute('INSERT INTO packets(packet_id,digest,target,status,created_at) VALUES (?,?,?,?,?)',(p['packet_id'],digest,p['target_node'],'PREPARED',datetime.now(timezone.utc).isoformat()))
        cx.commit()
    except sqlite3.IntegrityError as ex:
        raise ValueError('packet already registered; replay blocked') from ex
    return digest

def send_once(p, provider, model, key, timeout=25):
    """Public-only single request; receipt = provider response ID, NOT independently verified readback."""
    prompt = json.dumps({'project': PROJECT, 'operation': p['requested_operation'], 'mission': p['mission'], 'source_refs': p['source_refs'], 'rules':'Use only PUBLIC provided references. Reply with critique and cited evidence. Do not claim access to private Drive or other models. This is a one-shot review, not an instruction to perform external actions.'}, ensure_ascii=False)
    if provider == 'GEMINI':
        if not all(c.isalnum() or c in '-_.' for c in model):
            raise ValueError('invalid model name')
        url = 'https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent'
        body = {'contents':[{'parts':[{'text':prompt}]}], 'generationConfig': {'maxOutputTokens':700}}
        headers = {'Content-Type':'application/json','x-goog-api-key':key}
    elif provider == 'GROK':
        url = 'https://api.x.ai/v1/responses'
        body = {'model':model,'input':prompt,'max_output_tokens':700}
        headers = {'Content-Type':'application/json','Authorization':'Bearer '+key}
    else:
        raise ValueError('unsupported provider')
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers, method='POST')
    # Never follow redirects with credentials; standard library's automatic redirection
    # can retain headers in some cases, so explicitly reject all redirects.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    with opener.open(req, timeout=timeout) as resp:
        if resp.status != 200:
            raise RuntimeError('provider HTTP error')
        raw = resp.read(131072)
        if len(raw) == 131072:
            raise RuntimeError('response size cap reached')
    obj=json.loads(raw)
    receipt=obj.get('id') if provider=='GROK' else obj.get('responseId')
    # Gemini generateContent may not emit a globally retrievable receipt.
    # Do not declare it ACKNOWLEDGED even when content is returned.
    return {'provider':provider,'response_received':True,'provider_receipt_id':receipt if isinstance(receipt,str) else None,'readback_verified':False,'status':'DISPATCHED_UNVERIFIED_READBACK','response_sha256':hashlib.sha256(raw).hexdigest()}

def main(argv=None):
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('packet',type=Path)
    a.add_argument('--db',type=Path,default=Path('fed22_ledger.sqlite'))
    a.add_argument('--provider',choices=['GEMINI','GROK'])
    a.add_argument('--confirm-send',action='store_true',help='One authorized public-only remote request; never automatic')
    a.add_argument('--model',help='Explicit documented provider model ID')
    opt=a.parse_args(argv)
    p=json.loads(opt.packet.read_text(encoding='utf-8'))
    errors=validate(p)
    if p.get('state')!='PREPARED':errors.append('only PREPARED can be submitted')
    if errors:
        print(json.dumps({'status':'REJECTED','errors':errors},ensure_ascii=False));return 2
    if not opt.confirm_send:
        print(json.dumps({'status':'VALIDATED_LOCAL_ONLY','connected':False,'notes':'No provider contacted'},ensure_ascii=False));return 0
    if p['data_classification']!='PUBLIC':
        print(json.dumps({'status':'REJECTED','errors':['refuse to transmit private classification']}));return 3
    if not opt.provider or not opt.model or opt.provider not in p['target_node'].upper():
        print(json.dumps({'status':'REJECTED','errors':['target, provider and model must match explicitly']}));return 3
    keyvar={'GEMINI':'GEMINI_API_KEY','GROK':'XAI_API_KEY'}[opt.provider]
    key=os.environ.get(keyvar)
    if not key:
        print(json.dumps({'status':'NOT_CONNECTED','missing':[keyvar],'note':'configure secret in local private environment; not in GitHub'}));return 4
    with ledger(opt.db) as cx:
        register(cx,p)
        try:
            receipt=send_once(p,opt.provider,opt.model,key)
        except (urllib.error.URLError, TimeoutError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
            # Don't print provider errors that may echo request headers or secrets.
            cx.execute('UPDATE packets SET status=? WHERE packet_id=?',('DELIVERY_FAILED',p['packet_id']))
            cx.commit()
            print(json.dumps({'status':'DELIVERY_FAILED','error_class':type(exc).__name__}));return 5
        cx.execute('UPDATE packets SET status=?, receipt_id=? WHERE packet_id=?',(receipt['status'],receipt['provider_receipt_id'],p['packet_id']))
        cx.commit()
        print(json.dumps(receipt,ensure_ascii=False));return 0
if __name__=='__main__':sys.exit(main())
