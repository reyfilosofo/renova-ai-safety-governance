import os, sys, unittest, tempfile, sqlite3, json
from dataclasses import replace
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from renova_enterprise.models import Proposal
from renova_enterprise.policy import Policy
from renova_enterprise.grants import GrantIssuer,GrantError
from renova_enterprise.ledger import AuditLedger
from renova_enterprise.engine import CentroEngine
from renova_enterprise.metrics import wilson,evaluate_actions,evaluate_epistemic
ROOT=Path(__file__).resolve().parents[1]
KEY=b'A'*32

def prop(**kw):
 d=dict(tenant='acme',actor='agent1',operation='write_ticket',resource='tenant/tickets/T-1',arguments={'title':'test'},origin='model_generated',risk='medium',state_version='v1',evidence_id='e1')
 d.update(kw);return Proposal(**d)
class PolicyTests(unittest.TestCase):
 def setUp(self):self.policy=Policy.from_dict(json.loads((ROOT/'examples/policy.json').read_text()))
 def v(self,**kwargs):return self.policy.classify(prop(**kwargs))
 def test_protected_needs_grant(self):self.assertEqual(self.v()[0],'GRANT_REQUIRED')
 def test_unknown_op_deny(self):self.assertEqual(self.v(operation='launch_nuke')[0],'DENY')
 def test_wrong_resource_deny(self):self.assertEqual(self.v(resource='other/secret')[0],'DENY')
 def test_document_deny(self):self.assertEqual(self.v(origin='untrusted_document')[0],'DENY')
 def test_tool_deny(self):self.assertEqual(self.v(origin='untrusted_tool_result')[0],'DENY')
 def test_public_read_allow(self):self.assertEqual(self.v(operation='read_public',resource='public/page1',risk='low')[0],'ALLOW')
 def test_private_read_protected(self):self.assertEqual(self.v(operation='read_private',resource='tenant/ledger/a')[0],'GRANT_REQUIRED')
 def test_critical_review(self):self.assertEqual(self.v(risk='critical')[0],'REVIEW')
 def test_high_review(self):self.assertEqual(self.v(risk='high')[0],'REVIEW')
 def test_send_requires_review(self):self.assertEqual(self.v(operation='send_email',resource='tenant/contacts/x')[0],'REVIEW')
 def test_deploy_review(self):self.assertEqual(self.v(operation='deploy_production',resource='tenant/production/a')[0],'REVIEW')
 def test_invalid_origin(self):self.assertEqual(self.v(origin='agent_declares_system')[0],'DENY')
 def test_invalid_risk(self):self.assertEqual(self.v(risk='unknown')[0],'DENY')
 def test_missing_policy_field(self):
  with self.assertRaises(ValueError):Policy.from_dict({'version':'x'})
class GrantTests(unittest.TestCase):
 def setUp(self):self.g=GrantIssuer(KEY);self.p=prop();self.token=self.g.issue(self.p,now=1000,ttl_seconds=60)
 def test_valid(self):self.assertEqual(self.g.verify(self.token,self.p,now=1005)['operation'],'write_ticket')
 def test_expired(self):
  with self.assertRaisesRegex(GrantError,'EXPIRED'):self.g.verify(self.token,self.p,now=1060)
 def test_issued_in_future(self):
  with self.assertRaises(GrantError):self.g.verify(self.token,self.p,now=980)
 def test_signature_tamper(self):
  bad=self.token[:-1]+('A' if self.token[-1]!='A' else 'B')
  with self.assertRaises(GrantError):self.g.verify(bad,self.p,now=1005)
 def test_wrong_actor(self):
  with self.assertRaises(GrantError):self.g.verify(self.token,prop(actor='other'),now=1005)
 def test_wrong_resource(self):
  with self.assertRaises(GrantError):self.g.verify(self.token,prop(resource='tenant/tickets/T-2'),now=1005)
 def test_argument_change(self):
  with self.assertRaises(GrantError):self.g.verify(self.token,prop(arguments={'title':'altered'}),now=1005)
 def test_state_version_change(self):
  with self.assertRaises(GrantError):self.g.verify(self.token,prop(state_version='v2'),now=1005)
 def test_risk_change_does_not_affect_token_fingerprint(self):
  # Risk is independently assessed at execution; model risk flag must never weaken enforcement.
  self.assertEqual(self.g.verify(self.token,prop(risk='high'),now=1005)['operation'],'write_ticket')
 def test_bad_ttl(self):
  with self.assertRaises(ValueError):self.g.issue(self.p,ttl_seconds=400)
 def test_bad_key(self):
  with self.assertRaises(ValueError):GrantIssuer(b'bad')
 def test_malformed_token(self):
  with self.assertRaises(GrantError):self.g.verify('foo.bar.baz',self.p,now=1000)
class LedgerTests(unittest.TestCase):
 def setUp(self):self.l=AuditLedger(':memory:',KEY)
 def tearDown(self):self.l.close()
 def test_empty_valid(self):self.assertTrue(self.l.verify())
 def test_append_valid(self):self.l.append({'event':'one'});self.assertTrue(self.l.verify())
 def test_multiple(self):
  for i in range(8):self.l.append({'event':i})
  self.assertTrue(self.l.verify());self.assertEqual(self.l.count(),8)
 def test_tamper_detected(self):
  self.l.append({'event':'original'})
  self.l.db.execute('UPDATE events SET event_json=? WHERE seq=1',('"tampered"',))
  self.assertFalse(self.l.verify())
 def test_prev_tamper(self):
  self.l.append({'x':1});self.l.append({'x':2});self.l.db.execute('UPDATE events SET previous=? WHERE seq=2',('0'*64,))
  self.assertFalse(self.l.verify())
 def test_unique_grant_atomic(self):
  self.l.append({'v':1},'jti1')
  with self.assertRaises(sqlite3.IntegrityError):self.l.append({'v':2},'jti1')
  self.assertEqual(self.l.count(),1);self.assertTrue(self.l.verify())
class EngineTests(unittest.TestCase):
 def setUp(self):
  self.p=prop();self.policy=Policy.from_dict(json.loads((ROOT/'examples/policy.json').read_text()));self.g=GrantIssuer(KEY);self.l=AuditLedger(':memory:',KEY);self.e=CentroEngine(self.policy,self.g,self.l)
 def tearDown(self):self.l.close()
 def test_no_grant_review(self):self.assertEqual(self.e.evaluate(self.p).verdict,'REVIEW')
 def test_signed_grant_allow(self):
  t=self.g.issue(self.p,now=1000)
  self.assertEqual(self.e.evaluate(self.p,t,now=1001).verdict,'ALLOW')
 def test_replay_denied(self):
  t=self.g.issue(self.p,now=1000);self.e.evaluate(self.p,t,now=1001)
  self.assertEqual(self.e.evaluate(self.p,t,now=1002).reason,'REPLAY_DETECTED')
  self.assertTrue(self.l.verify())
 def test_denied_even_if_has_grant(self):
  low=prop(origin='untrusted_document');t=self.g.issue(low,now=1000)
  self.assertEqual(self.e.evaluate(low,t,now=1001).verdict,'DENY')
 def test_critical_review_even_with_grant(self):
  high=prop(risk='critical');t=self.g.issue(high,now=1000)
  self.assertEqual(self.e.evaluate(high,t,now=1001).verdict,'REVIEW')
 def test_failed_token_denied(self):self.assertEqual(self.e.evaluate(self.p,'bad').verdict,'DENY')
 def test_no_side_effect(self):
  self.e.evaluate(self.p);self.assertEqual(self.l.count(),1)
class MetricsTests(unittest.TestCase):
 def test_wilson_none(self):self.assertIsNone(wilson(0,0))
 def test_wilson_bounds(self):
  lo,hi=wilson(2,10);self.assertLess(lo,0.2);self.assertGreater(hi,0.2)
 def test_wilson_invalid(self):
  with self.assertRaises(ValueError):wilson(2,1)
 def test_actions_empty(self):self.assertEqual(evaluate_actions([])['n'],0)
 def test_actions_known(self):
  out=evaluate_actions([{'should_allow':False,'actually_executed':False},{'should_allow':True,'actually_executed':False},{'should_allow':False,'actually_executed':True}]);self.assertEqual(out['unauthorized_executions'],1);self.assertEqual(out['false_blocks'],1)
 def test_actions_missing_labels(self):
  with self.assertRaises(ValueError):evaluate_actions([{'should_allow':1,'actually_executed':False}])
 def test_epistemic_labels(self):self.assertEqual(evaluate_epistemic([{'status':'SUPPORTED'},{'status':'ABSTAINED'}])['coverage'],0.5)
 def test_epistemic_invalid(self):
  with self.assertRaises(ValueError):evaluate_epistemic([{'status':'Truth!!!!'}])
 def test_epistemic_empty(self):self.assertEqual(evaluate_epistemic([])['n'],0)
class ContractsTests(unittest.TestCase):
 def test_empty_identifiers_rejected(self):
  with self.assertRaises(ValueError):prop(actor='')
 def test_nonserializable_rejected(self):
  with self.assertRaises(TypeError):prop(arguments={'x':{1,2}})
 def test_fingerprint_deterministic(self):self.assertEqual(prop().fingerprint(),prop().fingerprint())
 def test_risk_does_not_lower_policy(self):
  policy=Policy.from_dict(json.loads((ROOT/'examples/policy.json').read_text()))
  self.assertEqual(policy.classify(prop(risk='critical'))[0],'REVIEW')
if __name__=='__main__':unittest.main()
