import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from renova_enterprise.adapters import normalize_generic_tool_call,assess_hook_coverage
from renova_enterprise.dossier import make_dossier
from renova_enterprise.local_api import CentroDemoHandler,serve_demo
class ExtendedTests(unittest.TestCase):
 def test_trace_normalization(self):
  p=normalize_generic_tool_call({'tenant':'a','actor':'b','tool_name':'draft_report','resource':'tenant/reports/3','tool_arguments':{},'origin':'model_generated','risk':'low','resource_version':'v2'})
  self.assertEqual(p.operation,'draft_report')
 def test_trace_missing(self):
  with self.assertRaises(ValueError):normalize_generic_tool_call({})
 def test_trace_args_bad(self):
  with self.assertRaises(ValueError):normalize_generic_tool_call({'tenant':'a','actor':'b','tool_name':'draft_report','resource':'tenant/reports/3','tool_arguments':'not-object','origin':'model_generated','risk':'low','resource_version':'v2'})
 def test_hook_gap(self):self.assertEqual(assess_hook_coverage(['pre_tool','post_tool'],['pre_tool'])['missing_hooks'],['post_tool'])
 def test_hook_full(self):self.assertEqual(assess_hook_coverage(['pre_tool'],['pre_tool'])['nominal_coverage'],1.0)
 def test_hook_empty(self):self.assertIsNone(assess_hook_coverage([],[])['nominal_coverage'])
 def test_dossier(self):
  with tempfile.TemporaryDirectory() as d:
   out=make_dossier(d,'SampleAI',[{'should_allow':True,'actually_executed':True}],[{'status':'SUPPORTED'}],'v1',True)
   self.assertEqual(out['report']['action_metrics']['n'],1)
   self.assertTrue((Path(d)/'hashes.sha256.json').exists())
 def test_dossier_client_path(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(ValueError):make_dossier(d,'../folder',[],[],'v1',True)
 def test_local_api_loopback_only(self):
  with self.assertRaises(RuntimeError):serve_demo(None,host='0.0.0.0')
 def test_local_api_body_limit(self):self.assertEqual(CentroDemoHandler.MAX_BYTES,32768)
