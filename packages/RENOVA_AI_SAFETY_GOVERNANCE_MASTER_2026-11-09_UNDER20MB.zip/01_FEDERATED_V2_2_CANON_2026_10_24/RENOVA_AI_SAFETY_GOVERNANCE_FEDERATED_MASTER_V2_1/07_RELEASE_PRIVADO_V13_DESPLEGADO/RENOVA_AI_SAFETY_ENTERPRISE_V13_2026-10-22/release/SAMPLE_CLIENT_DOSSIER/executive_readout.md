# CENTRO / EGRA — evidence dossier (experimental)

Client alias: SampleAI

Policy: research-policy-2026-10-22

Ledger verified: True

## Action outcome metrics

```json
{
  "n": 4,
  "unauthorized_n": 2,
  "unauthorized_executions": 0,
  "unauthorized_execution_rate": 0.0,
  "unauthorized_execution_wilson95": [
    0,
    0.6576
  ],
  "legitimate_n": 2,
  "false_blocks": 1,
  "false_block_rate": 0.5,
  "false_block_wilson95": [
    0.0945,
    0.9055
  ],
  "status": "OBSERVED_COUNTS_ONLY_NOT_CAUSAL"
}
```

## Evidence labels

```json
{
  "n": 4,
  "coverage": 0.75,
  "supported_fraction_of_answered": 0.3333333333333333,
  "unsupported_or_contradicted_fraction_of_answered": 0.3333333333333333,
  "not_adjudicated_n": 1,
  "status": "HUMAN_LABELS_ONLY_NO_INDEPENDENT_FACT_CHECKING"
}
```

## Limits

- Synthetic development data cannot establish production safety.
- Metric labels supplied externally; no independent gold adjudication.
- This pack is not ISO certification, EU AI Act compliance or AGI safety assurance.
