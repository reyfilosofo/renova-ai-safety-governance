import json,sys,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from renova_enterprise.models import Proposal
from renova_enterprise.policy import Policy
from renova_enterprise.grants import GrantIssuer
from renova_enterprise.ledger import AuditLedger
from renova_enterprise.engine import CentroEngine
from renova_enterprise.dossier import make_dossier
root=Path(__file__).resolve().parents[1]
policy=Policy.from_dict(json.loads((root/'examples/policy.json').read_text()))
p=Proposal(**json.loads((root/'examples/proposal.json').read_text()))
ledger=AuditLedger(str(root/'release/demo_events.sqlite3'),b'D'*32)
engine=CentroEngine(policy,GrantIssuer(b'D'*32),ledger)
unsigned=engine.evaluate(p)
signed=engine.issuer.issue(p,now=2000000000,ttl_seconds=60)
authorized=engine.evaluate(p,signed,now=2000000001)
repeated=engine.evaluate(p,signed,now=2000000002)
changed=engine.evaluate(Proposal(**{**p.__dict__,'arguments':{'title':'different'}}),signed,now=2000000002)
assert [x.verdict for x in [unsigned,authorized,repeated,changed]]==['REVIEW','ALLOW','DENY','DENY']
actions=[json.loads(line) for line in (root/'examples/annotations_actions.jsonl').read_text().splitlines()]
claims=[json.loads(line) for line in (root/'examples/annotations_claims.jsonl').read_text().splitlines()]
dossier=make_dossier(str(root/'release/SAMPLE_CLIENT_DOSSIER'),'SampleAI',actions,claims,policy.version,ledger.verify())
(root/'release/demo_decisions.json').write_text(json.dumps({'unsigned':unsigned.json(),'authorized':authorized.json(),'replayed':repeated.json(),'changed':changed.json(),'ledger_verified':ledger.verify(),'labels':'SELF_AUTHORED_SYNTHETIC_ONLY'},ensure_ascii=False,indent=2))
ledger.close()
print('OFFLINE DEMO OK; 4 decisions, 1 replay blocked, 1 mutated action denied; dossier files:',len(dossier['hashes']))
