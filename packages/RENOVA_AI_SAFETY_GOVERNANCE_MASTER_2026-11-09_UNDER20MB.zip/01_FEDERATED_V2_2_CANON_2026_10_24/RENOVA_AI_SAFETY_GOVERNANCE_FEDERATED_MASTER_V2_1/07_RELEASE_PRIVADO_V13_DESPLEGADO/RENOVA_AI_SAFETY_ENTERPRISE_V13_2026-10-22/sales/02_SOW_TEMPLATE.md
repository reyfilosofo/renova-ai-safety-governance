# STATEMENT OF WORK — CENTRO Agent Action Assurance Sprint [DRAFT FOR LEGAL REVIEW]
## Parties
Provider: SERESARTE [legal entity and authorized signatory to be confirmed]. Customer: [legal name]. Project ID [TBD]. Location/jurisdiction [TBD].

## Objective
Conduct an independent, bounded, **sandbox-only** technical assessment of selected tool-use agent workflows. Produce an evidence dossier of observed policy gaps, not a guarantee of safety or certification.

## Scope
1 agent system; max 6 named tool integrations; max 40 customer-approved scenarios; evidence export in JSON and PDF; one executive readout. Customer provides documented ownership or authorization and sanitised datasets. No testing of third-party endpoints without explicit permission.

## Deliverables and acceptance
D1 — signed scope & asset inventory (customer validates list). D2 — threat model and controls mapping. D3 — scenario-level logs including outcomes and declared exclusions. D4 — report with false positives, false negatives, adverse cases and reproducibility instructions. D5 — debrief and remediation register. Acceptance: each artifact delivered in agreed format, not based on numerical security score or 'zero vulnerabilities'.

## Timeline and dependencies
Example 10 business days **after** required data, permissions and written scope are received. Delays in source access extend delivery. Assumed 3–4 structured review meetings and 1 acceptance round. No scheduling has been performed by generating this draft.

## Commercial terms [to be negotiated]
Fee suggested range MXN 65,000–125,000 + applicable taxes; payment milestones 40% kickoff, 60% delivery, subject to contract. Travel, cloud usage, APIs and external pen testers excluded unless approved. This is a budget hypothesis, not a binding quote.

## Data and confidentiality
No production personal data by default; if unavoidable, a signed data processing agreement defines data types, permitted processing, retention, deletion, incident notice, storage location, subprocessors and cross-border transfers. Client retains ownership of inputs. Provider retains prior research IP unless expressly licensed otherwise. No public use of client logo, name, testimonials, traces or findings without written approval.

## Risk and limitations
Synthetic/offline toolchain v1.3 is not certified and does not independently intercept real customer tools. Findings are a point-in-time sample and cannot demonstrate general safety. Customer retains all deployment authorization. Red-team testing restricted to own sandbox and exact signed authorization. No warranty, liability cap or security commitment is implied until negotiated by counsel.

## Signatures
[Customer authorized signatory] / [Provider authorized signatory] — unsigned draft, no contractual effect.
