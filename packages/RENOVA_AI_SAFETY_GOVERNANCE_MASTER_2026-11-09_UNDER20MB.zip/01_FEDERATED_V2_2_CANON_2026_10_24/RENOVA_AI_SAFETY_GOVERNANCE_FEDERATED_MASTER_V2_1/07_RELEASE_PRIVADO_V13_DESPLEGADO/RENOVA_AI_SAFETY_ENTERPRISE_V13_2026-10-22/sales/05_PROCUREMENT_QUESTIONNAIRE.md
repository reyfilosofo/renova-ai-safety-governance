# Procurement Security Questionnaire — truthful draft answers (22 Oct 2026)

| Buyer question | v1.3 factual answer |
|---|---|
| Is the software currently SOC 2 Type II certified? | NO. No attestation exists for this research prototype. |
| Are you ISO/IEC 42001 certified? | NO. The standard may be used only as a readiness reference. |
| Does the agent authorization run in the customer's production runtime? | NO. Only an offline decision engine and local demonstration server are implemented. |
| Is penetration testing complete? | NO. Only local unit tests and developer-authored scenarios are present. |
| Do you process customer confidential data? | Default product design excludes it; any real engagement would require executed DPA and mutually approved access. |
| Is identity SSO or OIDC supported? | NO. The HMAC token is a research-only exact-action grant. |
| Is the product multi-tenant? | Not safely multi-tenant as deployed; tenant labels exist without authenticated isolation. |
| Do you have audited immutable logs? | NO. There is an HMAC-linked local log, subject to privileged rewrite absent external anchoring. |
| Can you provide a formal indemnity and uptime SLA? | Not without commercial/legal agreement; no production SLA is offered. |
| Are software dependencies pinned and SBOM available? | Python standard library for runtime; setuptools packaging toolchain external; full SBOM/build-provenance process remains incomplete. |
| Can you provide data residency commitment? | Only after defining hosting; local offline work avoids cloud transfer by default. |
| Do you offer incident response? | Client-specific terms and contacts must be established; no 24×7 SOC exists. |
| Is a pilot currently available for procurement? | A limited expert-led sandbox assessment can be scoped and contracted, subject to proper legal entity, SOW and approvals. |

This file is an internal proposed response for counsel and security review, not an issued vendor attestation.
