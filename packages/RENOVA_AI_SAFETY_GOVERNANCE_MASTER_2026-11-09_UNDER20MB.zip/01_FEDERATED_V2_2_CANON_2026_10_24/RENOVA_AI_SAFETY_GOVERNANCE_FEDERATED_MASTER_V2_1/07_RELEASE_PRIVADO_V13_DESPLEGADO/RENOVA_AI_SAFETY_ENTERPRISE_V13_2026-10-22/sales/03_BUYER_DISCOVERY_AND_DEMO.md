# B2B buyer discovery and proof-of-value demo

## 15-minute discovery questions
- Which agents can write, send, deploy, change permissions, refund, transfer or delete?
- What trusted component verifies user identity and exact authorization independently of the model?
- Can you prove all tool calls are intercepted, including subagents and MCP tools?
- What logs show attempted vs **executed** state-changing operations?
- What is the incident escalation and rollback responsibility?
- Do you have a baseline of legitimate tasks blocked vs unauthorized actions executed?
- Which jurisdiction, customer contract, sector requirements and data residency apply?
- How many agent families/tenants/users are in scope?
- What objective would justify the pilot cost without assuming new software efficacy?

## 20-minute runnable demo — offline sample only
1. `pip install -e .` and run 62 unit tests.
2. Show `examples/proposal.json` (synthetic ticket action) and an unsigned REVIEW.
3. Trusted human/operator issues a 60-second action-bound grant; observe ALLOW once.
4. Replay the grant, mutate arguments, change resource; observe deny.
5. Show `ledger.verify()`, then tamper DB in a disposable sandbox and demonstrate detection.
6. Open supplied `annotations_actions.jsonl`; show Wilson CIs and false blocks.
7. Generate a dossier with hashes, explain what is evidence vs an unproven assumption.

**Never demo on a customer's production account or imply third-party certification.**

## Qualification rubric
Qualified if buyer: owns/controls an agent sandbox, can share sanitized logs, assigns accountable CISO or AI engineer, accepts predefined scope, can judge value of an evidence dossier, and has procurement authority. Disqualify if seeking an AGI-safety guarantee, production protection in v1.3, or unauthorized penetration of vendors.

## Potential channels
AI engineering boutiques (white-label methodology subject to licensing), SecOps consulting partners, innovation teams, model providers' eval groups, insurance/safety assessment firms and regulated-enterprise AI governance teams.

## Proposed validation milestone
Before promoting SaaS: conduct 5–10 non-promissory buyer interviews and at least two paid sandbox pilots with anonymized reproducibility evidence. These are **future objectives** and no interviews, contracts or payments are claimed here.
