# ℛENOVA | Enterprise AI Assurance — B2B offering v1.3 (2026-10-22)

**What can legitimately be sold now?** A bounded engineering **assessment, offline pilot or workshop**, performed with a customer's authorization and evidence. Not a software subscription claiming to protect live agents until the runtime is independently hardened and supported.

## Product A — CENTRO Agent Action Assurance Sprint
**Buyer:** CTO / CISO / Head of AI Platform / AI Security Lead. **Problem:** agents take actions on email, code, ERP, CRM or tooling with overly broad delegation, incomplete authorizations and weak audit receipts.
**Scope:** 1 agent; <=6 tools; <=40 agreed safe/unsafe scenarios; limited 1 sandbox; 10 business days. **Outputs:** inventory of agent actions and existing controls, authorization matrix, red-team scenarios (authorized sandbox only), offline traces scored, false-block / unauthorized-action observations, prioritized mitigations, executive evidence report, remediation workshop. **Success measured:** number of critical tool paths inspected, evidence completeness and reproducible detection of *synthetic* policy violations; no claim of fully preventing attacks. **Fee hypothesis:** MXN 65,000–125,000 plus tax; quotation after discovery. **Payment gating:** mutually approved SOW and data protection terms; no guarantee of certification.

## Product B — LUCEM Evidence Integrity Evaluation
**Buyer:** Applied AI lead, Trust & Safety, RAG engineering teams, knowledge-intensive software vendors. **Problem:** unsupported model claims, mismatched citations and bad abstention in customer-facing applications.
**Scope:** 100–300 claim annotations, <=2 customer-approved corpora, 2 configurations, double-review sample; 10–15 business days. **Outputs:** claim dataset protocol, annotation rubric, evaluator agreement, paired metrics at matched coverage, failure taxonomy, sampled discrepancy report, reproducible dashboard exports and mitigation backlog. **Fee hypothesis:** MXN 50,000–115,000 plus tax. **Limitation:** v1.3 computes metrics from provided labels; manual adjudication and source verification must be contracted and performed separately. No automated truth detector is delivered.

## Product C — EGRA Independent Agent Evaluation Lab
**Buyer:** AI model integrators, scale-ups, model providers' external evaluation teams. **Problem:** unknown effect of epistemic checking and authorization controls on *actual* agent success/failure.
**Scope:** 4-arm factorial study, 1 sandbox, 1 agent stack, preregistered metrics, held-out examples after data protocol approved, 4–6 weeks. **Outputs:** threat model, preregistration, execution harness design, control-comparator design, effect estimates (if study executed), CIs, false positives/negatives, repeatable notebooks/scripts, limitations. **Fee hypothesis:** MXN 160,000–340,000 plus tax. **Limit:** full empirical study not included in v1.3 software by default; its performance claims depend on executing and agreeing the test plan.

## Product D — NOUS AI Governance Evidence Room
**Buyer:** VP Compliance, Risk officer, Audit lead, Procurement AI Governance. **Problem:** fragmented AI policies, unclear accountable owners and absent evidence for controls.
**Scope:** AI-system inventory up to five systems, 2–3 weeks, 6 stakeholder interviews max, evidence mapping against official standard references. **Outputs:** gap register, control owner map, risk acceptance register, governance evidence index, board/exec-ready action plan. **Fee hypothesis:** MXN 85,000–165,000 plus tax. **Not provided:** ISO certificate, regulatory opinion, legal sign-off or qualified conformity assessment.

## Product E — CENTRO Developer Sandbox License (candidate; not sale-ready as live control)
Prototype evaluation license for isolated development and vendor feedback only. Production license, support SLA, indemnities, external pen test, authenticated gateway and architecture isolation must be completed first. Price **not offered** before hardening.

## Product F — Edu-Zōḗ Human-AI Agency Workshop
**Buyer:** AI product education, responsible AI enablement, enterprise learning teams. 2×90 min sessions, decision handoff drills and unaided task-transfer exercises; MXN 35,000–60,000 plus tax exploratory quote. Does not claim proven cognitive improvement; subject to non-clinical training scope. Formal human-participant efficacy study requires ethics review.

### Pricing integrity
All figures above are **internally proposed negotiation ranges**, not observed market price, paid customer, official tariff or verified demand. They assume delivery by an expert-led small team and client-provided sanitized data. Modify after time-and-material cost model, legal and tax review, buyer discovery, and paid pilot evidence.

### Why these products are realistically purchasable
They solve bounded work that a team can commission today: independent tests and documentation of its existing agent workflow. They avoid unsupported product claims that an unvalidated prototype prevents real-world AGI catastrophes.
