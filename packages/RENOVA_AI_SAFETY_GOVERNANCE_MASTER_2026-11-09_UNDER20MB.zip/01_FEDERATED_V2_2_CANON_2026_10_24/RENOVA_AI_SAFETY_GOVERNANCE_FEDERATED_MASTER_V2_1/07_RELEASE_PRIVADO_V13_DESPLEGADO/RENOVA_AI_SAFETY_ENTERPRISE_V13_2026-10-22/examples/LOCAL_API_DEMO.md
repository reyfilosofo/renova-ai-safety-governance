# Localhost-only demo API commands

From repo root (all synthetic data):

```bash
export PYTHONPATH=src
export CENTRO_DEMO_SIGNING_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export CENTRO_DEMO_API_KEY="$(python -c 'import secrets; print(secrets.token_urlsafe(36))')"
python -m renova_enterprise.cli serve-demo --policy examples/policy.json --ledger centro-demo.sqlite3
```

In a separate local terminal (same `CENTRO_DEMO_API_KEY` environment):

```bash
python - <<'PY'
import json
p=json.load(open('examples/proposal.json'))
json.dump({'proposal':p},open('/tmp/centro-demo-request.json','w'))
PY
curl --fail-with-body -X POST http://127.0.0.1:8787/v1/evaluate \
  -H "Authorization: Bearer $CENTRO_DEMO_API_KEY" \
  -H 'Content-Type: application/json' \
  --data-binary @/tmp/centro-demo-request.json
```

Expected: REVIEW, NO_SIGNED_GRANT. This result is not a formal business approval. There is intentionally no token-issuance HTTP endpoint. `CENTRO_TRUSTED_OPERATOR=yes` in the CLI is a demonstration safeguard and **must not** be mistaken for actual human authentication.

**Never deploy or expose this process on internet or production networks.**
