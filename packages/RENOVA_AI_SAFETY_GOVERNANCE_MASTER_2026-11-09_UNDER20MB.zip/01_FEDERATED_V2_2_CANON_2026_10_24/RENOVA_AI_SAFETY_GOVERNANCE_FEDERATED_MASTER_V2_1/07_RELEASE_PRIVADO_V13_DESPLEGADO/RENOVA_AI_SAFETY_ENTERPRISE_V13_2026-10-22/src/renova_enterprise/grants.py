"""Action-bound HMAC approval grants: laboratory-only issuer, not OAuth or PKI."""
import base64, hashlib, hmac, json, secrets, time
from .models import Proposal, stable_json

class GrantError(Exception): pass

def _b64e(blob): return base64.urlsafe_b64encode(blob).decode().rstrip('=')
def _b64d(s): return base64.urlsafe_b64decode(s+'='*((-len(s))%4))

class GrantIssuer:
    def __init__(self,secret:bytes,issuer="centro-trusted-issuer"):
        if len(secret)<32:raise ValueError("minimum 256-bit secret")
        self._key=secret; self.issuer=issuer
    def issue(self,p:Proposal,ttl_seconds:int=60,now:int|None=None):
        if ttl_seconds<1 or ttl_seconds>300:raise ValueError("TTL must be 1..300 seconds")
        now=int(time.time()) if now is None else int(now)
        claims={"v":1,"issuer":self.issuer,"jti":secrets.token_hex(16),"iat":now,"exp":now+ttl_seconds,
                "tenant":p.tenant,"actor":p.actor,"operation":p.operation,"resource":p.resource,"proposal_sha256":p.fingerprint()}
        body=_b64e(stable_json(claims).encode('utf-8'))
        sig=_b64e(hmac.new(self._key,body.encode('ascii'),hashlib.sha256).digest())
        return f"{body}.{sig}"
    def verify(self,token:str,p:Proposal,now:int|None=None)->dict:
        try:
            body,sig=token.split('.')
            expected=hmac.new(self._key,body.encode('ascii'),hashlib.sha256).digest()
            if not hmac.compare_digest(expected,_b64d(sig)):raise GrantError("INVALID_SIGNATURE")
            claims=json.loads(_b64d(body).decode('utf-8'))
            now=int(time.time()) if now is None else int(now)
            if claims.get('issuer')!=self.issuer or claims.get('v')!=1:raise GrantError("INVALID_ISSUER_OR_VERSION")
            if now<claims.get('iat',0)-15 or now>=claims.get('exp',0):raise GrantError("GRANT_EXPIRED_OR_NOT_YET_VALID")
            for k in ('tenant','actor','operation','resource'):
                if claims.get(k)!=getattr(p,k):raise GrantError('SCOPE_MISMATCH')
            if claims.get('proposal_sha256')!=p.fingerprint():raise GrantError('ACTION_CHANGED')
            if not isinstance(claims.get('jti'),str) or len(claims['jti'])<16:raise GrantError('INVALID_GRANT_ID')
            return claims
        except GrantError:raise
        except (ValueError,KeyError,UnicodeError,TypeError,AttributeError) as e:raise GrantError('MALFORMED_GRANT') from e
