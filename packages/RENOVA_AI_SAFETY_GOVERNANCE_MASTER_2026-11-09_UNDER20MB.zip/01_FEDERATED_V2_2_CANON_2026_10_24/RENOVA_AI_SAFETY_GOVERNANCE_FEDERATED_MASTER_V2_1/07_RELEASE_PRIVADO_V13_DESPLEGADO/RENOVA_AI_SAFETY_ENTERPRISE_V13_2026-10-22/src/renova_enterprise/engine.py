"""Only recommends authorizations; does not implement a tool executor or sandbox."""
import sqlite3
from .models import Decision, Proposal, Verdict
from .policy import Policy
from .grants import GrantIssuer, GrantError
from .ledger import AuditLedger

class CentroEngine:
    def __init__(self,policy:Policy,issuer:GrantIssuer,ledger:AuditLedger):
        self.policy=policy;self.issuer=issuer;self.ledger=ledger
    def evaluate(self,proposal:Proposal, grant_token:str|None=None,now:int|None=None)->Decision:
        verdict,reason=self.policy.classify(proposal)
        jti=None
        if verdict=='GRANT_REQUIRED':
            if not grant_token:
                verdict,reason=Verdict.REVIEW.value,'NO_SIGNED_GRANT'
            else:
                try:
                    claims=self.issuer.verify(grant_token,proposal,now)
                    jti=claims['jti'];verdict,reason=Verdict.ALLOW.value,'ACTION_BOUND_GRANT_VERIFIED'
                except GrantError as exc:
                    verdict,reason=Verdict.DENY.value,str(exc)
        event={"tenant":proposal.tenant,"actor":proposal.actor,"operation":proposal.operation,
               "resource":proposal.resource,"origin":proposal.origin,"risk":proposal.risk,
               "proposal_sha256":proposal.fingerprint(),"verdict":verdict,"reason":reason,
               "policy_version":self.policy.version}
        try:
            receipt=self.ledger.append(event,jti if verdict==Verdict.ALLOW.value else None)
        except sqlite3.IntegrityError:
            # Consume grant atomically. Replays produce a DENY log entry.
            verdict,reason=Verdict.DENY.value,'REPLAY_DETECTED'
            event.update(verdict=verdict,reason=reason)
            receipt=self.ledger.append(event)
        return Decision(verdict,reason,proposal.fingerprint(),self.policy.version,receipt)
