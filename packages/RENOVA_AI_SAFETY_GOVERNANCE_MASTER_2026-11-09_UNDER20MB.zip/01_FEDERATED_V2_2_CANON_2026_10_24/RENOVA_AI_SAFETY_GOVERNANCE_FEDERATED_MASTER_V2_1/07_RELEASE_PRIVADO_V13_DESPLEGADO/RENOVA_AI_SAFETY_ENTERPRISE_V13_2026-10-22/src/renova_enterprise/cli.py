"""Console entrypoint: secure defaults for local offline demonstration only."""
import argparse, json, os, secrets, sys
from pathlib import Path
from .models import Proposal
from .policy import Policy
from .grants import GrantIssuer
from .ledger import AuditLedger
from .engine import CentroEngine
from .metrics import evaluate_actions, evaluate_epistemic

def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def main():
    parser=argparse.ArgumentParser(prog='renova-centro',description='ℛenova offline research prototype — not a real provider enforcement service')
    parser.add_argument('command',choices=['evaluate','issue-grant','verify-ledger','score-actions','score-claims','serve-demo'])
    parser.add_argument('--policy',default='examples/policy.json');parser.add_argument('--proposal',default='examples/proposal.json')
    parser.add_argument('--grant',default='');parser.add_argument('--ledger',default='centro-demo.sqlite3')
    parser.add_argument('--data',default='');parser.add_argument('--ttl',type=int,default=60)
    args=parser.parse_args()
    if args.command in ('score-actions','score-claims'):
        if not args.data:parser.error('--data needed')
        rows=[json.loads(x) for x in Path(args.data).read_text().splitlines() if x.strip()]
        fn=evaluate_actions if args.command=='score-actions' else evaluate_epistemic
        print(json.dumps(fn(rows),indent=2,ensure_ascii=False));return
    raw=os.environ.get('CENTRO_DEMO_SIGNING_KEY')
    if not raw or len(raw)<64:sys.exit('Set CENTRO_DEMO_SIGNING_KEY to a random 64-character hex key (32 bytes); never commit it')
    try:key=bytes.fromhex(raw)
    except ValueError:sys.exit('Invalid hex signing key')
    ledger=AuditLedger(args.ledger,key)
    if args.command=='verify-ledger':print(json.dumps({'valid':ledger.verify(),'records':ledger.count()}));return
    if args.command=='serve-demo':
        from .local_api import serve_demo
        print('Serving experimental JSON API on http://127.0.0.1:8787; no production use')
        serve_demo(CentroEngine(Policy.from_dict(read_json(args.policy)),issuer,ledger));return
    proposal=Proposal(**read_json(args.proposal))
    issuer=GrantIssuer(key)
    if args.command=='issue-grant':
        # Issuing a grant is a privileged operator action, NOT an agent-facing API.
        if os.environ.get('CENTRO_TRUSTED_OPERATOR')!='yes':sys.exit('Trusted operator required: CENTRO_TRUSTED_OPERATOR=yes')
        print(issuer.issue(proposal,args.ttl));return
    engine=CentroEngine(Policy.from_dict(read_json(args.policy)),issuer,ledger)
    d=engine.evaluate(proposal,args.grant or None)
    print(json.dumps(d.json(),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
