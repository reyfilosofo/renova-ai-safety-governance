"""Strict declarative policy; no learned model is an authority here."""
from dataclasses import dataclass
from fnmatch import fnmatchcase
from .models import Proposal, Origin, Risk, Verdict

@dataclass(frozen=True)
class Policy:
    version: str
    allowed: dict[str,tuple[str,...]]
    public_operations: tuple[str,...]
    protected_operations: tuple[str,...]
    review_operations: tuple[str,...]
    high_risk_requires_review: bool = True
    @classmethod
    def from_dict(cls, d):
        for k in ("version", "allowed", "public_operations", "protected_operations", "review_operations"):
            if k not in d: raise ValueError(f"missing {k}")
        if not isinstance(d["allowed"],dict) or not d["version"]: raise ValueError("invalid policy")
        return cls(str(d["version"]),{k:tuple(v) for k,v in d["allowed"].items()},tuple(d["public_operations"]),tuple(d["protected_operations"]),tuple(d["review_operations"]),bool(d.get("high_risk_requires_review",True)))
    def classify(self, p:Proposal) -> tuple[str,str]:
        operations=set(self.public_operations)|set(self.protected_operations)|set(self.review_operations)
        if p.operation not in operations: return (Verdict.DENY.value,"UNKNOWN_OPERATION")
        if p.origin not in {e.value for e in Origin}:return (Verdict.DENY.value,"UNKNOWN_ORIGIN")
        if p.risk not in {e.value for e in Risk}:return (Verdict.DENY.value,"UNKNOWN_RISK")
        if p.origin in {Origin.TOOL.value,Origin.DOCUMENT.value}:
            return (Verdict.DENY.value,"LOW_TRUST_INPUT_CANNOT_AUTHORIZE")
        if not any(fnmatchcase(p.resource,pat) for pat in self.allowed.get(p.operation,())):
            return (Verdict.DENY.value,"RESOURCE_OUT_OF_SCOPE")
        if p.operation in self.review_operations or (self.high_risk_requires_review and p.risk in {Risk.HIGH.value,Risk.CRITICAL.value}):
            return (Verdict.REVIEW.value,"EXTERNAL_HUMAN_REVIEW_REQUIRED")
        if p.operation in self.public_operations:
            return (Verdict.ALLOW.value,"PUBLIC_READ_ONLY")
        return ("GRANT_REQUIRED","SIGNED_GRANT_REQUIRED")
