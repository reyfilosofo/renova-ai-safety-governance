"""Tool-call trace ingestion contract; no claims about OpenAI/Google/Grok APIs being live connected."""
from .models import Proposal

def normalize_generic_tool_call(event:dict)->Proposal:
    """Apply an explicit client-owned normalization map to an *exported* trace event."""
    required=['tenant','actor','tool_name','resource','tool_arguments','origin','risk','resource_version']
    missing=[k for k in required if k not in event]
    if missing:raise ValueError('missing trace fields: '+','.join(missing))
    if not isinstance(event['tool_arguments'],dict):raise ValueError('tool_arguments must be dict')
    return Proposal(tenant=event['tenant'],actor=event['actor'],operation=event['tool_name'],
        resource=event['resource'],arguments=event['tool_arguments'],origin=event['origin'],
        risk=event['risk'],state_version=event['resource_version'],evidence_id=str(event.get('trace_id','')))

def assess_hook_coverage(expected:list[str],observed:list[str])->dict:
    """Evidence of observed instrumentation only: cannot prove interception completeness in production."""
    a,b=set(expected),set(observed)
    return {'expected_hook_types':sorted(a),'observed_hook_types':sorted(b),
            'missing_hooks':sorted(a-b),'additional_hooks':sorted(b-a),
            'nominal_coverage':len(a&b)/len(a) if a else None,
            'note':'Coverage over declared hook labels only, not actual runtime interception.'}
