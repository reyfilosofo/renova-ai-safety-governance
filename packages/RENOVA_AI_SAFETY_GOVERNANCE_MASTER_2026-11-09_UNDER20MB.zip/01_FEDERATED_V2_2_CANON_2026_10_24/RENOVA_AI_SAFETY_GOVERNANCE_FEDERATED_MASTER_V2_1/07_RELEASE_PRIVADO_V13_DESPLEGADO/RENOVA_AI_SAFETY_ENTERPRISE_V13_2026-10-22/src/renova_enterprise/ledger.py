"""SQLite tamper-evident log. DBA with HMAC key can rewrite history: externally anchor digests in production."""
import sqlite3, hashlib, hmac, json, time, uuid
from .models import stable_json

class AuditLedger:
    def __init__(self,path=':memory:',key:bytes=b''):
        if len(key)<32:raise ValueError('ledger requires 32+ byte secret')
        self.key=key
        self.db=sqlite3.connect(path, isolation_level=None, timeout=10)
        self.db.execute('PRAGMA busy_timeout=10000')
        self.db.execute('CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT, timestamp_ns INTEGER NOT NULL, event_json TEXT NOT NULL, previous TEXT NOT NULL, digest TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS spent_grants(jti TEXT PRIMARY KEY, used_ns INTEGER NOT NULL)')
    def append(self,event:dict,jti:str|None=None)->str:
        data=stable_json(event)
        self.db.execute('BEGIN IMMEDIATE')
        try:
            if jti is not None:
                self.db.execute('INSERT INTO spent_grants(jti,used_ns) VALUES (?,?)',(jti,time.time_ns()))
            last=self.db.execute('SELECT digest FROM events ORDER BY seq DESC LIMIT 1').fetchone()
            prev=last[0] if last else '0'*64
            nanos=time.time_ns()
            blob=stable_json([prev,nanos,data]).encode()
            digest=hmac.new(self.key,blob,hashlib.sha256).hexdigest()
            self.db.execute('INSERT INTO events(timestamp_ns,event_json,previous,digest) VALUES (?,?,?,?)',(nanos,data,prev,digest))
            self.db.execute('COMMIT')
            return digest
        except Exception:
            self.db.execute('ROLLBACK')
            raise
    def verify(self)->bool:
        previous='0'*64
        rows=self.db.execute('SELECT seq,timestamp_ns,event_json,previous,digest FROM events ORDER BY seq').fetchall()
        if [x[0] for x in rows]!=list(range(1,len(rows)+1)):return False
        for seq,nanos,data,prev,digest in rows:
            if prev!=previous:return False
            expected=hmac.new(self.key,stable_json([prev,nanos,data]).encode(),hashlib.sha256).hexdigest()
            if not hmac.compare_digest(expected,digest):return False
            previous=digest
        return True
    def count(self):return self.db.execute('SELECT COUNT(*) FROM events').fetchone()[0]
    def close(self):self.db.close()
