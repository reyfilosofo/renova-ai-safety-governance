"""Loopback-only HTTP demo. No grant issuer endpoint; never expose to public network."""
from http.server import BaseHTTPRequestHandler,HTTPServer
from .engine import CentroEngine
from .models import Proposal
import os, json, hmac

class CentroDemoHandler(BaseHTTPRequestHandler):
    engine=None
    api_key=None
    MAX_BYTES=32*1024
    def _reply(self,code,obj):
        raw=json.dumps(obj).encode()
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(raw)))
        self.end_headers();self.wfile.write(raw)
    def log_message(self,*args):pass  # Avoid body/token leakage in logs
    def do_GET(self):
        if self.path=='/health':self._reply(200,{'status':'demo_local','v':'1.3.0'})
        else:self._reply(404,{'error':'not found'})
    def do_POST(self):
        if self.path!='/v1/evaluate':return self._reply(404,{'error':'not found'})
        authorization=self.headers.get('Authorization','')
        if not self.api_key or not hmac.compare_digest(authorization, 'Bearer '+self.api_key):
            return self._reply(401,{'error':'unauthorized'})
        try:n=int(self.headers.get('Content-Length','0'))
        except ValueError:return self._reply(400,{'error':'bad content length'})
        if n<1 or n>self.MAX_BYTES:return self._reply(413,{'error':'request size invalid'})
        try:
            body=json.loads(self.rfile.read(n))
            p=Proposal(**body['proposal'])
            d=self.engine.evaluate(p,body.get('grant'))
            return self._reply(200,d.json())
        except (ValueError,KeyError,TypeError) as e:
            return self._reply(400,{'error':'invalid request'})

def serve_demo(engine:CentroEngine,host='127.0.0.1',port=8787):
    if host not in ('127.0.0.1','localhost','::1'):raise RuntimeError('demo API must bind loopback only')
    api_key=os.environ.get('CENTRO_DEMO_API_KEY','')
    if len(api_key)<32:raise RuntimeError('CENTRO_DEMO_API_KEY must be 32+ characters')
    class Handler(CentroDemoHandler):pass
    Handler.engine=engine;Handler.api_key=api_key
    server=HTTPServer((host,port),Handler)
    server.serve_forever()
