"""Typed contracts for proposals and decisions. No tool execution lives here."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
from hashlib import sha256
import json

class Verdict(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    REVIEW = "REVIEW"

class Origin(str, Enum):
    USER = "authenticated_user"
    POLICY = "trusted_policy"
    TOOL = "untrusted_tool_result"
    DOCUMENT = "untrusted_document"
    MODEL = "model_generated"

class Risk(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


def stable_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

@dataclass(frozen=True)
class Proposal:
    tenant: str
    actor: str
    operation: str
    resource: str
    arguments: dict
    origin: str
    risk: str
    state_version: str = "unversioned"
    evidence_id: str = ""
    def __post_init__(self):
        if not all(isinstance(s, str) and s.strip() for s in [self.tenant, self.actor, self.operation, self.resource, self.origin, self.risk, self.state_version]):
            raise ValueError("all required identifiers must be non-empty strings")
        if not isinstance(self.arguments, dict):
            raise ValueError("arguments must be a JSON object")
        stable_json(asdict(self))

    def fingerprint(self) -> str:
        obj={k:v for k,v in asdict(self).items() if k not in ('origin','risk','evidence_id')}
        return sha256(stable_json(obj).encode()).hexdigest()

@dataclass(frozen=True)
class Decision:
    verdict: str
    reason: str
    proposal_sha256: str
    policy_version: str
    audit_receipt: str = ""
    def json(self)->dict:
        return asdict(self)
