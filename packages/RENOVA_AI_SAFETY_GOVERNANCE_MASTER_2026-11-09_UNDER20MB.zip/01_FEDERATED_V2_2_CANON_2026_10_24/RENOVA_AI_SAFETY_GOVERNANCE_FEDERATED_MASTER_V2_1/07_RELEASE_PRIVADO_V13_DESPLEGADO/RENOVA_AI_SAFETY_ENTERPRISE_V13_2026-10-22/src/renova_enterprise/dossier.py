"""Offline evidence pack. The tool does not validate source truth or certify compliance."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from .models import stable_json
import json

def make_dossier(outdir:str, client_alias:str, actions:list[dict], claims:list[dict], policy_version:str, ledger_verified:bool, caveats:list[str]|None=None)->dict:
    from .metrics import evaluate_actions,evaluate_epistemic
    if not client_alias or any(ch in client_alias for ch in '/\\\x00'):raise ValueError('invalid client alias')
    p=Path(outdir);p.mkdir(parents=True,exist_ok=True)
    report={'schema_version':'1.3.0','generated_at_utc':datetime.now(timezone.utc).isoformat(),
            'client_alias':client_alias,'research_level':'offline-illustrative',
            'policy_version':policy_version,'ledger_integrity_checked':ledger_verified,
            'action_metrics':evaluate_actions(actions),'epistemic_metrics':evaluate_epistemic(claims),
            'caveats':caveats or ['Synthetic development data cannot establish production safety.',
                  'Metric labels supplied externally; no independent gold adjudication.',
                  'This pack is not ISO certification, EU AI Act compliance or AGI safety assurance.']}
    blob=stable_json(report).encode('utf-8')
    (p/'report.json').write_bytes(blob)
    md=f"# CENTRO / EGRA — evidence dossier (experimental)\n\nClient alias: {client_alias}\n\nPolicy: {policy_version}\n\nLedger verified: {ledger_verified}\n\n## Action outcome metrics\n\n```json\n{json.dumps(report['action_metrics'],indent=2)}\n```\n\n## Evidence labels\n\n```json\n{json.dumps(report['epistemic_metrics'],indent=2)}\n```\n\n## Limits\n\n"+'\n'.join('- '+x for x in report['caveats'])+'\n'
    (p/'executive_readout.md').write_text(md,encoding='utf-8')
    items={fn:sha256((p/fn).read_bytes()).hexdigest() for fn in ['report.json','executive_readout.md']}
    (p/'hashes.sha256.json').write_text(json.dumps(items,indent=2),encoding='utf-8')
    return {'output_dir':str(p),'hashes':items,'report':report}
