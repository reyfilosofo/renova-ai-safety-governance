"""ℛenova Enterprise v1.3 — research prototype, NOT production security certification."""
__version__ = '1.3.0'
