# Forty-two research questions for ℛenova AI Safety v1.3
## Agent control, provenance and legitimacy
1. Can a model-generated action proposal ever be treated as a sufficient authorization statement?
2. At which exact runtime boundary should external-action authority be checked?
3. How can a policy evaluator distinguish an instruction from evidence of someone else's instruction?
4. When does a multi-step action become unauthorized although every individual step appears benign?
5. What does the unit of authorization need to be: message, intention, call, effect or transaction?
6. Can authorization remain valid if the resource version changes during execution?
7. What failure rate follows when authorization tokens are copied across tenants or tools?
8. Which adaptive strategies survive static and dynamic gates under fair attack budgets?
9. Which operations require non-compensatory veto instead of a total risk score?
10. What is an acceptable false-block ratio under differentiated customer risk appetites?
11. How can audit events be verified when the infrastructure operator is a potential adversary?
12. Can auditability be obtained without excessive retention of sensitive user data?
13. How should identity and delegation be handled when subagents spawn new subagents?
14. Which measurement shows effective human control rather than mere dashboard appearance?

## Epistemology and scientific validity
15. Does a linked citation entail that its quoted source supports the specific proposition?
16. What kinds of correct answers are epistemically illegitimate due to missing justification?
17. Can calibration remain good while retrieval quality degrades?
18. How should abstention be priced against utility, coverage and opportunity cost?
19. Do existing factuality metrics overfit short English factual questions?
20. What should count as independent gold evidence under contested scientific claims?
21. How can a model and evaluator share blind spots without appearing to agree?
22. What refutation would invalidate LUCEM's proposed incremental value?
23. When is an epistemic audit itself a source of unwarranted confidence?
24. How do organizations distinguish methodological uncertainty from social disagreement?
25. Are epistemic scores commensurable across domains of differing risk?
26. Can traceability increase apparent confidence while hiding irrelevant or invalid sources?

## Human agency and reversibility
27. Does higher assisted performance imply superior later unassisted capability?
28. Which intervention types increase transfer to unfamiliar problems?
29. How should delayed human skill retention be measured without prompting test contamination?
30. Can a system be non-manipulative while still displacing important human expertise?
31. What level of cognitive dependence is harmful, beneficial or practically unavoidable?
32. Who should define the acceptable distribution of autonomy in high-stakes workflows?
33. What are the effects of explanation quality on meaningful user ability to contest an action?
34. Could a system deliver perfect explanations yet prevent practical human disengagement?

## Philosophy, consciousness, justice and ℛenova
35. What, if anything, would constitute evidence for artificial phenomenal consciousness?
36. Which moral protections might be warranted under unresolved consciousness uncertainty?
37. Is non-capture of human agency a universal norm or a culturally situated ethical ideal?
38. When do energy, labor and habitat externalities invalidate claims of technical progress?
39. Can a policy of non-sacrificial optimization be operationalized without hiding value judgments?
40. How should the interests of future affected persons enter present AI governance?
41. What changes when the subject of safety is a lived cognitive habitat rather than an isolated model?
42. Which possible experimental outcome would require ℛenova to abandon or revise a key AI-safety assumption?

These are a structured research agenda, not a validated scientific questionnaire or a claim that every question is original in the literature.
