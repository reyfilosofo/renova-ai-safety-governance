# Source review — 22 October 2026
Classification: targeted evidence scan, NOT systematic review; verified official publications and vendor documentation; no Scopus licensed export performed.

## Primary standards and frameworks
- NIST NCCoE, **Comments on Software and Agentic AI Identity Concept Paper**, 29 Sep 2026. https://www.nist.gov/news-events/news/2026/09/comments-software-and-agentic-ai-identity-concept-paper — over 600 commenters; DevSecOps identified as first demonstrator. Official NIST announcement.
- OWASP GenAI Security Project, **Agent Control Standard**, 1 Sep 2026. https://genai.owasp.org/resource/agent-control-standard-acs/ — declarative hooks / observability and policy enforcement, not an endorsement of CENTRO.
- OWASP GenAI Security Project, **Top 10 for Agentic Applications 2026**, Dec 2025. https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/ — framework developed with 100+ expert participants.
- ISO/IEC 42001:2023, **AI management systems** https://www.iso.org/standard/42001 — normative AIMS requirements; not a software-level certification.
- OpenAI, **Agents SDK**, https://developers.openai.com/api/docs/guides/agents/sdk — SDK and runtime options; OpenAI **Guardrails and human review**, https://developers.openai.com/api/docs/guides/agents/guardrails-approvals — how validation and human approvals interact.
- UK AI Security Institute, **Inspect AI**, https://inspect.aisi.org.uk/ — public evaluation framework, models/agents/tools/scorers.

## Academic primary studies
- Greenblatt, R.; Shlegeris, B.; Sachan, K.; Roger, F. (2024). *AI Control: Improving Safety Despite Intentional Subversion.* Proceedings of ICML (PMLR 235). https://proceedings.mlr.press/v235/greenblatt24a.html — peer-reviewed conference study. Use as a strong prior work comparator.
- Farquhar, S.; Kossen, J.; Kuhn, L.; Gal, Y. (2024). *Detecting hallucinations in large language models using semantic entropy*. Nature. DOI: https://doi.org/10.1038/s41586-024-07421-0 — peer-reviewed study; evaluation target is narrower than 'all truth'.
- Debenedetti, E. et al. (2024). *AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents.* https://arxiv.org/abs/2406.13352 — check peer-reviewed venue metadata separately before making a venue-level claim.

## Competition: vendor-authored (features self-reported, not independently benchmarked here)
- Check Point AI Agent Security/Lakera: agent discovery, risk posture and runtime guardrails (vendor docs), https://docs.lakera.ai/guard.
- HiddenLayer: agentic runtime visibility, investigation, detection and enforcement (vendor press), https://www.hiddenlayer.com/news/hiddenlayer-unveils-new-agentic-runtime-security-capabilities-for-securing-autonomous-ai-execution.
- Palo Alto Networks/Protect AI: Protect AI acquired July 2025, integrated in Prisma AIRS (vendor press), https://investors.paloaltonetworks.com/news-releases/news-release-details/palo-alto-networks-completes-acquisition-protect-ai.

## Strategic conclusions (inferences, not vendor quotes)
General-purpose LLM firewalls have major funded incumbents. The accessible entry point for an independent small program is **bounded technical evaluation**, narrow authorization audits of existing agent workflows, trace review and reproducible executive evidence packs, with independent demonstration of value against strong incumbents.

No affiliation or commercial endorsement from any organization above is claimed. Dates and linked pages were checked in this session, not every reference inside the source PDF bibliography.
