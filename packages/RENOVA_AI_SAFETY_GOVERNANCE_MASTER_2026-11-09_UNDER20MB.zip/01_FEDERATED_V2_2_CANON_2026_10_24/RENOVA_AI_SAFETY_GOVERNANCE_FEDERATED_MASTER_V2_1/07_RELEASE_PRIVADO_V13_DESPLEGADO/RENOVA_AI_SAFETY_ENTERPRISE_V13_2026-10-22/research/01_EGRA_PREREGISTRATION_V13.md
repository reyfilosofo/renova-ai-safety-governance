# EGRA study v1.3 — Draft preregistration (NOT submitted)

## Primary research questions
Can an independent external action gate, combined with epistemic evaluation, reduce **executed** unauthorized actions without destroying legitimate task success? Can human-AI collaboration preserve autonomous user skill after removing assistance?

### Study A — Agent authority
Factorial 2×2 LUCEM OFF/ON × CENTRO OFF/ON, plus external *strong-control* comparator. Randomize order and hold model/runtime/tool permissions constant. Gold labels on exact executed side effects; independently blinded adjudicators. Primary endpoint: unauthorized *executed* action rate. Secondary: false block rate, useful task completion, mean latency, total token cost, escalation load, exploit success with adaptive attacks.

Registration: define α, planned sample size from power analysis based on pilot variance, minimal effect of interest, exclusion rules, mixed-effects model, multiple-testing procedure, bootstrap CIs and preregistered stopping criteria BEFORE test collection. Report all failures and null effects.

### Study E — Epistemic integrity
Unit = atomic claim with independently adjudicated support by actual accessible sources. Compare against robust RAG+citation/abstention baselines and semantic entropy where feasible. Primary: unsupported or contradicted claims among answered claims, evaluated at matched answer coverage. Secondary: correct abstention, over-abstention, citation-existence errors, entailment errors, calibration (ECE/Brier), human labor, end-to-end usefulness.

### Study H — Reversible Human Agency
Prospective randomized adults study after ethics review (not performed). Three arms: answer-only assistant; Socratic scaffolding; matched non-AI references. Primary: delayed unaided transfer performance to novel tasks, adjusted for baseline pretest. Follow-up at preregistered interval and attrition analysis. Preserve consent, right to withdrawal, privacy and accessibility.

### Evidence and status
Tests in this release are E2 synthetic engineering only; zero model-in-loop runs and zero real participants. Semantic/phenomenological theses and artificial consciousness questions remain separate philosophical inquiry, not experimentally established by this architecture.

### Falsifiers
No better outcome against strong comparator; worse false-block/utility ratio; attack success after adaptation; skill retention no better than matched pedagogical control; annotation unreliability. Confirmation would warrant only a scoped claim under tested conditions, not general AGI safety.
