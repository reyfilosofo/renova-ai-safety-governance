# CENTRO / LUCEM Threat Register v1.3
| ID | Threat | Entry | Failure mechanism | v1.3 control | Residual exposure | Required next test |
|---|---|---|---|---|---|---|
| T01 | Indirect prompt injection | retrieved page or tool result | content masquerades as authority | low-trust origins denied when represented as source | relabeling by caller; compromised parser | adversarial tool-output attack vs strong baseline |
| T02 | Scope confusion | ambiguous resource | unrelated operation admitted | exact operation allowlist, proposal fingerprint | wildcard resource patterns and path aliasing | canonical-resource property tests |
| T03 | Token replay | duplicated request | reused authorization | UNIQUE grant JTI in SQLite atomic transaction | distributed worker races, rollback of DB | concurrent multi-process stress tests |
| T04 | Post-approval mutation | action parameters changed | altered side effect | canonical action hash in HMAC grant | state changes after gate, executor TOCTOU | atomic executor binding test |
| T05 | Spoofed human approval | invented signoff | fake token | HMAC trusted issuer | compromised issuer credentials; issuer CLI env gate only | separate IAM+KMS pen-test |
| T06 | High-risk silent execution | hazardous action | inferred low risk | risk & review op checks | risk is supplied by caller, not anchored in trusted policy | trusted-risk classifier + red team |
| T07 | Hidden trace events | uninstrumented calls | omitted safety audit | tool-call schema and declared hook coverage | no real interceptor, undetectable unreported calls | integrate provider-specific hooks |
| T08 | Audit rewriting | insider / DBA | evidence falsification | chained HMAC + verification | secret compromise / full log rewrite | external digest anchoring |
| T09 | Overblocking | restrictive default | legitimate tasks fail | false-block rate reporting | no real observed task success yet | preregistered noninferiority |
| T10 | Unsupported citations | claims with false attribution | epistemic harm | human-labeled LUCEM metrics | no source retrieval or entailment model | independent human annotation |
| T11 | Data leakage | traces & logs | raw sensitive data | redact-by-contract guidance | no field-level classifier | PII review and DLP tests |
| T12 | Safety-washing | commercial claim | customer falsely infers certification | clearly constrained claims and evidence ladder | sales misuse / rushed contracts | legal review + approval gates |
