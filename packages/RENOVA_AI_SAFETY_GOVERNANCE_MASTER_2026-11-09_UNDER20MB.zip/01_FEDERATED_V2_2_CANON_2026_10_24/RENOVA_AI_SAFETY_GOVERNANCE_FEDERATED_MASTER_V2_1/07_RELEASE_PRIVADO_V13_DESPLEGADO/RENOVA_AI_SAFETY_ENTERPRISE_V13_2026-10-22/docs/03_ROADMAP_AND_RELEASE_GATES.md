# Delivery readiness for actual software contracting

## Sell NOW, with scoped contract
- professional pilot audit of client-provided sanitized tool traces;
- simulated threat-model assessment and report;
- epistemic labeling and citation-error study with human adjudication;
- governance gap assessment and human-centered training;
- E2 prototype engineering and research design; DO NOT advertise production protection.

## NOT sale-ready
- continuous autonomous red team across services;
- cloud-native safety gateway for production financial or medical operations;
- formal ISO/EU compliance certification;
- objective 'AGI aligned' labeling;
- consciousness detector, cognitive improvement guarantees, benchmark accreditation.

## R3 production release gates, all currently PENDING
1. independent IAM including OIDC workload identity, KMS secrets, RBAC/ABAC tenant isolation;
2. trust policy engine, canonical resource IDs, high-risk classification independent of model;
3. enforcement immediately at the actual tool executor, with external hook completeness verified;
4. action-state atomicity / TOCTOU and durable distributed one-time grant storage;
5. async job queue, expiry, cancellations, timeouts and rollback proofs;
6. per-tenant audit anchor to write-once external log/ledger, SIEM exporter, retention rules;
7. resilience, availability tests, secrets scanning, dependency SBOM, packaging and security review;
8. adaptive red teaming, held-out attacks, CIs, independent reproducibility and controlled pilots;
9. vulnerability disclosure process, threat-model review, legal and DPA, security operations and incident response;
10. enterprise support operations, paid pilot evidence, real SLAs and documented licensing/ownership.

## Commercial progression
Week 1–2: buyer interviews, vendor integrations discovery; week 3–4: customer-specific sandbox adapter and baseline; week 5–8: independently labeled experiment; week 9–12: procurement-ready case study once authorized. These are product development stages, NOT automatic task schedules.
