# Security, licensing and disclosure — 1.3

**Responsible contact:** SERESARTE / ℛenova project owner (contact address to be confirmed). No formal incident hotline or bug bounty exists for this experimental code.

- In a research-only sandbox, do not enter secrets, client personal information, private customer logs or real financial payloads. Never bind the demo service to 0.0.0.0 or expose through a public tunnel.
- Security testing on targets outside one's ownership or explicit signed authorization is prohibited. Use only fixture data or client-owned environments with scope of work.
- The HMAC-based action grant is NOT federated authentication, external IAM, user consent nor model governance by itself.
- `CENTRO_TRUSTED_OPERATOR=yes` is a demonstration flag, not real human identity verification.
- The code is **not licensed open source by default**. All rights reserved to the actual authors of their respective contributions. Licensing, warranty, indemnity, redistribution and source access must be negotiated in writing. The author's existing ℛenova books are separate copyrighted assets and are not embedded in this delta package.
- A customer contract must specify environment ownership, pentest rules, support hours, retention and delete/export rules; no security SLA applies by default.
- Known gaps include: authenticated caller identity; risk classification independence; strict tenant/path controls; canonical object authorization; memory and key zeroization; KMS; token audience/capability and key IDs; rotation; external audit anchoring; concurrency across nodes; execution-time atomicity; rate limits; vulnerability scans; adaptive benchmark.
