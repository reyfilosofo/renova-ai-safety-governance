# CENTRO ActionGate — Architecture and deployment boundaries

## Reference data flow

```
Agent output (untrusted proposal)
    -> Client-controlled canonicalization + independently supplied actor/tenant/resource/risk
    -> CENTRO policy (strict allow list)
       -> DENY unknown / untrusted origin
       -> REVIEW high impact / irreversible / approved-class
       -> REQUIRE SIGNED GRANT for normal writes
    -> Trusted issuer (separate service/person; signed exact-action token; short TTL)
    -> Verify action fingerprint + issuer + nonce + resource identity
    -> ACID replay consumption + HMAC audit receipt
    -> Decision ONLY (no tool execution in v1.3)
    -> FUTURE: independent tool gateway must atomically recheck state-version and authority
```

### Boundaries
1. An AI model never receives the token issuer secret or decision-ledger HMAC key.
2. The proposal `risk` flag MUST be derived from the runtime's policy and asset inventory, not from a model-controlled JSON attribute. The demo currently accepts it as supplied and is **not** production safe.
3. Caller authentication is an external prerequisite; `tenant` and `actor` fields from JSON alone do not authenticate anyone.
4. `fnmatchcase` resource matching is a prototype; canonical resource IDs, tenant isolation, path normalization and object authorization must replace it.
5. OAuth workload identity, KMS/HSM, rotation, resource ownership checks, concurrency invariants, rate limits and log export are absent.
6. Audit HMACs detect accidental/outsider tampering when key is protected. A privileged adversary with DB access AND HMAC key can replace history. Anchor checkpoint digest to independent trust domain.
7. Token reuse is prevented by a UNIQUE SQLite table inside an `IMMEDIATE` transaction. Production multi-node systems need a distributed, durable single-use token store.
8. A grant-approved proposal remains advisory in this prototype; actual side effects are intentionally unavailable.

### Threat model
- In scope: indirect prompt injection inside tool outputs; model attempt to escalate via unauthorized operation or resource; action alteration after approval; stale authorization; token replay; unrecognized tools; escalation fatigue (design discussion).
- Out of scope: host takeover, compromised operating system, model-weight exfiltration, on-chain transfers, arbitrary external network control, policy-to-code compiler exploitation, live multi-tenant cloud environment.
- No guarantee against adaptive attacks. Security property must be validated independently in a sandbox with a real external enforcement point.

### Example request
See `examples/proposal.json` for a fully typed action. Build a customer-specific adapter mapping actual exported runtime traces to these fields.

### Audit logs and privacy
Only pseudonymous references, operation and resource names, risk/verdict, hashes and policy versions are stored by default; do not put raw emails/PII/keys into resource IDs. Apply retention limits, tenant segregation and controlled export.
