# Enterprise connector / federation state — 22 October 2026

| Provider | Production endpoint in v1.3 | Claim permitted |
| --- | --- | --- |
| Local JSONL / customer-exported traces | implemented adapter | Input export can be mapped to typed proposal after client contract review |
| OpenAI Agents SDK | **not connected** | Compatible trace fields may be adapted; no official integration is tested |
| Anthropic / Claude | **not connected** | No credentials or run hooks configured |
| Google Gemini / Vertex AI | **not connected** | Generic schema exists; no model API has been invoked |
| xAI Grok / Grokbot | **not connected** | No cross-bot messaging or direct evaluation performed |
| GitHub | separate authenticated ChatGPT connector MAY write authorized artifacts | GitHub repo connection is not runtime security integration |
| GitLab | **not connected** | Proposed CI export, no mirrored repo |
| Google Drive | separate authenticated document/file archive | Archive storage is not Gemini API control |
| Discord / Moltbook | **not connected** | No outbound posting/webhook configured |
| MCP tools | adapter contract only | No real interposition or ACS compliance validated |

A production adapter must be designed per SDK/runtime, with model-controlled fields treated as untrusted. Treat all third-party results as evidence rather than instruction. Default states NOT_CONNECTED; only move to VERIFIED after a provider-authenticated receipt and readback. No timer, cron, automation or background sync exists.
