# Change log — 22 October 2026
## v1.3.0 (NEW)
- New typed action contracts and policy evaluator independent of any model.
- New exact-action 256-bit HMAC grants, short-lived and replay-protected.
- New SQLite HMAC event ledger and integrity verifier.
- New LUCEM label metrics, Wilson interval, unauthorized-execution and false-block scores.
- New trace ingestion normalizer; declared hook-coverage report.
- New JSON/Markdown customer evidence dossier with SHA-256 artifact hashes.
- New localhost demonstration API without remotely callable grant issuance.
- Executed 62 unit tests and a four-step offline demonstration; generated example evidence pack.
- New six-product enterprise catalog, non-binding MXN price hypotheses, buyer/SOW, market and standards evidence review, procurement limitations.
- Standalone executive scientific-commercial report in editable Word and PDF.

This is a separately numbered **new delta** to the prior v1.2 archive. Previous historical ZIP not silently copied or overwritten because its exact bytes are not currently mounted in the container. See prior verified Google Drive archive: https://drive.google.com/file/d/1M4pALPOqsXhLFoyw86yAzheAgihVVPx5/view
