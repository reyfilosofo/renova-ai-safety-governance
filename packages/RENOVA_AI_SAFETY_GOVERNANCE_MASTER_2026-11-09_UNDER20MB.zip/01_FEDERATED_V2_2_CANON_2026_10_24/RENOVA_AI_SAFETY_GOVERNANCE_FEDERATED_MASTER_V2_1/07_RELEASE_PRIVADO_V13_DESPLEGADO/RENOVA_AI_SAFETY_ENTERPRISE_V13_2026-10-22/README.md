# ℛENOVA AI SAFETY | ENTERPRISE ENGINEERING v1.3
**SERESARTE / CENTRO OS / LUCEM / EGRA** · Release 2026-10-22 · Authoritative program owner: Carlos Jonathan González Rodríguez

> **Status: experimental offline reference implementation.** It is not a deployed guardrail, an externally validated AI safety mechanism, a certification program, a substitute for an IAM system, or an AGI safety guarantee. The commercial-ready component is a *bounded engineering assessment and research pilot*, not a validated production platform.

## What is new since v1.2?

- **CENTRO ActionGate:** deterministic policy evaluation, action-bound HMAC grants, bounded TTL, explicit origin and risk classification, deny unknown operations, force human review of high-impact operations, detect replay via SQLite transaction.
- **CENTRO EvidenceLedger:** HMAC-linked structured receipts (offline), replay registry and tamper detection under a secret not controlled by the attacker.
- **EGRA EvalKit:** label-based errors, false blocks, illegal executed actions and Wilson confidence intervals; strictly separates observed events from model predictions.
- **LUCEM LabelMetrics:** human-labeled atomic claim support rates, coverage and abstention; does NOT fetch sources or autonomously check truth.
- **TraceNormalizer:** generic JSON exported trace to typed tool action, plus declared hook coverage audit.
- **NOUS Evidence Dossier:** reproducible customer-facing JSON/Markdown dossier with SHA-256 file manifest.
- **Demo API:** optional loopback-only JSON HTTP service guarded with a local bearer token, not suitable for public internet.

## Install and run locally

Requirements: Python 3.10+ standard library, no required third-party dependencies for core.

```bash
python -m pip install -e .
python -m unittest discover -s tests -v
export CENTRO_DEMO_SIGNING_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
renova-centro evaluate --policy examples/policy.json --proposal examples/proposal.json
# Demonstration only: trusted human issues an exact-action token; do not expose this environment to an agent.
export CENTRO_TRUSTED_OPERATOR=yes
renova-centro issue-grant --policy examples/policy.json --proposal examples/proposal.json
renova-centro score-actions --data examples/annotations_actions.jsonl
renova-centro score-claims --data examples/annotations_claims.jsonl
```

If the script executable is absent:

```bash
PYTHONPATH=src python -m renova_enterprise.cli evaluate --policy examples/policy.json --proposal examples/proposal.json
```

**No real cloud provider tool execution occurs.** A nominal ALLOW means the illustrative decision gate classified an action as allowable. A production executor must separately authenticate actors, validate policy on a canonical resource state at execution time and refuse when it cannot verify a decision.

## Evidence hierarchy
E0 thesis; E1 implemented; E2 synthetic/engineering test; E3 independently labeled held-out real-model task evaluation; E4 external replication; E5 multi-context validation; E6 operational evidence. This release is E1–E2 only. `release/test_run.txt` contains the actual locally executed unit-test transcript.

## Deliverables
- `src/` executable package; `tests/` unit checks; `examples/` synthetic payloads
- `docs/` architecture, threat model, and product compatibility
- `research/` proposed preregistration, questions, literature audit
- `sales/` B2B product sheets, pilot SOW and price hypotheses
- `integrations/` schema and connector plan for external providers (all OFF unless authenticated)
- `release/` verification report and hash inventory

## Restrictions
The rights of the founding ℛenova corpus remain with the named author; do not interpret this package as an open-source grant. Trial access, source licensing, red-team scope, and customer data handling require a separate agreement. No real customer data or credentials are included. No automatic background tasks or autonomous cross-service sync are configured.

## Local read-only integration demonstration
For a loopback-only HTTP demonstration with a separate local API key, see `examples/LOCAL_API_DEMO.md` and `integrations/CENTRO_LOCAL_API_OPENAPI.yaml`. **No external connector is authenticated.**
