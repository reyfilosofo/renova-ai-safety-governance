# FED-21 — Contrato de mensajes verificable
**Estados:** PREPARED (solo archivo local), DISPATCHED (proveedor recibió solicitud), ACKNOWLEDGED (receipt_id real y readback), REJECTED, EXPIRED.
**Operaciones admitidas:** READ, ANALYZE, REVIEW, PROPOSE_PATCH. Publicación, emails, permisos, dinero o despliegue requieren autorización humana adicional.
**Campos obligatorios:** packet_id, schema_version, created_at, expires_at, source_node, target_node, project_id, data_classification, mission, requested_operation, source_refs, state, provider_receipt_id, readback_verified.
**Privacidad:** públicos solamente en GitHub. INTERNAL/CONFIDENTIAL solo transportes privados autenticados, nunca issue público/X.
**Controles del transporte externo pendientes:** identidades por proveedor y privilegio mínimo, autenticación independiente, cifrado, nonce, idempotencia, expiración, scope, trazabilidad, lectura posterior de destino, revocación, eliminación segura, supervisión humana y seguridad frente a prompt injection.
**Puertas:** G0 validación de esquema; G1 credenciales proveedor; G2 acceso exacto; G3 send+receipt+readback; G4 ataques/replay/revocación; G5 evaluación externa.
**IMPORTANTE:** el validador local no sustituye validación de permisos ni envía mensajes. Evitar publicar paquetes de pruebas etiquetados como acuses reales. No se activó ninguna tarea recurrente.
