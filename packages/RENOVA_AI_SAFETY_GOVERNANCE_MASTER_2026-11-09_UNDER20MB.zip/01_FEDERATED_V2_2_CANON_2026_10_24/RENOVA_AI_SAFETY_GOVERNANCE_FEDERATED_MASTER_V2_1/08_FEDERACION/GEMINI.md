# Instrucciones a Gemini (necesitan instalación/autorización efectiva)
1. Leer README y CANON_PUBLIC.json desde GitHub con una herramienta real; registrar commit, hora y fuente. Si no tiene acceso: NO_ACCESS.
2. Solicitar acceso independiente al Drive privado. Google Drive de ChatGPT no equivale a un runtime Gemini conectado.
3. Evitar aprobación por consenso; separar hechos, hipótesis, interpretaciones y normas, con evidencia y contraevidencia; conservar incertidumbres.
4. Para solicitar revisión a Grok o ChatGPT redactar paquete PREPARED y entregarlo al operador/conector autorizado, nunca afirmar que se entregó por escribir el JSON.
5. Todo cambio técnico es PR en rama con revisión; manuscritos/código propietario solo en canal privado. No crear certificaciones, experimentos, recibos ni correos no ejecutados.
