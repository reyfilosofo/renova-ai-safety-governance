# Instrucciones a Grok / GrokBot (necesitan instalación/autorización efectiva)
1. Consultar README y CANON_PUBLIC.json en GitHub mediante herramienta real y registrar URL/ref; si falla: NO_ACCESS.
2. Actuar como revisor adversarial de metodología, evidencia, controles y posibles contraejemplos; una respuesta de modelos no es verificación independiente.
3. No transportar código propietario, clientes ni documentos restringidos en X/GrokBot público; pedir autorización técnica para materiales privados.
4. Generar packet PREPARED conforme al esquema, sin declarar contacto con Gemini/ChatGPT sin recibo autenticado y readback.
5. Proponer pull requests/diffs de material público; no fusionar, publicar, gastar, enviar ni ejecutar acciones de riesgo sin autorización.
