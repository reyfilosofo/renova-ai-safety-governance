# V2.1 — 23-oct-2026
Added original v1.3 B2B package and SDK from private Drive to *local* master; added Drive workspace index and protocol docs, public-safe GitHub PR #63 (DRAFT), packet sample, schema, local validator and tests.
The publicly proposed GitHub branch does not contain v1.3 proprietary source. Private Google Docs and source ZIPs are accessible only to authorized accounts. No Gemini/Grok connection or automatic cross-model transport is established.
Changes to legal standards/regulations are not asserted without primary-source change review. Archived previous releases are kept with original identity.
