# Catálogo de fuentes (referencias de acceso controlado; no divulgar en repositorio público)
- Workspace privado creado: https://drive.google.com/drive/folders/1HwnD0oBAjavEVl-cTJjgYpfqo1zQbLEB
- Registro canónico federado: https://docs.google.com/document/d/1rhbpzDhaKmX_Q80QdbSpo8s2_UdZnFxVOk2a2iUgJ_Y/edit
- Protocolo de federación: https://docs.google.com/document/d/1fZlI0NEf1cP-j96HzdZhvwOk8yVgFDSV1eQoA0hbIO4/edit
- Delta 22-oct: https://docs.google.com/document/d/1OWpA8WXTxn_HqKQ5y_MleuojCHDW0ASkkY7gXdEyI6c/edit
- Registro v1.3: https://docs.google.com/document/d/1sQWQfiLtp4W-JAzY3jjRw4DtKqriyqZFe2DQCGUsxmY/edit
- ZIP B2B v1.3: https://drive.google.com/file/d/18jaIdueXTCiwjfmbhPSmUPJ5vgjWIwpa/view (180370 bytes; sha256 9c99f560447c74aa38ec5974bf9a0bbdc558509629150fd38a3da8d78d76f052)
- ZIP SDK v1.3: https://drive.google.com/file/d/1F0Wgi6OsJ3E9Ivn6BXC9A8m_2eZH58ot/view (21596 bytes)
- GitHub branch: https://github.com/reyfilosofo/renova-agent/tree/research/renova-federation-v21-20261023/05_AI_SAFETY_EGRA/federation/v2
No es evidencia de que Gemini/Grok tengan acceso. Las ACL de Google Drive no se cambiaron por este paquete. No hay vínculo de escritura automática.
