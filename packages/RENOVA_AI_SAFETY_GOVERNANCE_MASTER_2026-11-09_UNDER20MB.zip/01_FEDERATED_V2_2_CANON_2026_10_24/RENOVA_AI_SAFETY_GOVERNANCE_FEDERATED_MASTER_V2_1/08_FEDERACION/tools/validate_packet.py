#!/usr/bin/env python3
"""Offline syntactic safety check only. No transport, signatures or provider identity."""
from __future__ import annotations
import json,sys
from datetime import datetime,timezone
from pathlib import Path
REQUIRED={'packet_id','schema_version','created_at','expires_at','source_node','target_node','project_id','data_classification','mission','requested_operation','source_refs','state','provider_receipt_id','readback_verified'}
STATES={'PREPARED','DISPATCHED','ACKNOWLEDGED','REJECTED','EXPIRED'}
OPS={'READ','ANALYZE','REVIEW','PROPOSE_PATCH'}
CLASSES={'PUBLIC','INTERNAL','CONFIDENTIAL'}
def datetime_aware(value):
    if not isinstance(value,str): raise ValueError('datetime is not a string')
    dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    if dt.tzinfo is None or dt.utcoffset() is None: raise ValueError('datetime lacks timezone')
    return dt.astimezone(timezone.utc)
def validate(pkt,now=None):
    errors=[]
    if not isinstance(pkt,dict): return ['packet must be object']
    for field in sorted(REQUIRED-set(pkt)): errors.append('missing: '+field)
    for field in sorted(set(pkt)-REQUIRED): errors.append('unexpected: '+field)
    if errors:return errors
    if pkt['schema_version']!='2.1': errors.append('bad schema_version')
    if pkt['project_id']!='RENOVA-AI-SAFETY-GOVERNANCE': errors.append('bad project_id')
    if not isinstance(pkt['packet_id'],str) or len(pkt['packet_id'])<12:errors.append('bad packet_id')
    if pkt['requested_operation'] not in OPS: errors.append('unknown requested_operation')
    if pkt['data_classification'] not in CLASSES: errors.append('unknown data classification')
    if pkt['state'] not in STATES: errors.append('unknown state')
    if not all(isinstance(pkt[k],str) and len(pkt[k])>=2 for k in ('source_node','target_node')):errors.append('node labels missing')
    if not isinstance(pkt['mission'],str) or len(pkt['mission'])<10:errors.append('mission too short')
    if not isinstance(pkt['source_refs'],list) or not pkt['source_refs'] or not all(isinstance(x,str) and x.startswith('https://') for x in pkt['source_refs']):errors.append('source refs must be non-empty https URLs')
    if type(pkt['readback_verified']) is not bool: errors.append('readback_verified must be boolean')
    if pkt['provider_receipt_id'] is not None and (not isinstance(pkt['provider_receipt_id'],str) or not pkt['provider_receipt_id'].strip()):errors.append('bad receipt id')
    if pkt['state']=='ACKNOWLEDGED' and (not pkt['provider_receipt_id'] or pkt['readback_verified'] is not True):errors.append('ACK requires receipt + readback')
    if pkt['state']=='PREPARED' and (pkt['provider_receipt_id'] is not None or pkt['readback_verified'] is not False):errors.append('PREPARED cannot claim delivery')
    if pkt['state'] in ('DISPATCHED','REJECTED','EXPIRED') and pkt['readback_verified'] is True:errors.append('only ACK can be readback-verified')
    try:
        created=datetime_aware(pkt['created_at']);expires=datetime_aware(pkt['expires_at'])
        if expires<=created:errors.append('expires_at not after created_at')
        if (expires-created).total_seconds()>7*24*3600:errors.append('TTL over 7 days')
        if now is not None and now>expires and pkt['state'] not in ('EXPIRED','REJECTED'):errors.append('expired packet')
    except (TypeError,ValueError) as e:errors.append('invalid timestamps: '+str(e))
    # IMPORTANT: no inference of real transport authentication or confidentiality from a syntactically valid file.
    return errors
if __name__=='__main__':
    if len(sys.argv)!=2:sys.exit('Usage: validate_packet.py packet.json')
    try:
        data=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
        failures=validate(data,datetime.now(timezone.utc))
    except (OSError,ValueError,json.JSONDecodeError) as e:failures=[str(e)]
    print(json.dumps({'valid':not failures,'errors':failures,'note':'syntax only; no delivery/auth proof'},ensure_ascii=False))
    sys.exit(0 if not failures else 1)
