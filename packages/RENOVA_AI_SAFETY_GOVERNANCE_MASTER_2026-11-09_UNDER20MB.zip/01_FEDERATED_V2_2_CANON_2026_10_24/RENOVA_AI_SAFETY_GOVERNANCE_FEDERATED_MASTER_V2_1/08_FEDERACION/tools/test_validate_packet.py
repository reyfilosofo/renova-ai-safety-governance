import json, unittest,copy
from pathlib import Path
from validate_packet import validate
D=Path(__file__).resolve().parents[1]
class ContractTests(unittest.TestCase):
 def setUp(self):self.p=json.loads((D/'examples/example_PREPARED_NOT_SENT.json').read_text())
 def test_prepared_pass(self):self.assertEqual(validate(self.p),[])
 def test_missing_field(self):self.p.pop('packet_id');self.assertTrue(validate(self.p))
 def test_extra_field(self):self.p['secret']='x';self.assertTrue(validate(self.p))
 def test_unknown_operation(self):self.p['requested_operation']='DELETE';self.assertTrue(validate(self.p))
 def test_no_fake_ack(self):self.p['state']='ACKNOWLEDGED';self.assertTrue(validate(self.p))
 def test_bad_utc(self):self.p['created_at']='2026-10-23';self.assertTrue(validate(self.p))
 def test_expired_before_created(self):self.p['expires_at']='2026-10-22T16:00:00Z';self.assertTrue(validate(self.p))
 def test_ttl_cap(self):self.p['expires_at']='2026-12-22T16:00:00Z';self.assertTrue(validate(self.p))
 def test_no_fake_prepared_receipt(self):self.p['provider_receipt_id']='invented';self.assertTrue(validate(self.p))
 def test_ack_structural_only(self):self.p.update(state='ACKNOWLEDGED',provider_receipt_id='synthetic-test-not-real',readback_verified=True);self.assertEqual(validate(self.p),[])
if __name__=='__main__':unittest.main()
