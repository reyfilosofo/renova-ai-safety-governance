#!/usr/bin/env python3
from pathlib import Path
import hashlib,csv,sys
root=Path(__file__).resolve().parents[1]
manifest=root/'09_AUDITORIA/MANIFEST_SHA256.csv'
fail=[];count=0
with manifest.open(encoding='utf-8-sig',newline='') as f:
 for d in csv.DictReader(f):
  p=root/d['path'];count+=1
  if not p.is_file():fail.append(('MISSING',d['path']));continue
  if str(p.stat().st_size)!=d['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=d['sha256']: fail.append(('INVALID',d['path']))
print('FILES CHECKED:',count,'FAILURES:',len(fail))
for row in fail[:25]:print(*row)
sys.exit(bool(fail))
