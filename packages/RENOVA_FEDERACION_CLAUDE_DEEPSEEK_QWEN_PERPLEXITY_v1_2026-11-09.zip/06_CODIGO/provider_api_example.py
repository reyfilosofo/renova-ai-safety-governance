#!/usr/bin/env python3
"""Optional DeepSeek API text example. Default: dry-run with NO network.

Requires `pip install openai` only when --execute is explicitly provided.
Running --execute sends the prompt and document excerpts to a third-party API
and may cause costs. Review privacy and account permissions beforehand.
"""
import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROMPT = ROOT / "02_PROMPTS_PLATAFORMAS" / "DEEPSEEK_START.md"
CONTEXT = ROOT / "01_NUCLEO" / "MASTER_CONTEXT_ES.md"


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--provider", choices=["deepseek"], required=True)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--execute", action="store_true", help="EXPLICITLY permit one paid API request")
    mode.add_argument("--dry-run", action="store_true", help="preview only (default)")
    args = parser.parse_args(argv)
    system = "Critical research reviewer; no external actions, no invented evidence."
    user = PROMPT.read_text(encoding="utf8") + "\n\n--- CONTEXT ---\n" + CONTEXT.read_text(encoding="utf8")
    if not args.execute:
        print("DRY_RUN_ONLY: NO NETWORK, NO KEY REQUIRED")
        print(f"Provider: {args.provider} | prompt length: {len(user)} chars")
        print("To send, manually review files, accept API costs and run --execute.")
        return 0
    key = os.getenv("DEEPSEEK_API_KEY")
    if not key:
        print("Missing DEEPSEEK_API_KEY (do not paste secrets into documents)", file=sys.stderr)
        return 2
    try:
        from openai import OpenAI
    except ImportError:
        print("Install the `openai` Python package first", file=sys.stderr)
        return 2
    client = OpenAI(api_key=key, base_url="https://api.deepseek.com", timeout=90.0)
    result = client.chat.completions.create(
        model="deepseek-flash", messages=[{"role":"system","content":system}, {"role":"user","content":user}], stream=False
    )
    print(result.choices[0].message.content or "<no content>")
    return 0

if __name__ == "__main__":
    sys.exit(main())
