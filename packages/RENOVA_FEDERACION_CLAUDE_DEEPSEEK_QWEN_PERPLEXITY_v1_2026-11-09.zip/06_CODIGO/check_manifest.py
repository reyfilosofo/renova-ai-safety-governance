#!/usr/bin/env python3
"""Offline SHA-256 manifest verifier (does not make network requests)."""
import hashlib
import json
import sys
from pathlib import Path

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 06_CODIGO/check_manifest.py MANIFEST_SHA256.json")
        return 2
    manifest = Path(sys.argv[1]).resolve()
    root = manifest.parent
    entries = json.loads(manifest.read_text(encoding="utf8"))["files"]
    failures = []
    for relative, expected in entries.items():
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            failures.append((relative, "MISSING_OR_UNSAFE"))
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            failures.append((relative, "BAD_HASH"))
    if failures:
        for path, reason in failures:
            print(reason, path)
        return 1
    print(f"OK: {len(entries)} files with matching SHA-256 (local integrity only)")
    return 0

if __name__ == "__main__":
    sys.exit(main())
