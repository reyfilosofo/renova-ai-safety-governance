#!/usr/bin/env python3
"""RENOVA FED-21 v2.1 local packet utility. NO NETWORK. Python 3.10+ stdlib.

This performs targeted structural validation of the local contract. It is not
an authentication, send, readback, policy enforcement or full security system.
"""
from __future__ import annotations
import argparse
import json
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

OPERATIONS = {"READ", "ANALYZE", "REVIEW", "PROPOSE_PATCH"}
STATES = {"PREPARED", "DISPATCHED", "ACKNOWLEDGED", "REJECTED", "EXPIRED"}
CLASSIFICATIONS = {"PUBLIC", "INTERNAL", "CONFIDENTIAL"}
FIELDS = {"packet_id", "schema_version", "created_at", "expires_at",
          "source_node", "target_node", "project_id", "data_classification",
          "mission", "requested_operation", "source_refs", "state",
          "provider_receipt_id", "readback_verified"}
TARGETS = {"CLAUDE", "DEEPSEEK", "QWEN", "PERPLEXITY"}


def parse_dt(value: str) -> datetime:
    if not isinstance(value, str):
        raise ValueError("datetime must be a string")
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError("datetime must have timezone offset")
    return dt


def validate(packet: object) -> list[str]:
    errors: list[str] = []
    if not isinstance(packet, dict):
        return ["packet must be an object"]
    extra = set(packet) - FIELDS
    missing = FIELDS - set(packet)
    if extra:
        errors.append("unknown fields: " + ",".join(sorted(extra)))
    if missing:
        errors.append("missing fields: " + ",".join(sorted(missing)))
    if packet.get("schema_version") != "2.1":
        errors.append("schema_version must equal 2.1")
    if packet.get("project_id") != "RENOVA-AI-SAFETY-GOVERNANCE":
        errors.append("wrong project_id")
    for key, minlength in (("packet_id", 12), ("source_node", 2), ("target_node", 2), ("mission", 10)):
        val = packet.get(key)
        if not isinstance(val, str) or len(val) < minlength:
            errors.append(f"{key} requires string length >= {minlength}")
    for key, options in (("state", STATES), ("requested_operation", OPERATIONS), ("data_classification", CLASSIFICATIONS)):
        if packet.get(key) not in options:
            errors.append(f"{key} invalid")
    refs = packet.get("source_refs")
    if not isinstance(refs, list) or not refs or any(not isinstance(x, str) for x in refs):
        errors.append("source_refs must be nonempty list of strings")
    if not isinstance(packet.get("readback_verified"), bool):
        errors.append("readback_verified must be boolean")
    receipt = packet.get("provider_receipt_id")
    if receipt is not None and not isinstance(receipt, str):
        errors.append("provider_receipt_id must be string or null")
    if packet.get("state") == "ACKNOWLEDGED":
        if not isinstance(receipt, str) or not receipt:
            errors.append("ACKNOWLEDGED requires actual provider_receipt_id")
        if packet.get("readback_verified") is not True:
            errors.append("ACKNOWLEDGED requires readback_verified=true")
    if packet.get("state") == "PREPARED":
        if receipt is not None or packet.get("readback_verified") is not False:
            errors.append("PREPARED cannot claim provider receipt/readback")
    try:
        created = parse_dt(packet.get("created_at"))
        expires = parse_dt(packet.get("expires_at"))
        if expires <= created:
            errors.append("expires_at must be after created_at")
    except (ValueError, TypeError) as exc:
        errors.append(f"invalid timestamps: {exc}")
    return errors


def new_packet(target: str, mission: str, classification: str = "INTERNAL") -> dict:
    target = target.upper()
    if target not in TARGETS:
        raise ValueError(f"target must be one of {sorted(TARGETS)}")
    now = datetime.now(timezone.utc).replace(microsecond=0)
    packet = {
        "packet_id": "renova-" + str(uuid.uuid4()),
        "schema_version": "2.1",
        "created_at": now.isoformat(),
        "expires_at": (now + timedelta(days=30)).isoformat(),
        "source_node": "RENOVA_OWNER_MANUAL",
        "target_node": target,
        "project_id": "RENOVA-AI-SAFETY-GOVERNANCE",
        "data_classification": classification,
        "mission": mission,
        "requested_operation": "REVIEW",
        "source_refs": ["01_NUCLEO/MASTER_CONTEXT_ES.md"],
        "state": "PREPARED",
        "provider_receipt_id": None,
        "readback_verified": False,
    }
    assert not validate(packet)
    return packet


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Offline FED-21 packet preparation and structural validation (NO NETWORK)")
    subs = parser.add_subparsers(dest="cmd", required=True)
    create = subs.add_parser("new", help="create PREPARED packet locally; never sends")
    create.add_argument("--target", required=True, choices=sorted(TARGETS))
    create.add_argument("--output", required=True)
    create.add_argument("--mission", default="Review RENOVA research evidence and propose falsifiable experiments offline.")
    create.add_argument("--classification", choices=sorted(CLASSIFICATIONS), default="INTERNAL")
    check = subs.add_parser("validate", help="validate local JSON structure only")
    check.add_argument("file")
    args = parser.parse_args(argv)
    try:
        if args.cmd == "new":
            packet = new_packet(args.target, args.mission, args.classification)
            path = Path(args.output)
            if path.exists():
                print("Refusing to overwrite existing output", file=sys.stderr)
                return 2
            path.write_text(json.dumps(packet, indent=2, ensure_ascii=False) + "\n", encoding="utf8")
            print(f"CREATED_LOCAL_PREPARED: {path} (NOT SENT)")
        else:
            packet = json.loads(Path(args.file).read_text(encoding="utf8"))
            errors = validate(packet)
            if errors:
                print("INVALID: " + "; ".join(errors), file=sys.stderr)
                return 1
            print("VALID_LOCAL_STRUCTURE (NOT PROVIDER-AUTHENTICATED): " + args.file)
        return 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

if __name__ == "__main__":
    sys.exit(main())
