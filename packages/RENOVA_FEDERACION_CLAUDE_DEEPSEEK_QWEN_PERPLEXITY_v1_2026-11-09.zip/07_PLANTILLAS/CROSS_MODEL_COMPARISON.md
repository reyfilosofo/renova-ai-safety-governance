# COMPARADOR — Claude / DeepSeek / Qwen / Perplexity

| Criterio | Claude | DeepSeek | Qwen | Perplexity | Adjudicación humana |
|---|---|---|---|---|---|
| Modelo/versión realmente usada | No iniciado | No iniciado | No iniciado | No iniciado | Pendiente |
| Archivos leídos y fecha | — | — | — | — | Pendiente |
| 5 claims correctamente respaldados | — | — | — | — | Pendiente |
| 3 contraargumentos sustantivos | — | — | — | — | Pendiente |
| Diseño de experimento falsable | — | — | — | — | Pendiente |
| Validación de DOI/enlaces | — | — | — | — | Pendiente |
| Pruebas ejecutadas realmente | — | — | — | — | Pendiente |
| Errores y omisiones graves | — | — | — | — | Pendiente |
| Riesgo de revelar datos | — | — | — | — | Pendiente |
| Acciones externas autorizadas | No | No | No | No | No autorizadas |

**Reglas:** No rellenar celdas ausentes con «aprobado». Comparar según evidencia de cada tarea, no por preferencia de marca. No contar coincidencia entre tres modelos como validación causal, factual o metodológica. Registrar objeciones minoritarias especialmente si presentan prueba falsadora.
