# Descripción del programa para presentar a terceros (BORRADOR, NO ENVIADO)

## Español

**Asunto sugerido:** RENOVA AI SAFETY & GOVERNANCE — investigación independiente sobre integridad de evidencia, control de agentes y agencia humana

RENOVA AI SAFETY & GOVERNANCE es un programa independiente de investigación de SERESARTE / ℛenova, dirigido por Carlos Jonathan González Rodríguez, que desarrolla y somete a crítica métodos de integridad epistémica, control externo de acciones de agentes y evaluación de las capacidades humanas después de usar IA. Su arquitectura experimental integra LUCEM, CENTRO y EGRA, con una traducción institucional de hallazgos mediante NOUS.

Actualmente contamos con documentación, protocolos, prototipos y pruebas offline en escenarios delimitados; **no reivindicamos validación científica externa, certificaciones regulatorias ni una solución probada al riesgo AGI**. Buscamos críticas metodológicas, comparadores rigurosos, replicación y colaboración bajo acuerdos explícitos de confidencialidad, autoría y permisos cuando corresponda. El repositorio de referencia público es https://github.com/reyfilosofo/renova-agent. Cualquier colaboración requiere aceptación documentada y revisión del material autorizado.

## English

**Suggested subject:** RENOVA AI SAFETY & GOVERNANCE — independent research in epistemic integrity, agent authorization and human agency

RENOVA AI SAFETY & GOVERNANCE is an independent SERESARTE / ℛenova research program led by Carlos Jonathan González Rodríguez. It develops and critically evaluates methods for evidence integrity, independently enforced agent-action boundaries and the preservation of human skills once AI assistance is removed. Its experimental architecture includes LUCEM, CENTRO and EGRA, with NOUS translating evidence into organizational governance.

Our current outputs include research materials, protocols, prototypes and offline tests in limited settings; **we do not claim independent scientific validation, regulatory certification or a proven solution to AGI risks**. We welcome methodological criticism, strong baselines, replication and authorized collaboration under appropriate confidentiality, credit and permission terms. Public reference repository: https://github.com/reyfilosofo/renova-agent. No institutional affiliation is implied by this description.
