# CONTRIBUCIÓN INDEPENDIENTE — RENOVA AI SAFETY & GOVERNANCE

- **TASK_ID:** `RENOVA-MODEL-YYYYMMDD-XXXX`
- **Proveedor y modelo exacto:** (si es visible; no inventar)
- **Fecha y zona horaria:**
- **Autor humano responsable de importar/revisar:**
- **Operación:** READ / ANALYZE / REVIEW / PROPOSE_PATCH
- **Archivos/fuentes efectivamente vistos:** `nombre, versión, hash si existe`
- **Permisos disponibles y verificados:**
- **Alcance:**
- **Estado:** DRAFT / READY_FOR_HUMAN_REVIEW / BLOCKED

## 1. Resumen de 250 palabras

## 2. Tabla de afirmaciones

| ID | Afirmación | Estado epistémico | Fuente/DOI y fecha | Soporte específico | Contraevidencia | Confianza/alcance |
|---|---|---|---|---|---|---|

## 3. Crítica más fuerte contra RENOVA

## 4. Hipótesis falsable / diferencia frente a estado del arte

**Unidad, variables, comparadores, métricas, held-out, falsador y predicción diferencial.**

## 5. Implementación o protocolo propuesto

**Archivos, comandos, dependencia, licencia, entorno, método, config, semillas.**

## 6. Resultados realmente ejecutados

**Solo salidas reales. Si no se ejecutó: `NOT EXECUTED`.**

## 7. Riesgos, falsos positivos, falsos negativos e incertidumbre

## 8. Fuente de contradicción y posibles sesgos del modelo

## 9. Siguiente paso mínimo reversible

## 10. Gates/decisiones que requieren revisión humana

**Firma digital o recibo de proveedor**: ninguna, salvo evidencia externa real adjunta. Este documento es una propuesta de registro, no una certificación.
