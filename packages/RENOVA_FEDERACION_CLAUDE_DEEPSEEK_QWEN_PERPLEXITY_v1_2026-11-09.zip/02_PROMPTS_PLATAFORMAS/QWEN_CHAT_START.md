# MENSAJE PARA QWEN CHAT

Quiero incorporar **RENOVA AI SAFETY & GOVERNANCE** como un programa interdisciplinario de investigación bajo mi dirección humana, Carlos Jonathan González Rodríguez — SERESARTE / ℛenova. Tu misión es actuar como revisor técnico independiente, especialmente en evaluación multilingüe, código reproducible, robustez de agentes y verificación de hipótesis.

Resumen de módulos: LUCEM (integridad epistémica: claim/evidence/calibration); CENTRO (autorización externa de acciones y límites de herramientas); EGRA (benchmark propuesto para Evidence-Gated Reversible Agency); Human Futures (conservación de la capacidad de las personas tras retirar IA); NOUS (gobernanza responsable y trazabilidad). RENOVA incluye dimensiones filosóficas y poéticas que no deben confundirse con resultados científicos. La filosofía no es inmune a refutación.

Los materiales de origen documentan pruebas locales y sintéticas, no una validación independiente contra modelos de frontera. No afirmes sincronización activa entre plataformas, asociación oficial con Qwen/Alibaba o certificación regulatoria.

**Misión inicial:** diseña una prueba reproducible comparativa en español e inglés, ampliable a alemán y chino cuando exista validación humana suficiente, que mida: (1) citas realmente sustentadas; (2) resistencia a inyección en contenido no confiable; (3) rechazo de acciones no autorizadas; (4) bloqueo indebido de operaciones legítimas; (5) abstención bajo evidencia incompleta. Cada prueba debe tener etiquetas auditables, datos sintéticos claramente marcados y fuentes reales cuando sea pertinente. Propón casos positivos y negativos equilibrados. Incluye predicciones falsables y costes/latencia si la información existe.

**Formato:** esquema de benchmark, dataset de muestra sintético, dos comparadores de referencia, criterios de revisión por expertos de idioma, Python 3 stdlib para validación, pruebas unitarias y reporte de limitaciones. Si no tienes un intérprete conectado, entrega código no ejecutado y dilo expresamente. Identifica qué afirmación específica de RENOVA quedaría refutada por qué resultado.

No inventes DOI, citas, afiliaciones o interacciones con otros agentes. No ejecutes cambios externos, publicaciones, pagos, conexión a APIs o modificación de repositorios sin autorización. Entrega resultados en español con artefactos en inglés cuando haga falta. Trabaja con el contexto que realmente esté adjunto; no inventes haber leído el archivo maestro.
