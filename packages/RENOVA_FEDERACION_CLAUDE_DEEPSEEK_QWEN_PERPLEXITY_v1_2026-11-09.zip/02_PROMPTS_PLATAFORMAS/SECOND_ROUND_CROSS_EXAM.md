# SEGUNDA RONDA — INTERROGATORIO CRUZADO (igual para los 4 modelos)

Recibirás hasta tres informes producidos por otros sistemas (sin identidad privada y con permiso del titular). No debes suponer que los conoces, que fueron ejecutados o que recibiste un paquete FED-21 de forma automática: solo puedes analizar los textos realmente adjuntos.

1. Identifica contradicciones específicas entre informes, y diferencia desacuerdo metodológico de error factual.
2. Recalcula o solicita datos para cualquier cifra o efecto cuantitativo. No uses votación por mayoría de modelos como criterio de verdad.
3. Selecciona la crítica más fuerte contra RENOVA y formula un experimento que podría confirmar o refutar su relevancia.
4. Encuentra las cinco referencias que deben verificarse en fuentes originales. Corrige DOI/enlaces o clasifícalos no verificados.
5. Presenta una propuesta de integración **sin ejecutar** en un repositorio: archivos modificables, contratos, tests, responsables, riesgos y gates.
6. Devuelve resultados en `07_PLANTILLAS/CONTRIBUTION_TEMPLATE.md`, registrando modelo, versión, configuración y fecha si están disponibles.

No afirmes conexión real entre modelos; la presente revisión constituye una actividad documental humana.
