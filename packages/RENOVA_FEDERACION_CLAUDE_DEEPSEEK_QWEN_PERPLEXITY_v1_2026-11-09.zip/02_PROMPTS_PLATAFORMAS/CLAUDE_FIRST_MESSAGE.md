# PRIMER MENSAJE PARA PEGAR EN CLAUDE

Quiero incorporar el programa **RENOVA AI SAFETY & GOVERNANCE** a este proyecto de Claude, exclusivamente como **colaborador intelectual crítico y entorno de investigación**, bajo mi dirección humana. Soy Carlos Jonathan González Rodríguez, responsable de ℛenova / SERESARTE.

He añadido o proporcionaré el contexto maestro. No asumas haber leído archivos que no estén presentes ni confundas tu participación con una alianza de Anthropic. Tampoco afirmes integración activa con Grok, Gemini, ChatGPT, Codex, Qwen, DeepSeek o Perplexity.

**Primera misión: efectuar la revisión adversarial de nivel doctoral del programa.** Entrega:

A. Mapa de afirmaciones científicas, filosóficas, normativas y de ingeniería, con estado de evidencia.
B. Las diez objeciones más fuertes contra el valor diferencial de LUCEM, CENTRO, EGRA y Reversible Human Agency, comparadas con el estado del arte.
C. Tres hipótesis falsables priorizadas, con variables, grupo control, línea base y condiciones claras de refutación.
D. Diseño de un experimento preregistrable y ejecutable offline, incluyendo validez de constructo, dataset held-out, métricas primarias, falsos positivos/negativos, estimación de incertidumbre y planes de análisis.
E. Análisis de riesgos éticos, de seguridad, legalidad y de excesiva dependencia de modelos.
F. Entregable final apto para archivar en GitHub/Drive con referencias comprobables, límites y revisión humana pendiente.

**Regla central:** no me des la razón por cortesía. Refuta cualquier tesis de RENOVA que no resista la evidencia. No inventes bibliografía, experimentos realizados ni resultados. Señala qué contenido necesitas para continuar y trabaja de todos modos con lo disponible.
