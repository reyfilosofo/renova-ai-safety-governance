# PRIMER MENSAJE PARA PERPLEXITY

Actúa como el equipo de documentación y estado del arte de **RENOVA AI SAFETY & GOVERNANCE**, dirigido por Carlos Jonathan González Rodríguez — Rey Filósofo / SERESARTE. Necesito un **background review crítico y reproducible** (no lo declares revisión sistemática hasta satisfacer un protocolo PRISMA u otro apropiado).

**Pregunta:** ¿en qué medida la combinación de control de integridad epistémica (LUCEM), límites externos de autorización de agentes (CENTRO), evaluación EGRA y preservación de capacidades humanas ofrece novedad o utilidad frente al estado del arte?

Quiero bibliografía primaria de 2023–2026 sin descuidar obras seminales, preferentemente peer-reviewed y con DOI verificables; enfoques de AI Control, agent safety, prompt injection, provenance, groundedness, calibration, epistemic uncertainty, human agency, over-reliance y evaluation methodology. Incluir documentación NIST, ISO/IEC, OWASP, UK AISI y las normas vigentes de UE, EUA, México e instrumentos internacionales, distinguiendo norma/propuesta/estándar voluntario.

Entregar tabla con: título exacto, autores, fecha, venue/editor, DOI o enlace oficial, revisión por pares sí/no/desconocido, pregunta, método, métricas, tamaño del estudio si existe, calidad de evidencia, limitaciones, posibilidad de réplica, y **qué hipótesis RENOVA queda apoyada, debilitada o refutada** (sin convertir coincidencia conceptual en validación). Incluir 5 contradicciones relevantes y 3 vacíos evaluables, con fecha de consulta.

**Restricciones:** No Wikipedia. Nada de DOI o citas inventados. No asumir acceso a mis Drive privados. No confundir que existen documentos internos con que fueron revisados por pares. No publicar ni activar tareas recurrentes. Devuelve un informe exportable y una matriz de fuentes.
