# REPORTE QA DEL KIT LOCAL — 2026-11-09

**Alcance:** ejecución local en sandbox Python, no ejecución de modelos externos ni validación científica.

## Unit tests

Command: `python3 -m unittest discover -s tests -v`
Exit: `0`

```text
test_example_valid (test_fed21.TestFederationContract.test_example_valid) ... ok
test_expires_after_creation (test_fed21.TestFederationContract.test_expires_after_creation) ... ok
test_fake_acknowledgement_fails (test_fed21.TestFederationContract.test_fake_acknowledgement_fails) ... ok
test_invalid_operation_fails (test_fed21.TestFederationContract.test_invalid_operation_fails) ... ok
test_missing_required_field (test_fed21.TestFederationContract.test_missing_required_field) ... ok
test_no_unapproved_target_creation (test_fed21.TestFederationContract.test_no_unapproved_target_creation) ... ok
test_prepared_fake_receipt_fails (test_fed21.TestFederationContract.test_prepared_fake_receipt_fails) ... ok
test_prepared_valid (test_fed21.TestFederationContract.test_prepared_valid) ... ok
test_timezone_required (test_fed21.TestFederationContract.test_timezone_required) ... ok
test_unknown_field (test_fed21.TestFederationContract.test_unknown_field) ... ok
test_valid_datetime (test_fed21.TestFederationContract.test_valid_datetime) ... ok
test_wrong_project_fails (test_fed21.TestFederationContract.test_wrong_project_fails) ... ok

----------------------------------------------------------------------
Ran 12 tests in 0.001s

OK
```

## FED-21 packet creation

Command: `python3 06_CODIGO/fed21_cli.py new --target QWEN --output <temporary-file>`
Exit: `0`
Output: `CREATED_LOCAL_PREPARED: /tmp/tmpshtaeggv/test_prepared.json (NOT SENT)`

## FED-21 validation

Exit: `0`
Output: `VALID_LOCAL_STRUCTURE (NOT PROVIDER-AUTHENTICATED): /tmp/tmpshtaeggv/test_prepared.json`

## DeepSeek API dry run

Exit: `0`
Output:

```text
DRY_RUN_ONLY: NO NETWORK, NO KEY REQUIRED
Provider: deepseek | prompt length: 15119 chars
To send, manually review files, accept API costs and run --execute.
```

**No API keys used; no API call or provider receipt.** All validation results apply solely to the local kit.
