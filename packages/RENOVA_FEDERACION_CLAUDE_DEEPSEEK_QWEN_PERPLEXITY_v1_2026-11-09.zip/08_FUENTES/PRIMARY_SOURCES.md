# Fuentes primarias y documentos fundacionales — índice de consulta

## Fuentes propias proporcionadas (privadas; no incluidas en este ZIP)

- `RENOVA_AI_SAFETY_GOVERNANCE_MASTER_2026-11-09_UNDER20MB.zip`: corte documental 2026-11-09. Consultados: `00_COMIENZA_AQUI/{README,ESTADO_EJECUTIVO,FALTANTES_Y_LIMITACIONES,FUENTES_Y_ENLACES}`; `03_RESEARCH_PACK_V0_1/CHARTER_PROGRAMA_ES.md` y `research/PROTOCOLO_EGRA_001_ES.md`; `02_HUMAN_FUTURES_V1_0/02_PROTOCOL/ESTUDIO_AGENCIA_HUMANA_ES.md`; `01_FEDERATED_V2_2_CANON_2026_10_24/.../08_FEDERACION/{PROTOCOL.md,CANON_PUBLIC.json,packet.schema.json}`.
- `RENOVA_2026-11-09_08_REGISTROS_DRIVE_AUTENTICADOS.zip`: registros de federación y liberaciones, con estados de origen y limitaciones explícitas.
- Repositorio de referencia del titular: https://github.com/reyfilosofo/renova-agent (enlace público; verificar PR, commit y branch al extraer evidencia).

## Referencias técnicas y científicas de partida (no prueba de eficacia de RENOVA)

- NIST AI Risk Management Framework 1.0: https://www.nist.gov/itl/ai-risk-management-framework
- NIST GenAI Profile: https://airc.nist.gov/docs/NIST.AI.600-1.GenAI-Profile.ipd.pdf (comprobar URL/documento vigente con NIST antes de citar)
- ISO/IEC 42001 overview: https://www.iso.org/standard/42001
- EU AI Act — Reglamento (UE) 2024/1689: https://eur-lex.europa.eu/eli/reg/2024/1689/oj
- OWASP GenAI project: https://genai.owasp.org/
- UK AI Security Institute Inspect: https://inspect.aisi.org.uk/
- Greenblatt et al., AI Control (ICML 2024): https://proceedings.mlr.press/v235/greenblatt24a.html
- AgentDojo (NeurIPS 2024): https://openreview.net/forum?id=m1YYAQjO3w
- Farquhar et al., Nature (2024), DOI **10.1038/s41586-024-07421-0**: https://doi.org/10.1038/s41586-024-07421-0
- UNESCO Recommendation on the Ethics of AI (2021): https://www.unesco.org/en/artificial-intelligence/recommendation-ethics
- OECD AI Principles: https://oecd.ai/en/ai-principles

## Estado de referencias

Son *semillas de búsqueda* derivadas de materiales originales y documentación oficial. Antes de enviar informes académicos, volver a abrir cada referencia, comprobar metadatos y estatus editorial, y no inventar una revisión sistemática. No usar Wikipedia. Las normas no otorgan aval o certificación por el mero hecho de haber sido citadas.
