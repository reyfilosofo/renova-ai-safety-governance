import json
import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "06_CODIGO"))
from fed21_cli import new_packet, validate, parse_dt

class TestFederationContract(unittest.TestCase):
    def setUp(self):
        self.p = new_packet("CLAUDE", "Critically review EGRA science and its falsifiers")

    def test_prepared_valid(self):
        self.assertEqual(validate(self.p), [])

    def test_example_valid(self):
        sample = json.loads((ROOT / "05_FEDERACION" / "example_PREPARED.json").read_text())
        self.assertEqual(validate(sample), [])

    def test_missing_required_field(self):
        self.p.pop("mission")
        self.assertTrue(validate(self.p))

    def test_unknown_field(self):
        self.p["new_field"] = "hello"
        self.assertTrue(validate(self.p))

    def test_fake_acknowledgement_fails(self):
        self.p["state"] = "ACKNOWLEDGED"
        self.assertTrue(validate(self.p))

    def test_prepared_fake_receipt_fails(self):
        self.p["provider_receipt_id"] = "fabricated-receipt"
        self.assertTrue(validate(self.p))

    def test_wrong_project_fails(self):
        self.p["project_id"] = "OTHER"
        self.assertTrue(validate(self.p))

    def test_invalid_operation_fails(self):
        self.p["requested_operation"] = "DEPLOY"
        self.assertTrue(validate(self.p))

    def test_timezone_required(self):
        self.p["created_at"] = "2026-11-09T10:00:00"
        self.assertTrue(validate(self.p))

    def test_expires_after_creation(self):
        self.p["expires_at"] = self.p["created_at"]
        self.assertTrue(validate(self.p))

    def test_no_unapproved_target_creation(self):
        with self.assertRaises(ValueError):
            new_packet("UNKNOWN", "Review research and provide evidence")

    def test_valid_datetime(self):
        self.assertIsNotNone(parse_dt("2026-11-09T22:43:00-06:00"))

if __name__ == "__main__":
    unittest.main()
