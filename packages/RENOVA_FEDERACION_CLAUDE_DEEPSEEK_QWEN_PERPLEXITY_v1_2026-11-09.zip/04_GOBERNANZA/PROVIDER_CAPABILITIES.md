# Compatibilidad documental de proveedores — comprobación al 9/nov/2026

**ATENCIÓN:** las interfaces y planes evolucionan; esta matriz contiene indicaciones de *fuentes oficiales* consultadas durante el armado del kit. Corrobora opciones disponibles dentro de cada cuenta. No se accedió a tus cuentas personales ni se instalaron proyectos.

| Plataforma | Uso adecuado ahora | No inferir |
|---|---|---|
| Claude | `https://claude.ai/projects`, instrucciones de proyecto y conocimiento compartido dentro de ese proyecto. Documentos y textos admitidos; límites por plan y modalidad. | Compartición automática entre proyectos, acceso a GitHub/Drive no concedido, contrato de colaboración con Anthropic. |
| DeepSeek | `https://chat.deepseek.com` para conversar; API de texto OpenAI-compatible en `https://api.deepseek.com/chat/completions`. En el chat, pegar Markdown si no hay subida admisible. | Que `/files` de API acepte Markdown o ZIP: documentación oficial recuperada lo restringe a imágenes; tampoco equivalencia entre app y API. |
| Qwen | `https://chat.qwen.ai`/`https://qwen.ai`; para ingeniería local **Qwen Code** usa `QWEN.md` jerárquico como contexto del repo. | Que un chat web guarde para siempre el contexto de otro chat o que QWEN.md afecte mágicamente al sitio web. |
| Perplexity | `https://www.perplexity.ai` → **Proyectos** (antes Spaces), archivos persistentes y custom instructions. Instrucciones de proyecto hasta 8000 caracteres en documentación consultada. | Que las fuentes indexadas equivalgan a comprobación del documento original o que exista acceso a otros proveedores. |

## Fuentes originales de compatibilidad

- Anthropic: https://support.claude.com/en/articles/9519177-how-can-i-create-and-manage-projects
- Anthropic tipos de archivos: https://support.anthropic.com/en/articles/8241126-what-kinds-of-documents-can-i-upload-to-claude-ai
- DeepSeek primer request: https://api-docs.deepseek.com/quick_start/agent_integrations/
- DeepSeek Files API: https://api-docs.deepseek.com/guides/files_api/
- Qwen Code context: https://qwenlm.github.io/qwen-code-docs/en/users/configuration/settings/
- Qwen Code commands: https://qwenlm.github.io/qwen-code-docs/en/users/features/commands/
- Perplexity Projects: https://www.perplexity.ai/help-center/es/articles/10352961-que-son-los-espacios
- Perplexity platform changelog: https://www.perplexity.ai/changelog/shared-workspaces-personal-computer-for-windows-and-model-council

Las capacidades se citan por documentación técnica, no por un acceso autenticado dentro de cada proveedor. La plataforma puede cambiar de nombre, límites o interfaz y distintas cuentas pueden tener experiencias diferentes.
