# Release gates interplataforma

- **G0 Derechos y privacidad:** inventario de fuentes, PII y secretos; aprobación del titular al destino exacto. `PENDING`.
- **G1 Contexto y origen:** README + contexto + versionado, hashes correctos. Kit local `CREATED`, instalación remota `PENDING`.
- **G2 Identidad y permisos:** servicio y cuenta comprobados, scopes mínimos. `PENDING`.
- **G3 Receipts y readback:** si existe transporte autenticado, ID real de recepción, lectura de confirmación y registro inmutable. `PENDING`; no existe en este kit.
- **G4 Evaluación técnica:** pruebas locales, amenazas y fallos documentados. Ejecutar por separado para cada integración, nunca inferir por paquete original.
- **G5 Validación científica:** evaluador externo, dataset independent held-out, baselines, errores e incertidumbre. `PENDING`.
- **G6 Revisión legal/editorial y publicación:** titular decide licencia, coautorías, reservas y autorización. `PENDING`.

## Semántica de decisión

`DRAFT` = material preparado sin validación. `READY_FOR_HUMAN_REVIEW` = no hay acciones externas, entregables para decisión. `BLOCKED` = no autorizar avance por gate crítico. `APPROVED_FOR_SPECIFIC_ACTION` = aprobación documentada del titular limitada a acción/destino/fecha. Las acciones deben producir evidencias independientes y poder revocarse cuando sea posible.
