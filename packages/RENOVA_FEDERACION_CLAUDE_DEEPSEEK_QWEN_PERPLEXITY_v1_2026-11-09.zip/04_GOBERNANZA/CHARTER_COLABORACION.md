# Carta de colaboración intermodelo — documento de trabajo, no convenio

## Propósito

Permitir contribuciones técnicas y científicas producidas mediante distintas familias de modelos a RENOVA AI SAFETY & GOVERNANCE, sin asumir afiliación institucional, interoperabilidad espontánea o superioridad por consenso. La autoridad humana recae en el titular y, cuando corresponda, órganos competentes.

## Principios

**P1 Independencia crítica:** los modelos no deben adular ni proteger el paradigma. Pueden recomendar abandonar hipótesis.  
**P2 Falsabilidad:** toda propuesta científica define límites, medición y condición de refutación.  
**P3 Seguridad de acciones:** una respuesta persuasiva no sustituye permisos; enforcement fuera del LLM.  
**P4 Integridad de evidencia:** fuente, afirmación, inferencia y fecha no son intercambiables.  
**P5 Conservación de agencia humana:** medir capacidad sin asistencia, no solo productividad asistida.  
**P6 Privacidad y propiedad intelectual:** minimizar, revisar y autorizar cada canal externo.  
**P7 Reproducibilidad:** resultados ejecutados y diseñados deben distinguirse.  
**P8 Reversibilidad:** no alterar cuentas, repositorios productivos, archivos compartidos o identidad digital sin autorización y rollback.  
**P9 Disenso productivo:** desacuerdos se resuelven con datos, no votando por el modelo mayoritario.  
**P10 Gobernanza comprobable:** conservar event logs, versiones, estados, revisores humanos y conflictos de interés.

## Rangos de evidencia

VERIFICADO · DOCUMENTADO · EXPERIMENTAL · HIPÓTESIS · ESPECULATIVO · NO VERIFICADO · REFUTADO.  
El estatus debe estar asociado a una **afirmación concreta**, no al prestigio general de un proyecto o modelo.

## Derechos y usos

Este documento es un borrador para evaluación privada por el titular. No otorga representación contractual a Anthropic, DeepSeek, Alibaba, Perplexity, OpenAI ni otras organizaciones; no crea relación laboral, institucional o científica oficial. La selección de licencia de código, publicaciones, uso comercial y cesiones corresponde al titular humano.

## Producto mínimo de la colaboración

Un dossier versionado: pregunta y alcance, originales leídos, datos y configuración, refutaciones y contraargumentos, código/protocolo, métricas, controles de seguridad, errores, incertidumbre y decisión humana. Dossier sin evidencia es un borrador, no un hallazgo validado.
