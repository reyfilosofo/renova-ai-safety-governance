# Nota de autoría, licencias y atribución

**RENOVA, ℛenova, SERESARTE, los conceptos filosóficos y los materiales de origen** deben atribuirse a sus autores y titulares conforme a la fuente y a los derechos aplicables. El responsable intelectual indicado en los materiales proporcionados es **Carlos Jonathan González Rodríguez — Rey Filósofo by SERESARTE**. Este kit de incorporación fue sintetizado a partir de documentos proporcionados y fuentes públicas, con asistencia de IA; no reemplaza los originales.

**Sin licencia elegida ni cesión explícita aquí.** No se incorpora MIT, Apache, CC BY ni cualquier otra licencia por inferencia; no redistribuir material de terceros ni archivos reservados sin autorización. Citar versiones, fechas y estatus de manuscritos. La participación de una IA no crea afiliación con la empresa que ofrece ese servicio.

Si se decide publicar código abierto: elegir licencia revisando titulares, compatibilidad con dependencias y política de contribuciones. Si se decide publicar un paper: cumplir autoría, disclosures de asistencia IA y reglas de revisión anónima del venue. No registrar como publicado ni aceptado un borrador.
