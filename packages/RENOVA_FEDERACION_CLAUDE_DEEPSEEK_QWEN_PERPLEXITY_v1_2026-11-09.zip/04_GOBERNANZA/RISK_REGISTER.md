# Registro inicial de riesgos — para adaptación y revisión humana

| Riesgo | Amenaza/activo | Control propuesto | Residual abierto | Dueño |
|---|---|---|---|---|
| R-01 | Copiar material privado al chat de tercero | G0 de clasificación + revisión de ToS y cuentas | Retención/tratamiento del proveedor | Titular |
| R-02 | Reclamaciones científicas infladas | Registro claim-evidence + peer review | Sesgo de confirmación | Líder de investigación |
| R-03 | Inyección de prompt en documentos | Separar datos de instrucciones; enforcement externo | Bypass en herramienta | Ingeniero autorizado |
| R-04 | Exfiltración de claves | Ninguna credencial en prompts/repositorios; escaneo preflight | Errores humanos | Propietario de secretos |
| R-05 | «Sincronía» falsamente atribuida | FED-21 con receipt real y readback | Registros incompletos | Responsable federación |
| R-06 | Benchmarks contaminados | Dataset held-out privado y revisión independiente | Leakage difícil de detectar | Auditor de evaluación |
| R-07 | Bloqueos excesivos | Medir false denial junto a unauthorized execution | Coste operativo | Investigador principal |
| R-08 | Jurisdicción regulatoria mal interpretada | Fuente oficial, fecha, counsel adecuado | Cambio de leyes | Revisor jurídico |
| R-09 | Dependencia humana no medida | P2/T sin IA, controles de exposición | Confusores externos | Comité ético |
| R-10 | Código generado vulnerable | CI, threat model, revisión humana y sandbox | Supply-chain | Mantenedor |
| R-11 | Transferencia de derechos insuficiente | Comprobar autoría/licencias de cada adjunto | Terceros no identificados | Editor responsable |
| R-12 | Conflicto de interés por auditoría comercial | Separación investigación/ventas, divulgación | Presión comercial | Gobernanza |

**Clasificación**: todos son riesgos *hipotéticos identificados*, no incidentes reales verificados. Ninguna tabla sustituye un risk assessment formal del contexto operativo.
