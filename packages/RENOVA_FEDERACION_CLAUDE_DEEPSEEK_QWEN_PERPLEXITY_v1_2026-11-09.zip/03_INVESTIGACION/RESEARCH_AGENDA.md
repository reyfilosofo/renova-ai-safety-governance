# RENOVA — Agenda de investigación comparable y falsable (2026-11-09)

**Categoría:** HIPÓTESIS / DISEÑO. No se informa ningún resultado nuevo de modelos reales ni estudio con personas.

## Línea A: LUCEM — integridad epistémica

**Hipótesis H-A:** Una cadena que exige evidencia verificable y clasifica soporte/contraevidencia reduce el número de afirmaciones materialmente no sustentadas comparada con (i) respuesta LLM sin control, (ii) RAG con cita, y (iii) verificador de entailment estándar.  
**Población/tarea:** preguntas de hechos, literatura, regulaciones y claims de riesgo en documentos.  
**Unidad:** afirmación atómica; medir también por respuesta (correlación intraclúster).  
**Gold labels:** doble codificación independiente y adjudicación; soporta/no soporta/contradice/no determinable; mapa de evidencia.  
**Primario:** tasa de afirmaciones no sustentadas ponderada por gravedad, preregistrada.  
**Secundarios:** tasas de abstención correcta/incorrecta; precisión y recall por clase; calibración (ECE/Brier si salida probabilística); latencia; coste; desigualdad por idioma.  
**Falsación:** no hay mejora sustantiva vs. baseline fuerte bajo intervalos definidos, o el coste de falsas abstenciones supera el umbral preregistrado.  
**Peligros:** gold set contaminado, citas plausibles pero espurias, búsqueda no reproducible, modelo evaluador comparte los sesgos del generador.

## Línea B: CENTRO — control independiente de autorizaciones

**Hipótesis H-B:** Un ejecutor que exige autorización externa específica por herramienta/acción reduce las acciones prohibidas ejecutadas frente a instrucción de prompt y control débil, sin bloqueo excesivo de casos legítimos.  
**Diseño:** misma tarea y propuesta enviada a variantes: LLM directo, prompt-only safeguard, enforcement externo; casos positivos y negativos, permiso cambiante, replay, inyección indirecta y diferencias por rol.  
**Outcomes:** número de acciones efectivamente ejecutadas sin permiso; bloqueo legítimo; tasa de bypass; secuencia propuesta/decisión/ejecución; tiempo y revisión humana.  
**Falsación:** bypass persistente, enforcement incongruente con policy, o falso bloqueo inadmisible; fallo de logs, race, idempotencia o scope.  
**Peligros:** registrar un 'DENY' en un log **no** prueba que el sistema físico haya bloqueado la ejecución. Distinguir decision from enforcement.

## Línea C: EGRA — beneficio diferencial integrado

**Hipótesis H-C:** Combinar LUCEM y CENTRO produce mejoras diferenciales respecto a módulos independientes y a enfoques integrados existentes, en un dominio concreto.  
**Diseño factorial 2×2:** ningún módulo, LUCEM, CENTRO, LUCEM+CENTRO; controlar herramientas, modelo y prompts; más un baseline fuerte independiente.  
**Primario:** compuesto sólo si su definición y pesos están preregistrados; preferible reportar dos métricas co-primarias para veracidad y permisos.  
**Falsación:** ausencia de beneficio incremental o daño inesperado; inconsistencia en alta severidad; generalización insuficiente.

## Línea D: Reversible Human Agency (RHA) — retención humana

**Hipótesis H-D:** Con igual tiempo y exposición, un asistente que ofrece andamiaje en lugar de respuesta completa mejora el rendimiento diferido sin IA.  
**Diseño propuesto, no ejecutado:** asignación aleatoria A respuesta IA, B andamiaje, C materiales no generativos; pretest P0, rendimiento asistido PA, postest sin IA P1, medida diferida P2, transferencia T.  
**Primario candidato:** puntuación P2 ajustada por P0, preregistrada; CIs y efecto diferencial.  
**Falsación:** diferencia nula o negativa, desaparece controlando exposición, daño de accesibilidad y equidad.  
**Requisitos éticos:** consentimiento, minimización, acceso, privacidad y revisión institucional según jurisdicción. No inventar participantes.

## Línea E: gobernanza socio-técnica / NOUS

**Pregunta:** ¿La trazabilidad de la decisión y del fundamento facilita revisión humana y resolución de discrepancias?  
**Diseño propuesto:** auditores humanos comparan registros con y sin provenance/instrucciones claras, asignación aleatoria y doble adjudicación.  
**Medidas:** exactitud de juicio, tiempo, desacuerdo, reversibilidad, transparencia evaluada con instrumento validado cuando exista.  
**Falsación:** la traza no aporta mejora o induce exceso de confianza injustificado.

## Línea F: multilingüismo y distribución desplazada

Comparar ES, EN, DE, ZH mediante equivalencia semántica de casos revisada por expertos, no traducción automática sin control. Estratificar por tarea, idioma y habilidad del usuario; preservar diferencias socioculturales. No inferir generalización al mundo hispanohablante a partir de un conjunto sintético pequeño.

## Orden de prioridad propuesto

1. Auditoría bibliográfica de novedades, construct validity y claims (Claude + Perplexity).
2. Harness offline de límites de permisos (DeepSeek + Qwen), independiente y en sandbox.
3. LUCEM fact-checking con dos anotadores independientes y baseline (todos, tareas ciegas).
4. preregistro EGRA-002 multilingüe y RHA (sujeto a autorización ética/recursos).
5. revisión externa, preprint con métodos y limitaciones; nunca reivindicar certificación.

## Ficha preregistro resumida

`study_id`, `revision`, `PI`, `question`, `hypothesis`, `domain`, `sampling_frame`, `exclusions_predeclared`, `primary_outcome`, `secondary_outcomes`, `condition_assignments`, `baselines`, `gold_label_procedure`, `power_or_sample_rationale`, `random_seed`, `analysis_plan`, `alpha_and_correction`, `CIs`, `stopping_rule`, `ethics`, `adverse_event_handling`, `software_hash`, `deviations`, `dissemination_plan`, `reviewers`.
