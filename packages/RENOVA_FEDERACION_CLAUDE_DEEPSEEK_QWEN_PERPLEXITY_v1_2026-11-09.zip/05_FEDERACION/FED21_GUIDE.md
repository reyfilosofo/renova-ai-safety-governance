# FED-21 — Contrato documental y límites de interoperabilidad

**Base:** protocolo original FED-21 2.1 del archivo maestro privado, 24/oct/2026. **Estado de esta implementación:** utilidad offline parcial; no provider authentication, send, receipt ni readback implementados.

El contrato impide un error semántico esencial: preparar un mensaje *para* Claude/DeepSeek/Qwen/Perplexity **NO** equivale a enviarlo ni a que lo hayan recibido. El estado inicial es `PREPARED`. Los campos son: packet_id; schema_version=2.1; created_at; expires_at; source_node; target_node; project_id=RENOVA-AI-SAFETY-GOVERNANCE; data_classification; mission; requested_operation; source_refs; state; provider_receipt_id; readback_verified. Las únicas operaciones de la fase documental son READ, ANALYZE, REVIEW, PROPOSE_PATCH.

| Estado | Evidencia mínima | Se puede inferir de un archivo local |
|---|---|---|
| PREPARED | JSON generado/validado localmente | Sí |
| DISPATCHED | Solicitud concreta registrada por servicio autenticado, identificada inequívocamente | No |
| ACKNOWLEDGED | Recibo auténtico del proveedor + lectura de destino verificada | No |
| REJECTED | Rechazo real o decisión documentada | Sólo decisión local si se aclara |
| EXPIRED | Fecha de vigencia superada y constatada | Sí, semántica local |

## Restricciones

`PUBLIC` no significa «publicado»: solo puede ser *candidato* para un canal público. `INTERNAL` y `CONFIDENTIAL` requieren canales privados con destinatario, permisos y finalidad autorizados. Cualquier autorización de envío, escritura, publicación, pagos, cambios de permisos o despliegue debe ser externa al LLM y atribuible a identidad humana válida.

## Interoperabilidad propuesta (no activada)

1. Identidad y alcance por proveedor, permisos mínimos y expiración.
2. Payload schema + nonce/replay defense + idempotency + rate limits.
3. Transporte auditado y recibos autenticados con lectura independiente de destino.
4. Controles de clasificación, cifrado y minimización.
5. Revisión humana de acciones y reglas de rollback.
6. Pruebas externas de falsos acuses, duplicación, revocación, injection y fuga.

**El código incluido solo crea y valida mensajes PREPARED; no modifica sistemas remotos.**
