# ℛENOVA AI SAFETY & GOVERNANCE — FEDERACIÓN MULTIMODELO v1.0

**Corte:** 2026-11-09 (America/Mexico_City) · **Preparado por:** programa RENOVA × SERESARTE · **Dirección intelectual:** Carlos Jonathan González Rodríguez (Rey Filósofo).  
**Estado:** DOCUMENTADO / KIT DE INCORPORACIÓN NO DESPLEGADO · **Clasificación:** candidato a distribución controlada por el titular; NO implica licencia abierta ni autorización de publicación.  
**Repositorio de referencia:** https://github.com/reyfilosofo/renova-agent

## Qué se construyó y para qué

Este paquete proporciona un punto de entrada coherente y auditable para introducir el programa **RENOVA AI SAFETY & GOVERNANCE** en **Claude, DeepSeek, Qwen y Perplexity**, y solicitar contribuciones independientes sin confundir el razonamiento de un modelo con evidencia científica. Contiene: contexto de investigación bilingüe, cuatro prompts completos, modos de instalación, agenda experimental, evaluaciones, esquemas de mensajes federados, CLI offline, pruebas y plantillas de devolución.

**El paquete fue creado localmente; no se ha enviado automáticamente a ninguno de esos proveedores.** No hay conexión API viva, transferencia automática de estado, memoria federada ni aprobación institucional de los proveedores.

## Forma más fácil de empezar (sin programación)

1. **Lee `00_INICIO/SEGURIDAD_ANTES_DE_COMPARTIR.md`.** Ningún prompt autoriza divulgar secretos, manuscritos privados o datos de clientes.
2. En Claude crea un proyecto nuevo y pega `02_PROMPTS_PLATAFORMAS/CLAUDE_PROJECT_INSTRUCTIONS.md` en instrucciones de proyecto. Añade a la base de conocimiento `01_NUCLEO/MASTER_CONTEXT_ES.md`, `01_NUCLEO/MASTER_CONTEXT_EN.md` y `03_INVESTIGACION/RESEARCH_AGENDA.md`; envía `CLAUDE_FIRST_MESSAGE.md` al primer chat.
3. En DeepSeek abre un chat nuevo y pega `DEEPSEEK_START.md` (más el contexto maestro si la interfaz permite archivo de texto). Las capacidades de archivo de la app y de la API no se deben asumir idénticas.
4. En Qwen Chat pega `QWEN_CHAT_START.md`. Para Qwen Code, coloca `QWEN.md` en la raíz de una **copia local de trabajo autorizada** del proyecto. Evita activar herramientas de escritura y red sin revisión.
5. En Perplexity crea un **Proyecto** privado, pega `PERPLEXITY_PROJECT_INSTRUCTIONS.md` y adjunta el contexto maestro y la agenda de investigación. Envía `PERPLEXITY_FIRST_MESSAGE.md` para comenzar la búsqueda primaria.
6. Solicita **respuestas separadas**. Exporta o copia cada resultado a `07_PLANTILLAS/CONTRIBUTION_TEMPLATE.md`. No fusionar por mayoría de votos.
7. Revisa hechos, permisos, reproducibilidad y límites. Si procede, crea un PR *draft* para revisión humana; no hacer merge/desplegar/publicar automáticamente.

## Para trabajo con código local (opcional)

```bash
python3 06_CODIGO/fed21_cli.py new --target CLAUDE --output ejemplo_claude.json
python3 06_CODIGO/fed21_cli.py validate ejemplo_claude.json
python3 -m unittest discover -s tests -v
python3 06_CODIGO/check_manifest.py MANIFEST_SHA256.json
```

El CLI crea **paquetes documentales locales PREPARED**. No realiza llamadas de red, envíos, escrituras externas ni transacciones. La validación incluida es del subconjunto contractual definido en el kit y no constituye una auditoría de seguridad completa de FED-21.

## Documentos recomendados según proveedor

| Proveedor | Inicio | Memoria/contexto | Investigación inicial |
|---|---|---|---|
| Claude | `CLAUDE_FIRST_MESSAGE.md` | `CLAUDE_PROJECT_INSTRUCTIONS.md` + 2 contextos | Refutar diseño EGRA y proponer comparación |
| DeepSeek | `DEEPSEEK_START.md` | Reenviar contexto en chat/API | Diseñar harness offline, pruebas de gate |
| Qwen | `QWEN_CHAT_START.md` | `QWEN.md` en Qwen Code | Pruebas multilingües, auditoría de código |
| Perplexity | `PERPLEXITY_FIRST_MESSAGE.md` | `PERPLEXITY_PROJECT_INSTRUCTIONS.md` | Estado del arte y DOI verificados |

## Fuente y límites de procedencia

Base documental consultada: archivo privado `RENOVA_AI_SAFETY_GOVERNANCE_MASTER_2026-11-09_UNDER20MB.zip` (373 entradas, 24.44 MB descomprimidos) y `RENOVA_2026-11-09_08_REGISTROS_DRIVE_AUTENTICADOS.zip` (3 registros), recibidos en esta conversación. Se analizaron contenidos seleccionados —carta fundacional, protocolo EGRA-001, estudio de agencia humana, estado ejecutivo, FED-21 y registro de privacidad—, **no se revalidaron científicamente las afirmaciones de todo el archivo**. Las cifras de pruebas históricas pertenecen a los registros originales; no se replican por haber generado este kit.

El paquete original se conserva separado: contiene material privado no adecuado para publicación masiva. Los textos de este kit son una **síntesis nueva** y no reproducen toda la colección histórica ni implican autorización de terceros.

## Definiciones de estado

- `VERIFICADO`: corroborado con evidencia directa y alcance declarado.
- `DOCUMENTADO`: consta en fuente identificable, sin garantía de validez externa.
- `EXPERIMENTAL`: probado en condiciones delimitadas, reportando configuración.
- `HIPÓTESIS`: formulación falsable sin resultado suficiente.
- `ESPECULATIVO`: interpretación o posibilidad no validada.
- `NO VERIFICADO`: evidencia insuficiente.
- `REFUTADO`: refutación delimitada y fundamentada.

## Puerta de salida

**Aprobación humana explícita requerida** para publicar materiales, compartir enlaces privados, conceder acceso, enviar mensajes a terceros, lanzar evaluaciones con coste, realizar desplegues o activar agentes. Puede compartirse con cada plataforma únicamente lo que el titular determine tras revisar su política de datos. Ninguna herramienta puede autoatribuirse representación legal, afiliación, aval ni autoridad institucional.
