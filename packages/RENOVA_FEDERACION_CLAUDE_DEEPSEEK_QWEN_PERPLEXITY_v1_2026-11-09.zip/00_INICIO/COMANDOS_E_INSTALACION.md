# Comandos y pasos por plataforma

**Modo seguro por defecto:** lectura y análisis, sin escrituras externas ni costes. Los comandos siguientes son para ejecutarse **manualmente en tu dispositivo** tras revisar su alcance; no fueron ejecutados contra los servicios externos.

## 1. Claude

Entra a https://claude.ai/projects, crea un proyecto de nombre `RENOVA AI SAFETY & GOVERNANCE`. En las instrucciones del proyecto pega `02_PROMPTS_PLATAFORMAS/CLAUDE_PROJECT_INSTRUCTIONS.md`; en conocimiento añade `01_NUCLEO/MASTER_CONTEXT_ES.md` y `03_INVESTIGACION/RESEARCH_AGENDA.md`, además de `MASTER_CONTEXT_EN.md` si quieres salida bilingüe. Usa `CLAUDE_FIRST_MESSAGE.md` en el primer chat. **No tienes que subir el ZIP maestro privado.** Documentación: https://support.claude.com/en/articles/9519177-how-can-i-create-and-manage-projects.

## 2. DeepSeek Web

Entra a https://chat.deepseek.com. Empieza con el texto completo de `02_PROMPTS_PLATAFORMAS/DEEPSEEK_START.md`; si está disponible cargar un texto o documento, añade `MASTER_CONTEXT_ES.md`. Si el chat no admite el archivo, copia su contenido por partes. No suponer memoria persistente de proyecto en todos los planes. La API de `files` documentada oficialmente acepta **imágenes**, no ZIP ni Markdown; la API de chat acepta mensajes de texto.

### DeepSeek API — ejecución MANUAL opcional y posiblemente de pago

**Preparación (Linux/macOS):**

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install openai
export DEEPSEEK_API_KEY='PEGA_LA_CLAVE_EN_TU_TERMINAL_NO_EN_EL_CHAT'
python3 06_CODIGO/provider_api_example.py --provider deepseek --dry-run
```

El archivo de ejemplo no llama a la API salvo que se pase explícitamente `--execute`. Solo si revisaste términos/coste y lo autorizas:

```bash
python3 06_CODIGO/provider_api_example.py --provider deepseek --execute
```

La salida debe inspeccionarse antes de compartirla con otras plataformas. No guardes la clave en Git ni dentro del ZIP.

## 3. Qwen

Web: https://qwen.ai. Abre un chat, pega `02_PROMPTS_PLATAFORMAS/QWEN_CHAT_START.md` y añade, si su interfaz lo admite, `MASTER_CONTEXT_ES.md`.

**Qwen Code (en un repositorio local con permisos mínimos):**

```bash
git clone https://github.com/reyfilosofo/renova-agent.git renova-agent-lectura
cd renova-agent-lectura
# Copia QWEN.md desde el kit solo a tu copia local.
# No hacer git add / commit / push sin revisar licencias y autorizaciones.
qwen
```

Este ejemplo asume que tienes instalado `git` y Qwen Code. Para evitar modificar el repo origen no ejecutes `/init` ni comandos con escrituras sin revisar. La presencia de `QWEN.md` en el árbol establece contexto de Qwen Code, **no activa el chat web de Qwen**. Fuente: https://qwenlm.github.io/qwen-code-docs/en/users/configuration/settings/.

## 4. Perplexity

Entra a https://www.perplexity.ai, crea un **Proyecto** privado `RENOVA AI SAFETY & GOVERNANCE`, pega `PERPLEXITY_PROJECT_INSTRUCTIONS.md` (redactado dentro del límite de 8000 caracteres descrito en su guía) y adjunta `MASTER_CONTEXT_ES.md`, `MASTER_CONTEXT_EN.md` y `RESEARCH_AGENDA.md`. Envía `PERPLEXITY_FIRST_MESSAGE.md`. El nombre histórico Spaces puede persistir en alguna interfaz, pero la documentación 2026 describe Proyectos. Fuente: https://www.perplexity.ai/help-center/es/articles/10352961-que-son-los-espacios.

## 5. Federación offline sin APIs

Desde la carpeta raíz del kit:

```bash
python3 06_CODIGO/fed21_cli.py new --target CLAUDE --output claude_prepared.json
python3 06_CODIGO/fed21_cli.py new --target DEEPSEEK --output deepseek_prepared.json
python3 06_CODIGO/fed21_cli.py new --target QWEN --output qwen_prepared.json
python3 06_CODIGO/fed21_cli.py new --target PERPLEXITY --output perplexity_prepared.json
python3 06_CODIGO/fed21_cli.py validate claude_prepared.json
python3 -m unittest discover -s tests -v
python3 06_CODIGO/check_manifest.py MANIFEST_SHA256.json
```

**Interpretación:** los JSON quedan en estado PREPARED; no son mensajes transmitidos. La opción `--execute` en el código API es deliberadamente ajena al flujo offline y solo se ejecuta con claves, consentimiento, revisión de privacidad y aceptación de posibles costes.

## 6. Retorno y revisión

Copia resultados reales de las sesiones en cuatro archivos privados independientes (p. ej. `claude_2026-11-09.md`). Adjunta modelo/versión, fecha, sources y prompts reales; aplica `CONTRIBUTION_TEMPLATE.md` y `CROSS_MODEL_COMPARISON.md`. No mezclar inferencias como si fueran resultados replicados. Proponer cambios en un PR *draft* solo con aprobación de destino y revisión de datos.
