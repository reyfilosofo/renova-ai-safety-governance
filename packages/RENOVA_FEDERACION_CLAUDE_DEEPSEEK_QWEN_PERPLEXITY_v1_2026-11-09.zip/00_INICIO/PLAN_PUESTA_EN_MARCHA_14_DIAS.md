# Despliegue documental y crecimiento — 14 días (propuesta, no calendario activado)

| Fase | Acciones | Evidencia de cierre | Estado al entregar |
|---|---|---|---|
| G0 | Autorizar alcance, clasificación y cuenta de cada proveedor | Revisión de derechos y privacidad firmada | PENDIENTE |
| G1 | Crear 4 proyectos/chats, instalar prompts, cargar contexto autorizado | Captura o export de instrucciones por proveedor | PENDIENTE |
| G2 | Solicitar a cada uno autocrítica, fallos y plan experimental | Cuatro reportes firmados con versión y modelo | PENDIENTE |
| G3 | Confrontar críticas con evidencia primaria y diseño EGRA | Matriz de convergencia/disenso, sin votación | PENDIENTE |
| G4 | Implementar 1 benchmark offline con comparadores y held-out | Código + fixtures + reporte reproducible | PENDIENTE |
| G5 | Auditor externo de método y seguridad | Documento de observaciones independiente | PENDIENTE |
| G6 | Decidir paquete público, licencia y PR draft | Acta de aprobación humana | PENDIENTE |

## Qué medir

Cuatro entregas con evidencia de sesión y modelo; cobertura de 12 casos de la matriz; tasa de afirmaciones verificadas vs. no verificadas; referencias primarias resueltas; concordancia entre evaluadores humanos; cantidad de hallazgos críticos reproducibles; costes reales registrados (si se usó API); cero acciones externas no autorizadas. No atribuir resultados antes de medir.

## Secuencia inteligente

Priorizar validación de LUCEM (integridad epistémica) y CENTRO (límites de autoridad), luego EGRA y RHA (agencia humana). Dejar comercialización e indicadores institucionales para después de comprobar los métodos. Las cuatro plataformas pueden actuar en paralelo **solo si el usuario ejecuta las sesiones o dispone de conectores autenticados**; este documento no los inicia.
