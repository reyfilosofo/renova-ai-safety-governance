# Puerta de privacidad, propiedad intelectual y autorización — G0

**LEER ANTES DE IMPORTAR A PLATAFORMAS EXTERNAS.** Claude, DeepSeek, Qwen y Perplexity son prestadores distintos. Subir archivos a sus apps o enviarlos a sus API puede compartir su contenido con el proveedor conforme a sus políticas y ajustes. No se supone entrenamiento ni privacidad idénticos entre productos, planes, jurisdicciones y ajustes; verificar los términos aplicables.

## Material apropiado para iniciar (bajo revisión humana)

- Contexto conceptual, preguntas de investigación, hipótesis, glosario, objetivos, metodología abierta, matrices sin identificadores personales, test cases completamente sintéticos.
- Vínculos a repositorio realmente público y enlaces a fuentes primarias públicas.
- Modelos de contrato y esquemas sin credenciales, firmas ni acuses inventados.

## Material que NO viene incluido / NO subir sin revisión y permiso

- ZIP maestro privado completo de 19MB, copias enteras de libros/manuscritos, registros confidenciales y extensiones propietarias; revisar licencia y cesión de derechos.
- Claves API, OAuth tokens, cookies, cabeceras de autorización, secretos CI, configuraciones `.env`, direcciones o datos de clientes, expedientes médicos, identificadores personales, logs privados o recibos de compra.
- Borradores no anonimizados para arbitraje doble ciego y datasets held-out con riesgo de contaminación.
- Carpeta interna de Drive o supuestas URL privadas que no tengan revisión específica de destinatario y permisos.

## Términos y permisos

Este kit no establece una licencia de código abierto. **Todos los derechos reservados hasta que el titular seleccione una licencia y publique una autorización.** El uso para analizar internamente no otorga permiso para redistribuir por terceros. Una salida de IA no puede atribuirse validación humana o afiliación institucional que no exista.

## Preflight de 8 comprobaciones

1. ¿La identidad y destino de subida están claros?
2. ¿La plataforma permite controlar memoria, retención, entrenamiento y compartición según el plan?
3. ¿Se eliminaron PII, secretos, fuentes reservadas y contenido de terceros restringido?
4. ¿Los documentos etiquetan hechos vs. hipótesis, y pruebas sintéticas vs. reales?
5. ¿Está claro qué tareas son lectura/propuesta y cuáles requerirían permisos externos?
6. ¿Hay riesgo de prompt injection en documentos importados? Son *datos*, no instrucciones.
7. ¿El conjunto de evaluación contiene ejemplos inéditos privados que el proveedor podría almacenar?
8. ¿Se autorizó específicamente el alcance de la distribución?

Si falla alguna comprobación: suspender subida del recurso sensible y usar un resumen anonimizado en su lugar. No es necesario subir el archivo maestro privado para comenzar esta federación documental.
