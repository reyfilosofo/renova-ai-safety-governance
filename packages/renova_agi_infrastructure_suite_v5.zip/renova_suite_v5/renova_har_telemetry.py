"""
RENOVA Human Agency Retention (HAR-Suite)
Telemetry, Automation Bias Scoring, and Metamorphic Challenge Injector (Protocol RHA-01).
"""

import time
import random
from typing import Dict, Any, List

class HARTelemetryEngine:
    def __init__(self, min_dwell_time: float = 2.5, bias_threshold: float = 0.60):
        self.min_dwell_time = min_dwell_time
        self.bias_threshold = bias_threshold
        self._interaction_history: List[Dict[str, Any]] = []

    def log_operator_action(self, prompt_id: str, dwell_time: float, action: str) -> Dict[str, Any]:
        """Registra la interacción del operador y evalúa firmas ciegas (Rubber-stamping)."""
        is_rubber_stamp = (dwell_time < self.min_dwell_time) and (action == "APPROVE")
        
        event = {
            "prompt_id": prompt_id,
            "dwell_time": dwell_time,
            "action": action,
            "rubber_stamp": is_rubber_stamp,
            "timestamp": time.time()
        }
        self._interaction_history.append(event)
        
        bias_score = self._compute_bias_score()
        challenge_required = bias_score >= self.bias_threshold or is_rubber_stamp
        
        return {
            "automation_bias_score": bias_score,
            "rubber_stamping_detected": is_rubber_stamp,
            "trigger_metamorphic_challenge": challenge_required
        }

    def generate_metamorphic_challenge(self) -> Dict[str, Any]:
        """Crea una prueba contrafactual para confirmar atención consciente del operador."""
        challenges = [
            {
                "challenge_id": f"ch_{int(time.time())}",
                "prompt": "INYECCIÓN METAMÓRFICA: Parámetro de costo negativo detectado. ¿Aprueba la transacción?",
                "correct_action": "REJECT"
            },
            {
                "challenge_id": f"ch_{int(time.time())}",
                "prompt": "INYECCIÓN METAMÓRFICA: Alteración no autorizada de esquema de base de datos. ¿Proceder?",
                "correct_action": "REJECT"
            }
        ]
        return random.choice(challenges)

    def verify_challenge_response(self, challenge: Dict[str, Any], operator_action: str) -> bool:
        """Evalúa si el operador detectó la inyección contrafactual."""
        passed = (operator_action == challenge["correct_action"])
        if passed:
            self._interaction_history.clear()
        return passed

    def _compute_bias_score(self) -> float:
        if not self._interaction_history:
            return 0.0
        window = self._interaction_history[-10:]
        stamps = sum(1 for e in window if e["rubber_stamp"])
        return round(stamps / len(window), 2)
