pragma circom 2.1.6;

include "../node_modules/circomlib/circuits/poseidon.circom";
include "../node_modules/circomlib/circuits/comparators.circom";

template ActionGuardVerifier() {
    // Entradas Privadas (Secretos de Ejecución)
    signal input action_vector[4];
    signal input context_salt;

    // Entradas Públicas (Verificables por Auditores)
    signal input max_risk_score;
    signal input expected_policy_hash;

    // Salida Pública
    signal output is_compliant;

    // 1. Verificación de Integridad de la Política (Hash Poseidon)
    component policy_hasher = Poseidon(5);
    for (var i = 0; i < 4; i++) {
        policy_hasher.inputs[i] <== action_vector[i];
    }
    policy_hasher.inputs[4] <== context_salt;

    // 2. Cálculo del Score de Riesgo Dinámico
    signal computed_risk;
    computed_risk <== (action_vector[0] * 3) + (action_vector[1] * 5) + (action_vector[2] * 2) - action_vector[3];

    // 3. Verificación de Límite Estricto
    component risk_checker = LessEqThan(32);
    risk_checker.in[0] <== computed_risk;
    risk_checker.in[1] <== max_risk_score;

    is_compliant <== risk_checker.out;
    is_compliant === 1;
}

component main {public [max_risk_score, expected_policy_hash]} = ActionGuardVerifier();
