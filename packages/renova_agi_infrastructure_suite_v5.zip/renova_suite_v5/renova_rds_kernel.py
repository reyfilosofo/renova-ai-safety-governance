"""
RENOVA Deterministic State Sandbox (RDS-Kernel) v5.0
Runtime isolation, Copy-on-Write state machine, and atomic rollback engine for autonomous AI agents.
"""

import copy
import time
import logging
from typing import Dict, Any, Callable, List

logging.basicConfig(level=logging.INFO, format='%(asctime)s - [RDS-KERNEL] - %(levelname)s - %(message)s')

class ActionExecutionError(Exception):
    """Excepción generada cuando una acción falla en la caja de arena."""
    pass

class RDSTransactionContext:
    def __init__(self, global_state: Dict[str, Any], transaction_id: str):
        self.transaction_id: str = transaction_id
        self._global_state_ref: Dict[str, Any] = global_state
        self.staged_state: Dict[str, Any] = copy.deepcopy(global_state)
        self.execution_log: List[Dict[str, Any]] = []
        self.is_committed: bool = False
        self.is_rolled_back: bool = False
        self.created_at: float = time.time()

    def stage_action(self, action_id: str, action_fn: Callable[[Dict[str, Any]], Dict[str, Any]]) -> Dict[str, Any]:
        """Ejecuta una acción dentro del espacio Copy-on-Write aislado."""
        if self.is_committed or self.is_rolled_back:
            raise ActionExecutionError(f"Transacción {self.transaction_id} ya se encuentra cerrada.")
        
        try:
            prev_snapshot = copy.deepcopy(self.staged_state)
            self.staged_state = action_fn(self.staged_state)
            
            diff = {
                "keys_added": list(set(self.staged_state.keys()) - set(prev_snapshot.keys())),
                "keys_modified": [k for k in self.staged_state if k in prev_snapshot and self.staged_state[k] != prev_snapshot[k]],
                "keys_removed": list(set(prev_snapshot.keys()) - set(self.staged_state.keys()))
            }
            
            log_entry = {
                "action_id": action_id,
                "timestamp": time.time(),
                "diff": diff
            }
            self.execution_log.append(log_entry)
            logging.info(f"Acción '{action_id}' montada en sandbox [{self.transaction_id}]. Diff: {diff}")
            return {"status": "STAGED", "action_id": action_id, "diff": diff}
            
        except Exception as e:
            self.rollback(f"Fallo durante ejecución de acción {action_id}: {str(e)}")
            raise ActionExecutionError(f"Error en sandbox: {str(e)}")

    def commit(self, pdp_authorization_token: str) -> Dict[str, Any]:
        """Consolida atómicamente los cambios del sandbox al estado global de producción."""
        if self.is_committed or self.is_rolled_back:
            raise ActionExecutionError(f"Transacción {self.transaction_id} inactiva.")
            
        if not pdp_authorization_token.startswith("ALLOW_"):
            return self.rollback("Token de autorización PDP inválido o rechazado.")

        self._global_state_ref.clear()
        self._global_state_ref.update(self.staged_state)
        self.is_committed = True
        logging.info(f"COMMIT Exitoso en transacción [{self.transaction_id}]. Estado global actualizado.")
        return {"status": "COMMITTED", "transaction_id": self.transaction_id, "timestamp": time.time()}

    def rollback(self, reason: str) -> Dict[str, Any]:
        """Descarta todos los cambios del sandbox y restaura la memoria intacta."""
        self.staged_state.clear()
        self.execution_log.clear()
        self.is_rolled_back = True
        logging.warning(f"ROLLBACK ejecutado en transacción [{self.transaction_id}]. Causa: {reason}")
        return {"status": "ROLLED_BACK", "transaction_id": self.transaction_id, "reason": reason}
