"""
RENOVA BioLegitimacy Interop Protocol (BLIP Engine)
Quantifies bio-ecological impacts and computes Biospheric Viability Index (IVB) per GOV OS v3.
"""

from pydantic import BaseModel, Field
from typing import Dict, Any

class BioLegitimacyMetrics(BaseModel):
    vital_capacity_created: float = Field(..., ge=0.0, le=10.0, description="Variable C")
    habitat_integrity: float = Field(..., ge=0.0, le=10.0, description="Variable H")
    renovative_horizon: float = Field(..., ge=0.0, le=10.0, description="Variable O")
    irreversible_degradation: float = Field(..., ge=0.0, le=10.0, description="Variable D")
    unrepaired_wound: float = Field(..., ge=0.0, le=10.0, description="Variable W")
    gewalt_force: float = Field(..., ge=0.0, le=10.0, description="Variable G")
    evidence_reliability: float = Field(default=1.0, ge=0.1, le=1.0, description="Factor K")
    uncertainty_penalty: float = Field(default=0.5, ge=0.0, description="Penalización U")

class BLIPEngine:
    @staticmethod
    def calculate_ivb(metrics: BioLegitimacyMetrics) -> Dict[str, Any]:
        """
        Calcula el Índice de Viabilidad Biosférica (IVB).
        IVB = [K * (C + H + O)] / [(D + W + G) + U]
        """
        positive_sum = metrics.vital_capacity_created + metrics.habitat_integrity + metrics.renovative_horizon
        negative_sum = metrics.irreversible_degradation + metrics.unrepaired_wound + metrics.gewalt_force
        
        denominator = negative_sum + metrics.uncertainty_penalty
        ivb = (metrics.evidence_reliability * positive_sum) / (denominator if denominator > 0 else 0.001)
        
        if ivb >= 1.25:
            decision = "ALLOW"
        elif ivb >= 0.85:
            decision = "REVIEW"
        else:
            decision = "BLOCK"
            
        requires_ecological_holdout = metrics.irreversible_degradation >= 4.0 or metrics.gewalt_force > 0.0
        
        return {
            "ivb_score": round(ivb, 4),
            "decision": decision,
            "positive_metrics_sum": positive_sum,
            "negative_metrics_sum": negative_sum,
            "requires_ecological_holdout": requires_ecological_holdout
        }
