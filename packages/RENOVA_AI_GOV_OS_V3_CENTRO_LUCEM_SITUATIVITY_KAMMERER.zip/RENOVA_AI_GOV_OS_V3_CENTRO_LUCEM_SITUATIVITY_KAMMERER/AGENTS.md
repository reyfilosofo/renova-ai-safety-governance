# AGENTS.md — Instructions for Codex and AI Coding Agents

## Operating principle

You are working on **RENOVA AI GOVERNANCE OS**, a serious AI governance software MVP for SERESARTE Group / ℛenova. Treat this repository as a product-grade prototype, not as a toy demo.

## Non-negotiable product boundaries

1. Do not claim that the product certifies compliance with ISO/IEC 42001, NIST AI RMF, EU AI Act, OECD AI Principles or any legal/regulatory framework.
2. Do not invent legal obligations.
3. Do not provide legal advice.
4. Do not imply official affiliation with OpenAI, NIST, ISO, OECD, EU, Anthropic, Microsoft or any regulator.
5. Preserve product names:
   - SERESARTE Group
   - ℛenova
   - Renova AI Governance Studio
   - Renova AI Governance OS
   - ReyFilosofo Advisory
   - CLARITAS
   - RATIO
   - VITA
   - CENTRO
   - ℛ-Scorecard
6. Never replace “Renova” with “Renoba”.
7. Use “ℛ” where technically safe. If a filename, package or variable rejects it, use “Renova” or “RScorecard”.

## Coding conventions

- Use TypeScript.
- Use clear domain models in `src/lib/types.ts`.
- Put scoring logic in `src/lib/scoring.ts`.
- Keep presentation components under `src/components`.
- Keep generator functions under `src/lib/reportGenerators.ts`.
- Use pure functions for scoring, with tests.
- Avoid hidden network calls.
- Avoid secrets.
- Do not add authentication in v0.1 unless instructed.
- Prefer deterministic, auditable output over flashy UI.

## UI principles

- Premium, sober, institutional, board-level.
- Avoid generic neon AI aesthetics.
- Use high information hierarchy.
- Use clear dashboards, cards, score bars, tables and document previews.
- Content must be usable by CEO, board, legal, risk, compliance, CTO/CIO and Head of AI.

## Documentation principles

Every major change must update at least one of:

- `docs/ARCHITECTURE.md`
- `docs/METHODOLOGY.md`
- `docs/CHANGELOG.md`
- `docs/BACKLOG.md`
- `README.md`

## Testing expectations

- Add tests for scoring functions.
- Test edge cases:
  - missing scores
  - high-risk domain without human oversight
  - prohibited use
  - low traceability
  - high uncertainty
  - strong score but critical blocker
  - safe permitted demo case

## Definition of Done for v0.1

1. App runs locally.
2. Assessment can be completed.
3. Dashboard displays CLARITAS/RATIO/VITA/CENTRO/ℛ-Scorecard.
4. AI Constitution can be generated.
5. Truth & Life Audit can be generated.
6. Board Memo can be generated.
7. Playbooks are visible.
8. Roadmap 365 is visible.
9. Scoring logic has tests.
10. README and docs are updated.
11. Disclaimers are visible.
12. No compliance overclaiming.
