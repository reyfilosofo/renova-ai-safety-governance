# AI Constitution v1

## Organization

{{organization_name}}

## Purpose

This AI Constitution defines the operational principles, limits, review pathways and accountability architecture for organizational AI use.

## Principles

1. Truth before persuasion.
2. Human dignity before automation.
3. Traceability before scale.
4. Reversibility before irreversible deployment.
5. Human oversight before high-impact autonomy.
6. Plural evidence before confident decision.
7. Care before efficiency.
8. Governance before expansion.

## Red Zones

- No use for prohibited, deceptive, exploitative or harmful purposes.
- No high-impact decision without human review.
- No unsupported claims presented as fact.
- No fabricated citations or false authority.
- No concealed uncertainty in consequential contexts.
- No deployment without owner, escalation and review.

## Truth Protocol

- Claims must identify evidence level.
- Uncertainty must be explicit.
- Disagreement must not be hidden.
- Critical outputs must be traceable.

## Human Oversight Protocol

- High-risk domains require named accountable human reviewer.
- Users must know when AI is involved.
- Affected parties need appeal or correction pathways where relevant.

## Drift Reset

- Monitor behavior changes.
- Trigger review after incidents, model updates or domain shifts.
- Suspend or redesign if drift undermines truth, dignity, safety or accountability.

## Governance Committee

- Board sponsor
- Legal
- Risk/compliance
- Technology
- Data/AI lead
- Human impact lead
- Domain owner
- Renova/CENTRO advisor if engaged
