# Roadmap 365

## 0–30 days

- Inventory AI use cases.
- Assign owners.
- Establish initial committee.
- Identify high-risk domains.
- Freeze uncontrolled expansion where needed.
- Create evidence baseline.

## 31–90 days

- Draft AI Constitution v1.
- Run Truth & Life Audit.
- Define RACI.
- Create incident playbooks.
- Start executive education.
- Approve 90-day implementation plan.

## 91–180 days

- Add evidence registry.
- Perform re-test.
- Expand vendor governance.
- Add model/output review cycles.
- Train teams.
- Calibrate scoring.

## 181–365 days

- Formalize governance operating model.
- Integrate with risk/compliance.
- Run annual review.
- Publish internal AI governance report.
- Decide on methodology license, retainer or platform deployment.
