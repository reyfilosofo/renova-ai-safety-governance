# Incident Playbook

## Incident name

{{incident_name}}

## Trigger

{{trigger}}

## Severity levels

- Low
- Medium
- High
- Critical

## Immediate action

{{immediate_action}}

## Owner

{{owner}}

## Escalation path

{{escalation_path}}

## Evidence required

{{evidence_required}}

## Remediation

{{remediation}}

## Post-incident review

{{post_incident_review}}
