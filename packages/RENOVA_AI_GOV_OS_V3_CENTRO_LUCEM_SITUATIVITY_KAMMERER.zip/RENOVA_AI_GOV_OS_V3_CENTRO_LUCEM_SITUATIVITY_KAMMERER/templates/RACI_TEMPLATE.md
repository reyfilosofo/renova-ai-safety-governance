# RACI Template

| Activity | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| AI use-case approval | Head of AI | CENTRO Committee | Legal/Risk | Board Sponsor |
| Truth & Life Audit | Risk/Compliance | CENTRO Committee | Human Impact Lead | CEO |
| AI Constitution update | General Counsel | Board Sponsor | Renova Advisor | AI users |
| Incident escalation | System Owner | Risk/Compliance | Legal/CTO | Affected stakeholders |
