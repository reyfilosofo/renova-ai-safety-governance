# Technical Architecture

## 1. Architecture mode

v0.1 is a local/demo-first Next.js application.

```txt
User
  ↓
Next.js UI
  ↓
Assessment State / Demo Data
  ↓
Scoring Engine
  ↓
Dashboard + Report Generators
  ↓
Markdown/HTML Export
```

## 2. Core directories

```txt
src/
  app/
  components/
  lib/
data/
templates/
docs/
assets/
prototype/
```

## 3. Domain layer

- Assessment
- Organization
- AIUseCase
- LayerScore
- GovernanceRisk
- Recommendation
- GeneratedDocument
- Playbook
- RoadmapItem

## 4. Scoring layer

Scoring is deterministic and transparent. It should not depend on black-box AI calls.

Core functions:

- `scoreClaritas(useCase)`
- `scoreRatio(useCase)`
- `scoreVita(useCase)`
- `scoreCentro(useCase)`
- `scoreUseCase(useCase)`
- `scoreAssessment(assessment)`
- `classifyTrafficLight(score)`
- `generateRecommendations(result)`

## 5. Presentation layer

- Home page
- Assessment wizard
- Dashboard
- Reports
- Playbooks
- Roadmap

## 6. Persistence

v0.1 may use:

- demo data;
- React state;
- localStorage;
- JSON files.

v0.2 may add:

- SQLite;
- Prisma;
- Supabase/Postgres;
- auth;
- user accounts;
- audit log.

## 7. Export

v0.1:

- Markdown strings.
- HTML preview.
- Copy-to-clipboard.

v0.2:

- PDF export.
- DOCX export.
- signed evidence bundle.
- JSON evidence registry.

## 8. Security posture

- No secrets.
- No external model calls.
- No client data.
- No auth in v0.1.
- No legal/compliance certification claims.
- Demo only.
