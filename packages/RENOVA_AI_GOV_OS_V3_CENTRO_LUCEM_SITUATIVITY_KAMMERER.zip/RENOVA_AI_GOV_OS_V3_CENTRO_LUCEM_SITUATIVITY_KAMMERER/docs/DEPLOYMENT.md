# Deployment Plan

## v0.1 Local Demo

```bash
npm install
npm run dev
```

## v0.1 Static fallback

Open `prototype/index.html`.

## v0.2 Vercel deployment

1. Push repo to GitHub.
2. Connect Vercel.
3. Deploy Next.js app.
4. Keep repo private while still in prototype mode.
5. Add disclaimers in footer and reports.
6. Do not add real client data.

## v0.3 Secure pilot

Add:

- authentication;
- database;
- audit log;
- user roles;
- evidence upload;
- privacy review;
- backup process;
- export controls.
