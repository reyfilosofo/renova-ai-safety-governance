# Data Model

## Organization

- name
- sector
- country
- aiMaturity
- governanceStatus
- committeeExists

## AIUseCase

- id
- name
- department
- status
- description
- domain
- impactedUsers
- dataSensitivity
- autonomyLevel
- humanOversight
- truthRisk
- humanImpactRisk
- regulatoryRisk
- currentControls
- scores

## Scores

### CLARITAS

- truthfulness
- clarity
- coherence
- traceability
- epistemicNonHarm

### RATIO

- evidenceRobustness
- plurality
- reasoningConsistency
- challengeability
- uncertaintyHandling

### VITA

- humanImpact
- dignity
- reversibility
- care
- lifeCenteredFit

### CENTRO

- ownership
- humanOversight
- escalation
- driftReset
- vendorGovernance

## GeneratedDocument

- id
- type
- title
- createdAt
- assessmentId
- markdown
- html
