# Codex Runbook

## Step 1 — Upload repository

Upload this ZIP or push it to a private GitHub repository.

Recommended repo name:

```txt
renova-ai-governance-os
```

## Step 2 — Paste master prompt

Open:

```txt
CODEX_COPY_PASTE_PROMPT.md
```

Paste the full prompt into Codex.

## Step 3 — Ask Codex to inspect first

Codex must:

1. inspect repo;
2. summarize files;
3. create implementation plan;
4. then code.

## Step 4 — Use branches

Recommended:

```txt
main
codex/mvp-v0.1
codex/scoring-engine
codex/report-generators
codex/ui-dashboard
codex/docs-hardening
```

## Step 5 — Review pull requests

Do not merge blindly. Check:

- tests;
- UI;
- report outputs;
- disclaimers;
- no overclaims;
- no broken encoding.

## Step 6 — Iterate

After v0.1, run second prompt:

```txt
Review this MVP as a senior product engineer and AI governance architect. Improve architecture, scoring, export, tests and documentation. Do not add authentication yet.
```
