# Codex Runbook — Desktop Setup

## 1. Recommended local path

Unzip this package into:

```bash
~/Projects/renova-governance-os-v3
```

or:

```bash
~/Downloads/renova-governance-os-v3
```

## 2. Open in Codex

When Codex asks for a path, use an absolute path or a `~` path:

```txt
~/Projects/renova-governance-os-v3
```

If that fails, get the absolute path:

```bash
pwd
```

inside the folder, then paste the result into Codex.

## 3. Install

```bash
npm install
npm run typecheck
npm run test
npm run dev
```

## 4. First Codex task

Use `CODEX_MASTER_PROMPT_V3_CENTRO_LUCEM.md`.

## 5. Do not load secrets

Do not add API keys, client data, private medical files, litigation files or credentials.
