# Protocolo ℛenova + Benchmark Suite

## Core protocol

The applied Renova protocol follows the sequence:

1. **Hábitat** — What supports life here?
2. **Herida** — What damage, Gewalt, extraction or semiotic rupture is present?
3. **Horizonte** — What new life-configuration can be created?
4. **Intervention** — What must be suspended, redesigned, repaired, compensated or monitored?
5. **Benchmark** — What comparable cases or baseline metrics can test the claim?
6. **Recalculation** — When and how is the score recomputed?

## Core variables

The benchmark must use the following minimum variable family:

- `C` — creation of vital capacity.
- `E` — sustainable functional expansion.
- `Q` — systemic coherence.
- `M` — semiotic richness / meaning density.
- `G` — Gewalt / destructive force.
- `D` — irreversible degradation.
- `X` — hidden externalities.
- `H` — habitat integrity.
- `W` — wound visibility.
- `O` — horizon-opening potential.
- `U` — uncertainty.
- `K` — evidence reliability.

## Core index

A practical implementation may start with:

```txt
R_total = K * ((wC*C + wE*E + wQ*Q + wM*M + wH*H + wO*O) - (wG*G + wD*D + wX*X + wW*W)) - U
```

This is an operational heuristic, not a physical law.

## Benchmark scenarios

1. AI governance deployment.
2. Infrastructure project.
3. School or learning ecosystem.
4. Health or care project.
5. Cultural/artistic intervention.
6. Ecological regeneration.
7. Urban design.
8. Public policy.
9. Media/reputation system.
10. Research project.

## Benchmark output

Each benchmark report must include:

- baseline;
- system boundary;
- affected actors;
- evidence sources;
- score;
- uncertainty;
- sensitivity analysis;
- blockers;
- decision category;
- falsification condition;
- next measurement date.
