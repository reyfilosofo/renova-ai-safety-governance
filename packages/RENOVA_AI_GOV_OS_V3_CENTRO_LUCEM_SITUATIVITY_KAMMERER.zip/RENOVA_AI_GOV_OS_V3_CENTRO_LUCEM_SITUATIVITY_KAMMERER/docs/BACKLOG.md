# Product Backlog

## P0 — Must do for v0.1

- Build assessment wizard.
- Build scoring engine.
- Build dashboard.
- Build AI Constitution generator.
- Build Truth & Life Audit generator.
- Build Board Memo generator.
- Build playbook library.
- Add visible disclaimers.
- Add scoring tests.
- Improve documentation.

## P1 — v0.2

- localStorage persistence;
- PDF export;
- printable report views;
- sector-specific rubrics;
- evidence registry;
- improved risk map;
- recommended controls library;
- side-by-side NIST/ISO/EU/OECD mapping;
- sample sales demo route.

## P2 — v0.3

- authentication;
- Supabase/Postgres;
- multi-organization workspace;
- role-based access;
- evidence upload;
- incident log;
- vendor registry;
- committee workflow;
- signed assessment exports.

## P3 — v1.0

- real audit evidence;
- external expert review workflow;
- inter-rater calibration;
- API;
- methodology license mode;
- academy/training integration;
- SaaS deployment;
- dashboard analytics;
- longitudinal maturity tracking.
