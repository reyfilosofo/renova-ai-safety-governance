# Source Audit

## Internal source base

This package is based on the project architecture described in the user's Renova AI Governance materials:

- RENOVA AI GOVERNANCE OS as flagship product.
- AI Constitution.
- Truth & Life Audit.
- CLARITAS.
- RATIO.
- VITA.
- CENTRO.
- ℛ-Scorecard.
- Operating model, RACI, playbooks and roadmap 365.
- SERESARTE Group as advisory, governance, cultural intelligence, media, education and IP platform.
- Service menu and pricing ranges for executive briefing, constitution sprint, audit, Governance OS, fractional advisor, academy and methodology license.

## Public framework alignment

Use official sources for future verification:

- NIST AI RMF
- NIST AI RMF Playbook / AIRC
- ISO/IEC 42001
- EU AI Act
- OECD AI Principles
- Anthropic Constitutional AI as conceptual market reference

## Caution

This repository contains synthesized source notes, not full legal or standards texts. Codex must not invent obligations or certification claims.
