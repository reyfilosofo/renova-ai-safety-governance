# Changelog

## v0.1.0-codex-max-start — 2026-05-28

- Created Codex-ready package.
- Added Next.js starter app.
- Added standalone HTML prototype.
- Added scoring methodology.
- Added demo data.
- Added templates.
- Added SVG assets.
- Added docs.
- Added Codex master prompt.
