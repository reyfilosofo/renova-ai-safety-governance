# Ethics and Safety Boundaries

## Use allowed

- governance design;
- advisory assessment;
- internal readiness;
- risk mapping;
- playbook creation;
- board education;
- audit preparation;
- non-certified documentation.

## Use not allowed

- fake certification;
- regulatory laundering;
- bypassing legal review;
- hiding evidence gaps;
- approving high-risk AI without expert review;
- making clinical, legal, financial or employment decisions automatically;
- processing real sensitive data in prototype mode;
- producing manipulative or deceptive AI deployment materials.

## Human oversight

All high-impact or high-risk uses must include named human oversight, appeal, escalation and reversibility.
