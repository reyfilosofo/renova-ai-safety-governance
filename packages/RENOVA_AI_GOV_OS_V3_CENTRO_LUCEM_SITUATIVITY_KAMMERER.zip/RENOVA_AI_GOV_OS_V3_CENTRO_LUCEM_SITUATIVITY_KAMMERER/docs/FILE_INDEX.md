# File Index

## Root

- `README.md`: repository overview.
- `AGENTS.md`: agent instructions for Codex.
- `CODEX_COPY_PASTE_PROMPT.md`: master prompt to paste into Codex.
- `package.json`: Next.js/TypeScript scripts and dependencies.

## Application

- `src/app/page.tsx`: home/landing page.
- `src/app/assessment/page.tsx`: assessment wizard demo.
- `src/app/dashboard/page.tsx`: dashboard.
- `src/app/reports/page.tsx`: report generators.
- `src/app/playbooks/page.tsx`: playbook library.
- `src/app/roadmap/page.tsx`: roadmap 365.
- `src/lib/types.ts`: domain types.
- `src/lib/scoring.ts`: scoring engine.
- `src/lib/reportGenerators.ts`: executive documents.
- `src/lib/demoData.ts`: demo assessment data.
- `src/components/*`: UI components.

## Docs

- `docs/PRD.md`: product requirements document.
- `docs/ARCHITECTURE.md`: technical architecture.
- `docs/METHODOLOGY.md`: Renova methodology.
- `docs/SCIENTIFIC_ALIGNMENT.md`: alignment with public AI governance frameworks.
- `docs/LIMITATIONS.md`: legal, methodological and safety limits.
- `docs/DATA_MODEL.md`: core entities.
- `docs/QA_PLAN.md`: validation and testing.
- `docs/DEPLOYMENT.md`: deployment plan.
- `docs/BACKLOG.md`: product backlog.
- `docs/CHANGELOG.md`: change history.
- `docs/CODEX_RUNBOOK.md`: how to use Codex on this repo.
- `docs/ETHICS_SAFETY_BOUNDARIES.md`: safety boundaries.
- `docs/SOURCE_AUDIT.md`: source and evidence notes.

## Templates

- `templates/AI_CONSTITUTION_TEMPLATE.md`
- `templates/TRUTH_LIFE_AUDIT_TEMPLATE.md`
- `templates/BOARD_MEMO_TEMPLATE.md`
- `templates/PLAYBOOK_TEMPLATE.md`
- `templates/RACI_TEMPLATE.md`
- `templates/ROADMAP_365_TEMPLATE.md`

## Assets

- `assets/renova-logo.svg`
- `assets/seresarte-seal.svg`
- `assets/architecture-diagram.svg`
- `assets/scorecard-wheel.svg`
- `assets/governance-flow.svg`

## Prototype

- `prototype/index.html`: standalone no-build demo.
