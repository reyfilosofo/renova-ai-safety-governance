# QA Plan

## 1. Unit tests

Test scoring functions:

- normal permitted use case;
- high-risk domain;
- high-risk domain without human oversight;
- low traceability;
- low plurality;
- high uncertainty;
- prohibited term;
- perfect score;
- missing input;
- negative input;
- score above 100.

## 2. UX tests

Manual flows:

1. Open home.
2. Start assessment.
3. Add use case.
4. View dashboard.
5. Generate AI Constitution.
6. Generate Audit Report.
7. Generate Board Memo.
8. View Playbooks.
9. View Roadmap.

## 3. Content QA

Check:

- no compliance overclaiming;
- no invented certifications;
- no false affiliation;
- disclaimers visible;
- “Renova” spelled correctly;
- “ℛ” fallback handled.

## 4. Scientific/methodological QA

Check:

- subcriteria are defined;
- score rationale is generated;
- high scores do not override blockers;
- recommendations are tied to risks;
- evidence gaps are explicit.

## 5. Security QA

Check:

- no secrets in repo;
- no API keys;
- no real client data;
- no medical/personal data;
- no hidden network calls.
