# Situativity, Kammerer Seriality and Renovagrama

## Situativity layer

Situativity theory states that knowledge, thinking and learning are situated in experience. In the Renova system this becomes:

**Consciencia situada renovativa** — the quality of a decision, learning process or AI governance intervention cannot be evaluated apart from the participants, culture, physical environment, artifacts, history, language and institutional context in which it occurs.

Operational dimensions:

- participants;
- culture;
- physical environment;
- artifacts/tools/documents/computers;
- community participation;
- goal-directed activity;
- transfer risk;
- distributed cognition;
- nonlinear interaction effects.

## Why it matters

A high score in abstraction may fail in practice if the tool is used in the wrong context. Therefore every score must be situated.

## Kammerer seriality layer

Paul Kammerer published *Das Gesetz der Serie* in 1919. For this project, Kammerer is not used as proof of mysticism. He is used as a historical source for a cautious seriality module: a way to log recurrences, coincidences, clustered events and repeated patterns without collapsing into superstition.

The software must treat seriality as:

- pattern log;
- recurrence detector;
- hypothesis generator;
- anomaly register;
- not proof of causation;
- not proof of synchronicity;
- not evidence of hidden metaphysical law without further testing.

## Seriality variables

- `event_label`;
- `event_date`;
- `number_pattern`;
- `context`;
- `observer`;
- `source`;
- `recurrence_count`;
- `time_window`;
- `base_rate_estimate`;
- `plausible_causal_link`;
- `interpretive_note`;
- `statistical_warning`.

## Renovagrama rule

The Renovagrama requested in recent conversation must be treated as a **numerical pattern artifact**.

Rule:

- Use numbers, not generic mystical symbols.
- It can visualize repetition, spiral, sequence, recurrence, interval and distribution.
- It must support export as SVG/PNG/JSON.
- It must include a “statistical caution” label when presented analytically.

## Software output

The `/seriality` and `/renovagrama` modules should allow the user to:

1. Enter events.
2. Extract repeated numbers or sequences.
3. Visualize recurrence.
4. Distinguish observation from interpretation.
5. Export a report.
6. Link patterns to Renova hypotheses only as hypotheses.
