# Limitations and Legal Boundaries

RENOVA AI GOVERNANCE OS v0.1 is a governance design prototype.

It is not:

- legal advice;
- compliance certification;
- ISO/IEC certification;
- NIST certification;
- EU AI Act legal classification;
- cybersecurity audit;
- clinical audit;
- financial audit;
- human rights impact assessment by an accredited body;
- model evaluation benchmark;
- proof of safety;
- proof of non-discrimination;
- proof of truthfulness.

## Required professional review

Before organizational deployment, outputs must be reviewed by qualified experts in:

- law;
- compliance;
- cybersecurity;
- data protection;
- AI safety;
- domain operations;
- human rights / human impact;
- sector-specific regulation.

## Evidence limitation

v0.1 uses questionnaire data and demo assumptions. Questionnaire-based scores are not equivalent to audited evidence.

## Scoring limitation

The scores are advisory. They are not objective facts. They depend on input quality, context, evidence, reviewer judgment and calibration.

## Regulatory limitation

The product can map to public frameworks. It cannot certify compliance.

## Ethical limitation

The tool must not be used to launder risky or harmful AI deployments through superficial governance language.
