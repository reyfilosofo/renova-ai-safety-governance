# Prompt Pack for Future Codex Iterations

## v0.2 hardening

Review the current RENOVA AI GOVERNANCE OS MVP as a senior product engineer and AI governance architect. Improve scoring transparency, report exports, UI states, tests and documentation. Do not add authentication yet.

## v0.3 evidence registry

Add an evidence registry to each AI use case. Evidence items should include title, owner, source type, date, confidence level, review status and linked scoring criteria. Do not upload real sensitive data.

## v0.4 executive sales demo

Create a polished /demo route with preloaded sample company data, sample board memo, sample AI constitution, sample audit report, service menu, pricing ranges and lead capture placeholder.

## v0.5 secure pilot planning

Design an architecture proposal for authenticated multi-organization workspaces, role-based access, audit logs, export controls and privacy-preserving evidence storage. Do not implement until approved.
