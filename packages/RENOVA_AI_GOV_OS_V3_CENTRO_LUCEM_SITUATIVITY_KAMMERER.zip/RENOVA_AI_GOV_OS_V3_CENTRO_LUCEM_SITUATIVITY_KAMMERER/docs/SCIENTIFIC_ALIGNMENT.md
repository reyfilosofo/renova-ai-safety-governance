# Scientific and Governance Alignment Notes

This document guides Codex and reviewers when aligning RENOVA AI GOVERNANCE OS with public AI governance frameworks.

## NIST AI RMF

NIST AI RMF is structured around Govern, Map, Measure and Manage. RENOVA AI GOVERNANCE OS can map conceptually to these functions:

- Govern → AI Constitution, RACI, committee, operating model.
- Map → Use-case inventory, domain sensitivity, affected users.
- Measure → CLARITAS/RATIO/VITA/CENTRO scoring.
- Manage → Playbooks, roadmap, drift reset, re-test.

Do not state that the product is NIST-certified. NIST AI RMF is a framework for risk management, not a certification granted by this product.

## ISO/IEC 42001

ISO/IEC 42001 concerns AI management systems. RENOVA AI GOVERNANCE OS may support readiness documentation and operating-model thinking, but it is not an ISO certification product.

## EU AI Act

The EU AI Act is risk-based. RENOVA AI GOVERNANCE OS can help an organization think about prohibited, high-risk, limited-risk and general governance categories, but it must not provide formal legal classification or legal advice.

## OECD AI Principles

OECD AI Principles support trustworthy AI, human rights, democratic values, transparency, accountability and robustness. RENOVA’s truth/life/governance layers can be presented as compatible with those broad values, not as an official OECD assessment.

## Anthropic Constitutional AI

Anthropic’s Constitutional AI is a useful market reference for constitution-based AI behavior. RENOVA’s AI Constitution is an organizational governance artifact, not a claim to reproduce Anthropic’s technical method.

## Research posture

The MVP is not peer-reviewed. It should be treated as a methodological prototype. To approach peer-review quality, future versions require:

1. operational definitions;
2. evidence taxonomy;
3. validation studies;
4. inter-rater reliability;
5. sector-specific pilots;
6. adversarial testing;
7. external expert review;
8. formal documentation of limitations.
