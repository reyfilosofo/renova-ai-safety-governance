# Methodology — CLARITAS, RATIO, VITA, CENTRO, ℛ-Scorecard

## 1. Purpose

RENOVA AI GOVERNANCE OS translates philosophical judgment into governance operations. It does not reduce governance to compliance checklists. It asks whether an AI system can be used with truth, reason, human impact awareness, institutional accountability and corrective capacity.

## 2. CLARITAS — Truth Layer

CLARITAS evaluates whether AI preserves truth and clarity.

### Subcriteria

1. Truthfulness
2. Clarity
3. Coherence
4. Traceability
5. Epistemic non-harm

### Failure modes

- hallucination;
- false authority;
- fabricated citations;
- unclear uncertainty;
- persuasive but unsupported claims;
- hidden assumptions;
- untraceable decisions.

## 3. RATIO — Reasoning Layer

RATIO evaluates whether the system justifies outputs with sufficient evidence and argumentative discipline.

### Subcriteria

1. Evidence robustness
2. Plurality
3. Reasoning consistency
4. Challengeability
5. Uncertainty handling

### Failure modes

- one-sided reasoning;
- weak evidence;
- rhetorical confidence;
- inability to revise;
- hidden disagreement.

## 4. VITA — Human Impact Layer

VITA evaluates real-world effects on human beings, dignity, care, reversibility and life-centered outcomes.

### Subcriteria

1. Human impact
2. Dignity
3. Reversibility
4. Care
5. Life-centered fit

### Failure modes

- automation of harm;
- loss of human agency;
- irreversible decision damage;
- neglect of vulnerable users;
- dehumanizing institutional workflows.

## 5. CENTRO — Governance Layer

CENTRO evaluates whether the organization can govern AI decisions through responsibility, escalation, review, arbitration and drift reset.

### Subcriteria

1. Ownership
2. Human oversight
3. Escalation
4. Drift reset
5. Vendor governance

### Failure modes

- no owner;
- no appeal path;
- no incident response;
- no drift review;
- no vendor accountability;
- no committee authority.

## 6. ℛ-Scorecard — Executive Layer

ℛ-Scorecard integrates the layers into a board-level reading.

### Traffic light

- 0–39: Critical
- 40–59: Fragile
- 60–79: Developing
- 80–100: Governable

## 7. Decision logic

A high numerical score cannot override a critical blocker.

Blockers include:

- prohibited or abusive use;
- no human oversight in high-risk domain;
- traceability below minimum threshold;
- high uncertainty without disclosure;
- severe human impact with no reversibility;
- weak evidence in consequential decision contexts.

## 8. Evidence posture

The system must distinguish:

- self-reported maturity;
- documented controls;
- tested controls;
- independently reviewed controls;
- certified controls.

v0.1 uses self-reported and demo data. Production versions must require evidence.
