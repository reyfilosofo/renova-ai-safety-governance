# Commercial Package — Renova AI Governance Studio

## Positioning

Do not sell generic AI ethics. Sell board-level AI governance with constitution, truth, life, drift reset and operating architecture.

## Entry products

### Executive Briefing / Board Memo
Duration: 1–2 weeks.  
Price: $45,000–$90,000 MXN.  
Deliverables: executive session, diagnosis, board memo and initial recommendations.

### AI Constitution Sprint
Duration: 3–4 weeks.  
Price: $180,000–$350,000 MXN.  
Deliverables: AI Constitution v1, principles, limits, escalation and workshop.

### Truth & Life Audit
Duration: 4–6 weeks.  
Price: $280,000–$650,000 MXN.  
Deliverables: CLARITAS/RATIO/VITA audit, ℛ-Scorecard, risk findings and redesign recommendations.

### Renova AI Governance OS
Duration: 8–12 weeks.  
Price: $850,000–$2,200,000 MXN.  
Deliverables: constitution, audit, governance operating model, RACI, playbooks, committee model and Roadmap 365.

## Sales thesis

The client already uses AI. The question is whether the organization has enough truth, governance, traceability and human-impact architecture to scale AI without reputational, legal, cognitive or institutional damage.
