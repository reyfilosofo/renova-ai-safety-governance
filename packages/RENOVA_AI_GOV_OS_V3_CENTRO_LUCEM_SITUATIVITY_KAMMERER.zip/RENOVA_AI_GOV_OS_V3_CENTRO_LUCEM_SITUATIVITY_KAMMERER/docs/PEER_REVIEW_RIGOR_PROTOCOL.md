# Peer-Review Rigor Protocol

## Required epistemic labels

Every generated claim must carry one of these labels:

- **Ontology** — philosophical thesis.
- **Hypothesis** — scientific proposition needing testing.
- **Model** — formal or computational approximation.
- **Protocol** — operational rule.
- **Data** — empirical observation or measurement.
- **Inference** — interpretation from data.
- **Poetic-symbolic** — symbolic or artistic expression.

## Required report fields

Every generated score or recommendation must include:

1. claim;
2. label;
3. evidence grade;
4. uncertainty level;
5. source or assumption;
6. method;
7. falsification condition;
8. reviewer role;
9. next measurement date.

## Evidence grades

- `A` — audited dataset, repeatable method, external review.
- `B` — documented internal evidence and clear method.
- `C` — plausible but self-reported evidence.
- `D` — inference or weak evidence.
- `E` — symbolic, speculative or illustrative only.

## Anti-inflation rule

The system must not call a project “renovativo” unless it shows:

- life-net increase;
- damage reduction;
- hidden externalities surfaced;
- habitat strengthened;
- affected actors identified;
- remeasurement plan;
- explicit failure condition.
