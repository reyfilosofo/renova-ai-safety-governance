Use this local project path as the working project. If needed, replace it with the actual absolute path on this computer:

~/Projects/renova-governance-os-v3

You are Codex working on RENOVA AI GOVERNANCE OS v3 — CENTRO/LUCEM Protocol & Benchmark Suite.

Your task is not to create a simple landing page. Your task is to transform this repository into a serious, repo-scale, working MVP that integrates the latest Renova architecture: CENTRO, LUCEM, Protocolo ℛenova, Benchmark ℛenova, Situativity Theory, Kammerer Seriality and the Renovagrama numerical-pattern module.

Before coding:

1. Inspect the whole repository.
2. Read README.md, README_V3_UPDATE.md, AGENTS.md, CODEX_MASTER_PROMPT_V3_CENTRO_LUCEM.md.
3. Read docs/V3_UPDATE_BRIEF_CENTRO_LUCEM_SITUATIVITY_KAMMERER.md.
4. Read docs/CENTRO_LUCEM_OPERATIONAL_SPEC.md.
5. Read docs/PROTOCOL_BENCHMARK_SUITE.md.
6. Read docs/SITUATIVITY_KAMMERER_RENOVAGRAMA.md.
7. Read docs/PEER_REVIEW_RIGOR_PROTOCOL.md.
8. Inspect data/*.json, packages/renova_core/*, tools/*, examples/* and legacy_integrations/*.
9. Summarize what exists.
10. Identify gaps.
11. Propose an implementation plan.
12. Then implement.

Product identity:

- Product: RENOVA AI GOVERNANCE OS v3.
- Owner: Carlos Jonathan González Rodríguez / Jonathan ReyFilosofo by SERESARTE.
- Ecosystem: SERESARTE Group · ℛenova · Renova AI Governance Studio · ReyFilosofo Advisory · LUCEM · CENTRO.
- Core thesis: AI governance, civilizational evaluation and institutional design must be situated, traceable, evidence-graded, life-centered and falsifiable.

Non-negotiable conceptual updates:

1. CENTRO is the consensus, arbitration, escalation, redesign and failure-acceptance engine.
2. LUCEM is the consciousness, evidence, visualization and life-metric laboratory.
3. Protocolo ℛenova is the applied workflow: Hábitat → Herida → Horizonte → Intervention → Benchmark → Recalculation.
4. Benchmark ℛenova uses life-net metrics and must include baseline, boundary, actors, score, uncertainty, evidence grade, blockers and falsification condition.
5. Situativity means that scores must include participants, culture, environment, artifacts/tools/documents, community and distributed cognition.
6. Kammerer seriality is used only as a cautious recurrence/anomaly/pattern log. Never present seriality as proof of causation or metaphysical law.
7. Renovagrama must be treated as a numerical pattern artifact. Use numbers, not generic symbols, unless explicitly configured.

Build or improve these app modules:

1. `/` — premium executive landing.
2. `/assessment` — AI governance assessment wizard.
3. `/dashboard` — integrated ℛ-Scorecard dashboard.
4. `/reports` — AI Constitution, Truth & Life Audit, Board Memo.
5. `/centro` — CENTRO decision journal with consensus, blockers, escalation and redesign actions.
6. `/lucem` — LUCEM evidence map and visualization dashboard.
7. `/protocol` — Hábitat-Herida-Horizonte protocol wizard.
8. `/benchmark` — Benchmark Suite with scenarios, weights, score and decision category.
9. `/situativity` — map participants, culture, physical environment, artifacts/tools and distributed cognition.
10. `/seriality` — Kammerer-inspired seriality log with statistical caution.
11. `/renovagrama` — numerical recurrence visualization and JSON/SVG export.
12. `/playbooks` — incident and governance playbook library.
13. `/roadmap` — 90/180/365 implementation roadmap.
14. `/raci` — governance RACI matrix.

Technical requirements:

- Next.js + TypeScript.
- Keep scoring functions deterministic and testable.
- Use Zod for data validation where forms exist.
- Add localStorage persistence for demo data.
- Add Vitest tests for scoring, benchmark and report generators.
- Add Markdown export for reports.
- Add print view where feasible.
- Avoid auth in v0.1/v0.3 unless explicitly requested.
- Do not use real client data or secrets.

Rigor requirements:

Every score or recommendation must include:

1. score;
2. rationale;
3. evidence grade;
4. uncertainty;
5. claim type;
6. blockers;
7. falsification condition;
8. recommended action;
9. remeasurement date.

Use claim types:

- ontology;
- hypothesis;
- model;
- protocol;
- data;
- inference;
- poetic-symbolic.

Safety and limits:

- Do not claim legal compliance.
- Do not claim ISO/IEC 42001 certification.
- Do not claim NIST certification.
- Do not claim EU AI Act formal conformity.
- Do not provide legal advice.
- Do not invent scientific validation.
- Do not call a project “renovative” unless it shows life-net increase, damage reduction, externalities surfaced, habitat strengthened and a remeasurement plan.

Definition of done:

1. `npm install` succeeds.
2. `npm run typecheck` succeeds if typecheck script exists; otherwise add it.
3. `npm run test` succeeds if tests exist; otherwise add tests and make it succeed.
4. `npm run dev` starts the app.
5. Dashboard works.
6. Assessment works.
7. Reports render.
8. CENTRO module works.
9. LUCEM module works.
10. Protocol module works.
11. Benchmark module works.
12. Situativity module works.
13. Seriality/Renovagrama modules work at least as demo prototypes.
14. Docs are updated.
15. README explains setup and project structure.
16. No overclaiming.

Final response format:

1. What you implemented.
2. How to run.
3. Tests run and outputs.
4. Files changed.
5. Known limitations.
6. Next Codex task.
