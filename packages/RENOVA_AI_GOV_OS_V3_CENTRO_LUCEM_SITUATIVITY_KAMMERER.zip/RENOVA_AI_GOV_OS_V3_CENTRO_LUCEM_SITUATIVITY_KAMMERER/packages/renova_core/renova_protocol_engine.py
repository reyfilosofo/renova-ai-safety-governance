from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Literal

Decision = Literal['APPROVE','PILOT','REDESIGN','SUSPEND','REJECT']

POSITIVE = ['C','E','Q','M','H','O']
NEGATIVE = ['G','D','X','W']

@dataclass
class RenovaCase:
    case_id: str
    title: str
    scenario: str
    values: Dict[str, float]
    weights: Dict[str, float]
    evidence_grade: str = 'C'
    uncertainty: float = 0.15
    notes: str = ''

@dataclass
class RenovaResult:
    case_id: str
    raw_positive: float
    raw_negative: float
    evidence_multiplier: float
    uncertainty_penalty: float
    r_total: float
    decision: Decision
    blockers: List[str]
    falsification_condition: str

EVIDENCE_MULTIPLIERS = {'A':1.0,'B':0.9,'C':0.75,'D':0.55,'E':0.35}

def clamp(x: float, lo: float=0, hi: float=100) -> float:
    return max(lo, min(hi, float(x)))

def weighted_sum(keys: List[str], values: Dict[str,float], weights: Dict[str,float]) -> float:
    total_w = sum(weights.get(k,1.0) for k in keys)
    if total_w == 0: return 0.0
    return sum(clamp(values.get(k,0))*weights.get(k,1.0) for k in keys)/total_w

def detect_blockers(case: RenovaCase) -> List[str]:
    v=case.values
    blockers=[]
    if v.get('G',0) >= 80: blockers.append('Gewalt exceeds acceptable threshold.')
    if v.get('D',0) >= 75: blockers.append('Irreversible degradation risk is high.')
    if v.get('X',0) >= 70: blockers.append('Hidden externalities remain high.')
    if v.get('H',100) < 45: blockers.append('Habitat integrity is too weak.')
    if case.evidence_grade in ['D','E']: blockers.append('Evidence grade is insufficient for strong claims.')
    if case.uncertainty >= 0.35: blockers.append('Uncertainty is too high for final approval.')
    return blockers

def decide(score: float, blockers: List[str]) -> Decision:
    if any('Gewalt' in b or 'Irreversible' in b for b in blockers):
        return 'SUSPEND' if score >= 35 else 'REJECT'
    if score >= 75 and not blockers: return 'APPROVE'
    if score >= 60 and len(blockers) <= 1: return 'PILOT'
    if score >= 40: return 'REDESIGN'
    return 'REJECT'

def evaluate(case: RenovaCase) -> RenovaResult:
    pos=weighted_sum(POSITIVE, case.values, case.weights)
    neg=weighted_sum(NEGATIVE, case.values, case.weights)
    k=EVIDENCE_MULTIPLIERS.get(case.evidence_grade.upper(),0.75)
    u=clamp(case.uncertainty*100)
    score=clamp(k*(pos-neg+50)-u)
    blockers=detect_blockers(case)
    return RenovaResult(
        case_id=case.case_id,
        raw_positive=round(pos,2),
        raw_negative=round(neg,2),
        evidence_multiplier=k,
        uncertainty_penalty=round(u,2),
        r_total=round(score,2),
        decision=decide(score, blockers),
        blockers=blockers,
        falsification_condition='Reject or redesign if post-intervention measurement fails to show life-net increase and damage reduction within the stated review window.'
    )

def as_jsonable(result: RenovaResult):
    return asdict(result)
