#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'packages' / 'renova_core'))
from renova_protocol_engine import RenovaCase, evaluate, as_jsonable

def main():
    ap = argparse.ArgumentParser(description='Evaluate a Renova protocol benchmark case.')
    ap.add_argument('input', help='JSON input file')
    args = ap.parse_args()
    data = json.loads(Path(args.input).read_text(encoding='utf-8'))
    case = RenovaCase(**data)
    print(json.dumps(as_jsonable(evaluate(case)), ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
