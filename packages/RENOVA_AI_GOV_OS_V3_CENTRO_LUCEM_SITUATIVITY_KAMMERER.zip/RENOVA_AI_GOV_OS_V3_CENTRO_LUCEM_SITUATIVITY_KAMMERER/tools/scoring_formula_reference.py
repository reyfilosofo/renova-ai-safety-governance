from __future__ import annotations

def clamp(x: float) -> float:
    return max(0.0, min(100.0, float(x)))

def avg(values):
    return round(sum(clamp(v) for v in values) / len(values), 2)

def traffic(score):
    score = clamp(score)
    if score < 40:
        return "Critical"
    if score < 60:
        return "Fragile"
    if score < 80:
        return "Developing"
    return "Governable"

def score_use_case(scores):
    claritas = avg([scores["truthfulness"], scores["clarity"], scores["coherence"], scores["traceability"], scores["epistemicNonHarm"]])
    ratio = avg([scores["evidenceRobustness"], scores["plurality"], scores["reasoningConsistency"], scores["challengeability"], scores["uncertaintyHandling"]])
    vita = avg([scores["humanImpact"], scores["dignity"], scores["reversibility"], scores["care"], scores["lifeCenteredFit"]])
    centro = avg([scores["ownership"], scores["humanOversight"], scores["escalation"], scores["driftReset"], scores["vendorGovernance"]])
    r_score = avg([claritas, ratio, vita, centro])
    return {
        "CLARITAS": claritas,
        "RATIO": ratio,
        "VITA": vita,
        "CENTRO": centro,
        "RScore": r_score,
        "traffic": traffic(r_score)
    }

if __name__ == "__main__":
    demo = {
        "truthfulness": 68, "clarity": 61, "coherence": 66, "traceability": 55, "epistemicNonHarm": 60,
        "evidenceRobustness": 62, "plurality": 50, "reasoningConsistency": 65, "challengeability": 58, "uncertaintyHandling": 56,
        "humanImpact": 60, "dignity": 70, "reversibility": 58, "care": 66, "lifeCenteredFit": 63,
        "ownership": 45, "humanOversight": 76, "escalation": 40, "driftReset": 35, "vendorGovernance": 52
    }
    print(score_use_case(demo))
