You are Codex working on a repository called `renova-ai-governance-os`.

Your task is to transform this starter package into a serious, working, repo-scale MVP for RENOVA AI GOVERNANCE OS by SERESARTE Group / ℛenova / Renova AI Governance Studio / ReyFilosofo Advisory.

This is an intentionally ambitious project. Treat it as a high-rigor AI governance product prototype, not as a generic dashboard. The goal is to use Codex at maximum intensity: inspect the full repository, improve the architecture, implement the missing product flows, harden the scoring engine, add tests, polish the UI, and produce a credible executive demo.

PRODUCT IDENTITY

Product name:
RENOVA AI GOVERNANCE OS

Owner:
Carlos Jonathan González Rodríguez / Jonathan ReyFilosofo by SERESARTE

Ecosystem:
SERESARTE Group · ℛenova · Renova AI Governance Studio · ReyFilosofo Advisory

Core phrase:
“Gobernar IA no es frenar la inteligencia; es darle verdad, vida y dirección.”

Core product thesis:
Organizations are adopting AI faster than they can govern it. RENOVA AI GOVERNANCE OS converts principles, risks, metrics and philosophical judgment into operational AI governance: AI Constitution, Truth & Life Audit, CLARITAS/RATIO/VITA/CENTRO/ℛ-Scorecard, risk map, RACI, playbooks, board memo and Roadmap 365.

WHAT TO DO FIRST

Before coding:

1. Inspect the repository.
2. Read `README.md`, `AGENTS.md`, `docs/PRD.md`, `docs/ARCHITECTURE.md`, `docs/METHODOLOGY.md`, `docs/LIMITATIONS.md`, `docs/SCIENTIFIC_ALIGNMENT.md`, `docs/BACKLOG.md`, `source_materials/SOURCE_SYNTHESIS.md`.
3. Summarize what already exists.
4. Identify gaps.
5. Propose a concise implementation plan.
6. Then implement.

NON-NEGOTIABLE LIMITS

1. Do not claim legal compliance.
2. Do not claim ISO/IEC 42001 certification.
3. Do not claim NIST certification.
4. Do not claim EU AI Act formal conformity.
5. Do not provide legal advice.
6. Do not imply official affiliation with regulators or standards bodies.
7. Do not invent regulatory requirements.
8. Do not use real client data.
9. Do not add API keys or secrets.
10. Preserve the names SERESARTE, ℛenova, Renova AI Governance OS, Renova AI Governance Studio, ReyFilosofo Advisory, CLARITAS, RATIO, VITA, CENTRO, ℛ-Scorecard.
11. Never write “Renoba”.

TECH STACK

Use the existing starter stack unless you find a strong reason to alter it:

- Next.js
- TypeScript
- Tailwind CSS
- Zod
- React Hook Form if useful
- Recharts if useful
- Vitest
- Markdown/HTML export
- No auth in v0.1
- No external AI calls in v0.1
- No database in v0.1 unless absolutely necessary

PRIMARY BUILD GOALS

Build or improve the following:

1. Home / executive landing page
   - Premium board-level design.
   - Clear explanation of product.
   - Four phases: Diagnostic, AI Constitution, Truth & Life Audit, Governance OS.
   - Assurance stack: CLARITAS, RATIO, VITA, CENTRO, ℛ-Scorecard.
   - Clear disclaimers.

2. Full Assessment Wizard
   - Multi-step flow.
   - Organization profile.
   - AI maturity.
   - Governance status.
   - Committee status.
   - Add/edit/remove AI use cases.
   - Fields:
     - name
     - department
     - status
     - description
     - domain
     - affected users
     - data sensitivity
     - autonomy level
     - human oversight
     - truth risk
     - human impact risk
     - regulatory/reputational risk
     - current controls
     - evidence notes
   - Validate with Zod.
   - Persist locally with localStorage.
   - Allow reset to demo data.

3. Use Case Inventory
   - Table view.
   - Filter by risk class, status, department, domain.
   - Show owners, risk, current controls, missing controls.
   - Link to scoring details.

4. Scoring Engine
   - Keep pure deterministic functions.
   - Improve subcriteria scoring.
   - Explicitly score:
     - CLARITAS: truthfulness, clarity, coherence, traceability, epistemic non-harm.
     - RATIO: evidence robustness, plurality, reasoning consistency, challengeability, uncertainty handling.
     - VITA: human impact, dignity, reversibility, care, life-centered fit.
     - CENTRO: ownership, human oversight, escalation, drift reset, vendor governance.
   - Use blockers:
     - prohibited use indicator;
     - high-risk domain without human oversight;
     - traceability below threshold;
     - weak evidence plurality;
     - high human impact without reversibility;
     - weak drift reset;
     - no owner or escalation.
   - Add transparent rationale for every score.
   - Add tests.

5. Dashboard
   - Global ℛ-Score.
   - Layer scores.
   - Traffic light.
   - Use-case risk map.
   - Top risks.
   - Top recommendations.
   - Evidence gaps.
   - Blockers.
   - Roadmap preview.
   - Charts if useful.

6. AI Constitution Generator
   - Generate a full AI Constitution v1 based on assessment data.
   - Include principles, red zones, truth protocol, human oversight protocol, escalation, drift reset, vendor governance, committee, review cadence and limitations.
   - Render in app.
   - Export/copy as Markdown.
   - If feasible, add HTML export and print view.

7. Truth & Life Audit Generator
   - Generate a structured audit report.
   - Include executive summary, scope, methodology, use-case inventory, CLARITAS/RATIO/VITA/CENTRO findings, ℛ-Scorecard, blockers, evidence gaps, recommendations and roadmap.
   - Render in app.
   - Export/copy as Markdown.
   - If feasible, add HTML export and print view.

8. Board Memo Generator
   - Generate a board-level memo.
   - Include context, maturity, top risks, required decisions, workstreams, investment logic, 90/180/365-day roadmap and next meeting agenda.
   - Render in app.
   - Export/copy as Markdown.
   - If feasible, add HTML export and print view.

9. Playbook Library
   Create robust playbooks for:
   - hallucination / false authority incident;
   - bias or unfair output incident;
   - privacy or sensitive data incident;
   - model drift / behavior degradation;
   - high-impact decision escalation;
   - vendor/model update incident;
   - prompt injection or tool misuse;
   - public reputation incident.

   Each playbook must include:
   - trigger;
   - severity levels;
   - immediate action;
   - owner;
   - escalation path;
   - evidence required;
   - remediation;
   - post-incident review;
   - re-test requirement.

10. Roadmap 365
   - 0–30 days
   - 31–90 days
   - 91–180 days
   - 181–365 days
   Include actions, owners, evidence, outputs and decision points.

11. RACI
   - Create a visible RACI matrix.
   - Add recommended roles:
     - Board Sponsor
     - General Counsel
     - Risk/Compliance
     - CTO/CIO
     - Head of AI/Data
     - CISO
     - Human Impact Lead
     - Domain Owner
     - CENTRO Committee
     - External Expert / Renova Advisor

12. Documentation
   Update:
   - README.md
   - docs/ARCHITECTURE.md
   - docs/METHODOLOGY.md
   - docs/QA_PLAN.md
   - docs/BACKLOG.md
   - docs/CHANGELOG.md

13. Tests
   Add/expand tests for:
   - scoring functions;
   - traffic light classification;
   - high-risk blockers;
   - prohibited use;
   - missing values;
   - edge scores;
   - report generator smoke tests.

14. UX polish
   - Keep a premium institutional visual style.
   - Use black, bone, gold, restrained cobalt.
   - Avoid generic neon AI.
   - Make app useful to board/legal/risk/CTO users.
   - Make documents readable.

DEFINITION OF DONE

The task is complete when:

1. `npm install` succeeds.
2. `npm run typecheck` succeeds.
3. `npm run test` succeeds.
4. `npm run dev` starts the app.
5. User can complete or load an assessment.
6. Dashboard displays scores.
7. Reports render:
   - AI Constitution v1
   - Truth & Life Audit Report
   - Board Memo
8. Playbooks render.
9. Roadmap renders.
10. RACI renders.
11. Disclaimers are visible.
12. No compliance overclaiming exists.
13. README explains setup and use.
14. Backlog for v0.2 is updated.

IF SOMETHING IS TOO LARGE

Do not stop. Prioritize in this order:

1. scoring engine correctness;
2. assessment wizard;
3. dashboard;
4. report generators;
5. playbooks;
6. roadmap/RACI;
7. tests;
8. docs;
9. UI polish.

FINAL RESPONSE FORMAT

When done, provide:

1. Summary of implemented changes.
2. How to run.
3. Tests run and results.
4. Files changed.
5. Known limitations.
6. Recommended next Codex task for v0.2.
