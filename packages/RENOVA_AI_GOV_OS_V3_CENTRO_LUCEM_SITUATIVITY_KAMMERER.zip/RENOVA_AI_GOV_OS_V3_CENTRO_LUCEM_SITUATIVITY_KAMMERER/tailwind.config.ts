import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}", "./prototype/**/*.html"],
  theme: {
    extend: {
      colors: {
        ink: "#050505",
        paper: "#f6f1e8",
        bone: "#e7ddcc",
        cobalt: "#143b78",
        gold: "#b18a3b",
        ember: "#8b2e21"
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui"],
        serif: ["Georgia", "Times New Roman", "serif"]
      }
    }
  },
  plugins: []
};

export default config;
