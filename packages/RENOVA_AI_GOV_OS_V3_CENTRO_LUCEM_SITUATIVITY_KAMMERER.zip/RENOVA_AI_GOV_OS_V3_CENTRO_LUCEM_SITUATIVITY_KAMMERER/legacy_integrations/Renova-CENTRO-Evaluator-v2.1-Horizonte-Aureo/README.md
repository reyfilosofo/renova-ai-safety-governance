# ℛenova CENTRO Evaluator v2.1 — Horizonte Áureo

**Producto integrado SERESARTE / ℛenova / CENTRO / LUCEM**

Esta edición une dos capas:

1. **Renova Evaluator v2.0 Horizonte Áureo**: evaluación multicriterio basada en el Lagrangiano Renovativo corregido.
2. **LUCEM / CENTRO Safe Bundle**: identidad operativa y protocolo de gobernanza con CLARITAS, RATIO y VITA.

El resultado es un paquete más fuerte: no sólo calcula una puntuación renovativa, sino que obliga a pasar por una puerta ética explícita, auditable y reversible.

## Fórmula integrada

```text
L_R = C - G + νH + ρR - ωU
Q = (CLARITAS + RATIO + VITA) / 3
Score_Renova_CENTRO = Normalizar(L_R) × Q
```

## Qué contiene

- `renova_centro_evaluator_v2_1.py` — CLI principal integrado.
- `web/index.html` — app web premium estática, sin dependencias externas.
- `web/manifest.webmanifest` y `web/sw.js` — PWA instalable/offline.
- `governance/CENTRO_CHARTER.md` — charter CENTRO/LUCEM original integrado.
- `config/` — prompts y configuraciones JSON/YAML de CENTRO/LUCEM.
- `docs/` — metodología, formalización, límites, despliegue, Lovable, EdgeOne, Edu-Zōḗ.
- `examples/` — entradas demo y reporte demo.
- `source_bundles/` — bundle CENTRO original preservado para trazabilidad.
- `tools/create_renova_centro_zip.py` — generador reproducible del ZIP.

## Uso rápido CLI

```bash
python renova_centro_evaluator_v2_1.py --demo
python renova_centro_evaluator_v2_1.py --input examples/demo_renova_centro_input.json --export-md reporte.md --json reporte.json
```

## Uso web

Abre:

```text
web/index.html
```

o sube la carpeta `web/` a EdgeOne Pages, Netlify, Vercel, GitHub Pages o cualquier hosting estático.

## Estatuto epistemológico

Este paquete **no afirma** que la ℛenova esté validada como ley física universal. La presenta como un marco normativo, filosófico, metodológico y computacional para diseñar, comparar, auditar y mejorar decisiones. El protocolo CENTRO reduce el riesgo de mathwashing porque exige verdad, evidencia, reversibilidad, no-daño y delimitación explícita de incertidumbre.

## Estado

- LUCEM integrado como identidad operativa.
- CENTRO integrado como protocolo de evaluación.
- CLARITAS/RATIO/VITA integrados en el cálculo.
- App web y CLI funcionales.
- Paquete reproducible y auditable.
