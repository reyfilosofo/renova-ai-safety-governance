# Módulo Edu-Zoe

Edu-Zoe evalúa experiencias educativas según capacidad vital y daño evitable.

- C_bio: condiciones corporales y salud del aprendizaje.
- C_sem: sentido, comprensión, lenguaje y pluralidad.
- C_creat: producción de obras, preguntas, soluciones y prototipos.
- C_rel: cooperación, cuidado, comunidad y confianza.
- C_hor: continuidad, legado y posibilidades futuras.

G mide daño físico, exclusión estructural, violencia epistémica, impacto ecológico y cierre temporal.
