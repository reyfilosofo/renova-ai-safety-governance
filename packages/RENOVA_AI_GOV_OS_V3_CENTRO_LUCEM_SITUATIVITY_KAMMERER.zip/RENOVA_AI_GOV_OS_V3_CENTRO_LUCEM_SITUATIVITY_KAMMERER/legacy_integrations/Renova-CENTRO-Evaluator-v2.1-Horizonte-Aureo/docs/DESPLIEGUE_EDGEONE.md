# Despliegue en EdgeOne Pages

## Carpeta a subir

Sube la carpeta:

```text
web/
```

Debe incluir:

- `index.html`
- `manifest.webmanifest`
- `sw.js`
- `assets/icon.svg`
- `data/dao-centro-context.json`

## Tipo de despliegue

Hosting estático. No requiere backend.

## Seguridad

La app no envía datos por red. El historial queda en el navegador del usuario.

## Recomendación SERESARTE

Publicar primero como demo gratuita, luego evolucionar a versión full-stack con base de datos, cuentas y exportación PDF avanzada si el uso lo justifica.
