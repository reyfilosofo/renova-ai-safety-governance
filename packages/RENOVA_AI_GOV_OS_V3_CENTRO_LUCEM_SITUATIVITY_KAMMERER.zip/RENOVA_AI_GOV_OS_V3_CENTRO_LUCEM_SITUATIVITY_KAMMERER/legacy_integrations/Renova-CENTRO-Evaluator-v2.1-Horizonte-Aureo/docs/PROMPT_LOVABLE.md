# Prompt maestro para Lovable

Crea una aplicación web full-stack llamada Renova Evaluator v2.0 Horizonte Áureo. Debe implementar el cálculo L_R = C - G + nu H + rho R - omega U y la puerta ética Q = promedio de CLARITAS, RATIO y VITA. Incluye sliders 0-10 para C_bio, C_sem, C_creat, C_rel, C_hor, G_fis, G_estr, G_epis, G_eco, G_temp, H, R y U; reporte exportable en JSON y Markdown; historial persistente; módulo Dao De Jing contextual; módulo Edu-Zoe para currículos; interfaz premium SERESARTE / RENOVA PRESS; modo móvil; accesibilidad; y despliegue estático o con Supabase opcional.
