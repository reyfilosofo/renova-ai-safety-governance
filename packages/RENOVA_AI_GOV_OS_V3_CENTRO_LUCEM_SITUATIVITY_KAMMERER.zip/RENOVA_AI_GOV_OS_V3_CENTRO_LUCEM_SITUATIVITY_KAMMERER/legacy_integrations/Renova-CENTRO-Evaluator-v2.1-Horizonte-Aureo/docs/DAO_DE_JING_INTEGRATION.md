# Integración Dao De Jing contextual

El módulo Dao no debe usarse como prueba científica ni como argumento de autoridad. Funciona como capa hermenéutica: una lectura breve del resultado orientada a no forzar, reducir daño, preservar reversibilidad y actuar sin jactancia cuando el score es alto.
