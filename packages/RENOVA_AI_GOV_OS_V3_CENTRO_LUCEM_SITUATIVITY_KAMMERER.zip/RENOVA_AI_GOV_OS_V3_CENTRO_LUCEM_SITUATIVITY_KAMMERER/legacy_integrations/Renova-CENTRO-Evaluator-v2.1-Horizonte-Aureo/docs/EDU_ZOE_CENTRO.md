# Edu-Zōḗ + CENTRO

Edu-Zōḗ es el módulo educativo del paquete.

Convierte cualquier evaluación renovativa en una experiencia de aprendizaje:

1. Diagnóstico Hábitat-Herida-Horizonte.
2. Preguntas de CLARITAS.
3. Evidencia y contraste RATIO.
4. Impacto, reversibilidad y futuro VITA.
5. Producción de un ente: guía, obra, protocolo, maqueta, mapa, intervención.
6. Evaluación antes/después.
7. Registro de aprendizaje.

## Uso en Tlalnepantla o comunidad piloto

El módulo puede usarse para talleres de niñas, niños, familias, docentes, adultos mayores o gestores culturales.

## Producto esperado

Un currículo renovativo que no sólo transmite información, sino que produce agencia, cuidado, sentido y capacidad de transformación.
