# Prompt maestro para Lovable: Renova CENTRO Evaluator v2.1

Crea una aplicación full-stack premium llamada **Renova CENTRO Evaluator v2.1 — Horizonte Áureo**.

Debe unir:

1. El Lagrangiano Renovativo corregido:
   L_R = C - G + νH + ρR - ωU

2. La puerta ética CENTRO:
   Q = (CLARITAS + RATIO + VITA) / 3

3. Score final:
   Score = Normalizar(L_R) × Q

Requisitos:

- Frontend React + TypeScript + Tailwind.
- Tema visual oscuro, editorial, áureo, SERESARTE/ℛenova.
- Sliders 0-10 para C_bio, C_sem, C_creat, C_rel, C_hor.
- Sliders 0-10 para G_fis, G_estr, G_epis, G_eco, G_temp.
- Sliders H, R y U.
- Scorecard CENTRO con CLARITAS/RATIO/VITA.
- Dashboard con score, veredicto, recomendaciones, radar chart, barras y explicación.
- Historial de evaluaciones con Supabase.
- Exportación PDF, Markdown y JSON.
- Modo libro/proyecto/política/educación/arte/decisión familiar.
- Módulo Edu-Zōḗ para convertir una evaluación en currículo renovativo.
- Módulo Dao contextual según score.
- Aviso metodológico: no sustituye revisión experta.
- Sin promesas científicas no validadas.
- Botón de “Reevaluar después de implementación”.
- Responsive móvil.
- PWA instalable.

Texto de footer:
“SERESARTE · ℛenova · CENTRO · LUCEM — CLARITAS, RATIO, VITA.”
