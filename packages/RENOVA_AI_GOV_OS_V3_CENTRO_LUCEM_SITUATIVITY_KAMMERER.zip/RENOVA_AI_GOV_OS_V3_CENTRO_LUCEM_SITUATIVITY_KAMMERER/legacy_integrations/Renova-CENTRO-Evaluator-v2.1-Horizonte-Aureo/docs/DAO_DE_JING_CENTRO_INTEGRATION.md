# Dao De Jing + CENTRO

La integración Dao no pretende convertir el evaluador en herramienta mística.

Funciona como capa hermenéutica:

- Score alto: acción sin violencia, potencia sin exceso.
- Score medio: poda, ajuste, reducción del daño.
- Score bajo: detenerse también puede ser acción renovativa.

El Dao opera como recordatorio formal: no toda intervención fuerte es sabia; no toda expansión es horizonte.
