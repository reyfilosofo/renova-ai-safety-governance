# Protocolo CLARITAS · RATIO · VITA

CLARITAS evalúa claridad, verificabilidad, coherencia y daño evitable.

RATIO evalúa evidencia, objeciones, reproducibilidad y falsabilidad práctica.

VITA evalúa impacto vital, apertura intergeneracional, reversibilidad y aprendizaje.

Una decisión con L_R positivo pero Q bajo debe detenerse, documentarse y rediseñarse.
