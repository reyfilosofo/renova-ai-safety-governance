# Metodología y límites

## Método

1. Describir la decisión o proyecto.
2. Puntuar C: capacidad vital creada.
3. Puntuar G: carga destructiva o Gewalt.
4. Puntuar H: apertura de horizonte.
5. Puntuar R: reversibilidad.
6. Puntuar U: incertidumbre.
7. Evaluar CENTRO: CLARITAS, RATIO y VITA.
8. Leer score, veredicto y sugerencias.
9. Registrar evidencia y reevaluar después de la implementación.

## Límites

- Las puntuaciones son dependientes del criterio humano.
- Los pesos son configurables y deben justificarse por dominio.
- El score no prueba verdad ontológica.
- La herramienta es útil para deliberación, comparación, diseño y auditoría inicial.
- Para decisiones de alto riesgo debe existir evaluación experta independiente.

## Mejora frente a v2.0

La edición v2.1 integra CENTRO como puerta ética y no como apéndice textual. Eso vuelve el resultado más exigente: baja si hay poca evidencia, mala claridad, bajo no-daño o baja reversibilidad.
