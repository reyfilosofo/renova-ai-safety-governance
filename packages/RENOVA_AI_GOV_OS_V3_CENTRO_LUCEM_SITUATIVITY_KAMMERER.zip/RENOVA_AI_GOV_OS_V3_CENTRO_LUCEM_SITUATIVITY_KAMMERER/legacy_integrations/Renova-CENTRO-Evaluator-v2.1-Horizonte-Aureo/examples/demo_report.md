# Reporte Renova Evaluator v2.0

**Fecha:** 2026-05-22T05:32:14
**Decisión:** Desplegar Renova Evaluator como app web pública con historial local y exportación de reportes.
**Tipo:** comunitaria / tecnológica

## Resultado

- C_total ponderado: **48.4**
- G_total ponderado: **8.05**
- Bono de horizonte νH: **10.8**
- Bono de reversibilidad ρR: **8.0**
- Penalización de incertidumbre ωU: **4.8**
- Lagrangiano crudo L_R: **54.35**
- L_R normalizado: **83.9/100**
- Puerta ética CLARITAS/RATIO/VITA: **0.833**
- Score final: **69.92/100**
- Veredicto: **PROCEDER CON AJUSTES: positiva, pero mejorable.**

## Componentes C

- C_bio: 5.0
- C_sem: 8.5
- C_creat: 9.0
- C_rel: 7.5
- C_hor: 9.0

## Componentes G

- G_fis: 0.5
- G_estr: 1.0
- G_epis: 1.5
- G_eco: 1.0
- G_temp: 1.0

## Filtros

- CLARITAS: 0.85
- RATIO: 0.75
- VITA: 0.9

## Sugerencias

- Mayor carga G detectada: G_temp. Intervenir ahí produce el mayor aumento marginal de L_R.
- Componente C más débil: C_bio. Diseñar una acción concreta para elevarlo.

## Notas y supuestos

Evaluación demostrativa; debe sustituirse por datos reales en uso institucional.

## Advertencia metodológica

Este reporte es un instrumento de decisión multicriterio. No sustituye evaluación técnica, jurídica, médica, ambiental o científica especializada cuando el dominio lo exija.
