# CHANGELOG

## v2.1 — Renova CENTRO Evaluator Horizonte Áureo

- Integración completa del bundle LUCEM/CENTRO.
- CENTRO convertido en puerta ética numérica Q.
- Nuevo CLI `renova_centro_evaluator_v2_1.py`.
- Nueva app web premium sin dependencias externas.
- Módulo Edu-Zōḗ integrado.
- Módulo Dao contextual integrado.
- Gobernanza y política de despliegue seguro.
- Preservación del bundle CENTRO original en `source_bundles/`.
- Generador reproducible del ZIP.
