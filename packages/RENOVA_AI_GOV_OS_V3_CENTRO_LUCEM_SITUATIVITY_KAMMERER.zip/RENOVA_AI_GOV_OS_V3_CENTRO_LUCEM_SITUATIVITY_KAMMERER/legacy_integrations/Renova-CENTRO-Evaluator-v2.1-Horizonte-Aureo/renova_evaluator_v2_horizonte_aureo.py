#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RENOVA EVALUATOR v2.0 HORIZONTE ÁUREO
Herramienta operativa para evaluar decisiones mediante un Índice Lagrangiano Renovativo.

Autoría conceptual: Carlos Jonathan González Rodríguez / Rey Filósofo by SERESARTE
Implementación: versión técnica depurada para CLI, JSON y despliegue posterior en web.

IMPORTANTE METODOLÓGICO
-----------------------
Esta herramienta NO afirma medir "la vida" en sentido físico universal.
Opera como un instrumento de evaluación multicriterio inspirado en el vocabulario
lagrangiano: compara capacidad vital creada (C), carga destructiva/Gewalt (G),
potencial de horizonte (H), reversibilidad (R), incertidumbre (U) y calidad ética
(CLARITAS, RATIO, VITA).

Uso:
    python renova_evaluator_v2_horizonte_aureo.py
    python renova_evaluator_v2_horizonte_aureo.py --demo
    python renova_evaluator_v2_horizonte_aureo.py --history
    python renova_evaluator_v2_horizonte_aureo.py --export-md reporte.md

Dependencias:
    Python 3.9+ / biblioteca estándar.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import math
import os
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Tuple, Any


# ---------------------------------------------------------------------------
# COMPONENTES
# ---------------------------------------------------------------------------

C_COMPONENTS: Dict[str, str] = {
    "bio": "Vitalidad biológica, salud, cuidado corporal, energía funcional.",
    "sem": "Apertura semiótica: sentido, legibilidad, pluralidad interpretativa.",
    "creat": "Creación de entes nuevos: obras, conceptos, vínculos, instituciones.",
    "rel": "Florecimiento relacional: vínculos familiares, comunitarios, confianza.",
    "hor": "Horizonte temporal: futuros abiertos, continuidad, legado y aprendizaje.",
}

G_COMPONENTS: Dict[str, str] = {
    "fis": "Daño físico directo, riesgo corporal o daño material irreversible.",
    "estr": "Violencia estructural: desigualdad, precarización, exclusión, abuso.",
    "epis": "Violencia epistémica: borrado de saberes, opacidad, manipulación.",
    "eco": "Daño ecológico: pérdida de biodiversidad, residuos, extracción destructiva.",
    "temp": "Cierre de futuro: irreversibilidad, deuda vital, daño intergeneracional.",
}

DEFAULT_WEIGHTS: Dict[str, Any] = {
    "C": {"bio": 1.0, "sem": 1.1, "creat": 1.2, "rel": 1.3, "hor": 1.5},
    "G": {"fis": 1.8, "estr": 1.5, "epis": 1.3, "eco": 1.7, "temp": 2.0},
    "nu_horizon": 1.2,
    "rho_reversibility": 1.0,
    "omega_uncertainty": 1.2,
    "ethical_gate_min": 0.65,
}

QUALITY_QUESTIONS = {
    "claritas": [
        {
            "id": "verifiable",
            "question": "La información usada para puntuar C y G es verificable, clara y no contradictoria.",
            "positive": True,
        },
        {
            "id": "avoidable_harm",
            "question": "La decisión genera daño evitable a personas, comunidades o ecosistemas.",
            "positive": False,
        },
        {
            "id": "better_alternative",
            "question": "Existe una alternativa realista con mayor C y menor o igual G.",
            "positive": False,
        },
        {
            "id": "reversible",
            "question": "La decisión puede revertirse o corregirse si se demuestra equivocada.",
            "positive": True,
        },
    ],
    "ratio": [
        {
            "id": "evidence",
            "question": "Las puntuaciones se sustentan en evidencia empírica, histórica, técnica o experiencial explícita.",
            "positive": True,
        },
        {
            "id": "counterarguments",
            "question": "Se consideraron contraejemplos, objeciones y perspectivas afectadas.",
            "positive": True,
        },
        {
            "id": "replicable",
            "question": "Otra persona podría reproducir la evaluación con la misma información.",
            "positive": True,
        },
    ],
    "vita": [
        {
            "id": "net_positive",
            "question": "El impacto vital neto es positivo para las personas y sistemas directamente afectados.",
            "positive": True,
        },
        {
            "id": "future_options",
            "question": "La decisión preserva o aumenta opciones para generaciones futuras.",
            "positive": True,
        },
        {
            "id": "learning_loop",
            "question": "Existe un mecanismo concreto de seguimiento, corrección y aprendizaje.",
            "positive": True,
        },
    ],
}

SCORE_MAP_POSITIVE = {
    "alta": 1.0, "a": 1.0, "si": 1.0, "sí": 1.0, "s": 1.0, "1": 1.0,
    "media": 0.6, "m": 0.6, "parcial": 0.6, "p": 0.6, "0.5": 0.6,
    "baja": 0.2, "b": 0.2, "no": 0.0, "n": 0.0, "0": 0.0,
}

SCORE_MAP_NEGATIVE = {
    # Para preguntas de riesgo: "alta" significa mucho riesgo, por tanto puntúa bajo.
    "alta": 0.0, "a": 0.0, "si": 0.0, "sí": 0.0, "s": 0.0, "1": 0.0,
    "media": 0.5, "m": 0.5, "parcial": 0.5, "p": 0.5, "0.5": 0.5,
    "baja": 0.8, "b": 0.8, "no": 1.0, "n": 1.0, "0": 1.0,
}


# ---------------------------------------------------------------------------
# MODELOS DE DATOS
# ---------------------------------------------------------------------------

@dataclass
class EvaluationInput:
    decision: str
    decision_type: str
    c_scores: Dict[str, float]
    g_scores: Dict[str, float]
    horizon: float
    reversibility: float
    uncertainty: float
    quality_scores: Dict[str, float]
    notes: str = ""


@dataclass
class EvaluationResult:
    timestamp: str
    input: EvaluationInput
    c_total: float
    g_total: float
    horizon_bonus: float
    reversibility_bonus: float
    uncertainty_penalty: float
    raw_lagrangian: float
    normalized_lagrangian: float
    quality_gate: float
    final_score: float
    verdict: str
    suggestions: List[str]


# ---------------------------------------------------------------------------
# UTILIDADES DE CÁLCULO
# ---------------------------------------------------------------------------

def clamp(value: float, lo: float = 0.0, hi: float = 10.0) -> float:
    return max(lo, min(hi, float(value)))


def weighted_sum(scores: Dict[str, float], weights: Dict[str, float]) -> float:
    return sum(weights[k] * clamp(scores.get(k, 0.0)) for k in weights)


def normalize_to_100(raw: float, min_raw: float, max_raw: float) -> float:
    if math.isclose(max_raw, min_raw):
        return 0.0
    return max(0.0, min(100.0, 100.0 * (raw - min_raw) / (max_raw - min_raw)))


class RenovaEvaluator:
    def __init__(self, history_path: str | Path = "renova_horizonte_aureo_history.json",
                 weights: Dict[str, Any] | None = None):
        self.history_path = Path(history_path)
        self.weights = weights or DEFAULT_WEIGHTS

    def calculate(self, data: EvaluationInput) -> EvaluationResult:
        c_total = weighted_sum(data.c_scores, self.weights["C"])
        g_total = weighted_sum(data.g_scores, self.weights["G"])
        horizon_bonus = self.weights["nu_horizon"] * clamp(data.horizon)
        reversibility_bonus = self.weights["rho_reversibility"] * clamp(data.reversibility)
        uncertainty_penalty = self.weights["omega_uncertainty"] * clamp(data.uncertainty)

        raw = c_total - g_total + horizon_bonus + reversibility_bonus - uncertainty_penalty

        max_c = weighted_sum({k: 10 for k in C_COMPONENTS}, self.weights["C"])
        max_g = weighted_sum({k: 10 for k in G_COMPONENTS}, self.weights["G"])
        max_raw = max_c + self.weights["nu_horizon"] * 10 + self.weights["rho_reversibility"] * 10
        min_raw = -max_g - self.weights["omega_uncertainty"] * 10

        normalized = normalize_to_100(raw, min_raw, max_raw)

        quality_gate = sum(data.quality_scores.values()) / max(1, len(data.quality_scores))
        final_score = normalized * quality_gate

        verdict = self.verdict(raw, quality_gate, final_score)
        suggestions = self.generate_suggestions(data, c_total, g_total, raw, quality_gate)

        return EvaluationResult(
            timestamp=_dt.datetime.now().isoformat(timespec="seconds"),
            input=data,
            c_total=round(c_total, 3),
            g_total=round(g_total, 3),
            horizon_bonus=round(horizon_bonus, 3),
            reversibility_bonus=round(reversibility_bonus, 3),
            uncertainty_penalty=round(uncertainty_penalty, 3),
            raw_lagrangian=round(raw, 3),
            normalized_lagrangian=round(normalized, 2),
            quality_gate=round(quality_gate, 3),
            final_score=round(final_score, 2),
            verdict=verdict,
            suggestions=suggestions,
        )

    def verdict(self, raw: float, quality_gate: float, final_score: float) -> str:
        if raw <= 0:
            return "REDISEÑAR: la carga destructiva supera la capacidad vital creada."
        if quality_gate < self.weights["ethical_gate_min"]:
            return "DETENER Y DOCUMENTAR: el resultado matemático es positivo, pero los filtros éticos son insuficientes."
        if final_score >= 75:
            return "PROCEDER: decisión fuertemente renovativa, con seguimiento."
        if final_score >= 55:
            return "PROCEDER CON AJUSTES: positiva, pero mejorable."
        return "ITERAR: positiva débil; conviene rediseñar antes de ejecutar."

    def generate_suggestions(self, data: EvaluationInput, c_total: float, g_total: float,
                             raw: float, quality_gate: float) -> List[str]:
        suggestions: List[str] = []

        worst_g = sorted(data.g_scores.items(), key=lambda kv: kv[1] * self.weights["G"].get(kv[0], 1), reverse=True)
        weakest_c = sorted(data.c_scores.items(), key=lambda kv: kv[1] * self.weights["C"].get(kv[0], 1))

        if raw <= 0:
            suggestions.append("Reducir primero el componente G dominante antes de intentar aumentar C.")
        if worst_g:
            suggestions.append(f"Mayor carga G detectada: G_{worst_g[0][0]}. Intervenir ahí produce el mayor aumento marginal de L_R.")
        if weakest_c:
            suggestions.append(f"Componente C más débil: C_{weakest_c[0][0]}. Diseñar una acción concreta para elevarlo.")
        if data.reversibility < 6:
            suggestions.append("Aumentar reversibilidad: versionado, piloto pequeño, salida de emergencia, consentimiento informado o prueba A/B.")
        if data.uncertainty > 5:
            suggestions.append("Reducir incertidumbre: recolectar datos, consultar afectados, revisar antecedentes y documentar supuestos.")
        if quality_gate < self.weights["ethical_gate_min"]:
            suggestions.append("Reforzar CLARITAS/RATIO/VITA antes de ejecutar: sin calidad ética, el score final no debe usarse como autorización.")
        if data.horizon < 6:
            suggestions.append("Abrir horizonte: convertir la decisión en aprendizaje replicable mediante bitácora, reporte, archivo abierto o manual.")
        if not suggestions:
            suggestions.append("Mantener seguimiento: medir efectos reales después de ejecutar y comparar contra la predicción.")
        return suggestions

    def save(self, result: EvaluationResult) -> None:
        history = []
        if self.history_path.exists():
            try:
                history = json.loads(self.history_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                backup = self.history_path.with_suffix(".corrupt.bak")
                self.history_path.rename(backup)
                history = []
        history.append(asdict(result))
        self.history_path.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")

    def load_history(self) -> List[Dict[str, Any]]:
        if not self.history_path.exists():
            return []
        try:
            return json.loads(self.history_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return []

    def export_markdown(self, result: EvaluationResult, path: str | Path) -> None:
        path = Path(path)
        md = result_to_markdown(result)
        path.write_text(md, encoding="utf-8")


# ---------------------------------------------------------------------------
# ENTRADA/SALIDA
# ---------------------------------------------------------------------------

def ask_float(prompt: str, lo: float = 0.0, hi: float = 10.0) -> float:
    while True:
        raw = input(prompt).strip().replace(",", ".")
        if raw == "":
            return 0.0
        try:
            val = float(raw)
            if lo <= val <= hi:
                return val
            print(f"Introduce un número entre {lo:g} y {hi:g}.")
        except ValueError:
            print("Entrada inválida. Usa un número.")


def ask_component_scores(title: str, components: Dict[str, str]) -> Dict[str, float]:
    print(f"\n{title}")
    print("Escala: 0 = nulo / 10 = máximo")
    scores = {}
    for key, desc in components.items():
        scores[key] = ask_float(f"{key.upper():>5} | {desc}\n> ")
    return scores


def ask_quality_filter(name: str, questions: List[Dict[str, Any]]) -> float:
    print(f"\nFILTRO {name.upper()}")
    print("Responde: alta/media/baja o sí/no según corresponda.")
    values = []
    for item in questions:
        raw = input(f"- {item['question']}\n> ").strip().lower()
        mapper = SCORE_MAP_POSITIVE if item["positive"] else SCORE_MAP_NEGATIVE
        values.append(mapper.get(raw, 0.5))
    return sum(values) / len(values)


def run_interactive() -> EvaluationInput:
    print("=" * 78)
    print("RENOVA EVALUATOR v2.0 HORIZONTE ÁUREO")
    print("Evaluación multicriterio de decisiones mediante L_R = C - G + νH + ρR - ωU")
    print("=" * 78)

    decision = input("\nDescribe la decisión a evaluar:\n> ").strip()
    decision_type = input("\nTipo de decisión (familiar / artística / comunitaria / política / otra):\n> ").strip().lower()

    c_scores = ask_component_scores("CAPACIDAD VITAL CREADA (C)", C_COMPONENTS)
    g_scores = ask_component_scores("CARGA DESTRUCTIVA / GEWALT (G)", G_COMPONENTS)

    horizon = ask_float("\nH | Potencial de apertura de horizonte (0-10):\n> ")
    reversibility = ask_float("\nR | Reversibilidad/capacidad de corrección (0-10):\n> ")
    uncertainty = ask_float("\nU | Incertidumbre/riesgo de mala estimación (0-10):\n> ")

    quality_scores = {
        name: ask_quality_filter(name, questions)
        for name, questions in QUALITY_QUESTIONS.items()
    }

    notes = input("\nNotas, evidencias o supuestos principales:\n> ").strip()

    return EvaluationInput(
        decision=decision,
        decision_type=decision_type,
        c_scores=c_scores,
        g_scores=g_scores,
        horizon=horizon,
        reversibility=reversibility,
        uncertainty=uncertainty,
        quality_scores=quality_scores,
        notes=notes,
    )


def demo_input() -> EvaluationInput:
    return EvaluationInput(
        decision="Desplegar Renova Evaluator como app web pública con historial local y exportación de reportes.",
        decision_type="comunitaria / tecnológica",
        c_scores={"bio": 5.0, "sem": 8.5, "creat": 9.0, "rel": 7.5, "hor": 9.0},
        g_scores={"fis": 0.5, "estr": 1.0, "epis": 1.5, "eco": 1.0, "temp": 1.0},
        horizon=9.0,
        reversibility=8.0,
        uncertainty=4.0,
        quality_scores={"claritas": 0.85, "ratio": 0.75, "vita": 0.90},
        notes="Evaluación demostrativa; debe sustituirse por datos reales en uso institucional.",
    )


def result_to_markdown(result: EvaluationResult) -> str:
    data = result.input
    lines = [
        "# Reporte Renova Evaluator v2.0 Horizonte Áureo",
        "",
        f"**Fecha:** {result.timestamp}",
        f"**Decisión:** {data.decision}",
        f"**Tipo:** {data.decision_type}",
        "",
        "## Resultado",
        "",
        f"- C_total ponderado: **{result.c_total}**",
        f"- G_total ponderado: **{result.g_total}**",
        f"- Bono de horizonte νH: **{result.horizon_bonus}**",
        f"- Bono de reversibilidad ρR: **{result.reversibility_bonus}**",
        f"- Penalización de incertidumbre ωU: **{result.uncertainty_penalty}**",
        f"- Lagrangiano crudo L_R: **{result.raw_lagrangian}**",
        f"- L_R normalizado: **{result.normalized_lagrangian}/100**",
        f"- Puerta ética CLARITAS/RATIO/VITA: **{result.quality_gate}**",
        f"- Score final: **{result.final_score}/100**",
        f"- Veredicto: **{result.verdict}**",
        "",
        "## Componentes C",
        "",
    ]
    for k, v in data.c_scores.items():
        lines.append(f"- C_{k}: {v}")
    lines.extend(["", "## Componentes G", ""])
    for k, v in data.g_scores.items():
        lines.append(f"- G_{k}: {v}")
    lines.extend(["", "## Filtros", ""])
    for k, v in data.quality_scores.items():
        lines.append(f"- {k.upper()}: {round(v, 3)}")
    lines.extend(["", "## Sugerencias", ""])
    for s in result.suggestions:
        lines.append(f"- {s}")
    if data.notes:
        lines.extend(["", "## Notas y supuestos", "", data.notes])
    lines.extend([
        "",
        "## Advertencia metodológica",
        "",
        "Este reporte es un instrumento de decisión multicriterio. No sustituye evaluación técnica, jurídica, médica, ambiental o científica especializada cuando el dominio lo exija.",
        ""
    ])
    return "\n".join(lines)


def print_result(result: EvaluationResult) -> None:
    print("\n" + "=" * 78)
    print("REPORTE RENOVA EVALUATOR v2.0 HORIZONTE ÁUREO")
    print("=" * 78)
    print(f"Decisión: {result.input.decision}")
    print(f"Tipo: {result.input.decision_type}")
    print(f"\nC_total: {result.c_total}")
    print(f"G_total: {result.g_total}")
    print(f"νH: {result.horizon_bonus}")
    print(f"ρR: {result.reversibility_bonus}")
    print(f"ωU: -{result.uncertainty_penalty}")
    print(f"\nL_R crudo: {result.raw_lagrangian}")
    print(f"L_R normalizado: {result.normalized_lagrangian}/100")
    print(f"Puerta ética: {result.quality_gate}")
    print(f"Score final: {result.final_score}/100")
    print(f"\nVEREDICTO: {result.verdict}")
    print("\nSUGERENCIAS:")
    for i, item in enumerate(result.suggestions, 1):
        print(f"{i}. {item}")


def print_history(evaluator: RenovaEvaluator) -> None:
    history = evaluator.load_history()
    if not history:
        print("No hay historial todavía.")
        return
    print("Últimas evaluaciones:")
    for i, rec in enumerate(history[-10:], 1):
        print(
            f"{i:02d}. {rec.get('timestamp','')} | "
            f"L_R={rec.get('raw_lagrangian')} | "
            f"Score={rec.get('final_score')} | "
            f"{rec.get('input',{}).get('decision','')[:80]}"
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="Renova Evaluator v2.0 Horizonte Áureo")
    parser.add_argument("--demo", action="store_true", help="Ejecuta una evaluación demostrativa.")
    parser.add_argument("--history", action="store_true", help="Muestra el historial.")
    parser.add_argument("--history-file", default="renova_horizonte_aureo_history.json", help="Ruta del historial JSON.")
    parser.add_argument("--export-md", default="", help="Exporta el último reporte generado a Markdown.")
    args = parser.parse_args()

    evaluator = RenovaEvaluator(history_path=args.history_file)

    if args.history:
        print_history(evaluator)
        return

    data = demo_input() if args.demo else run_interactive()
    result = evaluator.calculate(data)
    print_result(result)
    evaluator.save(result)

    if args.export_md:
        evaluator.export_markdown(result, args.export_md)
        print(f"\nReporte exportado a: {args.export_md}")

    print(f"\nHistorial guardado en: {args.history_file}")


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------------------
# EXTENSIONES HORIZONTE ÁUREO
# ---------------------------------------------------------------------------

def horizonte_aureo_branding() -> str:
    return """Renova Evaluator v2.0 Horizonte Áureo
SERESARTE / RENOVA PRESS
Formula: L_R = C - G + nu H + rho R - omega U; Score = Normalizar(L_R) * Q."""


def dao_context_for_score(score: float) -> str:
    """Devuelve una lectura contextual inspirada en Dao De Jing, sin convertirla en autoridad técnica."""
    if score >= 75:
        return "Lectura Dao: proceder sin jactancia, ejecutar con seguimiento y preservar reversibilidad."
    if score >= 55:
        return "Lectura Dao: ajustar antes de forzar; aumentar claridad, evidencia y cuidado."
    if score > 0:
        return "Lectura Dao: la acción aún está inmadura; conviene retornar, simplificar y reducir daño."
    return "Lectura Dao: detener el impulso; donde aumenta la violencia del sistema, la acción no debe imponerse."


def edu_zoe_template() -> dict:
    return {
        "nombre": "Plantilla Edu-Zoe",
        "proposito": "Evaluar actividades educativas según capacidad vital, sentido, comunidad, horizonte y bajo daño.",
        "dimensiones": ["cuidado corporal", "sentido", "creacion", "relacion", "horizonte", "reversibilidad", "evidencia"],
        "uso": "Diseñar curriculos, talleres, experiencias culturales y pedagogias comunitarias renovativas."
    }
