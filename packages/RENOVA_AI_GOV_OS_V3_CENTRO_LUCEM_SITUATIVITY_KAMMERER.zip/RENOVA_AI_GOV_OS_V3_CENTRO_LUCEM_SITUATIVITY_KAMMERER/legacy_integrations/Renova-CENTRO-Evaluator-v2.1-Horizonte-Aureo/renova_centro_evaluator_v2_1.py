#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Renova CENTRO Evaluator v2.1 — Horizonte Áureo

Herramienta local, offline-first y auditable para evaluar decisiones, proyectos,
libros, políticas, obras o intervenciones desde el marco combinado:

    L_R = C - G + nu*H + rho*R - omega*U

donde:
    C = capacidad vital creada
    G = carga destructiva / Gewalt
    H = apertura de horizonte
    R = reversibilidad
    U = incertidumbre

El resultado se somete a la puerta ética CENTRO:

    Q = (CLARITAS + RATIO + VITA) / 3

y se normaliza a escala 0-100.

Esta herramienta NO pretende demostrar una ley física universal. Es un instrumento
normativo-multicriterio inspirado en forma lagrangiana para deliberación, auditoría
y diseño renovativo. Debe usarse con evidencia, pluralidad y revisión humana.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional


C_COMPONENTS = ["bio", "sem", "creat", "rel", "hor"]
G_COMPONENTS = ["fis", "estr", "epis", "eco", "temp"]

DEFAULT_WEIGHTS = {
    "C": {"bio": 1.00, "sem": 1.15, "creat": 1.25, "rel": 1.30, "hor": 1.50},
    "G": {"fis": 2.00, "estr": 1.55, "epis": 1.35, "eco": 1.85, "temp": 2.10},
    "nu": 1.35,
    "rho": 1.20,
    "omega": 1.45
}

CENTRO_AXES = {
    "CLARITAS": [
        "verdad_verificable",
        "coherencia_conceptual",
        "precision_inteligible",
        "no_dano_evitable"
    ],
    "RATIO": [
        "evidencia_suficiente",
        "contraste_contraejemplos",
        "reproducibilidad",
        "delimitacion_incertidumbre"
    ],
    "VITA": [
        "impacto_vital_positivo",
        "reversibilidad_operativa",
        "apertura_intergeneracional",
        "potencia_renovativa"
    ]
}

INTERPRETATION = [
    (85, "FUERTEMENTE RENOVATIVA", "Proceder con documentación, monitoreo e iteración."),
    (70, "RENOVATIVA CONDICIONADA", "Proceder sólo con controles, indicadores y revisión."),
    (50, "AMBIVALENTE", "Rediseñar: hay valor, pero también riesgo o incertidumbre."),
    (0, "NO RENOVATIVA", "No proceder en la forma actual; replantear C, G, R y evidencia.")
]


@dataclass
class EvaluationInput:
    title: str
    domain: str
    description: str
    C: Dict[str, float]
    G: Dict[str, float]
    H: float
    R: float
    U: float
    centro: Dict[str, Dict[str, float]]
    notes: str = ""


@dataclass
class EvaluationResult:
    timestamp: str
    input: Dict[str, Any]
    weighted_C: Dict[str, float]
    weighted_G: Dict[str, float]
    C_total: float
    G_total: float
    H_contribution: float
    R_contribution: float
    U_penalty: float
    lagrangian_raw: float
    centro_scores: Dict[str, float]
    Q: float
    normalized_lagrangian: float
    final_score: float
    verdict: str
    recommendation: str
    suggestions: List[str]


def clamp_0_10(value: float) -> float:
    return max(0.0, min(10.0, float(value)))


def weighted_sum(scores: Dict[str, float], weights: Dict[str, float], components: List[str]) -> Tuple[float, Dict[str, float]]:
    parts = {k: clamp_0_10(scores.get(k, 0.0)) * weights[k] for k in components}
    return sum(parts.values()), parts


def score_axis(axis_data: Dict[str, float], axis_name: str) -> float:
    keys = CENTRO_AXES[axis_name]
    if not axis_data:
        return 0.0
    return sum(clamp_0_10(axis_data.get(k, 0.0)) for k in keys) / (10.0 * len(keys))


def normalize_lagrangian(raw: float) -> float:
    """
    Logistic normalization to 0-100.
    L=0 => 50. Large positive values approach 100, negative values approach 0.
    """
    return 100.0 / (1.0 + math.exp(-raw / 20.0))


def interpret(score: float) -> Tuple[str, str]:
    for threshold, verdict, rec in INTERPRETATION:
        if score >= threshold:
            return verdict, rec
    return INTERPRETATION[-1][1], INTERPRETATION[-1][2]


def generate_suggestions(inp: EvaluationInput, res_data: Dict[str, Any]) -> List[str]:
    suggestions: List[str] = []
    C = inp.C
    G = inp.G

    if res_data["Q"] < 0.70:
        suggestions.append("Fortalecer CENTRO: elevar CLARITAS/RATIO/VITA antes de ejecutar.")
    if C.get("hor", 0) < 7:
        suggestions.append("Aumentar C_hor: definir beneficios futuros, legado, replicabilidad y transferencia intergeneracional.")
    if C.get("rel", 0) < 7:
        suggestions.append("Aumentar C_rel: incorporar participación real de personas afectadas y mecanismos de cuidado comunitario.")
    if C.get("creat", 0) < 7:
        suggestions.append("Aumentar C_creat: producir un artefacto nuevo verificable: guía, protocolo, obra, dataset, currículo o herramienta.")
    if G.get("fis", 0) > 3 or G.get("temp", 0) > 3:
        suggestions.append("Reducir G crítico: daño físico y cierre temporal requieren rediseño inmediato, no sólo compensación retórica.")
    if G.get("epis", 0) > 3:
        suggestions.append("Reducir G_epis: documentar fuentes, voces divergentes, límites e incertidumbre para evitar violencia epistémica.")
    if G.get("eco", 0) > 3:
        suggestions.append("Reducir G_eco: añadir criterios de bajo impacto, circularidad, materiales reutilizables y evaluación ambiental.")
    if inp.R < 7:
        suggestions.append("Elevar R: crear plan de reversibilidad, rollback, monitoreo y reparación si aparecen efectos no deseados.")
    if inp.U > 4:
        suggestions.append("Reducir U: obtener evidencia adicional, pilotos pequeños, revisión externa y medición independiente.")
    if not suggestions:
        suggestions.append("Mantener trazabilidad: registrar indicadores antes/después, responsables, evidencia y revisión posterior.")
    suggestions.append("Reevaluar después de la primera iteración: una decisión renovativa debe aprender de sus efectos reales.")
    return suggestions


def evaluate(inp: EvaluationInput, weights: Dict[str, Any] = DEFAULT_WEIGHTS) -> EvaluationResult:
    C_total, weighted_C = weighted_sum(inp.C, weights["C"], C_COMPONENTS)
    G_total, weighted_G = weighted_sum(inp.G, weights["G"], G_COMPONENTS)

    H_contribution = weights["nu"] * clamp_0_10(inp.H)
    R_contribution = weights["rho"] * clamp_0_10(inp.R)
    U_penalty = weights["omega"] * clamp_0_10(inp.U)

    raw = C_total - G_total + H_contribution + R_contribution - U_penalty

    centro_scores = {axis: score_axis(inp.centro.get(axis, {}), axis) for axis in CENTRO_AXES}
    Q = sum(centro_scores.values()) / 3.0
    normalized = normalize_lagrangian(raw)
    final_score = normalized * Q

    verdict, recommendation = interpret(final_score)
    interim = {
        "Q": Q,
        "normalized_lagrangian": normalized,
        "final_score": final_score
    }
    suggestions = generate_suggestions(inp, interim)

    return EvaluationResult(
        timestamp=datetime.now().isoformat(timespec="seconds"),
        input=asdict(inp),
        weighted_C={k: round(v, 4) for k, v in weighted_C.items()},
        weighted_G={k: round(v, 4) for k, v in weighted_G.items()},
        C_total=round(C_total, 4),
        G_total=round(G_total, 4),
        H_contribution=round(H_contribution, 4),
        R_contribution=round(R_contribution, 4),
        U_penalty=round(U_penalty, 4),
        lagrangian_raw=round(raw, 4),
        centro_scores={k: round(v, 4) for k, v in centro_scores.items()},
        Q=round(Q, 4),
        normalized_lagrangian=round(normalized, 4),
        final_score=round(final_score, 4),
        verdict=verdict,
        recommendation=recommendation,
        suggestions=suggestions
    )


def load_input(path: Path) -> EvaluationInput:
    data = json.loads(path.read_text(encoding="utf-8"))
    return EvaluationInput(
        title=data.get("title", "Evaluación sin título"),
        domain=data.get("domain", "universal"),
        description=data.get("description", ""),
        C=data.get("C", {}),
        G=data.get("G", {}),
        H=data.get("H", 0),
        R=data.get("R", 0),
        U=data.get("U", 0),
        centro=data.get("centro", {}),
        notes=data.get("notes", "")
    )


def demo_input() -> EvaluationInput:
    high = {
        "CLARITAS": {
            "verdad_verificable": 8.5,
            "coherencia_conceptual": 9.0,
            "precision_inteligible": 8.7,
            "no_dano_evitable": 9.2
        },
        "RATIO": {
            "evidencia_suficiente": 7.8,
            "contraste_contraejemplos": 8.2,
            "reproducibilidad": 8.5,
            "delimitacion_incertidumbre": 8.8
        },
        "VITA": {
            "impacto_vital_positivo": 9.0,
            "reversibilidad_operativa": 8.4,
            "apertura_intergeneracional": 9.2,
            "potencia_renovativa": 9.4
        }
    }
    return EvaluationInput(
        title="Despliegue Renova CENTRO Evaluator en EdgeOne/Lovable",
        domain="herramienta_computacional_renovativa",
        description="Unificar el evaluador renovativo con el protocolo CENTRO/LUCEM para decisiones, proyectos, libros, educación y políticas.",
        C={"bio": 6.5, "sem": 9.0, "creat": 9.5, "rel": 8.5, "hor": 9.7},
        G={"fis": 0.5, "estr": 1.2, "epis": 1.1, "eco": 0.8, "temp": 1.0},
        H=9.5,
        R=8.8,
        U=2.0,
        centro=high,
        notes="Demo de integración Renova + CENTRO."
    )


def to_markdown(res: EvaluationResult) -> str:
    inp = res.input
    lines = [
        f"# Reporte Renova CENTRO Evaluator v2.1",
        "",
        f"**Título:** {inp.get('title','')}",
        f"**Dominio:** {inp.get('domain','')}",
        f"**Fecha:** {res.timestamp}",
        "",
        "## Resultado",
        "",
        f"- **Score final:** {res.final_score:.2f}/100",
        f"- **Veredicto:** {res.verdict}",
        f"- **Recomendación:** {res.recommendation}",
        "",
        "## Lagrangiano Renovativo corregido",
        "",
        f"- C_total ponderado: {res.C_total:.2f}",
        f"- G_total ponderado: {res.G_total:.2f}",
        f"- H_contribution: {res.H_contribution:.2f}",
        f"- R_contribution: {res.R_contribution:.2f}",
        f"- U_penalty: {res.U_penalty:.2f}",
        f"- L_R bruto: {res.lagrangian_raw:.2f}",
        f"- L_R normalizado: {res.normalized_lagrangian:.2f}/100",
        "",
        "## Puerta CENTRO",
        "",
        f"- CLARITAS: {res.centro_scores['CLARITAS']:.3f}",
        f"- RATIO: {res.centro_scores['RATIO']:.3f}",
        f"- VITA: {res.centro_scores['VITA']:.3f}",
        f"- Q: {res.Q:.3f}",
        "",
        "## Sugerencias",
        ""
    ]
    lines.extend([f"- {s}" for s in res.suggestions])
    lines += [
        "",
        "## Nota metodológica",
        "",
        "Este resultado es una evaluación multicriterio para deliberación. No sustituye revisión experta, validación empírica ni consulta jurídica, médica, científica o técnica especializada cuando aplique."
    ]
    return "\n".join(lines) + "\n"


def save_history(result: EvaluationResult, history_path: Path) -> None:
    history = []
    if history_path.exists():
        try:
            history = json.loads(history_path.read_text(encoding="utf-8"))
        except Exception:
            history = []
    history.append(asdict(result))
    history_path.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")


def print_summary(res: EvaluationResult) -> None:
    print("\n=== RENOVA CENTRO EVALUATOR v2.1 ===")
    print(f"Score final: {res.final_score:.2f}/100")
    print(f"Veredicto: {res.verdict}")
    print(f"Recomendación: {res.recommendation}")
    print(f"L_R bruto: {res.lagrangian_raw:.2f} | L_R norm: {res.normalized_lagrangian:.2f}")
    print(f"Q CENTRO: {res.Q:.3f} | CLARITAS={res.centro_scores['CLARITAS']:.3f} RATIO={res.centro_scores['RATIO']:.3f} VITA={res.centro_scores['VITA']:.3f}")
    print("\nSugerencias:")
    for i, s in enumerate(res.suggestions, 1):
        print(f"{i}. {s}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Renova CENTRO Evaluator v2.1 — Horizonte Áureo")
    parser.add_argument("--input", type=Path, help="Archivo JSON con evaluación.")
    parser.add_argument("--demo", action="store_true", help="Ejecuta evaluación demo.")
    parser.add_argument("--json", type=Path, help="Exporta resultado JSON.")
    parser.add_argument("--export-md", type=Path, help="Exporta reporte Markdown.")
    parser.add_argument("--history", type=Path, default=Path("renova_centro_history.json"), help="Historial JSON acumulado.")
    parser.add_argument("--no-history", action="store_true", help="No guardar historial.")
    args = parser.parse_args()

    if args.demo:
        inp = demo_input()
    elif args.input:
        inp = load_input(args.input)
    else:
        parser.error("Usa --demo o --input archivo.json")

    res = evaluate(inp)
    print_summary(res)

    if args.json:
        args.json.write_text(json.dumps(asdict(res), ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\nJSON exportado: {args.json}")

    if args.export_md:
        args.export_md.write_text(to_markdown(res), encoding="utf-8")
        print(f"Markdown exportado: {args.export_md}")

    if not args.no_history:
        save_history(res, args.history)
        print(f"Historial actualizado: {args.history}")


if __name__ == "__main__":
    main()
