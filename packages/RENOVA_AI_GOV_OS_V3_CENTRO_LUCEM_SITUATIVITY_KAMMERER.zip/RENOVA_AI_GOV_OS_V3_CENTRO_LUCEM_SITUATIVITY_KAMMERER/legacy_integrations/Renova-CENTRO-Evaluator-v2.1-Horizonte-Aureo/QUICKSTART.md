# QUICKSTART

## 1. Ejecutar demo

```bash
python renova_centro_evaluator_v2_1.py --demo
```

## 2. Evaluar desde JSON

Edita `examples/demo_renova_centro_input.json` y ejecuta:

```bash
python renova_centro_evaluator_v2_1.py --input examples/demo_renova_centro_input.json --export-md mi_reporte.md --json mi_reporte.json
```

## 3. Usar la app web

Abre `web/index.html` en el navegador.

La app guarda historial sólo en el navegador (`localStorage`). No envía datos a servidores.

## 4. Publicar en EdgeOne Pages

Sube la carpeta `web/` completa. El archivo principal es `index.html`.

## 5. Integrar con Lovable

Usa `docs/LOVABLE_PROMPT_RENOVA_CENTRO.md`.
