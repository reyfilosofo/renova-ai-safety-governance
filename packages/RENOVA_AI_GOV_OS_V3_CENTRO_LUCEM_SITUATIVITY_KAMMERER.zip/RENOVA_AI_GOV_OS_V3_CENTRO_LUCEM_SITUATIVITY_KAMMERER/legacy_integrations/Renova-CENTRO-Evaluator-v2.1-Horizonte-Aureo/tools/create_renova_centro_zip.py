#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Rebuild ZIP for Renova CENTRO Evaluator v2.1.
Run this file from the package root:

    python tools/create_renova_centro_zip.py
"""
from pathlib import Path
import zipfile
import hashlib
import os

ROOT = Path(__file__).resolve().parents[1]
ZIP_NAME = "Renova-CENTRO-Evaluator-v2.1-Horizonte-Aureo.zip"
OUT = ROOT.parent / ZIP_NAME

EXCLUDE = {
    "__pycache__",
    ".DS_Store"
}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def should_skip(path: Path) -> bool:
    parts = set(path.parts)
    if any(x in parts for x in EXCLUDE):
        return True
    if path.suffix == ".pyc":
        return True
    return False

def main():
    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for file in sorted(ROOT.rglob("*")):
            if file.is_file() and not should_skip(file):
                arc = file.relative_to(ROOT.parent)
                z.write(file, arc)
    print(f"ZIP generado: {OUT}")
    print(f"SHA256: {sha256(OUT)}")

if __name__ == "__main__":
    main()
