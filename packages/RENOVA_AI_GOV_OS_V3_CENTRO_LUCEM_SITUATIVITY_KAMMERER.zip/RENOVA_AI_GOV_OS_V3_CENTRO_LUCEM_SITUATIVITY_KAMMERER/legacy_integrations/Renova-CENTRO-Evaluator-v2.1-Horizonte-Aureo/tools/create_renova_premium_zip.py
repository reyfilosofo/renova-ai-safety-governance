#!/usr/bin/env python3
from pathlib import Path
import zipfile, os, hashlib

ROOT = Path(__file__).resolve().parents[1]
ZIP = ROOT.parent / "Renova-Evaluator-v2.0-Horizonte-Aureo.zip"

def main():
    if ZIP.exists():
        ZIP.unlink()
    with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(ROOT.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(ROOT.parent))
    digest = hashlib.sha256(ZIP.read_bytes()).hexdigest()
    print(f"ZIP generado: {ZIP}")
    print(f"SHA256: {digest}")

if __name__ == "__main__":
    main()
