# Política de despliegue seguro

Este paquete está diseñado para uso legítimo:

- No contiene jailbreaks.
- No contiene instrucciones de evasión de seguridad.
- No recolecta datos personales por defecto.
- La app web funciona offline y guarda historial sólo en localStorage.
- Cualquier uso público debe incluir aviso de límites metodológicos.

## Recomendaciones

1. No usar la herramienta como sustituto de asesoría médica, legal, financiera o científica especializada.
2. Documentar fuentes y evidencia.
3. Registrar incertidumbre.
4. Diseñar reversibilidad antes de ejecutar decisiones de alto impacto.
5. Someter políticas públicas, intervenciones educativas o evaluaciones ambientales a revisión externa.
