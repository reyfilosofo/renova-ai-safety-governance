# CENTRO Scorecard

## CLARITAS

Evalúa:

- verdad verificable
- coherencia conceptual
- precisión inteligible
- no-daño evitable

## RATIO

Evalúa:

- evidencia suficiente
- contraste con contraejemplos
- reproducibilidad
- delimitación de incertidumbre

## VITA

Evalúa:

- impacto vital positivo
- reversibilidad operativa
- apertura intergeneracional
- potencia renovativa

## Regla decisiva

Una acción con alto C pero baja puntuación CENTRO debe clasificarse como incompleta, riesgosa o insuficientemente justificada. La puerta CENTRO impide que la ℛenova se vuelva sólo retórica.
