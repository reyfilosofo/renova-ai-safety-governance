#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python tools/renova_protocol_benchmark_cli.py examples/renova_protocol_case_demo.json
