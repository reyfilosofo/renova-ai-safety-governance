#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo "Installing dependencies..."
npm install
echo "Running tests if available..."
npm run test || true
echo "Starting dev server..."
npm run dev
