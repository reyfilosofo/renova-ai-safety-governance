# RENOVA AI GOVERNANCE OS — Codex Maximum Build Package

**Project:** RENOVA AI GOVERNANCE OS  
**Owner:** Carlos Jonathan González Rodríguez / Jonathan ReyFilosofo by SERESARTE  
**Ecosystem:** SERESARTE Group · ℛenova · Renova AI Governance Studio · ReyFilosofo Advisory  
**Version:** v0.1.0-codex-max-start  
**Date:** 2026-05-28  
**Status:** Codex-ready starter repository + methodological corpus + executable MVP skeleton.

This package is designed to push Codex into a serious, multi-file, repository-scale build task: a working AI governance software prototype, plus a professional methodological, legal, editorial, and commercial documentation base.

The package contains:

1. A Next.js/TypeScript starter application.
2. A standalone HTML prototype for immediate demonstration.
3. A scoring engine for CLARITAS, RATIO, VITA, CENTRO and ℛ-Scorecard.
4. Demo data and scoring rubrics.
5. Playbooks, RACI, board memo templates, AI Constitution templates and audit report templates.
6. A full Codex instruction set.
7. Architecture, product, methodology, limitations, QA and deployment documentation.
8. SVG assets and diagrams.
9. A backlog designed to force Codex to work at repo scale.

## Quick Start

```bash
npm install
npm run dev
```

Then open:

```txt
http://localhost:3000
```

## Alternative: immediate no-build demo

Open:

```txt
prototype/index.html
```

This standalone prototype works without Node, npm, Next.js or internet.

## What Codex must do first

Open `CODEX_COPY_PASTE_PROMPT.md`, paste it into Codex, and attach this whole repository/ZIP as the working context.

## Product thesis

RENOVA AI GOVERNANCE OS is a board-level governance tool and advisory product for organizations deploying AI systems. It turns AI principles into operational governance: AI constitution, truth and life audit, scorecards, risk maps, playbooks, RACI, board memos and a 90/180/365-day roadmap.

This MVP does **not** claim legal compliance, ISO certification, NIST certification, EU AI Act conformity, or formal assurance. It is an advisory and governance design prototype that can be aligned to public frameworks but must be reviewed by qualified legal, compliance, cybersecurity, data protection and domain experts before organizational deployment.

## Brand formula

> Gobernar IA no es frenar la inteligencia; es darle verdad, vida y dirección.

## Core stack

- CLARITAS — truth, clarity, coherence, traceability, epistemic non-harm.
- RATIO — evidence robustness, plurality, consistency, justification.
- VITA — human impact, dignity, reversibility, care, life-centered consequences.
- CENTRO — governance, consensus, arbitration, escalation and drift reset.
- ℛ-Scorecard — integrated executive score, traffic light, priorities, recommendations.

## Repository map

Read `docs/FILE_INDEX.md` for a full map.
