# Source Materials

Place original user-owned documents here before running Codex.

Recommended files to add manually:

- Renova_AI_Governance_OS_Producto_Estrella.pptx
- Renova_AI_Governance_OS_Producto_Estrella.pdf
- Renova_AI_Governance_OS_One_Pager.docx
- Renova_AI_Governance_OS_One_Pager.pdf
- Renova_AI_Governance_Sales_Deck.pptx
- Renova_AI_Governance_Service_Menu.docx
- SERESARTE_Group_Master_Portfolio_Deck.pptx
- SERESARTE_Group_Master_Portfolio_Deck.pdf
- Control_editorial_SERESARTE_RENOVA_ACTUALIZADO_2026-05-21.xlsx
- centro_core.py
- Any SERESARTE/ℛenova logo files you own.

Do not add confidential client data, medical data, litigation files, credentials, tokens, private family information or third-party protected materials.
