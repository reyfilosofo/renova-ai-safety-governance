# RENOVA AI GOVERNANCE OS v3 — CENTRO/LUCEM Protocol & Benchmark Update

This update package extends the original Codex Max Package with:

- CENTRO governance and arbitration layer.
- LUCEM evidence/consciousness/visualization layer.
- Protocolo ℛenova workflow: Hábitat → Herida → Horizonte.
- Benchmark Suite for life-net evaluation.
- Situativity mapping for participants, culture, environment and artifacts.
- Kammerer Seriality and Renovagrama numerical-pattern module.
- Legacy integration of `Renova-CENTRO-Evaluator-v2.1-Horizonte-Aureo`.

## Use with Codex

1. Unzip into `~/Projects/renova-governance-os-v3`.
2. Open that folder in Codex.
3. Paste `CODEX_MASTER_PROMPT_V3_CENTRO_LUCEM.md`.
4. Let Codex inspect the repository before coding.
5. Ask Codex to run install, typecheck, tests and dev server.

## Minimal local test

```bash
python tools/renova_protocol_benchmark_cli.py examples/renova_protocol_case_demo.json
```

Expected output: JSON with `r_total`, `decision`, `blockers`, and `falsification_condition`.
