"use client";

import { useState } from "react";
import { Header } from "@/components/Header";
import { Disclaimer } from "@/components/Disclaimer";
import { demoAssessment } from "@/lib/demoData";
import { scoreAssessment } from "@/lib/scoring";

export default function AssessmentPage() {
  const [name, setName] = useState(demoAssessment.organization.name);
  const [sector, setSector] = useState(demoAssessment.organization.sector);
  const result = scoreAssessment({ ...demoAssessment, organization: { ...demoAssessment.organization, name, sector } });

  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-6 py-12">
        <div className="badge">Assessment Wizard v0.1</div>
        <h1 className="mt-6 font-serif text-5xl">Start Assessment</h1>
        <p className="mt-4 max-w-3xl text-paper/70">This v0.1 page demonstrates the input model. Codex should expand this into a full multi-step wizard.</p>

        <div className="mt-10 grid gap-8 md:grid-cols-2">
          <section className="card">
            <label className="label">Organization name</label>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
            <label className="label mt-6">Sector</label>
            <input className="input" value={sector} onChange={(e) => setSector(e.target.value)} />
          </section>

          <section className="card">
            <h2 className="font-serif text-3xl">Preliminary reading</h2>
            <div className="mt-6 font-serif text-6xl">{result.globalScore}</div>
            <div className="badge mt-4">{result.trafficLight}</div>
            <p className="mt-6 text-paper/70">Use cases loaded from demo data: {result.useCaseResults.length}</p>
          </section>
        </div>
      </main>
      <Disclaimer />
    </>
  );
}
