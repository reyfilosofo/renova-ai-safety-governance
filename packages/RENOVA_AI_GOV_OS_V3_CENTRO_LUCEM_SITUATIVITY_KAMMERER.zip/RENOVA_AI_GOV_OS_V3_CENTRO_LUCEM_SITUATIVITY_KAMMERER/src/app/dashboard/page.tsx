import { Header } from "@/components/Header";
import { Disclaimer } from "@/components/Disclaimer";
import { ScoreCard } from "@/components/ScoreCard";
import { demoAssessment } from "@/lib/demoData";
import { scoreAssessment } from "@/lib/scoring";

export default function DashboardPage() {
  const result = scoreAssessment(demoAssessment);

  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-6 py-12">
        <div className="badge">Executive Dashboard</div>
        <h1 className="mt-6 font-serif text-5xl">ℛ-Scorecard</h1>
        <p className="mt-4 max-w-3xl text-paper/70">
          Demo dashboard for {result.organizationName}. Scores are advisory and based on demonstration data.
        </p>

        <div className="mt-10 grid gap-5 md:grid-cols-3">
          <ScoreCard title="Global ℛ-Score" score={result.globalScore} trafficLight={result.trafficLight} note="Integrated executive reading across use cases." />
          <div className="card md:col-span-2">
            <h2 className="font-serif text-3xl">Top risks</h2>
            <ul className="mt-5 space-y-3 text-paper/75">
              {result.topRisks.map((risk) => <li key={risk}>— {risk}</li>)}
            </ul>
          </div>
        </div>

        <section className="mt-10 grid gap-6">
          {result.useCaseResults.map((uc) => (
            <div key={uc.useCaseId} className="card">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="font-serif text-3xl">{uc.useCaseName}</h3>
                  <p className="mt-2 text-paper/60">Risk class: {uc.riskClass}</p>
                </div>
                <div className="text-right">
                  <div className="font-serif text-5xl">{uc.rScore}</div>
                  <div className="badge">{uc.trafficLight}</div>
                </div>
              </div>
              <div className="mt-6 grid gap-4 md:grid-cols-4">
                {uc.layers.map((layer) => (
                  <div key={layer.name} className="rounded-2xl border border-paper/10 p-4">
                    <div className="text-sm text-paper/60">{layer.name}</div>
                    <div className="mt-2 font-serif text-4xl">{layer.score}</div>
                    <div className="mt-2 text-xs text-paper/50">{layer.trafficLight}</div>
                  </div>
                ))}
              </div>
              <div className="mt-6 grid gap-6 md:grid-cols-2">
                <div>
                  <h4 className="font-bold text-gold">Blockers</h4>
                  <ul className="mt-3 space-y-2 text-sm text-paper/70">
                    {uc.blockers.map((b) => <li key={b}>— {b}</li>)}
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-gold">Recommendations</h4>
                  <ul className="mt-3 space-y-2 text-sm text-paper/70">
                    {uc.recommendations.map((r) => <li key={r}>— {r}</li>)}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </section>
      </main>
      <Disclaimer />
    </>
  );
}
