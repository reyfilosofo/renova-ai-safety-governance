import { Header } from "@/components/Header";
import { Disclaimer } from "@/components/Disclaimer";

const playbooks = [
  {
    name: "Hallucination / False Authority Incident",
    trigger: "AI output fabricates facts, citations, policies or expert authority.",
    action: "Pause output channel, capture evidence, notify owner, correct users and review truth protocol."
  },
  {
    name: "Bias or Unfair Output Incident",
    trigger: "AI output shows discriminatory, exclusionary or unfair treatment.",
    action: "Suspend affected workflow, preserve logs, perform impact review, add mitigation and re-test."
  },
  {
    name: "Privacy or Sensitive Data Incident",
    trigger: "Sensitive data exposed, entered into improper model or used beyond scope.",
    action: "Escalate to privacy/legal/security, preserve evidence, contain exposure and notify as required."
  },
  {
    name: "Model Drift / Behavior Degradation",
    trigger: "Output quality, tone, safety or truthfulness degrades after update or context shift.",
    action: "Activate drift reset, compare baseline outputs, review model/tool changes and re-score."
  },
  {
    name: "High-Impact Decision Escalation",
    trigger: "AI is used in health, legal, finance, employment, education or other consequential domain.",
    action: "Require human review, documented rationale, appeal route and committee escalation."
  }
];

export default function PlaybooksPage() {
  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-6 py-12">
        <div className="badge">Operating Model</div>
        <h1 className="mt-6 font-serif text-5xl">Playbook Library</h1>
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {playbooks.map((p) => (
            <article key={p.name} className="card">
              <h2 className="font-serif text-2xl text-gold">{p.name}</h2>
              <p className="mt-4 text-sm uppercase tracking-[0.18em] text-paper/50">Trigger</p>
              <p className="mt-2 leading-7 text-paper/75">{p.trigger}</p>
              <p className="mt-5 text-sm uppercase tracking-[0.18em] text-paper/50">Immediate action</p>
              <p className="mt-2 leading-7 text-paper/75">{p.action}</p>
            </article>
          ))}
        </div>
      </main>
      <Disclaimer />
    </>
  );
}
