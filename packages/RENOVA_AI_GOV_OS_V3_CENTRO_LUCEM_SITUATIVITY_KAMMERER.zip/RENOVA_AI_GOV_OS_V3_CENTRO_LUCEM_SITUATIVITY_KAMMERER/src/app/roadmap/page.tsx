import { Header } from "@/components/Header";
import { Disclaimer } from "@/components/Disclaimer";

const phases = [
  ["0–30 days", ["Inventory AI use cases", "Assign owners", "Establish committee baseline", "Identify high-risk domains", "Create evidence baseline"]],
  ["31–90 days", ["Draft AI Constitution v1", "Run Truth & Life Audit", "Define RACI", "Create incident playbooks", "Board review"]],
  ["91–180 days", ["Evidence registry", "Vendor governance", "Training", "Re-test", "Calibrate scoring"]],
  ["181–365 days", ["Formalize operating model", "Annual governance report", "Maturity model", "Retainer or license path", "Continuous improvement"]]
];

export default function RoadmapPage() {
  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-6 py-12">
        <div className="badge">Roadmap 365</div>
        <h1 className="mt-6 font-serif text-5xl">Implementation Roadmap</h1>
        <div className="mt-10 grid gap-6 md:grid-cols-4">
          {phases.map(([phase, items]) => (
            <section key={phase as string} className="card">
              <h2 className="font-serif text-3xl text-gold">{phase}</h2>
              <ul className="mt-5 space-y-3 text-paper/75">
                {(items as string[]).map(i => <li key={i}>— {i}</li>)}
              </ul>
            </section>
          ))}
        </div>
      </main>
      <Disclaimer />
    </>
  );
}
