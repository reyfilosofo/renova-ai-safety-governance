import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "RENOVA AI GOVERNANCE OS",
  description: "AI governance assessment, scoring and executive reporting prototype by SERESARTE Group / ℛenova."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  );
}
