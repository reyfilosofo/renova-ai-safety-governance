import { Header } from "@/components/Header";
import { Disclaimer } from "@/components/Disclaimer";
import { demoAssessment } from "@/lib/demoData";
import { scoreAssessment } from "@/lib/scoring";
import { generateAIConstitution, generateAuditReport, generateBoardMemo } from "@/lib/reportGenerators";

export default function ReportsPage() {
  const result = scoreAssessment(demoAssessment);
  const docs = [
    ["AI Constitution v1", generateAIConstitution(demoAssessment, result)],
    ["Truth & Life Audit", generateAuditReport(demoAssessment, result)],
    ["Board Memo", generateBoardMemo(demoAssessment, result)]
  ];

  return (
    <>
      <Header />
      <main className="mx-auto max-w-7xl px-6 py-12">
        <div className="badge">Generated Documents</div>
        <h1 className="mt-6 font-serif text-5xl">Reports</h1>
        <p className="mt-4 max-w-3xl text-paper/70">Demo-generated Markdown documents. Codex should add copy/export/PDF functions in v0.2.</p>

        <div className="mt-10 grid gap-8">
          {docs.map(([title, body]) => (
            <section key={title} className="card">
              <h2 className="font-serif text-3xl text-gold">{title}</h2>
              <pre className="mt-6 max-h-[520px] overflow-auto whitespace-pre-wrap rounded-2xl bg-black/30 p-5 text-sm leading-6 text-paper/80">
                {body}
              </pre>
            </section>
          ))}
        </div>
      </main>
      <Disclaimer />
    </>
  );
}
