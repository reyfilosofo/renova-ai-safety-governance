import Link from "next/link";
import { Header } from "@/components/Header";
import { Disclaimer } from "@/components/Disclaimer";

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <section className="mx-auto grid max-w-7xl gap-10 px-6 py-20 md:grid-cols-[1.1fr_0.9fr]">
          <div>
            <div className="badge">SERESARTE Group · ℛenova · AI Governance Studio</div>
            <h1 className="mt-8 font-serif text-6xl leading-tight md:text-7xl">
              Govern AI with truth, life and institutional judgment.
            </h1>
            <p className="mt-8 max-w-3xl text-xl leading-9 text-paper/75">
              RENOVA AI GOVERNANCE OS turns principles into controls, committees, metrics, playbooks and board-level decisions. It is designed for organizations using copilots, agents and automation without a mature governance architecture.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link href="/assessment" className="btn">Start Assessment</Link>
              <Link href="/dashboard" className="btn btn-secondary">View Demo Dashboard</Link>
            </div>
            <p className="mt-10 max-w-2xl font-serif text-2xl text-gold">
              “Gobernar IA no es frenar la inteligencia; es darle verdad, vida y dirección.”
            </p>
          </div>

          <div className="card">
            <h2 className="font-serif text-3xl">Renova Assurance Stack</h2>
            <div className="mt-8 grid gap-4">
              {[
                ["CLARITAS", "Truth, clarity, coherence, traceability and epistemic non-harm."],
                ["RATIO", "Evidence robustness, plurality, consistency and reasoned challenge."],
                ["VITA", "Human impact, dignity, reversibility, care and life-centered consequences."],
                ["CENTRO", "Governance, consensus, arbitration, escalation and drift reset."],
                ["ℛ-Scorecard", "Executive score, traffic light, priorities and roadmap."]
              ].map(([title, body]) => (
                <div key={title} className="rounded-2xl border border-paper/10 p-5">
                  <h3 className="text-lg font-bold text-gold">{title}</h3>
                  <p className="mt-2 text-sm leading-6 text-paper/70">{body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-6 py-10">
          <div className="grid gap-5 md:grid-cols-4">
            {["Diagnostic", "AI Constitution", "Truth & Life Audit", "Governance OS"].map((x, i) => (
              <div key={x} className="card">
                <div className="text-gold">0{i + 1}</div>
                <h3 className="mt-3 font-serif text-2xl">{x}</h3>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Disclaimer />
    </>
  );
}
