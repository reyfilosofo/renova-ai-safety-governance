import type { AIUseCase, Assessment, AssessmentScoreResult, LayerScore, TrafficLight, UseCaseScoreResult } from "./types";

const highRiskDomains = new Set(["health", "salud", "legal", "finance", "finanzas", "credit", "credito", "education", "educacion", "employment", "empleo", "biometrics", "biometria", "public safety", "seguridad_publica"]);
const prohibitedTerms = ["malware", "phishing", "credential theft", "jailbreak", "bypass safety", "exfiltrate", "social scoring"];

export function clampScore(value: number): number {
  if (Number.isNaN(value) || !Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, value));
}

export function average(values: number[]): number {
  if (!values.length) return 0;
  return Math.round((values.reduce((a, b) => a + clampScore(b), 0) / values.length) * 100) / 100;
}

export function classifyTrafficLight(score: number): TrafficLight {
  const s = clampScore(score);
  if (s < 40) return "Critical";
  if (s < 60) return "Fragile";
  if (s < 80) return "Developing";
  return "Governable";
}

export function classifyRisk(useCase: AIUseCase): string {
  const text = `${useCase.name} ${useCase.description} ${useCase.domain}`.toLowerCase();
  if (prohibitedTerms.some(term => text.includes(term))) return "prohibited";
  if (highRiskDomains.has(useCase.domain.toLowerCase())) return "high-risk";
  if (useCase.dataSensitivity === "high" || useCase.autonomyLevel === "autonomous") return "restricted";
  return "permitted";
}

function layer(name: LayerScore["name"], score: number, rationale: string): LayerScore {
  return {
    name,
    score: Math.round(clampScore(score) * 100) / 100,
    trafficLight: classifyTrafficLight(score),
    rationale
  };
}

export function scoreClaritas(useCase: AIUseCase): LayerScore {
  const s = useCase.scores;
  const score = average([s.truthfulness, s.clarity, s.coherence, s.traceability, s.epistemicNonHarm]);
  return layer("CLARITAS", score, "Evaluates truthfulness, clarity, coherence, traceability and epistemic non-harm.");
}

export function scoreRatio(useCase: AIUseCase): LayerScore {
  const s = useCase.scores;
  const score = average([s.evidenceRobustness, s.plurality, s.reasoningConsistency, s.challengeability, s.uncertaintyHandling]);
  return layer("RATIO", score, "Evaluates evidence robustness, plurality, reasoning consistency, challengeability and uncertainty handling.");
}

export function scoreVita(useCase: AIUseCase): LayerScore {
  const s = useCase.scores;
  const score = average([s.humanImpact, s.dignity, s.reversibility, s.care, s.lifeCenteredFit]);
  return layer("VITA", score, "Evaluates human impact, dignity, reversibility, care and life-centered fit.");
}

export function scoreCentro(useCase: AIUseCase): LayerScore {
  const s = useCase.scores;
  const score = average([s.ownership, s.humanOversight, s.escalation, s.driftReset, s.vendorGovernance]);
  return layer("CENTRO", score, "Evaluates ownership, human oversight, escalation, drift reset and vendor governance.");
}

export function detectBlockers(useCase: AIUseCase): string[] {
  const blockers: string[] = [];
  const risk = classifyRisk(useCase);
  const s = useCase.scores;

  if (risk === "prohibited") blockers.push("Prohibited or abusive use indicator detected.");
  if (risk === "high-risk" && !useCase.humanOversight) blockers.push("High-risk domain without explicit human oversight.");
  if (s.traceability < 60) blockers.push("Traceability below minimum governance threshold.");
  if (s.plurality < 50) blockers.push("Evidence plurality below acceptable threshold.");
  if (s.epistemicNonHarm < 50) blockers.push("Epistemic non-harm below acceptable threshold.");
  if (s.reversibility < 50 && useCase.humanImpactRisk > 70) blockers.push("High human impact with weak reversibility.");
  if (s.driftReset < 45) blockers.push("Drift reset process is underdeveloped.");

  return blockers;
}

export function generateRecommendations(useCase: AIUseCase, layers: LayerScore[], blockers: string[]): string[] {
  const recs: string[] = [];

  if (blockers.length) recs.push("Do not scale this use case until blockers are remediated and documented.");
  if (layers.find(l => l.name === "CLARITAS" && l.score < 70)) recs.push("Create a truth protocol: evidence levels, uncertainty labels, citation rules and output review.");
  if (layers.find(l => l.name === "RATIO" && l.score < 70)) recs.push("Strengthen evidence plurality and challenge review before consequential use.");
  if (layers.find(l => l.name === "VITA" && l.score < 70)) recs.push("Add human impact review, reversibility plan and safeguards for affected users.");
  if (layers.find(l => l.name === "CENTRO" && l.score < 70)) recs.push("Create owner, RACI, escalation path, drift reset and incident playbook.");
  if (classifyRisk(useCase) === "high-risk") recs.push("Require documented human oversight and legal/compliance review before production expansion.");
  if (!recs.length) recs.push("Maintain monitoring, evidence registry and periodic re-test.");

  return recs;
}

export function scoreUseCase(useCase: AIUseCase): UseCaseScoreResult {
  const layers = [scoreClaritas(useCase), scoreRatio(useCase), scoreVita(useCase), scoreCentro(useCase)];
  const raw = average(layers.map(l => l.score));
  const blockers = detectBlockers(useCase);
  const penalty = blockers.length * 5;
  const rScore = clampScore(raw - penalty);
  return {
    useCaseId: useCase.id,
    useCaseName: useCase.name,
    riskClass: classifyRisk(useCase),
    layers,
    rScore,
    trafficLight: classifyTrafficLight(rScore),
    blockers,
    recommendations: generateRecommendations(useCase, layers, blockers)
  };
}

export function scoreAssessment(assessment: Assessment): AssessmentScoreResult {
  const useCaseResults = assessment.useCases.map(scoreUseCase);
  const globalScore = average(useCaseResults.map(r => r.rScore));
  const topRisks = useCaseResults.flatMap(r => r.blockers.map(b => `${r.useCaseName}: ${b}`)).slice(0, 8);
  const recommendations = Array.from(new Set(useCaseResults.flatMap(r => r.recommendations))).slice(0, 10);

  return {
    organizationName: assessment.organization.name,
    globalScore,
    trafficLight: classifyTrafficLight(globalScore),
    useCaseResults,
    topRisks,
    recommendations
  };
}
