export type TrafficLight = "Critical" | "Fragile" | "Developing" | "Governable";

export type AIUseCaseStatus = "exploration" | "pilot" | "production" | "suspended";

export type Organization = {
  name: string;
  sector: string;
  country?: string;
  aiMaturity: string;
  governanceStatus: string;
  committeeExists: boolean;
};

export type UseCaseScores = {
  truthfulness: number;
  clarity: number;
  coherence: number;
  traceability: number;
  epistemicNonHarm: number;
  evidenceRobustness: number;
  plurality: number;
  reasoningConsistency: number;
  challengeability: number;
  uncertaintyHandling: number;
  humanImpact: number;
  dignity: number;
  reversibility: number;
  care: number;
  lifeCenteredFit: number;
  ownership: number;
  humanOversight: number;
  escalation: number;
  driftReset: number;
  vendorGovernance: number;
};

export type AIUseCase = {
  id: string;
  name: string;
  department: string;
  status: AIUseCaseStatus | string;
  description: string;
  domain: string;
  impactedUsers: string[];
  dataSensitivity: "low" | "medium" | "high" | string;
  autonomyLevel: "low" | "assistant" | "semi-autonomous" | "autonomous" | string;
  humanOversight: boolean;
  truthRisk: number;
  humanImpactRisk: number;
  regulatoryRisk: number;
  currentControls: string[];
  scores: UseCaseScores;
};

export type Assessment = {
  organization: Organization;
  useCases: AIUseCase[];
};

export type LayerScore = {
  name: "CLARITAS" | "RATIO" | "VITA" | "CENTRO";
  score: number;
  trafficLight: TrafficLight;
  rationale: string;
};

export type UseCaseScoreResult = {
  useCaseId: string;
  useCaseName: string;
  riskClass: string;
  layers: LayerScore[];
  rScore: number;
  trafficLight: TrafficLight;
  blockers: string[];
  recommendations: string[];
};

export type AssessmentScoreResult = {
  organizationName: string;
  globalScore: number;
  trafficLight: TrafficLight;
  useCaseResults: UseCaseScoreResult[];
  topRisks: string[];
  recommendations: string[];
};
