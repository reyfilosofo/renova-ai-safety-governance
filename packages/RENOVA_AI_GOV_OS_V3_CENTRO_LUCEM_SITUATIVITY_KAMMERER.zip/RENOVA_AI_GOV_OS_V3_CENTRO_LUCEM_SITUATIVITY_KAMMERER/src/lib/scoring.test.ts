import { describe, expect, it } from "vitest";
import { demoAssessment } from "./demoData";
import { classifyTrafficLight, scoreAssessment, scoreUseCase } from "./scoring";

describe("scoring", () => {
  it("classifies traffic lights", () => {
    expect(classifyTrafficLight(20)).toBe("Critical");
    expect(classifyTrafficLight(50)).toBe("Fragile");
    expect(classifyTrafficLight(70)).toBe("Developing");
    expect(classifyTrafficLight(90)).toBe("Governable");
  });

  it("scores demo assessment", () => {
    const result = scoreAssessment(demoAssessment);
    expect(result.globalScore).toBeGreaterThan(0);
    expect(result.useCaseResults).toHaveLength(2);
  });

  it("detects high-risk health use case blockers", () => {
    const result = scoreUseCase(demoAssessment.useCases[0]);
    expect(result.riskClass).toBe("high-risk");
    expect(result.blockers.length).toBeGreaterThan(0);
  });

  it("does not let blockers increase score", () => {
    const result = scoreUseCase(demoAssessment.useCases[0]);
    const rawLayerAverage = result.layers.reduce((sum, l) => sum + l.score, 0) / result.layers.length;
    expect(result.rScore).toBeLessThanOrEqual(rawLayerAverage);
  });
});
