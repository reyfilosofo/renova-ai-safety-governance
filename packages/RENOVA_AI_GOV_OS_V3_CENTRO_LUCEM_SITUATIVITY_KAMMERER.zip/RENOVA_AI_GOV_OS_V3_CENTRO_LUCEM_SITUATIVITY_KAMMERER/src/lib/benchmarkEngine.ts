export type RenovaValues = Record<string, number>;
export type Decision = 'APPROVE' | 'PILOT' | 'REDESIGN' | 'SUSPEND' | 'REJECT';

const POSITIVE = ['C','E','Q','M','H','O'];
const NEGATIVE = ['G','D','X','W'];
const EVIDENCE: Record<string, number> = { A:1, B:0.9, C:0.75, D:0.55, E:0.35 };

export function clamp(x: number, lo = 0, hi = 100): number {
  if (!Number.isFinite(x)) return lo;
  return Math.max(lo, Math.min(hi, x));
}

export function weightedAverage(keys: string[], values: RenovaValues, weights: RenovaValues): number {
  const totalWeight = keys.reduce((sum, k) => sum + (weights[k] ?? 1), 0);
  if (totalWeight === 0) return 0;
  return keys.reduce((sum, k) => sum + clamp(values[k] ?? 0) * (weights[k] ?? 1), 0) / totalWeight;
}

export function blockers(values: RenovaValues, evidenceGrade: string, uncertainty: number): string[] {
  const out: string[] = [];
  if ((values.G ?? 0) >= 80) out.push('Gewalt exceeds acceptable threshold.');
  if ((values.D ?? 0) >= 75) out.push('Irreversible degradation risk is high.');
  if ((values.X ?? 0) >= 70) out.push('Hidden externalities remain high.');
  if ((values.H ?? 100) < 45) out.push('Habitat integrity is too weak.');
  if (['D','E'].includes(evidenceGrade)) out.push('Evidence grade is insufficient for strong claims.');
  if (uncertainty >= 0.35) out.push('Uncertainty is too high for final approval.');
  return out;
}

export function decide(score: number, bs: string[]): Decision {
  if (bs.some(b => b.includes('Gewalt') || b.includes('Irreversible'))) return score >= 35 ? 'SUSPEND' : 'REJECT';
  if (score >= 75 && bs.length === 0) return 'APPROVE';
  if (score >= 60 && bs.length <= 1) return 'PILOT';
  if (score >= 40) return 'REDESIGN';
  return 'REJECT';
}

export function evaluateRenovaBenchmark(values: RenovaValues, weights: RenovaValues, evidenceGrade = 'C', uncertainty = 0.15) {
  const positive = weightedAverage(POSITIVE, values, weights);
  const negative = weightedAverage(NEGATIVE, values, weights);
  const k = EVIDENCE[evidenceGrade] ?? 0.75;
  const uncertaintyPenalty = clamp(uncertainty * 100);
  const rTotal = clamp(k * (positive - negative + 50) - uncertaintyPenalty);
  const bs = blockers(values, evidenceGrade, uncertainty);
  return {
    positive: Math.round(positive * 100) / 100,
    negative: Math.round(negative * 100) / 100,
    evidenceMultiplier: k,
    uncertaintyPenalty,
    rTotal: Math.round(rTotal * 100) / 100,
    decision: decide(rTotal, bs),
    blockers: bs,
    falsificationCondition: 'Reject or redesign if remeasurement fails to show life-net increase and damage reduction.'
  };
}
