import type { Assessment, AssessmentScoreResult } from "./types";

export function generateAIConstitution(assessment: Assessment, result: AssessmentScoreResult): string {
  const org = assessment.organization;
  return `# AI Constitution v1 — ${org.name}

## Purpose

This AI Constitution defines the operating principles, limits, accountability and review paths for AI use at ${org.name}.

## Current governance reading

- Sector: ${org.sector}
- AI maturity: ${org.aiMaturity}
- Governance status: ${org.governanceStatus}
- Global ℛ-Score: ${result.globalScore} (${result.trafficLight})

## Principles

1. Truth before persuasion.
2. Human dignity before automation.
3. Traceability before scale.
4. Reversibility before irreversible deployment.
5. Human oversight before high-impact autonomy.
6. Plural evidence before confident decision.
7. Care before efficiency.
8. Governance before expansion.

## Red zones

- No high-impact decision without accountable human review.
- No unsupported claims presented as fact.
- No hidden uncertainty in consequential contexts.
- No fabricated citations, false authority or deceptive outputs.
- No deployment without owner, escalation path and review cycle.

## Truth protocol

Outputs must identify evidence level, uncertainty, assumptions and sources where applicable.

## Human oversight protocol

High-risk or high-impact AI use requires named owners, review paths and documented appeal or correction mechanisms.

## Drift reset protocol

If model behavior degrades, shifts, becomes overconfident, produces harmful errors or loses alignment with the AI Constitution, the use case must be paused, reviewed, remediated and re-tested.

## Governance committee

Recommended: Board Sponsor, Legal, Risk/Compliance, CTO/CIO, Head of AI/Data, Human Impact Lead, Domain Owner and CENTRO/Renova advisor.

## Disclaimer

This document is an advisory prototype. It is not legal advice and does not certify compliance with any standard or law.
`;
}

export function generateAuditReport(assessment: Assessment, result: AssessmentScoreResult): string {
  const lines = result.useCaseResults.map(r => {
    return `### ${r.useCaseName}

- Risk class: ${r.riskClass}
- ℛ-Score: ${r.rScore} (${r.trafficLight})
- CLARITAS: ${r.layers.find(l => l.name === "CLARITAS")?.score}
- RATIO: ${r.layers.find(l => l.name === "RATIO")?.score}
- VITA: ${r.layers.find(l => l.name === "VITA")?.score}
- CENTRO: ${r.layers.find(l => l.name === "CENTRO")?.score}

Blockers:
${r.blockers.length ? r.blockers.map(b => `- ${b}`).join("\n") : "- No critical blocker detected in demo data."}

Recommendations:
${r.recommendations.map(x => `- ${x}`).join("\n")}
`;
  }).join("\n");

  return `# Truth & Life Audit Report — ${assessment.organization.name}

## Executive Summary

Global ℛ-Score: ${result.globalScore} (${result.trafficLight})

This advisory audit evaluates AI use cases through CLARITAS, RATIO, VITA, CENTRO and ℛ-Scorecard.

## Methodology

- CLARITAS: truth, clarity, coherence, traceability, epistemic non-harm.
- RATIO: evidence robustness, plurality, consistency, uncertainty handling.
- VITA: human impact, dignity, reversibility, care, life-centered fit.
- CENTRO: ownership, oversight, escalation, drift reset, vendor governance.
- ℛ-Scorecard: integrated executive score.

## Top Risks

${result.topRisks.length ? result.topRisks.map(r => `- ${r}`).join("\n") : "- No top risks detected in demo data."}

## Use Case Findings

${lines}

## System Recommendations

${result.recommendations.map(r => `- ${r}`).join("\n")}

## Limitations

This audit is advisory. It is not legal advice, not certification and not a substitute for professional audits in law, cybersecurity, privacy, clinical safety, finance or sector-specific compliance.
`;
}

export function generateBoardMemo(assessment: Assessment, result: AssessmentScoreResult): string {
  return `# Board Memo — AI Governance Readiness

## To

Board / Executive Committee

## From

Renova AI Governance Studio

## Subject

AI Governance Readiness for ${assessment.organization.name}

## Executive context

The organization has entered an AI governance phase where isolated AI adoption must be converted into traceable, accountable and reviewable governance.

## Current maturity

- Global ℛ-Score: ${result.globalScore}
- Status: ${result.trafficLight}
- Use cases reviewed: ${result.useCaseResults.length}

## Critical risks

${result.topRisks.length ? result.topRisks.map(r => `- ${r}`).join("\n") : "- No critical blockers detected in demo data."}

## Required board decisions

1. Appoint an AI Governance Sponsor.
2. Approve a formal AI Constitution process.
3. Approve a Truth & Life Audit of active use cases.
4. Establish a CENTRO governance committee.
5. Require human oversight for high-risk domains.
6. Approve a 90/180/365-day roadmap.

## Recommended workstreams

- AI Constitution Sprint.
- Use Case Inventory and risk map.
- CLARITAS/RATIO/VITA scoring.
- CENTRO committee and RACI.
- Incident playbooks and drift reset.
- Executive education.

## Roadmap

### 0–30 days
Inventory, owners, committee baseline and urgent blockers.

### 31–90 days
AI Constitution v1, Truth & Life Audit, playbooks, RACI and board review.

### 91–180 days
Evidence registry, vendor governance, training and re-test.

### 181–365 days
Maturity model, annual governance report and continuous improvement.

## Disclaimer

This memo is advisory and requires review by qualified legal, compliance, cybersecurity, privacy and domain experts.
`;
}
