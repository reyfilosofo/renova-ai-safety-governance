import type { Assessment } from "./types";

export const demoAssessment: Assessment = {
  organization: {
    name: "Asteria University Hospital",
    sector: "health",
    country: "Mexico",
    aiMaturity: "pilot",
    governanceStatus: "fragmented",
    committeeExists: false
  },
  useCases: [
    {
      id: "uc-001",
      name: "Clinical documentation assistant",
      department: "Medical Operations",
      status: "pilot",
      description: "LLM-assisted summarization of clinician notes and draft discharge instructions.",
      domain: "health",
      impactedUsers: ["clinicians", "patients", "administrators"],
      dataSensitivity: "high",
      autonomyLevel: "assistant",
      humanOversight: true,
      truthRisk: 72,
      humanImpactRisk: 78,
      regulatoryRisk: 80,
      currentControls: ["manual review", "restricted pilot group", "no autonomous diagnosis"],
      scores: {
        truthfulness: 68, clarity: 61, coherence: 66, traceability: 55, epistemicNonHarm: 60,
        evidenceRobustness: 62, plurality: 50, reasoningConsistency: 65, challengeability: 58, uncertaintyHandling: 56,
        humanImpact: 60, dignity: 70, reversibility: 58, care: 66, lifeCenteredFit: 63,
        ownership: 45, humanOversight: 76, escalation: 40, driftReset: 35, vendorGovernance: 52
      }
    },
    {
      id: "uc-002",
      name: "Student admissions chatbot",
      department: "Admissions",
      status: "production",
      description: "Chatbot that answers admissions questions and recommends application paths.",
      domain: "education",
      impactedUsers: ["prospective students", "parents", "admissions officers"],
      dataSensitivity: "medium",
      autonomyLevel: "low",
      humanOversight: false,
      truthRisk: 64,
      humanImpactRisk: 55,
      regulatoryRisk: 60,
      currentControls: ["FAQ review", "fallback email"],
      scores: {
        truthfulness: 74, clarity: 70, coherence: 72, traceability: 66, epistemicNonHarm: 68,
        evidenceRobustness: 66, plurality: 57, reasoningConsistency: 69, challengeability: 61, uncertaintyHandling: 58,
        humanImpact: 65, dignity: 74, reversibility: 72, care: 61, lifeCenteredFit: 67,
        ownership: 60, humanOversight: 45, escalation: 44, driftReset: 42, vendorGovernance: 59
      }
    }
  ]
};
