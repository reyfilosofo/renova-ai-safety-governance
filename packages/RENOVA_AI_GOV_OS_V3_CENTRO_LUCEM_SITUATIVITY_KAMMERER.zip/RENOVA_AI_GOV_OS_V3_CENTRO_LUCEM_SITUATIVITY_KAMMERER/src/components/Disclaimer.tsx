export function Disclaimer() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-8 text-xs leading-6 text-paper/55">
      <strong className="text-paper/80">Limitations:</strong> This is an advisory governance prototype. It is not legal advice, not a compliance certification, not ISO/NIST/EU/OECD certification, and not a substitute for qualified legal, compliance, cybersecurity, privacy, clinical, financial or domain-specific expert review.
    </section>
  );
}
