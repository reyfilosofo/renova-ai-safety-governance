import Link from "next/link";

export function Header() {
  const links = [
    ["Assessment", "/assessment"],
    ["Dashboard", "/dashboard"],
    ["Reports", "/reports"],
    ["Playbooks", "/playbooks"],
    ["Roadmap", "/roadmap"]
  ];

  return (
    <header className="border-b border-gold/30 bg-ink/95">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <Link href="/" className="font-serif text-2xl tracking-wide">
          ℛ RENOVA AI GOVERNANCE OS
        </Link>
        <nav className="hidden gap-5 md:flex">
          {links.map(([label, href]) => (
            <Link key={href} href={href} className="text-sm text-paper/75 hover:text-paper">
              {label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
