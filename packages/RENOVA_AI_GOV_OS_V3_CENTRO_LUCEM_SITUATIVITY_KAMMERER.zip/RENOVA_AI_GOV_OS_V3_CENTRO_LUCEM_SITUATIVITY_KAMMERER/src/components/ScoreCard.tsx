import type { TrafficLight } from "@/lib/types";

function colorFor(light: TrafficLight) {
  if (light === "Critical") return "border-red-500/50 text-red-200";
  if (light === "Fragile") return "border-orange-400/50 text-orange-200";
  if (light === "Developing") return "border-yellow-400/50 text-yellow-100";
  return "border-green-400/50 text-green-100";
}

export function ScoreCard({ title, score, trafficLight, note }: { title: string; score: number; trafficLight: TrafficLight; note?: string }) {
  return (
    <div className={`card ${colorFor(trafficLight)}`}>
      <div className="text-sm uppercase tracking-[0.2em] text-paper/60">{title}</div>
      <div className="mt-3 flex items-end justify-between">
        <div className="font-serif text-6xl">{score}</div>
        <div className="badge">{trafficLight}</div>
      </div>
      {note ? <p className="mt-4 text-sm leading-6 text-paper/70">{note}</p> : null}
    </div>
  );
}
